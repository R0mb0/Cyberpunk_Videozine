;
; This program is bootloaded to a 68HC11 processor in order to allow data to
; be written to the EEPROM. Uses DAsm's RAS (Random Access Segment) format.
; Assumes all addresses you would want to load to are EEPROM, so be forewarned.
;
; Ron Menelli (12/10/91)
; Written for the DAsm assembler for the Amiga
; To be used in conjunction with dload.c
;

    PROCESSOR   68HC11

    ORG         $0000

;
; Serial port registers
;

BAUD    EQU     $102B
SCCR1   EQU     $102C
SCCR2   EQU     $102D
SCSR    EQU     $102E
SCDR    EQU     $102F

;
; EEPROM control registers
;

BPROT   EQU     $1035
PPROG   EQU     $103B

JUNK:

    NOP                         ; Junk for avoiding stupid download errors
    NOP                         ; when the first character or two is messed up.
    NOP
    NOP

INIT:

    SEI                         ; Turn interrupts off!

    ;
    ; Allow EEPROM writes in HC811E2 (except to CONFIG)
    ;

    LDAA    #%00010000
    STAA    BPROT

    ;
    ; Set up serial port (assumes that SCCR1,2 and BAUD are set by bootloader)
    ;

    LDS     #$00FF              ; Load stack pointer

WAITFF:

    BSR     GETBYTE             ; Get next byte from serial
    CMPA    #$FF                ; Is it $FF?
    BNE     WAITFF              ; No - loop back

GETADDR:

    BSR     GETBYTE             ; Get low byte of address
    TAB
    BSR     GETBYTE             ; Get high byte of address

    CPD     #0                  ; If address = 0 (definitely not EEPROM!), quit
    BEQ     QUIT

    XGDX                        ; Address now in X

    BSR     GETBYTE             ; Get low byte of count
    TAB
    BSR     GETBYTE             ; Get high byte of count
    XGDY                        ; Count now in Y

DOBYTE:

    BSR     GETBYTE             ; Get next byte
    
    LDAB    #$16                ; Set to erase a byte of EEPROM
    STAB    PPROG
    STAB    0,X
    LDAB    #$17
    STAB    PPROG
    BSR     DLY10               ; Wait 10ms
    CLR     PPROG

    LDAB    #$02                ; Set to program a byte of EEPROM
    STAB    PPROG
    STAA    0,X
    LDAB    #$03
    STAB    PPROG
    BSR     DLY10
    CLR     PPROG

    INX                         ; Increment program address
    DEY                         ; Decrement count
    BNE     DOBYTE              ; Not done - do another byte
    BRA     GETADDR             ; Done - try for another hunk

QUIT:

    BRA     QUIT                ; Just die


GETBYTE:

    LDAA    SCSR                ; Check RDRF
    ANDA    #%00100000
    BEQ     GETBYTE             ; Branch if not set (no character)
    LDAA    SCDR                ; Get character
    RTS


DLY10:

    PSHX                        ; Delay loop of about 10ms @ 8 MHz
    LDX     #$0D06

DLOOP:

    DEX
    BNE     DLOOP
    PULX
    RTS

    ORG     $00FF               ; Fake a 256 byte length for the downloader

    dc.b    0

