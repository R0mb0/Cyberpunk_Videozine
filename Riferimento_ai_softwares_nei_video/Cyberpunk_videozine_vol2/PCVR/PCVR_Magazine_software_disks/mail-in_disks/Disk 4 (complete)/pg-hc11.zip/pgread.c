/*
 * pgread.c - Receives and displays Power Glove data from the serial port
 *
 *            Amiga Version (Lattice C V5.10)
 *
 *            By: Ron Menelli (1/12/92)
 *
 */

#include <exec/types.h>
#include <devices/serial.h>
#include <devices/timer.h>
#include <intuition/intuition.h>
#include <intuition/intuitionbase.h>
#include <proto/exec.h>
#include <proto/intuition.h>
#include <proto/graphics.h>
#include <stdio.h>
#include <string.h>
#include <fcntl.h>

struct MsgPort  *SerialMP;
struct IOExtSer *SerialIO;

struct Window   *win;
struct Screen   *scr;
struct ViewPort *vp;
struct RastPort *rp;

extern struct IntuitionBase *IntuitionBase;
extern struct GfxBase       *GfxBase;

/*
 * Color definitions
 */

#define BKGND   0
#define RED     1
#define BLUE    2
#define BLACK   3

/*
 * Screen and Window definitions
 */

struct  NewScreen   ns = {
    0, 0,           /* start pos */
    640, 400, 2,    /* end pos, depth */
    BKGND, BLACK,   /* detail, block */
    HIRES|LACE,     /* Hires, interlaced */
    CUSTOMSCREEN,   /* like it says... */
    NULL,           /* default font */
    NULL,           /* no title */
    NULL            /* no gadgets */
};

struct  NewWindow   nw = {
    0, 0,           /* start pos */
    640, 400,       /* end pos */
    BKGND, BLACK,   /* detail, block */
    VANILLAKEY,     /* catch keypresses */
    ACTIVATE|BORDERLESS|SMART_REFRESH|NOCAREREFRESH,
                    /* window flags */
    NULL,           /* no gadgets */
    NULL,           /* default checkmark */
    NULL,           /* window title */
    NULL,           /* screen pointer (not set yet) */
    NULL,           /* no superbitmap */
    640, 400, 640, 400,
                    /* min, max sizes */
    CUSTOMSCREEN    /* like it says... */
};

void open_serial(void)
{
    int err;

    /*
     * Open serial device
     */

    if (SerialMP = CreatePort(0,0) )
    {
        if (SerialIO = (struct IOExtSer *) CreateExtIO(SerialMP,sizeof(struct IOExtSer)))
        {
            SerialIO->io_SerFlags = SERF_XDISABLED|SERF_SHARED;
            if (OpenDevice("serial.device",0,(struct IORequest *)SerialIO,0))
            {
                printf(" *** Error: can't open serial device.\n\n");
                exit (100);
            }

            SerialIO->IOSer.io_Command = SDCMD_SETPARAMS;
            SerialIO->io_SerFlags |= SERF_XDISABLED|SERF_SHARED;
            SerialIO->io_Baud = 9600L;
            SerialIO->io_ReadLen = 8;
            SerialIO->io_WriteLen = 8;
            SerialIO->io_StopBits = 1;
            if (err = DoIO((struct IORequest *)SerialIO))
            {
                printf(" *** Error: can't change serial params (#%d).\n\n",err);
                exit (100);
            }
        }
    }
}

int close_all(void)
{
    /*
     * Close serial device
     */

    if (SerialIO)
    {
        AbortIO((struct IORequest *)SerialIO);
        WaitIO((struct IORequest *)SerialIO);
        CloseDevice((struct IORequest *)SerialIO);
    }

    if (SerialMP) DeletePort(SerialMP);
    if (SerialIO) DeleteExtIO((struct IORequest *)SerialIO);

    /*
     * Close window and screen
     */

    if (win) CloseWindow(win);
    if (scr) CloseScreen(scr);
    if (IntuitionBase) CloseLibrary((struct Library *)IntuitionBase);
    if (GfxBase) CloseLibrary(GfxBase);

    return(0);
}

void open_window(void)
{
    GfxBase = OpenLibrary("graphics.library",0);
    if (GfxBase == NULL)
    {
        printf(" *** Can't open graphics.library.\n\n");
        exit(100);
    }

    IntuitionBase = (struct IntuitionBase *)OpenLibrary("intuition.library",0);
    if (IntuitionBase == NULL)
    {
        printf(" *** Can't open intuition.library.\n\n");
        CloseLibrary(GfxBase);
        exit(100);
    }

    scr = (struct Screen *)OpenScreen(&ns);
    if(scr == NULL)
    {
        printf(" *** Can't open custom screen.\n\n");
        close_all();
        exit (100);
    }

    vp = &scr->ViewPort;
    SetRGB4(vp, BKGND, 10, 10, 10);
    SetRGB4(vp, RED, 10, 0, 0);
    SetRGB4(vp, BLUE, 0, 0, 10);
    SetRGB4(vp, BLACK, 0, 0, 0);
    
    nw.Screen = scr;

    win = (struct Window *)OpenWindow(&nw);
    if (win == NULL)
    {
        printf(" *** Can't open window.\n\n");
        close_all();
        exit (100);
    }

    rp = win->RPort;
    SetAPen(rp, BLACK);
}

void get_glove(char *buffer)
{
    buffer[0] = '\0';

    while (buffer[0] != '\xA0')
    {
        SerialIO->IOSer.io_Command = CMD_READ;
        SerialIO->IOSer.io_Length = 1;
        SerialIO->IOSer.io_Data = (APTR)(buffer);
        DoIO((struct IORequest *)SerialIO);
    }
    SerialIO->IOSer.io_Command = CMD_READ;
    SerialIO->IOSer.io_Length = 6;
    SerialIO->IOSer.io_Data = (APTR)(&(buffer[1]));
    DoIO((struct IORequest *)SerialIO);
}

int oldx = 0;
int oldy = 0;
int osize = 0;

void render_box(int x, int y, int z)
{
    int     sx, sy, size;

    SetAPen(rp, BKGND);
    RectFill(rp, oldx-osize, oldy-osize, oldx+osize, oldy+osize);

    oldx = sx = ((x + 128) * 640) / 256;
    oldy = sy = ((256 - (y + 128)) * 400) / 256;
    osize = size = z + 30;
    if (size < 0) size = 0;

    SetAPen(rp, BLACK);
    Move(rp, sx-size, sy-size);
    Draw(rp, sx+size, sy-size);
    Draw(rp, sx+size, sy+size);
    Draw(rp, sx-size, sy+size);
    Draw(rp, sx-size, sy-size);
    Draw(rp, sx+size, sy+size);
    Move(rp, sx+size, sy-size);
    Draw(rp, sx-size, sy+size);
}

void main(int argc, char *argv[])
{
    char    buffer[7], outbuf[80];

    SerialIO = SerialMP = NULL;
    win = scr = NULL;

    open_window();

    open_serial();

    onexit(close_all);

    /*
     * Send character for continuous mode
     */
    buffer[0] = 'C';
    SerialIO->IOSer.io_Command = CMD_WRITE;
    SerialIO->IOSer.io_Length = 1;
    SerialIO->IOSer.io_Data = (APTR)(buffer);
    DoIO((struct IORequest *)SerialIO);

	/*
	 * Repeat main loop until "Start" is pressed
	 */
    buffer[6] = '\xFF';
    while (buffer[6] != '\x82')
    {
        get_glove(buffer);
		/*
		 * Set deglitch/no deglitch based on A/B buttons
		 */
		if (buffer[6] == '\x0A')
		{
            buffer[0] = '+';
            SerialIO->IOSer.io_Command = CMD_WRITE;
            SerialIO->IOSer.io_Length = 1;
            SerialIO->IOSer.io_Data = (APTR)(buffer);
            DoIO((struct IORequest *)SerialIO);
        }
		else if (buffer[6] == '\x0B')
		{
            buffer[0] = '-';
            SerialIO->IOSer.io_Command = CMD_WRITE;
            SerialIO->IOSer.io_Length = 1;
            SerialIO->IOSer.io_Data = (APTR)(buffer);
            DoIO((struct IORequest *)SerialIO);
		}

		/*
		 * Print data at the top of the screen
		 */
		sprintf(outbuf,"%4d  %4d  %4d  %4d  %02X  %02X",(int)buffer[1],
			(int)buffer[2],(int)buffer[3],(int)buffer[4],
			(int)((unsigned char)buffer[5]),(int)((unsigned char)buffer[6]));
        SetAPen(rp,BKGND);
        RectFill(rp,0,0,640,10);
        SetAPen(rp,BLACK);
        Move(rp,0,0);
        Text(rp,outbuf,strlen(outbuf));

        render_box((int)(buffer[1]),(int)(buffer[2]),(int)(buffer[3]));
    }

    close_all();

}
