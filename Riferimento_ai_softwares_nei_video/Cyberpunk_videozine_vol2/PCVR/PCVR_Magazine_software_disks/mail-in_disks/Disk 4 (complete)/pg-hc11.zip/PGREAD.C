/*
 * pgread.c - Receives Power Glove data from the serial port
 *
 * MS-DOS Version (Turbo C V2.0)
 *
 * By: Ron Menelli (1/10/92)
 *
 */

#include <stdio.h>
#include <string.h>
#include <dos.h>
#include <graphics.h>

int         com_port;
long int    maxx, maxy;

void open_serial(void)
{
    union REGS  inregs, outregs;

    /*
	 * Open serial device
	 * 9600 baud, 8 data bits, no parity, 1 stop bit
	 */
	inregs.h.ah = (unsigned char) 0;
	inregs.h.al = (unsigned char) 0xE3;
	inregs.x.dx = com_port;
	int86(0x14, &inregs, &outregs);
}

void close_all(void) 
{
    /*
     * Close serial device (not needed)
     */

    /*
     * Close window and screen
     */
    closegraph();
}

void open_window(void)
{
    int gfxdriver = DETECT;
    int gfxresult;

    initgraph(&gfxdriver, NULL, "C:\\TC\\BGI");
    if ((gfxresult = graphresult()) != 0)
    {
        close_all();
        printf("    *** %s.\n\n", grapherrormsg(gfxresult));
        exit(100);
    }
    maxx = getmaxx();
    maxy = getmaxy();
}

void get_glove(char *buffer)
{
    union REGS  inregs, outregs;
    int         i;

    buffer[0] = '\0';

    while (buffer[0] != '\xA0')
    {
        inregs.x.dx = com_port;
        inregs.h.ah = '\x02';
        int86(0x14, &inregs, &outregs);
        buffer[0] = (char) outregs.h.al;
    }

    for (i = 1; i < 7; i++)
    {
        inregs.x.dx = com_port;
        inregs.h.ah = '\x02';
        int86(0x14, &inregs, &outregs);
        buffer[i] = (char) outregs.h.al;
        if (outregs.h.ah != '\x00')
        {
            close_all();
            printf("\n\n    *** Serial read error!!!\n\n");
            exit(100);
        }
    }
}

long int    oldx = 0;
long int    oldy = 0;
long int    osize = 0;

void render_box(long int x, long int y, long int z)
{
    long int    sx, sy, size;

    setfillstyle(EMPTY_FILL, 0);
    bar(oldx - osize, oldy - osize, oldx + osize, oldy + osize);

    oldx = sx = ((x + 128) * maxx) / 256;
    oldy = sy = ((256 - (y + 128)) * maxy) / 256;
    osize = size = z + 30;
    if (size < 0) size = 0;

    setcolor(getmaxcolor());
    moveto(sx - size, sy - size);
    lineto(sx + size, sy - size);
    lineto(sx + size, sy + size);
    lineto(sx - size, sy + size);
    lineto(sx - size, sy - size);
    lineto(sx + size, sy + size);
    moveto(sx + size, sy - size);
    lineto(sx - size, sy + size);
}

void main(int argc, char *argv[])
{
    char        buffer[7], outbuf[80];
    union REGS  inregs, outregs;

    if (argc != 2)
    {
        printf("\n\nUsage: pgread <com_port>\n\n");
        exit(0);
    }
    else
    {
        com_port = atoi(argv[1]) - 1;
    }

    open_serial();
    open_window();

    /*
     * Send character for continuous mode
     */
    inregs.x.dx = com_port;
    inregs.h.ah = 1;
    inregs.h.al = 'C';
    int86(0x14, &inregs, &outregs);

    /*
     * Repeat main loop until "Start" is pressed
     */
    buffer[6] = '\xFF';
    while (buffer[6] != '\x82')
    {
        get_glove(buffer);

        /*
         * Set deglitch/no deglitch based on A/B buttons
         */
        if (buffer[6] == '\x0A')
        {
            inregs.x.dx = com_port;
            inregs.h.ah = 1;
            inregs.h.al = '+';
            int86(0x14, &inregs, &outregs);
        }
        else if (buffer[6] == '\x0B')
        {
            inregs.x.dx = com_port;
            inregs.h.ah = 1;
            inregs.h.al = '-';
            int86(0x14, &inregs, &outregs);
        }

        /*
         * Print data at the top of the screen
         */
        sprintf(outbuf, "%4d  %4d  %4d  %4d  %02X  %02X", (int) buffer[1],
            (int) buffer[2], (int) buffer[3], (int) buffer[4], 
            (int) ((unsigned char) buffer[5]),
                        (int) ((unsigned char) buffer[6]));
        setfillstyle(EMPTY_FILL, 0);

        bar(0, 0, maxx, 9);
        outtextxy(0, 0, outbuf);

        /*
         * Draw the box
         */
        render_box((long int) (buffer[1]), (long int) (buffer[2]), 
               (long int) (buffer[3]));
    }

    close_all();
}

