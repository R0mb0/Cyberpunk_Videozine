/*
 * dload.c - Sends a binary file to a 68HC11 processor in bootstrap mode
 *
 *           MS-DOS Version (Turbo C++ V2.0)
 *
 *           By: Ron Menelli  (1/7/92)
 *
 */

#include <stdio.h>
#include <fcntl.h>
#include <dos.h>
#include <io.h>

int     com_port;
char    *buffer;

void open_serial(void)
{
    union REGS inregs, outregs;

    /*
     * Open serial device
     * 1200 baud, 8 data bits, no parity, 1 stop bit
     */
    inregs.h.ah = (unsigned char) 0;
    inregs.h.al = (unsigned char) 0x83;
    inregs.x.dx = com_port;
    int86(0x14,&inregs,&outregs);
}

void send_file(char *fname)
{
    char        writebuf[257];
    int         fh, i;
    union REGS  inregs, outregs;

    /*
     * Load the given 256 byte boot file into memory
     */

    writebuf[0] = (char) 0xFF;

	if ((fh = open(fname,(O_RDONLY|O_BINARY),0)) >= 0)
	{
		i = read(fh,&(writebuf[1]),256);
		if (i != 256)
		{
			printf(" *** Warning: Only loaded %d bytes from the file.\n\n",i);
        }
        close (fh);
    }
    else
    {
        printf(" *** Error: couldn't open data file %s.\n\n",fname);
        free((void *)buffer);
        exit (100);
    }

    /*
     * No handshake mode implemented yet, just send it!
     */
    for (i = 0; i < 257; i++)
    {
        inregs.x.dx = com_port;
        inregs.h.ah = 1;
        inregs.h.al = writebuf[i];
        int86(0x14,&inregs,&outregs);
    }
}

void main(int argc, char *argv[])
{
    union REGS  inregs, outregs;
    char        filename[80];
    int         i, j, fh, eeprom;

    buffer = (char *) calloc(1,4100);
    if (buffer == NULL)
    {
        printf(" *** Error: Couldn't allocate memory!\n\n");
        exit (100);
    }

    printf("\n68HC11 Downloader V1.0 - RJM\n");

    /*
     * Check if help needed
     */

    if ((argc == 1) || (*(argv[1]) == '?'))
    {
        printf("\n Usage: dload [-c <1,2,3,4>] [-e] file\n\n");
        free((void *)buffer);
        exit (10);
    }

    /*
     * Set defaults
     */

    filename[0] = '\0';
    com_port = 0;
    eeprom = 0;

    /*
     * Parse arguments
     */

    for (i = 1; i < argc; i++)
    {
        if (*(argv[i]) == '-')
        {
            switch ((argv[i])[1])
            {
                case 'c':

                    if ((argc-1) > i)
                    {
						com_port = atoi(argv[++i]) - 1;
						if ((com_port < 0) || (com_port > 3))
						{
							printf(" *** Error: COM port must be from 1 to 4.\n\n");
							free((void *)buffer);
							exit (100);
						}
					}
					else
					{
						printf(" *** Error: COM port number expected.\n\n");
						free((void *)buffer);
						exit (100);
					}
					break;

                case 'e':

                    eeprom = 1;
                    break;

                default:

                    printf(" *** Error: invalid option %s.\n\n",argv[i]);
                    free((void *)buffer);
                    exit (100);
                    break;
            }
        }
        else
        {
            if (filename[0] == '\0')
            {
                strcpy(filename, argv[i]);
            }
            else
            {
                printf(" *** Error: filename supplied twice.\n\n");
                free((void *)buffer);
                exit (100);
                break;
            }
        }

    }

    /*
     * Print out options
     */

    printf("Running: COM port = %d, file = %s\n",com_port+1,filename);
    printf("         options = ");
    if (eeprom) printf("-e ");
    printf("\n");

    open_serial();

    if (!eeprom)
    {
        /*
         * Send the data file
         */
        send_file(filename);
    }
    else  /* eeprom == TRUE */
    {
        /*
         * Send the EEPROM loader file
         */
        send_file("eeload.o");

        /*
         * Send the file to be sent to EEPROM
         * File must <= 4096 bytes long
         */

        buffer[0] = (char) 0xFF;
		if ((fh = open(filename,(O_RDONLY|O_BINARY),0)) >= 0)
        {
            printf(" Sending to EEPROM.\n");
            i = read(fh,&(buffer[1]),4096);
            if (i > 0)
            {
                /*
                 * Add the stop flag to the end of the buffer
                 */
                buffer[++i] = '\0';
                buffer[++i] = '\0';
                for (j = 0; j <= i; j++)
                {
                    inregs.x.dx = com_port;
                    inregs.h.ah = 1;
                    inregs.h.al = buffer[j];
                    int86(0x14,&inregs,&outregs);

                    /*
                     * Heinous delay to make sure that the HC11 can keep up
                     * during EEPROM programming.
                     */

					delay(30);
				}
			}
			else
			{
				printf(" *** Error: file read error!\n\n");
				free((void *)buffer);
				exit (100);
			}
		}
		else
		{
			printf(" *** Error: couldn't open data file %s.\n\n",filename);
			free((void *)buffer);
			exit (100);
		}
	}

    printf(" File sent.\n\n");
    free((void *)buffer);
    exit (0);
}

