/*
 * dload.c - Sends a binary file to a 68HC11 processor in bootstrap mode
 *
 *           Amiga Version (Lattice C V5.10)
 *
 *           By: Ron Menelli  (1/7/92)
 *
 */

#include <exec/types.h>
#include <exec/memory.h>
#include <devices/serial.h>
#include <devices/timer.h>
#include <proto/exec.h>
#include <stdio.h>
#include <string.h>
#include <fcntl.h>

struct MsgPort  *SerialMP;
struct IOExtSer *SerialIO;

char            devname[80], *writebuf;
ULONG           devnum;

void open_serial(void)
{
    int err;

    /*
     * Open serial device
     */

    if (SerialMP = CreatePort(0,0) )
    {
        if (SerialIO = (struct IOExtSer *) CreateExtIO(SerialMP,sizeof(struct IOExtSer)))
        {
            SerialIO->io_SerFlags = SERF_XDISABLED|SERF_SHARED;
            if (OpenDevice(devname,devnum,(struct IORequest *)SerialIO,0))
            {
                printf(" *** Error: can't open serial device.\n\n");
                exit (100);
            }

            SerialIO->IOSer.io_Command = SDCMD_SETPARAMS;
            SerialIO->io_SerFlags |= SERF_XDISABLED|SERF_SHARED;
            SerialIO->io_Baud = 1200L;
            SerialIO->io_ReadLen = 8;
            SerialIO->io_WriteLen = 8;
            SerialIO->io_StopBits = 1;
            if (err = DoIO((struct IORequest *)SerialIO))
            {
                printf(" *** Error: can't change serial params (#%d).\n\n",err);
                exit (100);
            }
        }
    }
}

int TDelay(secs, microsec)
ULONG   secs, microsec;
{
    struct  timeval     tv;
    struct  timerequest *tr;
    LONG    error;
    struct  MsgPort     *timerport;
    
    timerport = (struct MsgPort *) CreatePort(NULL,0);
    if (timerport == NULL) return(-1);

    tr = (struct timerequest *)
         CreateExtIO(timerport, sizeof(struct timerequest));
    if (tr == NULL)
    {
        DeletePort(timerport);
        return(-1);
    }

    error = OpenDevice("timer.device",UNIT_MICROHZ,(struct IORequest *) tr, 0L);
    if (error != 0)
    {
        DeleteExtIO((struct IORequest *) tr);
        DeletePort(timerport);
        return(-1);
    }

    tr->tr_node.io_Command = TR_ADDREQUEST;
    tv.tv_secs = secs;
    tv.tv_micro = microsec;
    tr->tr_time = tv;

    DoIO((struct IORequest *) tr);

    DeletePort(timerport);
    CloseDevice((struct IORequest *) tr);
    DeleteExtIO((struct IORequest *) tr);

    return(0);
}

int close_serial(void)
{
    /*
     * Close serial device
     */

    AbortIO((struct IORequest *)SerialIO);
    WaitIO((struct IORequest *)SerialIO);
    CloseDevice((struct IORequest *)SerialIO);

    if (SerialMP) DeletePort(SerialMP);
    if (SerialIO) DeleteExtIO((struct IORequest *)SerialIO);

    FreeMem(writebuf,4100);

    return (0);
}

void send_file(char *fname)
{
    char    writebuf[257];
    int     fh, i;

    /*
     * Load the given file
     */

    writebuf[0] = (char) 0xFF;

    if ((fh = open(fname,O_RDONLY,0)) >= 0)
    {
        i = read(fh,&(writebuf[1]),256);
        if (i != 256)
        {
            printf(" *** Warning: Only loaded %d bytes from the file.\n\n",i);
        }
        close (fh);
    }
    else
    {
        printf(" *** Error: couldn't open data file %s.\n\n",fname);
        exit (100);
    }

    /*
     * No handshake mode implemented yet, just send it!
     */
    SerialIO->IOSer.io_Command = CMD_WRITE;
    SerialIO->IOSer.io_Length = 257;
    SerialIO->IOSer.io_Data = (APTR)writebuf;
    DoIO((struct IORequest *)SerialIO);
}

void main(int argc, char *argv[])
{
    char    filename[80];
    BOOL    eeprom;
    int     i, j, fh;

    writebuf = (char *) AllocMem(4100,MEMF_CLEAR);
    if (writebuf == NULL)
    {
        printf(" *** Error: Couldn't allocate memory!\n\n");
        exit(100);
    }

    printf("\n68HC11 Downloader V1.0 - RJM\n");

    /*
     * Check if help needed
     */

    if ((argc == 1) || (*(argv[1]) == '?'))
    {
        printf("\n Usage: dload [-d device_name] [-u unit_num] [-e] file\n\n");
        FreeMem(writebuf,4100);
        exit (5);
    }

    /*
     * Set defaults
     */

    strcpy(devname, "serial.device");
    filename[0] = '\0';
    devnum = 0L;
    eeprom = FALSE;

    /*
     * Parse arguments
     */

    for (i = 1; i < argc; i++)
    {

        if (*(argv[i]) == '-')
        {
            switch ((argv[i])[1])
            {
                case 'd':

                    if ((argc-1) > i)
                    {
                        strcpy(devname, argv[++i]);
                    }
                    else
                    {
                        printf(" *** Error: device name expected.\n\n");
                        FreeMem(writebuf,4100);
                        exit (100);
                    }
                    break;

                case 'e':

                    eeprom = TRUE;
                    break;

                case 'u':

                    if ((argc-1) > i)
                    {
                        devnum = strtol(argv[++i],NULL,10);
                    }
                    else
                    {
                        printf(" *** Error: unit number expected.\n\n");
                        FreeMem(writebuf,4100);
                        exit (100);
                    }
                    break;

                default:

                    printf(" *** Error: invalid option %s.\n\n",argv[i]);
                    FreeMem(writebuf,4100);
                    exit (100);
                    break;
            }
        }
        else
        {
            if (filename[0] == '\0')
            {
                strcpy(filename, argv[i]);
            }
            else
            {
                printf(" *** Error: filename supplied twice.\n\n");
                FreeMem(writebuf,4100);
                exit (100);
                break;
            }
        }
        
    }

    /*
     * Print out options
     */

    printf("Running: device  = %s, unit = %lu, file = %s\n",devname,devnum,filename);
    printf("         options = ");
    if (eeprom == TRUE) printf("-e ");
    printf("\n");

    open_serial();

    onexit(close_serial);

    if (eeprom == FALSE)
    {
        /*
         * Send the data file
         */
        send_file(filename);
    }
    else  /* eeprom == TRUE */
    {
        /*
         * Send the EEPROM loader file
         */
        send_file("eeload.o");

        /*
         * Send the file to be sent to EEPROM
         */

        writebuf[0] = (char) 0xFF;
        if ((fh = open(filename,O_RDONLY,0)) >= 0)
        {
            printf(" Sending to EEPROM.\n");
            i = read(fh,&(writebuf[1]),4096);
            if (i > 0)
            {
                writebuf[++i] = '\0';
                writebuf[++i] = '\0';
                for (j = 0; j <= i; j++)
                {
                    SerialIO->IOSer.io_Command = CMD_WRITE;
                    SerialIO->IOSer.io_Length = 1;
                    SerialIO->IOSer.io_Data = (APTR)(&(writebuf[j]));
                    DoIO((struct IORequest *)SerialIO);

                    /*
                     * Heinous delay to make sure that the HC11 can keep up
                     * during EEPROM programming.
                     */

                    if (TDelay(0L,20000L) != 0)
                    {
                        printf(" *** Error: bad timer call.\n\n");
                        exit(100);
                    }
                }
            }
            else
            {
                printf(" *** Error: file read error!\n\n");
                exit(100);
            }
        }
        else
        {
            printf(" *** Error: couldn't open data file %s.\n\n",filename);
            exit (100);
        }
    }

    printf(" File sent.\n\n");
    exit (0);
}
