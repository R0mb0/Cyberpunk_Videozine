#include <stdio.h>
#include "glove.h"

void main()
	{
	glove_data glov;
	glove_init(IHIRES, NULL);
	printf("\n\n");
	while(!kbhit())
		if (glove_ready()) {
			glove_read(&glov);
			printf("%+4d %+4d %+4d %+4d %02.2X %02.2X \r",
				glov.x, glov.y, glov.z, glov.rot,
				glov.fingers & 0xFF, glov.keys & 0xFF);
			}
		else
			glove_delay();
	getch();
	glove_quit();
	}
