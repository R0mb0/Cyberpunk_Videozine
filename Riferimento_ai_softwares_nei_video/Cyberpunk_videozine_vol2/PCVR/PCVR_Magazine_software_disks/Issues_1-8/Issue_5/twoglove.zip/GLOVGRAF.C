/* Graphics-mode demonstration code for PowerGlove */

/* Written by Dave Stampe, Modified by Bernie Roehl, October 1991 */

#include <dos.h>
#include <bios.h>
#include <stdio.h>
#include <conio.h>
#include <graphics.h>
#include "glove.h"

int gdriver = DETECT;		/* for graphics plot and cursor */
int gmode = VGAHI;

void main()
	{
	glove_data glov;		/* glove data */
	void drawthing(), drawp();

	initgraph(&gdriver, &gmode, "");
	if (graphresult() < 0) {
		printf("could not initialize graphics\n");
		exit(1);
		}
	cleardevice();
	glove_init(IHIRES, NULL);
	while(!kbhit())
		if (glove_ready()) {
			if (glove_read(&glov))
				drawthing(&glov);  		/* animate glove cursor */
			}
		else
			glove_delay();
	getch();			/* exit when keyboard hit */
	glove_quit();
	closegraph();
	}

static void drawit(glove_data *g)		/* draw/erase box cursor */
	{
	int x = 320+2*(g->x);		/* compute X,Y center */
	int y = 240-2*(g->y);
	int z = 30+(g->z);		/* size prop. to Z */

	rectangle(x-z,y-z,x+z,y+z);
	}

static glove_data oldbuf;	/* used to store old state for drawing */

static int drawn = 0;		/* set if cursor to be erased */

void drawthing(glove_data *g)	/* draw square cursor */
	{
	if (g->keys == 2) return;		/* hold down "2" to stop drawing */

	if(drawn)			/* erase old box */
		{
		setcolor(0);
		drawit(&oldbuf);
		}

	setcolor(15);			/* draw new box */
	drawit(g);
	drawn = 1;

	oldbuf = *g;
	}

static int xx = 0;           		/* plot position */

void drawp(glove_data *g)	/* plot X,Y data to test smoothing */
	{
	if(g->keys==4) 	/* restart at left edge if "4" pressed */
		{
		cleardevice();
		xx=0;
		}

	setcolor(0);
	line(xx,0,xx,479);
	line(xx+1,0,xx+1,479);
	setcolor(15);
	line(xx,240-2*g->x,xx+1,240-2*g->x);
	setcolor(14);
	line(xx+1,240-2*g->y,xx+2,240-2*g->y);
	xx++;
	xx++;
	if(xx > 639) xx = 0;
	}

