/* This program is copyrighted by Gradecki Publishing */
/* Some of the functions are copyrighted by Dave Stampe */
/* This program requires Release 3.01 of Rend386 to compile */

/* For this program, the following keys are available:

    Q,q : Quit the program
*/

#include <stdio.h>
#include <stdlib.h>
#include <dos.h>
#include "rend386.h"
#include "userint.h"
#include "plg.h"

/* Global variables */
static VIEW our_view =  {       0,0,-10000,
                                0,0,0,
                                9*65536L,
                                1000,15000,-5000,
                                0,319,0,199,
                                1,100000,
                                1/1.25*65535L,
                                0
                        };

static VIEW     *current_view;
static int      visual_page = 0,
                shifted = 0;
extern int      screen_clear_color;
int             execution = 1,
                redraw = 1;
unsigned char   panmiddle,
                pancurrent,
                tiltmiddle,
                tiltcurrent;
SEGMENT         *hand_array[14], *hand_segment;
static OBJLIST  *objlist;


static l_x = 1000, l_y = 15000, l_z = -5000; /* light source */

static long center_d = 10000;
static long center_x = 0;
static long center_y = 0;
static long center_z = 0;
static long latitude = 0;
static long longitude = 0;
static long center_roll = 0;



void closeall(){
  exit_graphics();
  reset_render();
  exit(0);
}

/* This function is from Rend386 demo2.c program */
unsigned getkey(){
  unsigned c;
  union REGS regs;

  regs.h.ah = 2;
  int86(0x16, &regs,&regs );
  shifted = (regs.h.al & 3);
  if ((c=bioskey(0)) & 0xff) c &= 0xff;
  else if ( shifted ) c |= 1;
  return c;
}
           
/* Handle any user keys.  Only quit is handled in this program 'q' or 'Q' */
void handle_key ( unsigned int c ){
FILE *infile;

  switch ( c ) {
    case 'q':
    case 'Q':popmsg ( "Do you wish to quit? (y/n)" );
	     if ( toupper(getkey())== 'Y' ) execution = 0;
	     else redraw = 1;
	     break;
           
    case 't': rel_move_segment ( hand_segment, 50, 0, 0 );
	      update_segment ( hand_segment );
	      redraw = 1;
	      break;

    case 'T': rel_move_segment ( hand_segment , -50, 0, 0 );
	      update_segment ( hand_segment );
	      redraw = 1;
	      break;

    case 'x': abs_rot_segment ( hand_segment, 45*65536L, 0, 0 );
	      update_segment ( hand_segment );
	      redraw = 1;
	      break;

    case 'X': rel_rot_segment ( hand_segment, -45*65536L, 0, 0 );
	      update_segment ( hand_segment );
	      redraw = 1;
	      break;

    case 'f': rel_move_segment ( hand_array[2], 0, 50, 0 );
	      update_segment ( hand_segment );
	      redraw = 1;
	      break;

    case 'F': rel_move_segment ( hand_array[2], 0, -50, 0 );
	      update_segment ( hand_segment );
	      redraw = 1;
          break;
 }}
  
/* Do a page switch */
void new_display(){

  if ( ++visual_page > 2 ) visual_page = 0;
  clear_display ( visual_page );
  set_drawpage ( visual_page );
  render ( objlist, current_view );
  set_vidpage( visual_page, 0 );
  redraw = 0;
}




void polar_compute()
{
	MATRIX m,n;

	long x = 0;
	long y = 0;
	long z = -center_d;

	make_matrix(m,longitude,latitude,center_roll,0,0,0);
	inverse_matrix(m,n);

	matrix_point(n,&x,&y,&z);
	current_view->ex = x + center_x;
	current_view->ey = y + center_y;
	current_view->ez = z + center_z;

/*    x = l_x;  y = l_y;  z = l_z;
	matrix_point(n,&x,&y,&z);
    current_view->lx = x;
	current_view->ly = y;
    current_view->lz = z;  */


    current_view->pan = latitude;
	current_view->tilt = longitude;
	current_view->roll = center_roll;
}




void process_tilt ( unsigned char value )
{

  longitude = (value-tiltmiddle) * 2 * 65536L;
  polar_compute();
  compute_view_factors ( current_view );
  tiltcurrent = value;
  redraw = 1;
}

void process_pan ( unsigned char value )
{

   latitude = (value-panmiddle)*2*65536L;
   polar_compute();
   compute_view_factors ( current_view );
   pancurrent = value;
   redraw = 1;
}


void main_loop(){

  unsigned char  value;
  while ( execution )
    {
      if ( bioskey(1) ){handle_key (getkey());}
      if (redraw)  new_display();
      outportb ( 641,1 );
      delay (10);
      value = inportb(642);
      if ( abs(value-tiltcurrent) > 5 ) process_tilt(value);

      outportb ( 641,0 );
      delay (10);
      value = inportb(642);
      if ( abs(value-pancurrent) > 5 ) process_pan(value);

}}

void load_hand()
{   SEGMENT *readseg();
    FILE    *infile;

    if ((infile = fopen("hand.fig", "r")) == NULL ) { exit(1); }

    set_readseg_objlist ( objlist );
    set_readseg_seglist ( hand_array, 14 );
    if ((hand_segment = readseg ( infile, NULL )) == NULL ){exit(1);}
    else
      update_segment ( hand_segment );

    close ( infile );
}

main(){

  outportb ( 643, 137 );
  outportb ( 640, 0 );
  outportb ( 641, 0 );


/* Head tracker initialization */
  printf ( "Stand with your hand in an upright forward looking position\n" );
  printf ( "While I find the position of your head. (approx. 6 seconds)\n" );
  delay ( 5000 );
  outportb ( 641, 0 );
  delay ( 10 );
  panmiddle = inportb ( 642 );
  pancurrent = panmiddle;
  outportb ( 641, 1 );
  delay ( 10 );
  tiltmiddle = inportb ( 642 );
  tiltcurrent = tiltmiddle;
  printf ( "Thank You!" );


  current_view = &our_view;
  compute_view_factors ( current_view );

  setup_render();
  atexit(closeall);

  objlist = new_objlist();
  if (enter_graphics()) {
    fprintf ( stderr, "could not enter graphics mode\n\n");
    exit(1);
    }

  compute_view_factors ( current_view );
  set_colors();
  screen_clear_color = 0;

  load_hand();
  redraw = 1;
  main_loop();   /* start us off */
  delete_segment ( hand_segment, NULL );
}
