#include <stdio.h>
#include <stdlib.h>
#include <graphics.h>
#include <math.h>
#include <conio.h>
#include <dos.h>
#include "glove.h"

#define to_radians 0.017453292
#define rho 5000
#define theta 90.0
#define phi 180.0
#define screendist 1000.0

int screen_x = 640,
    screen_y = 480;

int screen_x2 = 320;
int screen_y2 = 240;



int va,vb,ve,vf,vg,vi,vj,vk,vl;



/* This is a basic point on the 3D screen */
struct point
       {
	int          x, y, z;
	int          oldx, oldy, oldz;
	int          ax, ay;
	struct point *next;
       };


/* This structure defines the four points that make up the polygon
   for the palm of the hand */
struct polygon
       {
	struct point   *points;
	struct polygon *next;
	int            color;
	int            line;
       };

struct object
	{
	  struct polygon *polygons;
	  int            number;
	};

struct matrix
	{
	  int m[4][4];
	};


struct matrix * identity ( struct matrix *m )
{

  int i,j;

  for (i=0;i<4;i++ )
  {
    for (j=0;j<4;j++)
    {
      m->m[i][j] = 0.0;
    }
  }

  m->m[0][0] = 1.0;
  m->m[1][1] = 1.0;
  m->m[2][2] = 1.0;
  m->m[3][3] = 1.0;

  return ( m );

}





void create_view_transformation()
{
  float sintheta, costheta, sinphi, cosphi;

  sintheta = sin(theta*to_radians);
  costheta = cos(theta*to_radians);
  sinphi = sin(phi*to_radians);
  cosphi = cos(phi*to_radians);

  va = -sintheta;
  vb = costheta;
  ve = -costheta*cosphi;
  vf = -sintheta*cosphi;
  vg = sinphi;
  vi = -costheta*sinphi;
  vj = -sintheta*sinphi;
  vk = -cosphi;
  vl = rho;
}



struct object * create_object ( struct object *obj )
{

  obj = (struct object *)malloc(sizeof (struct object));
  obj->polygons = NULL;
  obj->number   = 0;

  return (obj);

}


void release_object ( struct object *obj )
{
  struct polygon *p;
  struct point   *d;

  if ( obj->number > 0 )
  {
    while ( obj->polygons != NULL )
    {
      p = obj->polygons;
      obj->polygons = obj->polygons->next;
      while ( p->points != NULL )
      {
	d = p->points;
	p->points = p->points->next;
	free (d);
      }
      free (p);
    }
  }

  free (obj);

}



struct polygon * add_polygon ( struct object *obj, struct polygon *p, int line )
{

  p = (struct polygon *)malloc(sizeof(struct polygon));
  p->next = NULL;
  p->points = NULL;
  p->line = line;

  if ( obj->polygons == NULL )
  {
    obj->polygons = p;
  }
  else
  {
    p->next = obj->polygons;
    obj->polygons = p;
  }

  obj->number++;
  return ( p );
}


void proj ( struct point *p, int *sx, int *sy, struct matrix *mat )
{

   int xt, yt, zt,
	 xe, ye, ze,
	 xw, yw, zw;

   /* Apply current global Matrix (mat) */
   xt = p->x*mat->m[0][0] +
	p->y*mat->m[1][0] +
	p->z*mat->m[2][0] +
	     mat->m[3][0];

   yt = p->x*mat->m[0][1] +
	p->y*mat->m[1][1] +
	p->z*mat->m[2][1] +
	     mat->m[3][1];

   zt = p->x*mat->m[0][2] +
	p->y*mat->m[1][2] +
	p->z*mat->m[2][2] +
	     mat->m[3][2];

   xw = xt;
   yw = yt;
   zw = zt;

   /* Translate to view */
   xe = va*xw;                /* + vb*yw; */
   ye = /* ve*xw + vf* */      yw;       /*+ vg*zw; */
   ze = /* vi*xw + vj*yw + vk* */ zw + vl;

   /* Translate to perpective view */
   *sx = screendist * xe / ze;
   *sy = screendist * ye / ze;

}



void draw_object ( struct object *obj, struct matrix *mat, int color )
{

  struct polygon  *p;
  struct point *d;
  int x, y, x2, y2, *sx, *sy, *sx2, *sy2, svx, svy;

  setcolor ( color );
  sx = &x;
  sy = &y;
  sx2 = &x2;
  sy2 = &y2;

    p = obj->polygons;
    while ( p != NULL )
    {

      d = p->points;
      proj ( d, sx, sy, mat );
      svx = d->ax = x; 		       /* Save actual points for erase */
      svy = d->ay = y;
      d = d->next;

      while ( d != NULL )
      {
	proj(d, sx2, sy2, mat );
	d->ax = x2;			/* Save actual points for erase */
	d->ay = y2;
	line (screen_x2-x, screen_y2-y, screen_x2- x2, screen_y2 - y2 );

	d = d->next;
	x = x2;
	y = y2;
      }
      if ( p->line == 0 )
      {
	line ( screen_x2-x, screen_y2-y, screen_x2-svx, screen_y2-svy );
      }
      p = p->next;
    }
}




void erase_object ( struct object *obj )
{

  struct polygon  *p;
  struct point *d;
  int svx, svy, x, y;

  setcolor ( BLACK );
  p = obj->polygons;
  while ( p != NULL )
    {
      d = p->points;
      x = svx = d->ax;
      y = svy = d->ay;

      d = d->next;
      while ( d != NULL )
      {
	line ( screen_x2-x, screen_y2-y, screen_x2-d->ax, screen_y2-d->ay );
	x = d->ax;
	y = d->ay;
	d = d->next;
      }
      if ( p->line == 0 )
      {
	line ( screen_x2-x, screen_y2-y, screen_x2-svx, screen_y2-svy );
      }
      p = p->next;
    }
}




void add_vertex ( struct polygon *p, int x, int y, int z )
{
  struct point   *d, *temp;

  temp = p->points;
  if ( temp != NULL )
  {
    while ( temp->next != NULL )
    { temp = temp->next; }
  }

  d = (struct point *)malloc(sizeof(struct point));
  d->x = x;
  d->y = y;
  d->z = z;
  d->oldx = x;
  d->oldy = y;
  d->oldz = z;
  d->next = NULL;

  if ( p->points == NULL )
  {
    p->points = d;
  }
  else
  {
    temp->next = d;
  }
}


struct object * make_plane_object ( struct object *obj )
{

  struct polygon *p;

  obj = create_object ( obj );


/* Plane */
   p = add_polygon ( obj, p, 0 );
   add_vertex ( p, -1600,-1000,0 );
   add_vertex ( p, -1600,-1000,6000 );
   add_vertex ( p, 1600,-1000,6000 );
   add_vertex ( p, 1600,-1000,0 );

/* Vertical Marks */
   p = add_polygon ( obj, p, 1 );
   add_vertex ( p, -1400, -1000, 0 );
   add_vertex ( p, -1400, -1000, 6000 );

   p = add_polygon ( obj, p, 1 );
   add_vertex ( p, -1200, -1000, 0 );
   add_vertex ( p, -1200, -1000, 6000 );

   p = add_polygon ( obj, p, 1 );
   add_vertex ( p, -1000, -1000, 0 );
   add_vertex ( p, -1000, -1000, 6000 );

   p = add_polygon ( obj, p, 1 );
   add_vertex ( p, -800, -1000, 0 );
   add_vertex ( p, -800, -1000, 6000 );

   p = add_polygon ( obj, p, 1 );
   add_vertex ( p, -600, -1000, 0 );
   add_vertex ( p, -600, -1000, 6000 );

   p = add_polygon ( obj, p,1 );
   add_vertex ( p, -400, -1000, 0 );
   add_vertex ( p, -400, -1000, 6000 );

   p = add_polygon ( obj, p,1 );
   add_vertex ( p, -200, -1000, 0 );
   add_vertex ( p, -200, -1000, 6000 );

   p = add_polygon ( obj, p,1 );
   add_vertex ( p, 0, -1000, 0 );
   add_vertex ( p, 0, -1000, 6000 );

   p = add_polygon ( obj, p,1 );
   add_vertex ( p, 200, -1000, 0 );
   add_vertex ( p, 200, -1000, 6000 );

   p = add_polygon ( obj, p,1 );
   add_vertex ( p, 400, -1000, 0 );
   add_vertex ( p, 400, -1000, 6000 );

   p = add_polygon ( obj, p,1 );
   add_vertex ( p, 600, -1000, 0 );
   add_vertex ( p, 600, -1000, 6000 );

   p = add_polygon ( obj, p,1 );
   add_vertex ( p, 800, -1000, 0 );
   add_vertex ( p, 800, -1000, 6000 );

   p = add_polygon ( obj, p,1 );
   add_vertex ( p, 1000, -1000, 0 );
   add_vertex ( p, 1000, -1000, 6000 );

   p = add_polygon ( obj, p,1 );
   add_vertex ( p, 1200, -1000, 0 );
   add_vertex ( p, 1200, -1000, 6000 );

   p = add_polygon ( obj, p,1 );
   add_vertex ( p, 1400, -1000, 0 );
   add_vertex ( p, 1400, -1000, 6000 );



/* Horizontal marks */
   p = add_polygon ( obj, p,1 );
   add_vertex ( p, -1600,-1000, 500 );
   add_vertex ( p, 1600, -1000, 500 );

   p = add_polygon ( obj, p,1 );
   add_vertex ( p, -1600, -1000, 1000 );
   add_vertex ( p, 1600, -1000, 1000 );

   p = add_polygon ( obj, p,1 );
   add_vertex ( p, -1600,-1000, 1500 );
   add_vertex ( p, 1600, -1000, 1500 );

   p = add_polygon ( obj, p,1 );
   add_vertex ( p, -1600, -1000, 2000 );
   add_vertex ( p, 1600, -1000, 2000 );

   p = add_polygon ( obj, p,1 );
   add_vertex ( p, -1600,-1000, 2500 );
   add_vertex ( p, 1600, -1000, 2500 );

   p = add_polygon ( obj, p,1 );
   add_vertex ( p, -1600, -1000, 3000 );
   add_vertex ( p, 1600, -1000, 3000 );

   p = add_polygon ( obj, p,1 );
   add_vertex ( p, -1600,-1000, 3500 );
   add_vertex ( p, 1600, -1000, 3500 );

   p = add_polygon ( obj, p,1 );
   add_vertex ( p, -1600, -1000, 4000 );
   add_vertex ( p, 1600, -1000, 4000 );

   p = add_polygon ( obj, p,1 );
   add_vertex ( p, -1600,-1000, 4500 );
   add_vertex ( p, 1600, -1000, 4500 );

   p = add_polygon ( obj, p,1 );
   add_vertex ( p, -1600, -1000, 5000 );
   add_vertex ( p, 1600, -1000, 5000 );

   p = add_polygon ( obj, p,1 );
   add_vertex ( p, -1600, -1000, 5500 );
   add_vertex ( p, 1600, -1000, 5500 );

   return ( obj );

}



struct object * make_hand_object ( struct object *hand )
{

  struct polygon *p;

  hand = create_object ( hand );

  p = add_polygon ( hand, p,0 );
  add_vertex ( p, 400,0,1000 );
  add_vertex ( p, 400,400,1000 );
  add_vertex ( p, 400,400,300 );
  add_vertex ( p, 400,0,300 );

/*  p = add_polygon ( hand, p );
  add_vertex ( p, 440,0,1000 );
  add_vertex ( p, 440,400,1000 );
  add_vertex ( p, 440,400,300 );
  add_vertex ( p, 440,0,300 );

  p = add_polygon ( hand, p );
  add_vertex ( p, 400,400,300 );
  add_vertex ( p, 440,400,300 );

  p = add_polygon ( hand, p );
  add_vertex ( p, 400,0,300 );
  add_vertex ( p, 440,0,300 );

  p = add_polygon ( hand, p );
  add_vertex ( p, 400,400,1000 );
  add_vertex ( p, 440,400,1000 );

  p = add_polygon ( hand, p );
  add_vertex ( p, 400,0,1000 );
  add_vertex ( p, 440,0,1000 ); */

  return ( hand );

}

struct object * make_finger1_object ( struct object *f )
{

  struct polygon *p;

  f = create_object ( f );

  p = add_polygon ( f, p,1 );
  add_vertex ( p, 400,400,1000 );
  add_vertex ( p, 400,400,1300 );
  add_vertex ( p, 400,400,1500 );
  add_vertex ( p, 400,400,1600 );

  return ( f );

}


struct object * make_finger2_object ( struct object *f )
{

  struct polygon *p;

  f = create_object ( f );

  p = add_polygon ( f, p,1 );
  add_vertex ( p, 400,240,1000 );
  add_vertex ( p, 400,240,1300 );
  add_vertex ( p, 400,240,1500 );
  add_vertex ( p, 400,240,1600 );

  return ( f );

}

struct object * make_finger3_object ( struct object *f )
{

  struct polygon *p;

  f = create_object ( f );

  p = add_polygon ( f, p,1 );
  add_vertex ( p, 400,120,1000 );
  add_vertex ( p, 400,120,1300 );
  add_vertex ( p, 400,120,1500 );
  add_vertex ( p, 400,120,1600 );

  return ( f );

}

struct object * make_finger4_object ( struct object *f )
{

  struct polygon *p;

  f = create_object ( f );

  p = add_polygon ( f, p,1 );
  add_vertex ( p, 400,0,1000 );
  add_vertex ( p, 400,0,1300 );
  add_vertex ( p, 400,0,1500 );
  add_vertex ( p, 400,0,1600 );

  return ( f );

}



struct matrix * matrixmult ( struct matrix *a, struct matrix *b )
{
  int i, j, k;
  int t;
  struct matrix *c;

  c = (struct matrix *)malloc(sizeof(struct matrix));

  for (i=0;i<4;i++)
  {
   for (j=0;j<4;j++)
   {
    t = 0.0;
    for (k=0;k<4;k++)
    {
     t = t + a->m[i][k] * b->m[k][j];
    }
    c->m[i][j] = t;
   }
  }

  return ( c );
}


struct matrix * object_translate ( struct matrix *mat, int transx, int transy, int transz )
{
  struct matrix *b, *c;
  b = (struct matrix *)malloc(sizeof(struct matrix));

  b = identity ( b );
  b->m[3][0] = transx;
  b->m[3][1] = transy;
  b->m[3][2] = transz;
  c = matrixmult ( mat, b );
  free ( mat );
  free (b);

  return ( c );
}



struct matrix * object_scale ( struct matrix *mat, float scale )
{
  struct matrix *b, *c;
  b = (struct matrix *)malloc(sizeof(struct matrix));

  b = identity ( b );
  b->m[0][0] *= scale;
  b->m[1][1] *= scale;
  b->m[2][2] *= scale;
  c = matrixmult ( mat, b );
  free ( mat );
  free(b);

  return ( c );
}


struct matrix * object_xrot ( struct matrix *mat, float deg )
{
  float thecos, thesin;
  struct matrix *b, *c;

  thecos = cos ( deg*to_radians );
  thesin = sin ( deg*to_radians );
  b = (struct matrix *)malloc(sizeof(struct matrix));

  b = identity ( b );
  b->m[1][1] = thecos;
  b->m[1][2] = thesin;
  b->m[2][1] = -thesin;
  b->m[2][2] = thecos;
  c = matrixmult ( mat, b );
  free ( mat );
  free ( b );

  return ( c );
}


struct matrix * object_yrot ( struct matrix *mat, float deg )
{
  float thecos, thesin;
  struct matrix *b, *c;

  thecos = cos ( deg*to_radians );
  thesin = sin ( deg*to_radians );
  b = (struct matrix *)malloc(sizeof(struct matrix));

  b = identity ( b );
  b->m[0][0] = thecos;
  b->m[0][2] = -thesin;
  b->m[2][0] = thesin;
  b->m[2][2] = thecos;
  c = matrixmult ( mat,b );
  free ( mat );
  free ( b );

  return ( c );
}



struct matrix * object_zrot ( struct matrix *mat, float deg )
{
  float thecos, thesin;
  struct matrix *b, *c;

  thecos = cos ( deg*to_radians );
  thesin = sin ( deg*to_radians );
  b = (struct matrix *)malloc(sizeof(struct matrix));

  b = identity ( b );
  b->m[0][0] = thecos;
  b->m[0][1] = thesin;
  b->m[1][0] = -thesin;
  b->m[1][1] = thecos;
  c = matrixmult ( mat, b );
  free ( mat );
  free ( b );

  return ( c );
}


void change_finger_joint_one ( float deg, struct point *d )
{

  int x, y, z, ox, oy, oz, i;
  float thesin, thecos;
  struct matrix *m, *n, *o, *old;
  struct point *e;

  n = (struct matrix *)malloc(sizeof(struct matrix));
  o = (struct matrix *)malloc(sizeof(struct matrix));

  n = identity ( n );
  o = identity ( o );

  thecos = cos ( deg * to_radians );         /* set up rotation matrix */
  thesin = sin ( deg * to_radians );

  o->m[0][0] = thecos;
  o->m[2][0] = thesin;
  o->m[0][2] = -thesin;
  o->m[2][2] = thecos;


  ox = d->oldx;
  oy = d->oldy;
  oz = d->oldz;

    n->m[3][0] = -ox;		     /* setup translation matrix to origin */
    n->m[3][1] = -oy;
    n->m[3][2] = -oz;
    m = matrixmult ( n, o );         /* multiply these */


    e = d;
    d = d->next;
    n->m[3][0] = e->x;		     /* Previous point translation back */
    n->m[3][1] = e->y;
    n->m[3][2] = e->z;

    old = m;
    m = matrixmult ( old, n );                  /* Final matrix */
    free ( old );

    ox = d->x;
    oy = d->y;
    oz = d->z;

    x = d->x * m->m[0][0] +
	d->y * m->m[1][0] +
	d->z * m->m[2][0] +
	       m->m[3][0];

    y = d->x * m->m[0][1] +
	d->y * m->m[1][1] +
	d->z * m->m[2][1] +
	       m->m[3][1];

    z = d->x * m->m[0][2] +
	d->y * m->m[1][2] +
	d->z * m->m[2][2] +
	       m->m[3][2];

    d->oldx = d->x;
    d->oldy = d->y;
    d->oldz = d->z;

    d->x = x;
    d->y = y;
    d->z = z;

  free ( n );
  free ( o );
  free ( m );

}


void main()
{

  char ch;
  int change=0, close = 0, good = 0;
  int graphmode, graphdriver, i, x, y, z,
      glovex=0, glovey=0, glovez=0, gloveroll=0;
  struct object *hand, *ball, *finger1, *finger2, *finger3, *finger4,
		*plane;
  struct matrix *hand_matrix, *ball_matrix,
		*finger1_matrix,
		*finger2_matrix,
		*finger3_matrix,
		*finger4_matrix,
		*plane_matrix;

  glove_data    glov;



  glove_init ( HIRES, NULL );
  printf ( "Exercise the glove and then Press any key!!\n" );
  getch();

  graphmode = VGAHI;
  graphdriver = VGA;
  initgraph ( &graphdriver, &graphmode, "" );
  setbkcolor ( BLACK );
  cleardevice();

  plane_matrix   = (struct matrix *)malloc(sizeof(struct matrix));
  hand_matrix    = (struct matrix *)malloc(sizeof(struct matrix));
  finger1_matrix = (struct matrix *)malloc(sizeof(struct matrix));
  finger2_matrix = (struct matrix *)malloc(sizeof(struct matrix));
  finger3_matrix = (struct matrix *)malloc(sizeof(struct matrix));
  finger4_matrix = (struct matrix *)malloc(sizeof(struct matrix));

  plane_matrix   = identity ( plane_matrix );
  hand_matrix    = identity ( hand_matrix );
  finger1_matrix = identity ( finger1_matrix );
  finger2_matrix = identity ( finger2_matrix );
  finger3_matrix = identity ( finger3_matrix );
  finger4_matrix = identity ( finger4_matrix );

  create_view_transformation();

  plane   = make_plane_object ( plane );
  hand    = make_hand_object ( hand );
  finger1 = make_finger1_object ( finger1 );
  finger2 = make_finger2_object ( finger2 );
  finger3 = make_finger3_object ( finger3 );
  finger4 = make_finger4_object ( finger4 );

  x = hand->polygons->points->x;
  y = hand->polygons->points->y;
  z = hand->polygons->points->z;

  hand_matrix    = object_translate ( hand_matrix, -x, -y, -z );
  hand_matrix    = object_zrot ( hand_matrix, 90 );
  hand_matrix    = object_translate ( hand_matrix, x, y, z );
  finger1_matrix = object_translate ( finger1_matrix, -x, -y, -z );
  finger1_matrix = object_zrot ( finger1_matrix, 90 );
  finger1_matrix = object_translate ( finger1_matrix, x, y, z );
  finger2_matrix = object_translate ( finger2_matrix, -x, -y, -z );
  finger2_matrix = object_zrot ( finger2_matrix, 90 );
  finger2_matrix = object_translate ( finger2_matrix, x, y, z );
  finger3_matrix = object_translate ( finger3_matrix, -x, -y, -z );
  finger3_matrix = object_zrot ( finger3_matrix, 90 );

  finger3_matrix = object_translate ( finger3_matrix, x, y, z );
  finger4_matrix = object_translate ( finger4_matrix, -x, -y, -z );
  finger4_matrix = object_zrot ( finger4_matrix, 90 );
  finger4_matrix = object_translate ( finger4_matrix, x, y, z );


  draw_object ( plane, plane_matrix, BLUE );
  draw_object ( hand, hand_matrix, RED );
  draw_object ( finger1, finger1_matrix, RED );
  draw_object ( finger3, finger3_matrix, RED );
  draw_object ( finger4, finger4_matrix, RED );

  ch = 0;
  while ( ch != 'q' )
  {

    while (!glove_ready()) glove_delay();
    glove_read(&glov);
    x = y = z = 0;

    if ( glov.x != glovex )
    {
      change = 2;
      if ( glov.x > glovex )
	x = abs(glov.x-glovex) * 25;
      else
	x = abs(glov.x-glovex) * -25;
      glovex = glov.x;
    }


    if ( glov.y != glovey  )
    {
      change = 2;
      if ( glov.y > glovey )
	y = abs(glov.y-glovey) * 25;
      else
	y = abs(glov.y-glovey) * -25;
      glovey = glov.y;
    }

    if ( glov.z != glovez )
    {
      change = 2;
      if ( glov.z > glovez )
	z = abs(glov.z-glovez) * -200;
      else
	z = abs(glov.z-glovez) * 200;
      glovez = glov.z;
    }



    if ( change == 2 )
    {
      hand_matrix = object_translate ( hand_matrix, x,y,z );
      finger1_matrix = object_translate ( finger1_matrix, x,y,z  );
      finger2_matrix = object_translate ( finger2_matrix, x,y,z  );
      finger3_matrix = object_translate ( finger3_matrix, x,y,z  );
      finger4_matrix = object_translate ( finger4_matrix, x,y,z  );
    }

    if ( change == 2 )
    {
    erase_object ( hand );
    erase_object ( finger1 );
    erase_object ( finger2 );
    erase_object ( finger3 );
    erase_object ( finger4 );
    change = 1;
    }



    if ( (glov.keys & 0xff) <= 0xA0 )
    {
      ch = 'q';
    }



    if (((glov.fingers & 0xff ) <= 0x80 ) && ( close == 1 ) )
    {
      x =  -270;
      y =  180;
      z =  270;

/*      cleardevice(); */
      change_finger_joint_one ( x, finger1->polygons->points  );
      change_finger_joint_one ( y, finger1->polygons->points->next  );
      change_finger_joint_one ( z, finger1->polygons->points->next->next );

      change_finger_joint_one ( x, finger2->polygons->points  );
      change_finger_joint_one ( y, finger2->polygons->points->next  );
      change_finger_joint_one ( z, finger2->polygons->points->next->next );

      change_finger_joint_one ( x, finger3->polygons->points  );
      change_finger_joint_one ( y, finger3->polygons->points->next  );
      change_finger_joint_one ( z, finger3->polygons->points->next->next );

      change_finger_joint_one ( x, finger4->polygons->points  );
      change_finger_joint_one ( y, finger4->polygons->points->next  );
      change_finger_joint_one ( z, finger4->polygons->points->next->next );
      close = 0;
    }

    if (((glov.fingers & 0xff ) > 0x80 ) && ( close == 0 ))
    {
      x = -90;
      y = 180;
      z =  90;

/*      cleardevice(); */
      change_finger_joint_one ( x, finger1->polygons->points  );
      change_finger_joint_one ( y, finger1->polygons->points->next  );
      change_finger_joint_one ( z, finger1->polygons->points->next->next );

      change_finger_joint_one ( x, finger2->polygons->points  );
      change_finger_joint_one ( y, finger2->polygons->points->next  );
      change_finger_joint_one ( z, finger2->polygons->points->next->next );

      change_finger_joint_one ( x, finger3->polygons->points  );
      change_finger_joint_one ( y, finger3->polygons->points->next  );
      change_finger_joint_one ( z, finger3->polygons->points->next->next );

      change_finger_joint_one ( x, finger4->polygons->points  );
      change_finger_joint_one ( y, finger4->polygons->points->next  );
      change_finger_joint_one ( z, finger4->polygons->points->next->next );
      close = 1;

    }

    if (( glov.rot >= 3 ) && (glov.rot <=10 ) && ( gloveroll == 0))
    {
      x = hand->polygons->points->x;
      y = hand->polygons->points->y;
      z = hand->polygons->points->z;


      hand_matrix = object_translate ( hand_matrix, -x, -y, -z );
      hand_matrix = object_zrot ( hand_matrix, -90 );
      hand_matrix = object_translate ( hand_matrix, x, y, z );

      finger1_matrix = object_translate ( finger1_matrix, -x, -y, -z );
      finger1_matrix = object_zrot ( finger1_matrix, -90 );
      finger1_matrix = object_translate ( finger1_matrix, x, y, z );

      finger2_matrix = object_translate ( finger2_matrix, -x, -y, -z );
      finger2_matrix = object_zrot ( finger2_matrix, -90 );
      finger2_matrix = object_translate ( finger2_matrix, x, y, z );

      finger3_matrix = object_translate ( finger3_matrix, -x, -y, -z );
      finger3_matrix = object_zrot ( finger3_matrix, -90 );
      finger3_matrix = object_translate ( finger3_matrix, x, y, z );

      finger4_matrix = object_translate ( finger4_matrix, -x, -y, -z );
      finger4_matrix = object_zrot ( finger4_matrix, -90 );
      finger4_matrix = object_translate ( finger4_matrix, x, y, z );
      gloveroll = 1;
    }


    if ((glov.rot < 2 )  && ( gloveroll == 1 ))
    {
      gloveroll = 0;
      x = hand->polygons->points->x;
      y = hand->polygons->points->y;
      z = hand->polygons->points->z;


      hand_matrix = object_translate ( hand_matrix, -x, -y, -z );
      hand_matrix = object_zrot ( hand_matrix, 90 );
      hand_matrix = object_translate ( hand_matrix, x, y, z );

      finger1_matrix = object_translate ( finger1_matrix, -x, -y, -z );
      finger1_matrix = object_zrot ( finger1_matrix, 90 );
      finger1_matrix = object_translate ( finger1_matrix, x, y, z );

      finger2_matrix = object_translate ( finger2_matrix, -x, -y, -z );
      finger2_matrix = object_zrot ( finger2_matrix, 90 );
      finger2_matrix = object_translate ( finger2_matrix, x, y, z );

      finger3_matrix = object_translate ( finger3_matrix, -x, -y, -z );
      finger3_matrix = object_zrot ( finger3_matrix, 90 );
      finger3_matrix = object_translate ( finger3_matrix, x, y, z );

      finger4_matrix = object_translate ( finger4_matrix, -x, -y, -z );
      finger4_matrix = object_zrot ( finger4_matrix, 90);
      finger4_matrix = object_translate ( finger4_matrix, x, y, z );
    }


     if ( change == 1 )
     {
      draw_object ( hand, hand_matrix, RED );
      draw_object ( finger1, finger1_matrix, RED );
      draw_object ( finger2, finger2_matrix, RED );
      draw_object ( finger3, finger3_matrix, RED );
      draw_object ( finger4, finger4_matrix, RED );
      change = 0;
     }

  }

  getch();
  release_object ( hand );
  release_object ( finger1 );
  release_object ( finger2 );
  release_object ( finger3 );
  release_object ( finger4 );
  release_object ( plane );

  free ( hand_matrix );
  free ( finger1_matrix );
  free ( finger2_matrix );
  free ( finger3_matrix );
  free ( finger4_matrix );
  free ( plane_matrix );
  closegraph();
  glove_quit();

}
