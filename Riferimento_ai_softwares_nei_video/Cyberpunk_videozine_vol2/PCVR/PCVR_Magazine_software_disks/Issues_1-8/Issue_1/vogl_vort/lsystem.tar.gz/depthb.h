#include "matrix4.h"

#define PERSPECTIVE 1
#define ORTHOGRAPHIC 2

#define MAX_POLYSIDES 64

#define BAD_SPHERE 1
#define BAD_CYLINDER 8

#define AVG_SPHERE 2
#define AVG_CYLINDER 16

#define GOOD_SPHERE 3
#define GOOD_CYLINDER 32


#ifndef VECTOR_DEFINED
typedef struct {float x, y, z;} vector;
#define VECTOR_DEFINED
#endif

typedef struct {float r, g, b;} color;

typedef struct dbp {int sides, col, trf; vector n[2], *v;
				struct dbp *next; } dbpoly;

typedef struct ls {vector dir; float col; struct ls *next;} light_source;

typedef struct {int xres, yres; vector vpoint, vtarget, worldup;
			 float zoom, fcp, bcp, tilt;} viewpars;

extern int db_colors;
extern matrix4 tmatrix;
extern int proj;
extern float lambient, backfacing;
extern int dbwidth, dbheight;
extern float dbxcent, dbycent;
extern viewpars vpars;

/* db????.c */
int	db_plotpoint(int, int, float, int);
void db_hline(int, float, float, float, float, int);
int	start_db_graphics(int, color *, char *);
void end_db_graphics(void);

/* dbmisc.c */
void *db_memreq(int size);
dbpoly *alloc_dbpoly(int);
void free_dbpoly(dbpoly *);
void set_dbpolynormal(dbpoly *, int);
void transform_dbpoly(dbpoly *);
void transform_point(vector *);
void shade_dbpoly(dbpoly *);
void set_projection(int);
void set_lightsource(vector, float);
int read_parfile(char *);
#define  set_ambient(c)	{ lambient = c; }
void remove_lights(void);
void draw_dbpolylist(dbpoly *);
void free_dbpolylist(dbpoly *);

/* dbprim.c */
void init_prims(void);
void uninit_prims(void);
void db_drawpolygon(dbpoly *);
void db_drawcylinder(vector, vector, float, int, int);
void db_drawsphere(vector, float, int, int);
