#define DEFINE_VARS

#include "lsystem.h"
#ifdef MSC
#include <conio.h>
#endif


int turtlemode;


void *memrequest(int size)
{
	void *a;

	a=(void *)malloc(size);

	if (a==NULL) {
		printf("Unable to allocate %d bytes.\n", size);
		exit(-1);
		}

	return a;
}



char HUGE *alloc_string(void)
{
	char HUGE *c;

	c = (char HUGE *) HUGEALLOC((long)MAX_STR/2L, 2);

	if (c == NULL) {
		puts("Unable to allocate l-system string.");
		exit(-1);
	}

	return c;
}



void setinput(void)
{
	int tkp;
	int i;
	char definstr[] = "A16 #Td.5 #Tr0 #Tx.1 #Ty.1 #Tz.1 STr #Tr0 ,^90 RTr";
	int j = 0;
	char prodtoken[] = "#PRODUCTIONS?:";
	time_t now;

	tkp = recontoken("#INIT_STRING:");
	if (itoken[tkp].type == UNDEF) {
		fprintf(stderr, "Init string undefined. Using default\n");
		init_string = (char HUGE *)memrequest(strlen(definstr) + 1);
		strcpy(init_string, definstr);
	}
	else {
		init_string = (char HUGE *)memrequest(strlen(definstr) +
							 strlen(itoken[tkp].v.str) + 1);
		strcpy(init_string, definstr);
		strcat(init_string, itoken[tkp].v.str);
		free(itoken[tkp].v.str);
	}


	tkp = recontoken("#TITLE:");
	if (itoken[tkp].type == UNDEF)
		title = NULL;
	else {
		title = itoken[tkp].v.str;
	}


	tkp = recontoken("#AXIOM:");
	if (itoken[tkp].type == UNDEF) {
		fprintf(stderr, "Axiom undefined. Program aborted\n");
		exit(-4);
	}
	else {
		axiom = itoken[tkp].v.str;
	}


/*
** ignore is an array that will have TRUE only in correspondence
** of that chars to be ignored
*/
	for (i = 0; i < MAX_CHARS; i++)
		ignore[i] = FALSE;
	tkp = recontoken("#IGNORE:");
	if (itoken[tkp].type != UNDEF) {
		for (i = 0; itoken[tkp].v.str[i] != 0; i++)
			ignore[itoken[tkp].v.str[i]] = TRUE;
		free(itoken[tkp].v.str);
	}

	tkp = recontoken("#DEPTH_LEVEL:");
	if (itoken[tkp].type == UNDEF) {
		fprintf(stderr, "Depth level undefined. Program aborted\n");
		exit(-4);
	}
	else {
		depthlev = *itoken[tkp].v.val;
		free(itoken[tkp].v.val);
	}


	tkp = recontoken("#RAND_SEED:");
	if (itoken[tkp].type == UNDEF)
		randseed = (unsigned)(time(&now) % 37);
	else {
		randseed = (unsigned)*itoken[tkp].v.val;
		free(itoken[tkp].v.val);
	}


/* N.B.: MAX_PRODTAB <= 9 */
	for (i = 0; i < MAX_PRODTAB; i++) {
		sprintf(prodtoken, "#PRODUCTIONS%d:", (i+1));
		tkp = recontoken(prodtoken);
		if (itoken[tkp].type != UNDEF)
			setprodset[j++] = itoken[tkp].v.prod;
	}
	if (j == 0) {
		fprintf(stderr, "No production given. Program aborted\n");
		exit(-4);
	}


	tkp = recontoken("#COLORS:");
	if (itoken[tkp].type == UNDEF)
		fprintf(stderr, "Colors undefined. Using default\n");


	tkp = recontoken("#MATERIALS:");
	if (itoken[tkp].type == UNDEF)
		fprintf(stderr, "Materials undefined. Using default\n");


	tkp = recontoken("#SUBROUTINES:");
	if (itoken[tkp].type == UNDEF)
		subs[0][0] = NULL;

}



void main(int argc, char **argv)
{
	char ifile[40], lfile[40], avfile[40], *fnp;
	int lmode, recursion, i;
	unsigned int rseed;

	iline = memrequest(MAXINSTR);
	errstr = memrequest(256);
	itoken = (token *)memrequest(MAX_ITOKEN * sizeof(token));

	turtlemode = 1;
	strcpy(avfile, "lsystem.par");

	ifile[0] = 0;
	lmode = 0;
	recursion = -1;
	rseed = 0;

	if (argc < 2) {
		puts("Usage:\nlsystem [-a artfile] [-g genfile] [-u usefile] [-v viewfile] [-r nn] [-s nn] inputfile");
		exit(-1);
	}

	for (i=1; i<argc; i++)
		if (0==strcmp(argv[i], "-a")) {
			turtlemode = 0;
			i++;
			strcpy(avfile, argv[i]);
		} else if (0==strcmp(argv[i], "-g")) {
			lmode = 1;
			i++;
			strcpy(lfile, argv[i]);
		} else if (0==strcmp(argv[i], "-u")) {
			lmode = 2;
			i++;
			strcpy(lfile, argv[i]);
		} else if (0==strcmp(argv[i], "-v")) {
			turtlemode = 1;
			i++;
			strcpy(avfile, argv[i]);
		} else if (0==strcmp(argv[i], "-r")) {
			i++;
			if (1!=sscanf(argv[i], "%d", &recursion)) {
				puts("-r requires a number");
				exit(-1);
			}
		} else if (0==strcmp(argv[i], "-s")) {
			i++;
			if (1!=sscanf(argv[i], "%u", &rseed)) {
				puts("-s requires a number");
				exit(-1);
			}
		} else
			strcpy(ifile, argv[i]);

	fnp = strrchr(avfile, '.');
	if (fnp == NULL)
		if (turtlemode == 0)
			strcat(avfile, ".scn");
		else if (turtlemode == 1)
			strcat(avfile, ".par");

	if (ifile[0] == 0) {
		puts("You must specify a l-system filename.");
		exit(-1);
	}

	fnp = strrchr(ifile, '.');
	if (fnp == NULL)
		strcat(ifile, ".l");

	readinfile(ifile);

	if (rseed != 0)
		randseed = rseed;

	srand(randseed);

	if (recursion == -1)
		recursion = depthlev;

	if (lmode == 1) {
		lstring = derive(recursion, setprodset[0]);

		writelfile(lstring, lfile);

		exit(0);

	} else if (lmode == 2)
		lstring = readlfile(lfile);
	else
		lstring = derive(recursion, setprodset[0]);

	initturtle(turtlemode, avfile);

	interpretlsystem(init_string, lstring);

#ifdef MSC
	if (turtlemode == 1)
		getch();
#endif

	endturtle();
}
