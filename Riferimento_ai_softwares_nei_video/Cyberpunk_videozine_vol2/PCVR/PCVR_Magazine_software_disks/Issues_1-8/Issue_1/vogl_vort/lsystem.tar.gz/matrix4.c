#include <math.h>

#define MATRIX4_MODULE
#include "matrix4.h"

vector axes[3] = { {1.0, 0.0, 0.0},
			    {0.0, 1.0, 0.0},
			    {0.0, 0.0, 1.0} };



void normalize(register vector *v)
{
	register float m;

	m = NORM(*v);

	if (m != 0.0) {
		m = 1.0 / m;
		VECSCALE(*v, m, *v);
	}
}



void m4ident(register matrix4 m)
{
	m[0][1] = m[0][2] = m[0][3] = m[1][0] = m[1][2] = m[1][3] = m[2][0] =
		  m[2][1] = m[2][3] = m[3][0] = m[3][1] = m[3][2] = 0.0;
	m[0][0] = m[1][1] = m[2][2] = m[3][3] = 1.0;
}



void m4transl(matrix4 m, vector *t)
{
	m4ident(m);

	m[0][3] = t->x;
	m[1][3] = t->y;
	m[2][3] = t->z;
}



void m4rotate(matrix4 m, int axis, register float a)
{
	m4ident(m);

	switch(axis) {
	case X_AXIS:
		m[1][1] = m[2][2] = cos(a);
		m[1][2] = - ( m[2][1] = sin(a) );
		break;

	case Y_AXIS:
		m[0][0] = m[2][2] = cos(a);
		m[2][0] = - ( m[0][2] = sin(a) );
		break;

	case Z_AXIS:
		m[0][0] = m[1][1] = cos(a);
		m[0][1] = - ( m[1][0] = sin(a) );
		break;
	}
}



void m4perspective(matrix4 m, float s, float fcp, float bcp)
{
	m4ident(m);

	m[2][2] = s / (fcp * (1 - fcp/bcp) );
	m[2][3] = - s / (1 - fcp/bcp);
	m[3][2] = s / fcp;
}



void m4orthographic(matrix4 m, float s, float fcp, float bcp)
{
	m4ident(m);

	m[0][0] = 1.0 / s;
	m[1][1] = 1.0 / s;

	m[2][2] = 1.0 / (bcp - fcp);
	m[2][3] = - fcp / (bcp - fcp);
}



void m4print(matrix4 m)
{
	int r;

	for (r=0; r<4; r++)
		printf("%f %f %f %f\n", m[r][0], m[r][1], m[r][2], m[r][3]);
}



void m4apply(register vector *r, register matrix4 m, register vector *v)
{
	r->x = v->x * m[0][0] + v->y * m[0][1] + v->z * m[0][2] + m[0][3];
	r->y = v->x * m[1][0] + v->y * m[1][1] + v->z * m[1][2] + m[1][3];
	r->z = v->x * m[2][0] + v->y * m[2][1] + v->z * m[2][2] + m[2][3];
}



void m4apply4(register vector4 *r, register matrix4 m, register vector4 *v)
{
	r->x = v->x * m[0][0] + v->y * m[0][1] + v->z * m[0][2] + v->w * m[0][3];
	r->y = v->x * m[1][0] + v->y * m[1][1] + v->z * m[1][2] + v->w * m[1][3];
	r->z = v->x * m[2][0] + v->y * m[2][1] + v->z * m[2][2] + v->w * m[2][3];
	r->w = v->x * m[3][0] + v->y * m[3][1] + v->z * m[3][2] + v->w * m[3][3];
}



void m4add(register matrix4 mr, register matrix4 m1, register matrix4 m2)
{
	register int r, c;

	for (r=0; r<4; r++)
		for (c=0; c<4; c++)
			mr[r][c] = m1[r][c] + m2[r][c];
}



void m4copy(register matrix4 mr, register matrix4 m1)
{
	register int r, c;

	for (r=0; r<4; r++)
		for (c=0; c<4; c++)
			mr[r][c] = m1[r][c];
}



void m4sub(register matrix4 mr, register matrix4 m1, register matrix4 m2)
{
	register int r, c;

	for (r=0; r<4; r++)
		for (c=0; c<4; c++)
			mr[r][c] = m1[r][c] - m2[r][c];
}



void m4mult(matrix4 mr, register matrix4 m1, register matrix4 m2)
{
	register int r, c;

	for (r=0; r<4; r++)
		for (c=0; c<4; c++)
			mr[r][c] = m1[r][0] * m2[0][c] + m1[r][1] * m2[1][c] +
					 m1[r][2] * m2[2][c] + m1[r][3] * m2[3][c];
}
