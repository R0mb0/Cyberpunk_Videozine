#include <math.h>
#include <memory.h>
#include <stdio.h>
#include <stdlib.h>

#include "depthb.h"



typedef struct {int active; vector v0, v1, ddy, v;} edge;

/* edge list for db_drawpolygon */
edge *e;
#ifdef UNIX
long int npolys = 0L;
#endif



void init_prims(void)
{
	e = (edge *) db_memreq(MAX_POLYSIDES * sizeof(edge));
}



void uninit_prims(void)
{
	free(e);
}



#define ADDPOINT(v)   xp[j] = v.x;  zp[j++] = v.z;


void db_drawpolygon(dbpoly *p)
{
	register int i, j, y, k;
	int ymin, ymax;
	float xp[16], zp[16], xt, zt, dy;
	vector vt0;

#ifdef UNIX
	if (!(npolys%1024L))
		printf("Processing polygon: %ld\n", npolys);

	npolys++;
#endif

	if (!p->trf)
		transform_dbpoly(p);

	vt0 = p->v[0];
	if (proj == ORTHOGRAPHIC) {
		vt0.x = 0.0;
		vt0.y = 0.0;
	}

	dy = DOT(p->n[1], vt0);

	if ( (backfacing * dy) > 0.0 )
		return;

	if (dy < 0.0) {
		p->n[0].x = - p->n[0].x;
		p->n[0].y = - p->n[0].y;
		p->n[0].z = - p->n[0].z;
	}

	shade_dbpoly(p);

	for (i=0; i<p->sides; i++) {
		j= (i==0)? p->sides-1 : i-1;
		e[i].v0 = p->v[j];
		e[i].v1 = p->v[i];

		if (e[i].v1.y > e[i].v0.y) {
			vt0 = e[i].v0;
			e[i].v0 = e[i].v1;
			e[i].v1 = vt0;
		}
	}

	ymin = 5000;
	ymax = -5000;

	for (i=0; i<p->sides; i++) {
		e[i].active = 0;

		e[i].v0.x = floor(0.5 + (float)dbxcent * (1.0 + e[i].v0.x));
		e[i].v0.y = floor(0.5 + (float)dbycent - (float)dbxcent * e[i].v0.y);

		e[i].v1.x = floor(0.5 + (float)dbxcent * (1.0 + e[i].v1.x));
		e[i].v1.y = floor(0.5 + (float)dbycent - (float)dbxcent * e[i].v1.y);

		if (e[i].v0.y < ymin)
			ymin = (int) e[i].v0.y;
		if (e[i].v1.y > ymax)
			ymax = (int) e[i].v1.y;

		e[i].v = e[i].v0;

		dy = (e[i].v1.y - e[i].v0.y);

		if (dy==0.0) {
			e[i].ddy.x = 1e10;
			e[i].ddy.z = 1e10;
		} else {
			e[i].ddy.x = (e[i].v1.x - e[i].v0.x) / dy;
			e[i].ddy.z = (e[i].v1.z - e[i].v0.z) / dy;
		}
	}

	if (ymax >= dbheight)
		if (ymin >= dbheight)
			return;
		else
			ymax = dbheight - 1;

	if (ymin < 0 && ymax < 0)
		return;

	if (ymax == ymin) {
		xp[0] = -5000;
		xp[1] = 5000;

		for (i=0; i<p->sides; i++) {
			if (e[i].v0.x > xp[0]) {
				xp[0] = e[i].v0.x;
				zp[0] = e[i].v0.z;
			}
			if (e[i].v0.x < xp[1]) {
				xp[1] = e[i].v0.x;
				zp[1] = e[i].v0.z;
			}
		}

		db_hline(ymin, xp[0], zp[0], xp[1], zp[1], p->col);

		return;
	}

	for (y=ymin; y<=ymax; y++) {

		j = 0;

		for (i=0; i<p->sides; i++)
			if (e[i].active)
				if (e[i].v1.y == y)
					e[i].active = 0;
				else {
					e[i].v.x += e[i].ddy.x;
					e[i].v.z += e[i].ddy.z;

					ADDPOINT(e[i].v);
				}
			else
				if (e[i].v0.y == y)
					if (e[i].ddy.x != 1e10) {
						e[i].active = 1;

						ADDPOINT(e[i].v);
					}

		if (j&1) {
			/* this is an internal error */
			end_db_graphics();
			puts("Porca puttana!");

			exit(-1);
			}

		if (y >= 0) {
			for (i=0; i<(j-1); i++)
				for (k=i+1; k<j; k++)
					if (xp[k] < xp[i]) {
						xt = xp[i];
						xp[i] = xp[k];
						xp[k] = xt;
						zt = zp[i];
						zp[i] = zp[k];
						zp[k] = zt;
					}

			for (i=0; i<j; i+=2)
				db_hline(y, xp[i], zp[i], xp[i+1], zp[i+1], p->col);
		}
	}

}



void db_drawcylinder(vector b1, vector b2, float rad, int col, int csides)
{
	vector r1, r2, fp, op, d1, d2, d;
	float c, s, t, bfsave, nb2;
	register float a;
	dbpoly *ep, *bp1, *bp2;
	int first;
	register int i;

	bfsave = backfacing;
	backfacing = 1.0;

	ep = alloc_dbpoly(4);
	bp1 = alloc_dbpoly(csides);
	bp2 = alloc_dbpoly(csides);

	r1.x = 0.0;
	r1.y = 0.0;
	r1.z = 1.0;  /* a generic random vector */

	VECSUB(b2, b2, b1);

	t = DOT(b2, r1);
	nb2 = DOT(b2, b2);

	if (fabs(t) >= (0.9 * sqrt(nb2)) ) { /* unlucky day */
		r1.x = 0.0;
		r1.y = 1.0;
		r1.z = 0.0;

		t = DOT(b2, r1);
	}

	t = t / nb2;

	VECSCALE(r2, t, b2);
	VECSUB(r1, r1, r2);
	CROSS(r2, r1, b2);

	normalize(&r1);
	normalize(&r2);

	t = PI2 / (float) csides;

	first = 1;

	for (i=0, a=0.0; i<csides; a+=t, i++) {
		s = rad * sin(a);
		c = rad * cos(a);

		VECSCALE(d1, c, r1);
		VECSCALE(d2, s, r2);

		d = b1;
		VECADD(d, d, d1);
		VECADD(d, d, d2);

		bp1->v[i] = d;

		if (first) {
			first = 0;
			fp = d;
			op = d;
			continue;
		}

		ep->col = col;
		ep->trf = 0;

		ep->v[1] = d;
		VECADD(ep->v[2], b2, d);

		ep->v[0] = op;
		VECADD(ep->v[3], b2, op);

		set_dbpolynormal(ep, 0);

		db_drawpolygon(ep);

		op = d;
	}

	/* draw last poly */
	ep->col = col;
	ep->trf = 0;

	ep->v[0] = op;
	VECADD(ep->v[3], b2, op);

	ep->v[1] = fp;
	VECADD(ep->v[2], b2, fp);

	set_dbpolynormal(ep, 0);

	db_drawpolygon(ep);

	/* draw the bases */
	for (i=0; i<csides; i++) {
		bp2->v[csides-i-1] = bp1->v[i];
		VECADD(bp1->v[i], b2, bp1->v[i]);
	}

	bp1->col = col;
	bp2->col = col;
	bp1->trf = 0;
	bp2->trf = 0;

	set_dbpolynormal(bp1, 0);
	set_dbpolynormal(bp2, 0);

	db_drawpolygon(bp1);
	db_drawpolygon(bp2);

	free_dbpoly(ep);
	free_dbpoly(bp1);
	free_dbpoly(bp2);

	backfacing = bfsave;
}



vector spc;
float sprad;
int spcol;
dbpoly *spp;

void _subtriangle(vector v1, vector v2, vector v3, int depth)
{
	vector m1, m2, m3;

	if (depth == 0) {
		spp->trf = 0;
		spp->col = spcol;

		VECSCALE(spp->v[0], sprad, v1);
		VECADD(spp->v[0], spp->v[0], spc);
		VECSCALE(spp->v[1], sprad, v2);
		VECADD(spp->v[1], spp->v[1], spc);
		VECSCALE(spp->v[2], sprad, v3);
		VECADD(spp->v[2], spp->v[2], spc);

		set_dbpolynormal(spp, 0);

		db_drawpolygon(spp);

		return;
	}

	VECADD(m1, v1, v2);
	VECSCALE(m1, 0.5, m1);
	normalize(&m1);

	VECADD(m2, v2, v3);
	VECSCALE(m2, 0.5, m2);
	normalize(&m2);

	VECADD(m3, v3, v1);
	VECSCALE(m3, 0.5, m3);
	normalize(&m3);

	depth--;

	_subtriangle(v3, m3, m2, depth);
	_subtriangle(m3, v1, m1, depth);
	_subtriangle(m2, m3, m1, depth);
	_subtriangle(v2, m2, m1, depth);
}



void db_drawsphere(vector c, float rad, int col, int sdepth)
{
	vector v1, v2, v3;
	float bfsave;

	bfsave = backfacing;
	backfacing = 1.0;

	spc = c;
	sprad = rad;
	spcol = col;
	spp = alloc_dbpoly(3);

	v1.x = 0.0; v1.y = 1.0; v1.z = 0.0;
	v2.x = 1.0; v2.y = 0.0; v2.z = 0.0;
	v3.x = 0.0; v3.y = 0.0; v3.z = 1.0;
	_subtriangle(v1, v2, v3, sdepth);

	v2 = v3;
	v3.x = -1.0; v3.y = 0.0; v3.z = 0.0;
	_subtriangle(v1, v2, v3, sdepth);

	v2 = v3;
	v3.x = 0.0; v3.y = 0.0; v3.z = -1.0;
	_subtriangle(v1, v2, v3, sdepth);

	v2 = v3;
	v3.x = 1.0; v3.y = 0.0; v3.z = 0.0;
	_subtriangle(v1, v2, v3, sdepth);

	v1.x = 0.0; v1.y = -1.0; v1.z = 0.0;
	v2.x = 0.0; v2.y = 0.0; v2.z = 1.0;
	_subtriangle(v1, v2, v3, sdepth);

	v2 = v3;
	v3.x = 0.0; v3.y = 0.0; v3.z = -1.0;
	_subtriangle(v1, v2, v3, sdepth);

	v2 = v3;
	v3.x = -1.0; v3.y = 0.0; v3.z = 0.0;
	_subtriangle(v1, v2, v3, sdepth);

	v2 = v3;
	v3.x = 0.0; v3.y = 0.0; v3.z = 1.0;
	_subtriangle(v1, v2, v3, sdepth);

	free_dbpoly(spp);

	backfacing = bfsave;
}
