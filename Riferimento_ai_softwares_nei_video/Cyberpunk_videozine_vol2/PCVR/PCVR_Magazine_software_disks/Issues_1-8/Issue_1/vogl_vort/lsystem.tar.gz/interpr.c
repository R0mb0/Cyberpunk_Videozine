#include "lsystem.h"


typedef float variables[26];


variables vars, *varstack;
float *vstack;
int varstackp, vstackp;

float invert;

char prgname[MAX_SUBCALLS+1][40];
char HUGE *prgcurr[MAX_SUBCALLS+1];
char HUGE *prgorig[MAX_SUBCALLS+1];
int prgstackp;
char HUGE *prg;

int inpoly;



void do_error(void)
{
	endturtle();
	printf("%s at offset %ld in %s", errstr, (long) (prg -
		  prgorig[prgstackp]), prgname[prgstackp]);

	while (prgstackp != 0) {
		prgstackp--;

		printf(", called by %s at offset %ld", prgname[prgstackp],
			  (long) (prgcurr[prgstackp] - prgorig[prgstackp]) );
	}

	putchar('\n');
	exit(-1);
}



int decode_varspec(void)
{
	int i;
	register char c1, c2 = 0;

	c1 = *(prg++);

	if (islower(c1))
		return c1 - 'a';

	else if (c1 == 'T') {

		c2 = *(prg++);

		if (islower(c2)) {

			i = varcvtab[(int) c2 - 'a'];

			if (i != -1)
				return -i - 1;
		}
	}

	sprintf(errstr, "Illegal variable specification '%c%c'", c1, c2);
	do_error();
}



float get_variable(void)
{
	int i;

	i = decode_varspec();

	if (i>=0)
		return vars[i];
	else
		return tvars[-i - 1];
}



void set_variable(float val)
{
	int i;

	i = decode_varspec();

	if (i>=0)
		vars[i] = val;
	else
		tvars[-i - 1] = val;
}



void set_varspec(int i, float val)
{
	if (i>=0)
		vars[i] = val;
	else
		tvars[-i - 1] = val;
}



float get_varspec(int i)
{
	if (i>=0)
		return vars[i];
	else
		return tvars[-i - 1];
}



#define isinfloat(c)   ( isdigit(c) || (c)=='.' )



float get_float(void)
{
	float val = 0.0;
	char num[32], c;
	register int i = 0;

	c = *prg;

	if (islower(c) || c == 'T')
		val = get_variable();

	else if (isinfloat(c)) {

		while (isinfloat(*prg))
			num[i++] = *(prg++);

		num[i] = 0;

		val = atof(num);
	} else {
		sprintf(errstr, "Unable to read float value");
		do_error();
	}

	return val;
}



void execute_rotation(char cmd, int deft, float ang)
{
	int axis;

	switch(cmd) {
	case '+':
		if (deft)
			axis = YP_DEFAULT;
		else
			axis = Y_AXIS;
		break;

	case '-':
		if (deft)
			axis = YM_DEFAULT;
		else {
			axis = Y_AXIS;
			ang = -ang;
		}
		break;

	case '/':
		if (deft)
			axis = XP_DEFAULT;
		else
			axis = X_AXIS;
		break;

	case '\\':
		if (deft)
			axis = XM_DEFAULT;
		else {
			axis = X_AXIS;
			ang = -ang;
		}
		break;

	case '^':
		if (deft)
			axis = ZP_DEFAULT;
		else
			axis = Z_AXIS;
		break;

	case '_':
		if (deft)
			axis = ZM_DEFAULT;
		else {
			axis = Z_AXIS;
			ang = -ang;
		}
		break;
	}

	operate_turtle(T_ROTATE, axis, ang);
}



int push_variables(void)
{
	if (varstackp == MAX_STACKENTRIES)
		return 0;

	memcpy(varstack[varstackp], vars, sizeof(variables));

	varstackp++;

	return 1;
}



int pull_variables(void)
{
	if (varstackp == 0)
		return 0;

	varstackp--;

	memcpy(vars, varstack[varstackp], sizeof(variables));

	return 1;
}



void do_computations(void)
{
	char c;
	int i;
	float val;

	i = decode_varspec();

	c = *prg;

	switch(c) {
	case '+':
		prg++;
		val = get_float();
		set_varspec(i, get_varspec(i) + val);
		break;

	case '-':
		prg++;
		val = get_float();
		set_varspec(i, get_varspec(i) - val);
		break;

	case '*':
		prg++;
		val = get_float();
		set_varspec(i, get_varspec(i) * val);
		break;

	case '/':
	case 'I':
		if (c=='/') {
			prg++;
			val = get_float();
		} else {
			val = get_varspec(i);
			set_varspec(i, 1.0);
		}

		if (val == 0.0) {
			sprintf(errstr, "Trying to divide a number by 0.0");
			do_error();
		}

		set_varspec(i, get_varspec(i) / val);
		break;


	case 'S':
		set_varspec(i, sqrt(get_varspec(i)));
		break;

	case '?':
		set_varspec(i, (float)rand()/(float)RAND_MAX);
		break;

	default:
		set_varspec(i, get_float());
	}
}



void execute(register char HUGE *code, char *prgn)
{
	char c;
	float val;
	int i;

	strcpy(prgname[prgstackp], prgn);
	prgorig[prgstackp] = code;
	prgcurr[prgstackp] = code;
	prg = code;

loop:
	c = *(prg++);

	switch(c) {
	case 0:
		flush_output();
		return;

	case 'F':
		operate_turtle(T_DRAW, 0, tvars[1] * tvars[2]);
		break;

	case 'D':
		operate_turtle(T_DRAW, 0, tvars[1]);
		break;

	case 'G':
		operate_turtle(T_MOVE, 0, tvars[1] * tvars[2]);
		break;

	case 'M':
		operate_turtle(T_MOVE, 0, tvars[1]);
		break;

	case '+':
	case '-':
	case '/':
	case '\\':
	case '^':
	case '_':
		execute_rotation(c, 1, 0.0);
		break;

	case '|':
		operate_turtle(T_ROTATE, Y_AXIS, PI);
		break;

	case '!':
		invert = -1.0 * invert;
		break;

	case '@':
		val = get_float();
		tvars[2] *= val;
		break;

	case '[':
		i = push_variables();
		i += push_turtle();

		if (i!=2) {
			sprintf(errstr, "[] stack overflow");
			do_error();
		}
		break;

	case ']':
		i = pull_variables();
		i += pull_turtle();

		if (i!=2) {
			sprintf(errstr, "[] stack underflow");
			do_error();
		}
		break;

	case '#':
		do_computations();
		break;

	case ',':
		c = *(prg++);

		if ( (*prg) == '?') {
			prg++;

			val = get_float();

			val = val * (2.0 * (float)rand()/(float)RAND_MAX - 1.0);
		} else
			val = get_float();

		if (val == 0.0)
			break; /* nothing..... */

		if (c=='F') {
			operate_turtle(T_DRAW, 0, val * tvars[2]);
			break;
		} else if (c=='G') {
			operate_turtle(T_MOVE, 0, val * tvars[2]);
			break;

		} else if (c=='D') {
			operate_turtle(T_DRAW, 0, val);
			break;
		} else if (c=='M') {
			operate_turtle(T_MOVE, 0, val);
			break;

		} else {
			 val = val / 360.0 * PI2;
			 execute_rotation(c, 0, val);
		}
		break;

	case 'A':
		val = get_float();

		if (val == 0.0) {
			sprintf(errstr, "You can't use 'A0'");
			do_error();
		}

		tvars[0] = PI2 / val;
		set_defaultrot(tvars[0]);
		break;

	case '(':
		if (inpoly) {
			sprintf(errstr, "Filled polygons can't be nested");
			do_error();
		}

		inpoly = 2;
		operate_turtle(T_BEGUPOLY, 0, 0.0);
		break;

	case ')':
		if (inpoly != 2) {
			sprintf(errstr, "Ending a polygon ) which never began");
			do_error();
		}

		inpoly = 0;
		operate_turtle(T_ENDPOLY, 0, 0.0);
		break;

	case '$':
		if (inpoly != 2) {
			sprintf(errstr, "$ can't be used outside of ()");
			do_error();
		}

		operate_turtle(T_SETPOINT, 0, 0.0);
		break;

	case '{':
		if (inpoly) {
			sprintf(errstr, "Filled polygons can't be nested");
			do_error();
		}

		inpoly = 1;
		operate_turtle(T_BEGPOLY, 0, 0.0);
		break;

	case '}':
		if (inpoly != 1) {
			sprintf(errstr, "Ending a polygon } which never began");
			do_error();
		}

		inpoly = 0;
		operate_turtle(T_ENDPOLY, 0, 0.0);
		break;

	case 'E':
		flush_output();

		if (prgstackp == MAX_SUBCALLS) {
			sprintf(errstr, "Program stack overflow");
			do_error();
		}

		for (i=0; subs[i][0] != NULL; i++)
			if (0==hstrncmp(subs[i][0], prg, strlen(subs[i][0]))) {

				prgcurr[prgstackp] = prg;
				prgstackp++;

				execute(subs[i][1], subs[i][0]);

				prgstackp--;
				prg = prgcurr[prgstackp];
				prg += strlen(subs[i][0]);
				break;
			}

		if (subs[i][0] == NULL) {
			char temp[20];

			hstrncpy(temp, prg, 16);
			sprintf(errstr, "Unknown subroutine call (%s)", temp);
			do_error();
		}

		break;

	case 'S':
		val = get_variable();

		if (vstackp != MAX_STACKENTRIES) {
			vstack[vstackp] = val;
			vstackp++;
		} else {
			sprintf(errstr, "Variable stack overflow");
			do_error();
		}
		break;

	case 'R':
		if (vstackp != 0) {
			vstackp--;
			val = vstack[vstackp];
		} else {
			sprintf(errstr, "Variable stack underflow");
			do_error();
		}

		set_variable(val);
		break;

	default:
		/* ignore this */
		break;
	}

	goto loop;
}



void interpretlsystem(char HUGE *ini, char HUGE *cod)
{
	int i;

	varstack = (variables *) memrequest(MAX_STACKENTRIES * sizeof(variables));
	varstackp = 0;
	vstack = (float *) memrequest(MAX_STACKENTRIES * sizeof(float));
	vstackp = 0;
	prgstackp = 0;

	invert = 1.0;

	for (i=0; i<26; i++)
		vars[i] = 0.0;

	vars[15] = PI;

	inpoly = 0;

	execute(ini, "Init String");

	execute(cod, "Main Program");

	free(vstack);
	free(varstack);
}
