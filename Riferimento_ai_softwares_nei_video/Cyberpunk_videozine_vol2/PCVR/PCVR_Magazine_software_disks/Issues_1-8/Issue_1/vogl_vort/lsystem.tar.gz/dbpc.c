#include <fgraph.h>
#include <math.h>
#include <memory.h>
#include <stdio.h>
#include <stdlib.h>

#include "depthb.h"

#include "ems.h"

#define	EMS_MAXINTS 8192


int EMS_handle;



int alloc_depthbuffer(int width, int height)
{
	unsigned int *EMS_addr;
	int EMS_page, offset;
	int i;
	long total;

	if (dbheight != -1)
		return 0;

	if (!EMS_rdy())
		return 0;

	i = (int) ( (long) width * (long) height * 2L / EMS_PAGE_SIZE ) + 1;

	EMS_handle = EMS_alloc(i);
	if (EMS_handle == EMS_NULL_HDL)
		return 0;

	/* init depth buffer to max value (0xFFFF) */
	EMS_addr = EMS_base();
	offset = 0;
	EMS_page = 0;

	total = 2L * (long)width * (long)height; /* bytes to clear */

	EMS_map(EMS_handle, EMS_page);

	while (total > (long)EMS_PAGE_SIZE) {

		memset(EMS_addr, 0xff, EMS_PAGE_SIZE);
		total -= (long)EMS_PAGE_SIZE;
		EMS_map(EMS_handle, ++EMS_page);
	}

	memset(EMS_addr, 0xff, (unsigned int)total);

	dbwidth = width;
	dbheight = height;
	dbxcent = (float)dbwidth / 2.0;
	dbycent = (float)dbheight / 2.0;

	return 1;
}



static
void free_depthbuffer(void)
{
	if (dbheight == -1)
		return;

	EMS_release(EMS_handle);

	dbheight = -1;
}



int db_plotpoint(int x, int y, float depth, int col)
{
	unsigned int *EMS_addr;
	int EMS_page, offset;
	long int t;
	unsigned int d;

	if (x<0 || x>=dbwidth || y<0 || y>=dbheight || depth<0.0 || depth>1.0)
		return 0;

	d = (unsigned int) (depth * 65535.0 + 0.5);

	t = ( (long)x + (long)y *(long)dbwidth ) * 2L;

	EMS_page = (int) (t / EMS_PAGE_SIZE);
	offset = (int) (t % EMS_PAGE_SIZE) / 2;

	EMS_addr = EMS_base();

	EMS_map(EMS_handle, EMS_page);

	if (EMS_addr[offset] >= d) {
		EMS_addr[offset] = d;

		putcolor(x, y, col);
	} else
		return 0;
}



void db_hline(int y, float x0, float z0, float x1, float z1, int color)
{
	int ix0, ix1;
	register int x;
	float dzdx;
	register float z;
	unsigned int *EMS_addr;
	int EMS_page, mapped;
	register int offset;
	register long int t;
	register unsigned int d;

	if (y<0 || y>=dbheight)
		return;

	ix0 = (int) x0;
	ix1 = (int) x1;

	if ( (ix0<0 && ix1<0) || (ix0>dbwidth && ix0>dbwidth) )
		return;

	if ( (z0<0.0 && z1<0.0) || (z0>1.0 && z1>1.0) )
		return;

	if (ix0 == ix1) {
		db_plotpoint(ix0, y, z0, color);
		return;
	}

	z = z0;
	dzdx = (z1 - z0) / (x1 - x0);

	if (ix1 >= xdots)
		ix1 = xdots - 1;

	mapped = 0;

	for (x=ix0; x<=ix1; x++)
		if (x<0)
			z += dzdx;
		else {
			if (!mapped) {
				t = ( (long)x + (long)y *(long)dbwidth ) * 2L;

				EMS_page = (int) (t / EMS_PAGE_SIZE);
				offset = (int) (t % EMS_PAGE_SIZE) / 2;

				EMS_addr = EMS_base();

				EMS_map(EMS_handle, EMS_page);

				mapped = 1;
			}

			if (z>=0.0 && z<=1.0) {
				d = (unsigned int) (z * 65535.0 + 0.5);

				if (EMS_addr[offset] >= d) {
					EMS_addr[offset] = d;

					putcolor(x, y, color);
				}
			}

			offset++;
			if (offset == EMS_MAXINTS) {
				offset = 0;

				EMS_map(EMS_handle, ++EMS_page);
				}

			z += dzdx;
		}

}



int start_db_graphics(int nc, color *cols, char *nm)
{
	int mode, i, j, r, c;
	float rc, gc, bc, l;

	c = vpars.xres;
	r = vpars.yres;

	if (c == 640 && r == 480)
		mode = SUPVGA640480256;
/*		mode = IBM8514640480256; 		*/
/* change here if you have a 8514 */
	else if (c == 800 && r == 600)
		mode = SUPVGA800600256;
	else if (c == 1024 && r == 768)
		mode = SUPVGA1024768256;
/*		mode = IBM85141024768256;		*/
/* change here if you have a 8514 */

	else
		return 0;

	if (nc != 4 && nc != 8)
		return 0;

	db_colors = nc;

	if (!alloc_depthbuffer(c, r))
		return 0;

	startgraphics(mode);

	if (nc == 4) {
		for (j=0; j<4; j++)
			for (i=0; i<64; i++) {
				l = (float)i/63.0;

				rc = cols[j].r * l;
				gc = cols[j].g * l;
				bc = cols[j].b * l;

				dacbox[j*64 + i][0] = (int) (rc * 63.0 + .5);
				dacbox[j*64 + i][1] = (int) (gc * 63.0 + .5);
				dacbox[j*64 + i][2] = (int) (bc * 63.0 + .5);
			}
	} else {
		for (j=0; j<8; j++)
			for (i=0; i<32; i++) {
				l = (float)i/31.0;

				rc = cols[j].r * l;
				gc = cols[j].g * l;
				bc = cols[j].b * l;

				dacbox[j*32 + i][0] = (int) (rc * 63.0 + .5);
				dacbox[j*32 + i][1] = (int) (gc * 63.0 + .5);
				dacbox[j*32 + i][2] = (int) (bc * 63.0 + .5);
			}
	}

	storedac();

	init_prims();

	return 1;
}



void end_db_graphics(void)
{
	uninit_prims();
	free_depthbuffer();

	settextmode();
}
