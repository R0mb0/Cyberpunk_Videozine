#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef MSC
#include <conio.h>
#endif

#include "offlib.h"
#include "depthb.h"

vector lightdir;
vector vpoint;
vector vtarget;
vector worldup;
float zoom, fcp, bcp;
float lint, amb;


color colortable[4] = { {1.0, 1.0, 1.0},
				    {1.0, 0.0, 0.0},
				    {0.0, 1.0, 0.0},
				    {0.0, 0.0, 1.0} };


void main(int argc, char **argv)
{
	geometry *geo;
	vector vmax, vmin, vrange, vcenter;
	register int i, j;
	FILE *inf;
	float scal;
	dbpoly *p, *op, *dbpl;
	char parfile[50], *parf;

	if (argc != 2) {
		puts("drawgeo filespec");
		exit(-1);
	}

	inf = fopen(argv[1], "r");

	if (inf == NULL) {
		puts("Geo file not found.");
		exit(-1);
	}

	geo = readgeofile(inf);

	fclose(inf);

	if (geo == NULL) {
		puts("Unable to read the .geo file.");
		exit(-1);
	}

	/* rescale the geo */
	vmin.x = 50000.0;
	vmin.y = 50000.0;
	vmin.z = 50000.0;
	vmax.x = -50000.0;
	vmax.y = -50000.0;
	vmax.z = -50000.0;

	for (i=0; i<geo->nv; i++) {
		if (geo->vl[i].x < vmin.x)
			vmin.x = geo->vl[i].x;
		if (geo->vl[i].x > vmax.x)
			vmax.x = geo->vl[i].x;

		if (geo->vl[i].y < vmin.y)
			vmin.y = geo->vl[i].y;
		if (geo->vl[i].y > vmax.y)
			vmax.y = geo->vl[i].y;

		if (geo->vl[i].z < vmin.z)
			vmin.z = geo->vl[i].z;
		if (geo->vl[i].z > vmax.z)
			vmax.z = geo->vl[i].z;
	}

	VECSUB(vrange, vmax, vmin);
	VECADD(vcenter, vmax, vmin);
	VECSCALE(vcenter, 0.5, vcenter);

	scal = vrange.x;
	if (vrange.y > scal)
		scal = vrange.y;
	if (vrange.z > scal)
		scal = vrange.z;

	scal = 2.0/scal;

	for (i=0; i<geo->nv; i++) {
		VECSUB(geo->vl[i], geo->vl[i], vcenter);
		VECSCALE(geo->vl[i], scal, geo->vl[i]);
	}

	strcpy(parfile, argv[0]);

	parf = strrchr(parfile, '\\');
	parf++;

	strcpy(parf, "drawgeo.par");

	if (!read_parfile(parfile)) {
		printf("Error reading %s\n", parfile);
		exit(-1);
	}

	if (!start_db_graphics(4, colortable, "drawgeo.pix")) {
		puts("Unable to init depth buffer.");
		exit(-1);
	}

	set_projection(ORTHOGRAPHIC);

/*	end_db_graphics();
	m4print(tmatrix);	*/

	/* build the polygon list */
	op = NULL;

	for (i=0; i<geo->np; i++) {
		p = alloc_dbpoly(geo->pl[i].sides);

		if (op != NULL)
			op->next = p;
		else
			dbpl = p;

		for (j=0; j<geo->pl[i].sides; j++)
			p->v[j] = geo->vl[geo->cl[geo->pl[i].beg + j]];

		p->trf = 0;
		p->col = 0;
		set_dbpolynormal(p, 0);

		op = p;
	}

	p->next = NULL;

	draw_dbpolylist(dbpl);

#ifdef MSC
	getch();
#endif

	end_db_graphics();

	free_geometry(geo);
	free_dbpolylist(dbpl);
}
