#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <memory.h>
#include <malloc.h>
#include <ctype.h>
#include <time.h>

#include "depthb.h"
#ifdef MSC
#include "hstring.h"
#endif


#ifdef HUGE
#undef HUGE  /* sorry, we need that */
#endif

#ifdef MSC
#define HUGE huge
#define HUGEALLOC(c, s)	halloc((long)c, s)
#define HUGEFREE(p)  hfree(p)
#else
#define HUGE
#define HUGEALLOC(c, s)	malloc((long)c*(long)s)
#define HUGEFREE(p)  free(p)

#define hstrcmp strcmp
#define hstrncmp strncmp
#define hstrcpy strcpy
#define hstrncpy strncpy
#define hstrlen strlen
#endif


#define MAX_COLORS		8	 /* Max number of colors */
#define MAX_MATERIALS	8	 /* Max number of materials */
#define MAX_LENMAT		300	 /* Max length of any material description */
#define MAX_SUBROUTINES	64	 /* Max number of subroutines */
#define MAX_SUBNAMELEN	64	 /* Max length of a subroutine name */
#define MAX_SUBCALLS	32	 /* Max depth of program stack */
#define MAX_STACKENTRIES 64	 /* Max depth of var/turtle stacks */
#define MAX_PROD		50	 /* Max number of production */
#define MAX_PRODTAB 	4	 /* Max number of different table of production */
#define MAXINSTR		400	 /* Max length of any input line */
#define MAX_LINE		4096  /* Max length of any input string */
#define MAX_STR		150000/* Max length of the string we can generate */
#define MAX_CHARS		256	 /* We will use chars from 0 to MAXCHARS-1 */
#define MAX_SUCCESSOR	8	 /* Max number of stocastic successor */

#define TRUE  1
#define FALSE 0


/* turtle statuses */
#define T_NOMOVE 0
#define T_BEGPOLY 1
#define T_ROTATE 2
#define T_DRAW 3
#define T_MOVE 4
#define T_DOPOLY 5
#define T_ENDPOLY 6
#define T_BEGUPOLY 7
#define T_DOUPOLY 8
#define T_SETPOINT 9

/* distortion modes */
#define TD_NONE 0
#define TD_ROTATE 1

/* output mode flags */
#define TO_NULL 0
#define TO_SPHERE 1
#define TO_CYLINDER 2
#define TO_POLYEDGE 3
#define TO_POLYEND 4

/* default rotation axes */
#define XP_DEFAULT 10
#define XM_DEFAULT 11
#define YP_DEFAULT 12
#define YM_DEFAULT 13
#define ZP_DEFAULT 14
#define ZM_DEFAULT 15


typedef struct {
	double prob;
	char *succ;
	int succlen;
} successor;

typedef struct {
	char *lcon;
	int lconlen;
	char *pred;
	int predlen;
	char *rcon;
	int rconlen;
	successor listsucc[MAX_SUCCESSOR];
	int numsucc;
} production;


#define	MAX_LENTOKEN	32	/* Max length of a token */
#define	MAX_ITOKEN	16	/* Max number of token */

/* token value types */

#define UNDEF 0
#define INTEGER 1
#define FLOAT 2
#define STRING 3
#define PRODUCTION 4
#define COLOR 5
#define MATERIAL 6
#define SUBROUTINE 7
#define DISTORTION 8

/* token definition */

typedef struct {
	char name[MAX_LENTOKEN];
	void (*evaluate)(int);
	int type, curr;
	union {
		char *str;
		int *val;
		production *prod;
	} v;
} token;


/* error/warning macros */

#define ERROR { printf("%s at line %d\n", errstr, infline); exit(-1); }
#define WARNING { printf("%s at line %d\n", errstr, infline); }


#ifdef DEFINE_VARS

/* turtle variables */
vector tdir, tpos;
void (*output_begin)(char *);
void (*output_move)(vector, vector, float *);
void (*output_rotate)(vector, vector, float *);
void (*output_end)(void);
int distmode = TD_NONE;
float diststrength = 0.0;
vector distdir = {0.0, -1.0, 0.0};

/* tvars and conversion table */
float tvars[11];
int varcvtab[26] = { 0,	3,  4,  1, -1, -1, -1, -1, -1, -1,
				-1, -1,  5, -1, -1, 10, -1,  6,  2, -1,
				-1, -1, -1,  7,  8,  9};

/* output variables */
/* default values */
color colortable[MAX_COLORS] = { {.51, .75, .17},   /* stelo */
						   {.95, .95, .95},   /* flower white */
						   {.14, .78, .14},   /* leaf */
						   {.95, .95, 0.1},   /* flower yellow */
						   {0.0, 1.0, 1.0},
						   {1.0, 0.0, 1.0},
						   {1.0, 1.0, 0.0},
						   {0.0, 0.0, 0.0} };

/* generate/interpret strings */
char HUGE *lstring;

/* subroutine strings */
char HUGE *subs[MAX_SUBROUTINES][2];

char descr[MAX_MATERIALS][MAX_LENMAT] = {
	"\tmaterial 1, 1, 0, 0\n",
	"\tmaterial 1, .8, .2, 20\n\ttexture bumpy {\n\
		\t\tscalefactor .2\n\t\t}\n"
};

/* current line in input file */
int infline;

/* input line and pointer */
char *iline;
int ilineptr;

/* error report string */
char *errstr;

/* "don't read a line" flag */
int alreadygotline;

/* "read a line" flag */
int gicgetline;

/* input token table */
token *itoken;

/* subroutines table */
char HUGE *subs[MAX_SUBROUTINES][2];

/* input file */
FILE *inf;

/* global variables for lsystem */
char HUGE *init_string;

/* global variables for input and generator */
char *title;
char *axiom;
char ignore[MAX_CHARS];
unsigned randseed;
int depthlev;

/* production tables */
production *setprodset[MAX_PRODTAB];

#else

extern vector tdir, tpos;
extern void (*output_begin)(char *);
extern void (*output_move)(vector, vector, float *);
extern void (*output_rotate)(vector, vector, float *);
extern void (*output_end)(void);
extern int distmode;
extern float diststrength;
extern vector distdir;
extern float tvars[10];
extern int varcvtab[26];
extern color colortable[MAX_COLORS];
extern char descr[MAX_MATERIALS][MAX_LENMAT];
extern char HUGE *lstring;
extern char HUGE *subs[MAX_SUBROUTINES][2];
extern int infline, ilineptr;
extern char *iline, *errstr;
extern int alreadygotline, gicgetline;
extern token *itoken;
extern char HUGE *subs[MAX_SUBROUTINES][2];
extern FILE *inf;
extern char HUGE *init_string;
extern char *title, *axiom;
extern char ignore[MAX_CHARS];
extern unsigned randseed;
extern int depthlev;
extern production *setprodset[MAX_PRODTAB];

#endif

/* lsystem.c */
void *memrequest(int);
char HUGE *alloc_string(void);
void setinput(void);

/* turtle.c */
void initturtle(int, char *);
void endturtle(void);
void set_defaultrot(float);
void get_axis(int, vector *);
void move_forward(vector *, vector *, float);
void rotate_turtle(vector *, vector *, int, float);
int	push_turtle(void);
int	pull_turtle(void);
void operate_turtle(int, int, float);
void flush_output(void);

/* toutput.c */
void depthb_init_output(char *);
void depthb_output_move(vector, vector, float *);
void depthb_output_rotate(vector, vector, float *);
void depthb_end_output(void);

void art_init_output(char *);
void art_output_move(vector, vector, float *);
void art_output_rotate(vector, vector, float *);
void art_end_output(void);

/* interp.c */
void do_error(void);
void interpretlsystem(char HUGE *, char HUGE *);

/* fileio.c */
void readinfile(char *);
void writelfile(char HUGE *, char *);
char HUGE *readlfile(char *);
int recontoken(char *);
void parseinput(void);
int checkdefine(int);
char getichar(void);
void getdataline(void);
void getnextline(void);
void parseinput(void);
void inititoken(void);
int pullstring(char *, int, int);
int pullinteger(void);
float pullfloat(void);
void proceedtotoken(void);
void getstring(int);
void getinteger(int);
void getfloat(int);
void getprod(int);
void getcol(int);
void getmat(int);
void getsub(int);
void getdist(int);
void enterr(float *, char *, successor *);
void normalizeprob(successor [] , int);

/* generate.c */
char HUGE *derive(int, production *);
production *findprod(char *, production[], char []);
void applyprod(char HUGE **, char HUGE **, char HUGE **, production *);
int stocaschoice(production *);
int prefix(char *, char *);
int rcondiff(char *, char *, char []);
int lcondiff(char *, char *, char []);
char *skipright(char *);
char *skipleft(char *);
