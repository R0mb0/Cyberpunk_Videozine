/*
 *	string.h library able to work on huge strings.
 *	(for MSC)
 *
 */

char huge *hstrcat(register char huge *s, register char huge *a)
{
	char huge *sav = s;

	for (; *s; s++);

	while (*s++ = *a++);

	return(sav);
}



char huge *hstrchr(register char huge *s, register int c)
{
	while (*s) {
		if (*s == c)
			return s;
		s++;
	}

	if (c == 0)
		return s;

	return (char huge *)0L;
}



int hstrcmp(register char huge *s1, register char huge *s2)
{
	while (*s1 == *s2++)
		if (*s1++ == 0)
			return 0;

	return (*(unsigned char *)s1 - *(unsigned char *)--s2);
}



char huge *hstrcpy(register char huge *t, register char huge *f)
{
	char *sav = t;

	for (; *t = *f; f++, t++);

	return(sav);
}



long int hstrlen(register char huge *s)
{
	long l = 0L;

	for (; *s; s++, l++);

	return l;
}



char huge *hstrncat(register char huge *t, register char huge *f,
			    register long int n)
{
	char huge *sav = t;

	if (n!=0L) {

		for (; *t; t++);

		do
			if (!(*t = *f++))
				break;
			else
				t++;
		  while (--n != 0L);

		*t = 0;
	}

	return sav;
}



int hstrncmp(register char huge *s1, register char huge *s2,
		  register long int n)
{

	if (n == 0L)
		return 0;

	do {
		if (*s1 != *s2++)
			return (*(unsigned char *)s1 - *(unsigned char *)--s2);
		if (*s1++ == 0)
			break;
	} while (--n != 0L);

	return 0;
}



char huge *hstrncpy(register char huge *t, register char huge *f,
			    register long int n)
{
	char huge *sav = t;

	if (n != 0L)

		do
			if ((*t++ = *f++) == 0) {

				while (--n != 0L)
					*t++ = 0;
				break;
			}

		  while (--n != 0L);

	return sav;
}



char huge *hstrrchr(register char huge *s, register int c)
{
	char huge *sp=(char huge *)0L;

	while (*s) {
		if (*s == c)
			sp = s;
		s++;
	}

	if (c == 0)
		return s;

	return sp;
}
