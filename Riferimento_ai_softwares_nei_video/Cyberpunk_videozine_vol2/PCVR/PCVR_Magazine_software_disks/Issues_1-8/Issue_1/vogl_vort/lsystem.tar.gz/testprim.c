#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef MSC
#include <conio.h>
#endif

#include "depthb.h"

vector lightdir;
vector vpoint;
vector vtarget;
vector worldup;
float zoom, fcp, bcp;
float lint, amb;


color colortable[4] = { {1.0, 1.0, 1.0},
				    {1.0, 0.0, 0.0},
				    {0.0, 1.0, 0.0},
				    {0.0, 0.0, 1.0} };



void main(int argc, char **argv)
{
	vector v1, v2;

	if (!read_parfile("view.par")) {
		puts("Error reading view.par");
		exit(-1);
	}

	if (!start_db_graphics(4, colortable, "testprim.pix")) {
		puts("Unable to init depth buffer.");
		exit(-1);
	}

	set_projection(ORTHOGRAPHIC);

/*	end_db_graphics();
	m4print(tmatrix);	*/

	v1.x = 0.0; v1.y = -1.0; v1.z = 0.0;
	v2.x = 0.0; v2.y = 1.0; v2.z = 0.0;
	db_drawcylinder(v1, v2, 0.2, 1, GOOD_CYLINDER);
	db_drawsphere(v1, .22, 1, GOOD_SPHERE);
	db_drawsphere(v2, .22, 1, GOOD_SPHERE);

	v1.x = 1.0; v1.y = 0.0; v1.z = 0.0;
	v2.x = -1.0; v2.y = 0.0; v2.z = 0.0;
	db_drawcylinder(v1, v2, 0.2, 1, GOOD_CYLINDER);
	db_drawsphere(v1, .22, 1, GOOD_SPHERE);
	db_drawsphere(v2, .22, 1, GOOD_SPHERE);

	v1.x = 0.0; v1.y = 0.0; v1.z = 1.0;
	v2.x = 0.0; v2.y = 0.0; v2.z = -1.0;
	db_drawcylinder(v1, v2, 0.2, 1, GOOD_CYLINDER);
	db_drawsphere(v1, .22, 1, GOOD_SPHERE);
	db_drawsphere(v2, .22, 1, GOOD_SPHERE);

	v1.x = -0.8; v1.y = -0.8; v1.z = -0.8;
	v2.x = 0.8; v2.y = 0.8; v2.z = 0.8;
	db_drawcylinder(v1, v2, 0.15, 2, GOOD_CYLINDER);
	db_drawsphere(v1, .17, 2, GOOD_SPHERE);
	db_drawsphere(v2, .17, 2, GOOD_SPHERE);

	v1.x = 0.8; v1.y = -0.8; v1.z = -0.8;
	v2.x = -0.8; v2.y = 0.8; v2.z = 0.8;
	db_drawcylinder(v1, v2, 0.15, 2, GOOD_CYLINDER);
	db_drawsphere(v1, .17, 2, GOOD_SPHERE);
	db_drawsphere(v2, .17, 2, GOOD_SPHERE);

	v1.x = -0.8; v1.y = -0.8; v1.z = 0.8;
	v2.x = 0.8; v2.y = 0.8; v2.z = -0.8;
	db_drawcylinder(v1, v2, 0.15, 2, GOOD_CYLINDER);
	db_drawsphere(v1, .17, 2, GOOD_SPHERE);
	db_drawsphere(v2, .17, 2, GOOD_SPHERE);

	v1.x = -0.8; v1.y = 0.8; v1.z = -0.8;
	v2.x = 0.8; v2.y = -0.8; v2.z = 0.8;
	db_drawcylinder(v1, v2, 0.15, 2, GOOD_CYLINDER);
	db_drawsphere(v1, .17, 2, GOOD_SPHERE);
	db_drawsphere(v2, .17, 2, GOOD_SPHERE);

	v1.x = 0.0; v1.y = 0.0; v1.z = 0.0;
	db_drawsphere(v1, .6, 3, GOOD_SPHERE);

#ifdef MSC
	getch();
#endif

	end_db_graphics();
}
