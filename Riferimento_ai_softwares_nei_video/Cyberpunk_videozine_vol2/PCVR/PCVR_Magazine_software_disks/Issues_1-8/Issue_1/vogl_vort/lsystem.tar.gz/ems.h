#define	EMS_PAGE_SIZE	16384
#define	EMS_NULL_HDL	0xFFFF

extern int EMS_rdy(void);
extern void far *EMS_base(void);
extern int EMS_count(void);
extern int EMS_alloc(int);
extern int EMS_map(int, int);
extern int EMS_release(int);
