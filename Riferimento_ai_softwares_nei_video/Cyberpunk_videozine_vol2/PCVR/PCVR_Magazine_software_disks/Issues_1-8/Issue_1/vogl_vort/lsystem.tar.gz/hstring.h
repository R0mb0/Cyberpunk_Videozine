/* string.h for huge strings */

char huge *hstrcat(char huge *, char huge *);
char huge *hstrchr(char huge *, int);
int hstrcmp(char huge *, char huge *);
char huge *hstrcpy(char huge *, char huge *);
long int hstrlen(char huge *);
char huge *hstrncat(char huge *, char huge *, long int);
int hstrncmp(char huge *, char huge *, long int);
char huge *hstrncpy(char huge *, char huge *, long int);
char huge *hstrrchr(char huge *, int);
