#include <math.h>
#include <memory.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "depthb.h"


light_source *lslist = NULL, *curl = NULL;
float lambient, backfacing;
int db_colors;
matrix4 tmatrix;
int proj;
int dbwidth, dbheight=-1;
float dbxcent, dbycent;
viewpars vpars;



float sign(float f)
{
	if (f > 0.0)
		return 1.0;
	else if (f < 0.0)
		return -1.0;
	else
		return 0.0;
}



void *db_memreq(int size)
{
	void *a;

	a=(void *)malloc(size);

	if (a==NULL) {
		printf("Unable to allocate %d bytes.\n", size);
		exit(-1);
		}

	return a;
}



dbpoly *alloc_dbpoly(int nsides)
{
	dbpoly *p;

	p = (dbpoly *) db_memreq(sizeof(dbpoly));
	p->v = (vector *) db_memreq(nsides * sizeof(vector));
	p->sides = nsides;

	return p;
}



void free_dbpoly(dbpoly *p)
{
	free(p->v);
	free(p);
}



void set_dbpolynormal(dbpoly *p, int wn)
{
	vector s1, s2;

	VECSUB(s1, p->v[1], p->v[0]);
	VECSUB(s2, p->v[2], p->v[1]);
	CROSS(p->n[wn], s1, s2);
	normalize(&p->n[wn]);
}



void transform_dbpoly(dbpoly *p)
{
	int i;
	vector4 o, t;

	for (i=0; i<p->sides; i++) {
		o.x = p->v[i].x;
		o.y = p->v[i].y;
		o.z = p->v[i].z;
		o.w = 1.0;

		m4apply4(&t, tmatrix, &o);

		p->v[i].x = t.x / t.w;
		p->v[i].y = t.y / t.w;
		p->v[i].z = t.z / t.w;
	}

	set_dbpolynormal(p, 1);
}



void transform_point(vector *v)
{
	vector4 o, t;

	o.x = v->x;
	o.y = v->y;
	o.z = v->z;
	o.w = 1.0;

	m4apply4(&t, tmatrix, &o);

	v->x = t.x / t.w;
	v->y = t.y / t.w;
	v->z = t.z / t.w;
}



void shade_dbpoly(dbpoly *p)
{
	float fsh, v;
	light_source *l;

	fsh = lambient;
	l = lslist;

	while (l != NULL) {
		v = - DOT(l->dir, p->n[0]);
		fsh += (v<=0.0)? 0.0 : (l->col * v);

		l = l->next;
	}

	if (fsh > 1.0)
		fsh = 1.0;

	fsh = (float) (256 / db_colors - 1) * (fsh + (float) p->col);

	p->col = (int) fsh;
}



void set_projection(int mode)
{
	matrix4 m1, m2, m3, m4, mt;
	vector vp, vt, up, xe, ye, ze;
	float t;

	vp = vpars.vpoint;
	vt = vpars.vtarget;
	up = vpars.worldup;

	VECSUB(vt, vt, vpars.vpoint);

	normalize(&vt);
	VECCOPY(ze, vt);

	normalize(&up);

	t = DOT(up, vt);

	if (t == 1.0) {
		/* vaffanculo, stronzo */
		exit(-1);
		}

	VECSCALE(vt, t, vt);
	VECSUB(up, up, vt);

	VECCOPY(ye, up);
	normalize(&ye);

	CROSS(xe, ze, ye);

	VECSCALE(vp, -1.0, vp);
	m4transl(m1, &vp);

	m4ident(m2);
	m2[0][0] = xe.x;
	m2[1][0] = ye.x;
	m2[2][0] = ze.x;
	m2[0][1] = xe.y;
	m2[1][1] = ye.y;
	m2[2][1] = ze.y;
	m2[0][2] = xe.z;
	m2[1][2] = ye.z;
	m2[2][2] = ze.z;

	m4rotate(m3, Z_AXIS, vpars.tilt);

	if (mode == PERSPECTIVE)
		m4perspective(m4, vpars.zoom, vpars.fcp, vpars.bcp);
	else
		m4orthographic(m4, vpars.zoom, vpars.fcp, vpars.bcp);

	proj = mode;

	m4ident(tmatrix);

	m4copy(mt, tmatrix);
	m4mult(tmatrix, m1, mt);
	m4copy(mt, tmatrix);
	m4mult(tmatrix, m2, mt);
	m4copy(mt, tmatrix);
	m4mult(tmatrix, m3, mt);
	m4copy(mt, tmatrix);
	m4mult(tmatrix, m4, mt);
}



void set_lightsource(vector dir, float it)
{
	light_source *l;

	l = db_memreq(sizeof(light_source));

	if (curl == NULL) {
		curl = l;
		lslist = l;
	} else {
		curl->next = l;
		curl = l;
	}

	l->dir = dir;
	normalize(&l->dir);

	l->col = it;
	l->next = NULL;
}



void remove_lights(void)
{
	light_source *l, *nl;

	l = lslist;

	while (l!=NULL) {
		nl = l->next;
		free(l);
		l = nl;
	}
}



void draw_dbpolylist(dbpoly *pl)
{
	while (pl != NULL) {
		db_drawpolygon(pl);

		pl = pl->next;
	}
}



void free_dbpolylist(dbpoly *pl)
{
	dbpoly *npl;

	while (pl != NULL) {
		npl = pl->next;

		free_dbpoly(pl);

		pl = npl;
	}
}



int read_parfile(char *pfn)
{
	FILE *pf;
	char s1[100], s2[100];
	int stat;
	vector l;
	float li;

	pf = fopen(pfn, "r");

	if (pf == NULL)
		return 0;

	/* some defaults */
	backfacing = 0;
	set_ambient(0.0);
	vpars.xres = 640;
	vpars.yres = 480;
	vpars.vpoint.x = 0.0;
	vpars.vpoint.y = 0.0;
	vpars.vpoint.z = 2.0;
	vpars.vtarget.x = 0.0;
	vpars.vtarget.y = 0.0;
	vpars.vtarget.z = 0.0;
	vpars.worldup.x = 0.0;
	vpars.worldup.y = 1.0;
	vpars.worldup.z = 0.0;
	vpars.zoom = 1.0;
	vpars.fcp = 1.0;
	vpars.bcp = 3.0;
	vpars.tilt = 0.0;

	stat = 1;

	while (1) {
		fgets(s1, 99, pf);

		if (feof(pf))
			break;

		sscanf(s1, "%s", s2);

		if (0==strcmp(s2, "resolution")) {
			if (2!=sscanf(s1+11, "%d %d", &vpars.xres, &vpars.yres)) {
				stat = 0;
				break;
			}
		} else if (0==strcmp(s2, "vpoint")) {
			if (3!=sscanf(s1+7, "%f %f %f", &vpars.vpoint.x, &vpars.vpoint.y,
					    &vpars.vpoint.z)) {
				stat = 0;
				break;
			}
		} else if (0==strcmp(s2, "vtarget")) {
			if (3!=sscanf(s1+8, "%f %f %f", &vpars.vtarget.x, &vpars.vtarget.y,
					    &vpars.vtarget.z)) {
				stat = 0;
				break;
			}
		} else if (0==strcmp(s2, "up")) {
			if (3!=sscanf(s1+3, "%f %f %f", &vpars.worldup.x, &vpars.worldup.y,
					    &vpars.worldup.z)) {
				stat = 0;
				break;
			}
		} else if (0==strcmp(s2, "light")) {
			if (4!=sscanf(s1+6, "%f %f %f %f", &li, &l.x, &l.y, &l.z)) {
				stat = 0;
				break;
			} else
				set_lightsource(l, li);

		} else if (0==strcmp(s2, "ambient")) {
			if (1!=sscanf(s1+8, "%f", &li)) {
				stat = 0;
				break;
			} else
				set_ambient(li);

		} else if (0==strcmp(s2, "zoom")) {
			if (1!=sscanf(s1+5, "%f", &vpars.zoom)) {
				stat = 0;
				break;
			}
		} else if (0==strcmp(s2, "fcp")) {
			if (1!=sscanf(s1+4, "%f", &vpars.fcp)) {
				stat = 0;
				break;
			}
		} else if (0==strcmp(s2, "bcp")) {
			if (1!=sscanf(s1+4, "%f", &vpars.bcp)) {
				stat = 0;
				break;
			}
		} else if (0==strcmp(s2, "backfacing")) {
			if (1!=sscanf(s1+11, "%f", &backfacing)) {
				stat = 0;
				break;
			}
		} else if (0==strcmp(s2, "tilt")) {
			if (1!=sscanf(s1+5, "%f", &vpars.tilt)) {
				stat = 0;
				break;
			}
		}

	}

	fclose(pf);

	return stat;
}
