/* definitions for polygon manipulation */

#ifndef VECTOR_DEFINED
typedef struct {float x, y, z;} vector;
#define VECTOR_DEFINED
#endif

typedef struct {int sides; int beg; vector n;} geopoly;

typedef struct {vector *vl; geopoly *pl; int *cl; int nv, np, nc, mv, mp, mc;}
			geometry;


geometry *alloc_geometry(int, int, int);
void free_geometry(geometry *);
geometry *readgeofile(FILE *);
void writegeofile(geometry *, FILE *);
geometry *copygeo(geometry *);
int addvertex(geometry *, vector);
int setvertex(geometry *, vector, int);
int addconn(geometry *, int);
int copypoly(geometry *, geometry *, int);
int addpoly(geometry *, int, vector *, int *);
