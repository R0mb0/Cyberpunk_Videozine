#include <math.h>
#include <malloc.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include "offlib.h"


#define VSUB(r, v1, v2)	(r).x=(v1).x-(v2).x; (r).y=(v1).y-(v2).y; (r).z=(v1).z-(v2).z;
#define VLEN(v1)  sqrt((v1).x*(v1).x + (v1).y*(v1).y + (v1).z*(v1).z)
#define DOT(v1, v2) ((v1).x*(v2).x + (v1).y*(v2).y + (v1).z*(v2).z)
#define VECTOR(r, v1, v2) (r).x=  (v1).y*(v2).z - (v1).z*(v2).y; \
					 (r).y=  (v1).z*(v2).x - (v1).x*(v2).z; \
					 (r).z=  (v1).x*(v2).y - (v1).y*(v2).x


static
void *memrequest(int size)
{
	void *a;

	a=(void *)malloc(size);

	if (a==NULL) {
		printf("Unable to allocate %d bytes.\n", size);
		exit(-1);
	}

	return a;
}



geometry *alloc_geometry(int nv, int np, int nc)
{
	geometry *g;

	g = (geometry *) memrequest(sizeof(geometry));
	g->vl = (vector *) memrequest(nv * sizeof(vector));
	g->pl = (geopoly *) memrequest(np * sizeof(geopoly));
	g->cl = (int *) memrequest(nc * sizeof(int));

	g->nv = 0;
	g->mv = nv;
	g->np = 0;
	g->mp = np;
	g->nc = 0;
	g->mc = nc;

	return g;
}



void free_geometry(geometry *g)
{
	free(g->vl);
	free(g->pl);
	free(g->cl);

	free(g);
}



geometry *readgeofile(FILE *pf)
{
	int sides, i, j, k;
	geometry *geo;
	vector *gvl;
	geopoly *gpl;
	int *gcl;

	if (3!=fscanf(pf, "%d %d %d", &i, &j, &k))
		return NULL;

	geo = alloc_geometry(i, j, k);

	geo->nv = geo->mv;
	geo->np = geo->mp;
	geo->nc = geo->mc;

	gvl = geo->vl;
	gpl = geo->pl;
	gcl = geo->cl;

	for (i=0; i<geo->mv; i++)
		if (3!=fscanf(pf, "%f %f %f", &gvl[i].x, &gvl[i].y, &gvl[i].z))
			return NULL;

	j=0;

	for (i=0; i<geo->np; i++) {
		if (0==fscanf(pf, "%d", &sides))
			return NULL;

		gpl[i].sides = sides;
		gpl[i].beg = j;

		for (k=0; k<sides; k++) {

			if (j==geo->nc) {
				puts("Error in connectivity definition.");
				exit(-1);
			}

			if (0==fscanf(pf, "%d", &gcl[j]))
				return NULL;

			gcl[j]--;
			j++;
		}
	}

	return geo;
}



void writegeofile(geometry *geo, FILE *pf)
{
	int i, j;

	fprintf(pf, "%d %d %d\n", geo->nv, geo->np, geo->nc);

	for (i=0; i<geo->nv; i++)
		 fprintf(pf, "%f %f %f\n", geo->vl[j].x, geo->vl[j].y, geo->vl[j].z);

	for (i=0; i<geo->np; i++) {
		fprintf(pf, "%d", geo->pl[i].sides);

		for (j=0; j<geo->pl[i].sides; j++)
			fprintf(pf, " %d", 1 + geo->cl[geo->pl[i].beg+j]);
	}
}



geometry *copygeo(geometry *og)
{
	geometry *g;

	g = alloc_geometry(og->nv, og->np, og->nc);

	memcpy(g->vl, og->vl, og->nv * sizeof(vector));
	memcpy(g->cl, og->cl, og->nc * sizeof(int));
	memcpy(g->pl, og->pl, og->np * sizeof(geopoly));

	return g;
}



int addvertex(geometry *g, vector v)
{
	if (g->nv == g->mv)
		return 0;

	g->vl[g->nv] = v;
	g->nv++;
}



int setvertex(geometry *g, vector v, int force)
{
	int i;

	if (!force) {
		for (i=0; i<g->nv; i++)
			if (v.x == g->vl[i].x &&
			    v.y == g->vl[i].y &&
			    v.z == g->vl[i].z)	 /* it's already in there */

				return i+1;
	}
	/* must add the vert */
	if (!addvertex(g, v))
		return 0;

	return g->nv;
}



int addconn(geometry *g, int vo)
{
	if (g->nv == g->mv)
		return 0;

	g->cl[g->nc] = vo;
	g->nc++;

	return 1;
}



int copypoly(geometry *g, geometry *og, int pn)
{
	int i, j;

	if (g->np == g->mp)
		return 0;

	g->pl[g->np].sides = og->pl[pn].sides;
	g->pl[g->np].n = og->pl[pn].n;

	g->pl[g->np].beg = g->nc;

	g->np++;

	for (i=0; i<og->pl[pn].sides; i++) {
		j = setvertex(g, og->vl[og->cl[og->pl[pn].beg + i] - 1], 0);

		if (j==0)
			return 0;

		if (addconn(g, j) == 0)
			return 0;
	}

	return 1;
}



int addpoly(geometry *g, int sid, vector *vs, int *force)
{
	int i, j;

	if (g->np == g->mp)
		return 0;

	g->pl[g->np].sides = sid;

	g->pl[g->np].beg = g->nc;

	g->np++;

	for (i=0; i<sid; i++) {
		j = setvertex(g, vs[i], force[i]);

		if (j==0)
			return 0;

		if (addconn(g, j) == 0)
			return 0;
	}

	return 1;
}
