#include <math.h>
#include <time.h>
#include <memory.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "depthb.h"

#include <vort.h>



unsigned char rm[256], gm[256], bm[256], ml[2048];

char imgname[40];
unsigned char *db_img;

unsigned int *db_depth;


static
int alloc_depthbuffer(int width, int height)
{
	long total;

	if (dbheight != -1)
		return 0;

	total = (long)sizeof(unsigned int) * (long)width * (long)height;

	db_depth = (unsigned int *)malloc(total);

	if (db_depth == NULL)
		return 0;

	memset(db_depth, 0xff, total);

	dbwidth = width;
	dbheight = height;
	dbxcent = (float)dbwidth / 2.0;
	dbycent = (float)dbheight / 2.0;

	return 1;
}



static
void free_depthbuffer(void)
{
	free(db_depth);
}



int db_plotpoint(int x, int y, float depth, int col)
{
	long int t;
	unsigned int d;

	if (x<0 || x>=dbwidth || y<0 || y>=dbheight || depth<0.0 || depth>1.0)
		return 0;

	d = (unsigned int) (depth * 65535.0 + 0.5);

	t = ( (long)x + (long)y *(long)dbwidth );

	if (db_depth[t] >= d) {
		db_depth[t] = d;

		db_img[t] = col;
	} else
		return 0;
}



void db_hline(int y, float x0, float z0, float x1, float z1, int color)
{
	int ix0, ix1;
	register int x;
	float dzdx;
	register float z;
	long int t;
	register unsigned int d;
	register unsigned int *dp;
	register unsigned char *ip;

	if (y<0 || y>=dbheight)
		return;

	ix0 = (int) x0;
	ix1 = (int) x1;

	if ( (ix0<0 && ix1<0) || (ix0>dbwidth && ix0>dbwidth) )
		return;

	if ( (z0<0.0 && z1<0.0) || (z0>1.0 && z1>1.0) )
		return;

	if (ix0 == ix1) {
		db_plotpoint(ix0, y, z0, color);
		return;
	}

	z = z0;
	dzdx = (z1 - z0) / (x1 - x0);

	if (ix1 >= dbwidth)
		ix1 = dbwidth - 1;

	t = ( (long) ((ix0<0)? 0 : ix0) + (long)y * (long)dbwidth );
	dp = db_depth + t;
	ip = db_img + t;

	for (x=ix0; x<=ix1; x++)
		if (x<0)
			z += dzdx;
		else {
			if (z>=0.0 && z<=1.0) {
				d = (unsigned int) (z * 65535.0 + 0.5);

				if ((*dp) >= d) {
					(*dp) = d;

					(*ip) = color;
				}
			}

			dp++;
			ip++;

			z += dzdx;
		}

}



int start_db_graphics(int nc, color *cols, char *nm)
{
	int i, j, r, c;
	float rc, gc, bc, l;

	c = vpars.xres;
	r = vpars.yres;

	if (nc != 4 && nc != 8)
		return 0;

	db_colors = nc;

	puts("Starting depth buffer graphics.");

	if (!alloc_depthbuffer(c, r))
		return 0;

	db_img = (unsigned char *) malloc((long)r * (long)c);

	if (db_img == NULL)
		return 0;

	memset(db_img, 0, (long)r * (long)c);

	if (nc == 4) {
		for (j=0; j<4; j++)
			for (i=0; i<64; i++) {
				l = (float)i/63.0;

				rc = cols[j].r * l;
				gc = cols[j].g * l;
				bc = cols[j].b * l;

				rm[j*64 + i] = (int) (rc * 255.0 + .5);
				gm[j*64 + i] = (int) (gc * 255.0 + .5);
				bm[j*64 + i] = (int) (bc * 255.0 + .5);
			}
	} else {
		for (j=0; j<8; j++)
			for (i=0; i<32; i++) {
				l = (float)i/31.0;

				rc = cols[j].r * l;
				gc = cols[j].g * l;
				bc = cols[j].b * l;

				rm[j*32 + i] = (int) (rc * 255.0 + .5);
				gm[j*32 + i] = (int) (gc * 255.0 + .5);
				bm[j*32 + i] = (int) (bc * 255.0 + .5);
			}
	}

	init_prims();

	strcpy(imgname, nm);

	return 1;
}



void end_db_graphics(void)
{
	image *iout;
	int l;
	long int o;

	if (dbheight == -1)
		return;

	puts("Ending depth buffer graphics.");

	uninit_prims();
	free_depthbuffer();

	/* output the image */
	if ( (iout=openimage(imgname, "w"))==(image *)NULL ) {
		puts("Can't open output file.");
		exit(-1);
	}

	/* init pix info */
	imagetype(iout) = PIX_RLECMAP;
	imagewidth(iout) = dbwidth;
	imageheight(iout) = dbheight;
	imagedepth(iout)= 24; /* really? */
	imagedate(iout) = time((time_t *)NULL);
	imagebackgnd(iout).r = 0;
	imagebackgnd(iout).g = 0;
	imagebackgnd(iout).b = 0;
	titlelength(iout) = 0;
	imagefragment(iout) = 0;
	setcmap(iout, 256, rm, gm, bm);
	writeheader(iout);

	for (l=0, o=0L; l<dbheight; l++, o+=(long)dbwidth)
		writemappedline(iout, db_img + o);

	closeimage(iout);

	free(db_img);

	dbheight = -1;
}
