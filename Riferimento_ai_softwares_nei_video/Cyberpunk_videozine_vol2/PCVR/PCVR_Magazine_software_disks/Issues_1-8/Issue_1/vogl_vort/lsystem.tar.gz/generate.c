#include "lsystem.h"



char HUGE *derive(int dplev, production *prodset)
{
	char HUGE *curpntr, HUGE *nextpntr, HUGE *temppntr;
	char HUGE *string1, HUGE *string2;
	char HUGE *limpntr1,HUGE *limpntr2, HUGE *curlimp;
	int j;

	string1 = alloc_string();
	string2 = alloc_string();

	limpntr1 = string1 + ((long)MAX_STR - 1L);
	limpntr2 = string2 + ((long)MAX_STR - 1L);

	hstrcpy(string1, axiom);

	for (j = 1; j <= dplev; j++) {
		fprintf(stderr,"Computing derivation step %d\r", j);
		curpntr = string1;
		nextpntr = string2;
		curlimp = limpntr2;
		while (*curpntr != '\0') {
			applyprod(&curpntr, &nextpntr, &curlimp,
			findprod(curpntr, prodset, ignore));
			*nextpntr = '\0';
		}

		/* swap string2 with string1 and so their limits */
		temppntr = string1;
		string1 = string2;
		string2 = temppntr;

		temppntr = limpntr1;
		limpntr1 = limpntr2;
		limpntr2 = temppntr;
	}

	return(string1);
}



void applyprod(char HUGE **curhndl, char HUGE **nexthndl, char HUGE **limpntr,
			production *prodpntr)
{
	int index;

	if (prodpntr != NULL) {
		/* if we have more than one successor we choice our stocastly */
		if (prodpntr->numsucc == 1)
			index = 0;
		else index = stocaschoice(prodpntr);

		/* check we aren't going to break upper limit */
		if ((*nexthndl + prodpntr->listsucc[index].succlen) > *limpntr) {
			fprintf (stderr, "\nApplyprod: string too long\n");
			exit(-3);
		}

		hstrcpy(*nexthndl, prodpntr->listsucc[index].succ);
		*curhndl += prodpntr->predlen;
		*nexthndl += prodpntr->listsucc[index].succlen;
	}
	else {
		/* we have no matching production, so we copy a char; but first
		** check upper limit */
		if ((*nexthndl + 1) > *limpntr) {
			fprintf (stderr, "\nApplyprod: string too long\n");
			exit(-3);
		}

		**nexthndl = **curhndl;
		++(*nexthndl);
		++(*curhndl);
	}
}


int stocaschoice(production *prodpntr)
{
	double randnum;
	int i = 0;

	randnum = (double)rand() / (double)RAND_MAX;

	while(prodpntr->listsucc[i].prob < randnum)
		i++;

	return(i);
}


production *findprod(curpntr, prodset, ignore)
char *curpntr;
production prodset[];
char ignore[];
{
	while (prodset->predlen != 0) {
		if (prefix(prodset->pred, curpntr) ||
		rcondiff(prodset->rcon, curpntr + prodset->predlen, ignore) ||
		lcondiff(prodset->lcon + prodset->lconlen - 1, curpntr -1, ignore))
			++prodset;
		else
			return(prodset);
	}
	return(NULL);
}



int prefix (s1, s2)
char *s1, *s2;
{
	while (*s1 != '\0')
		if (*s2++ != *s1++)
			return(TRUE);

	return(FALSE);
}



int rcondiff(s1, s2, ignore)
char *s1, *s2;
char ignore[];
{
	while (TRUE) {
		if (*s1 == '\0')
			return(FALSE);
		if(ignore[*s2])
			s2++;
		else if (*s2 == '[')
			s2 = skipright(s2 + 1) + 1;
		else if (*s1++ != *s2++)
			return(TRUE);
	}
}



int lcondiff(s1, s2, ignore)
char *s1, *s2;
char ignore[];
{
	while (TRUE) {
		if (*s1 == '\0')
			return(FALSE);
		if(ignore[*s2] || (*s2 == '['))
			s2--;
		else if (*s2 == ']')
			s2 = skipleft(s2);
		else if (*s1-- != *s2--)
			return(TRUE);
	}
}



char *skipright(s)
char *s;
{
	int level = 0;

	while (*s != '\0') {
		switch (*s) {
			case '[': ++level;
					break;
			case ']': if (level == 0)
						return(s);
					else
						--level;
					break;
			default:	break;
		}
		s++;
	}

	return(s);
}



char *skipleft(s)
char *s;
{
	int level = 0;

	s--;
	while (*s != '\0') {
		switch (*s) {
			case ']': ++level;
					break;
			case '[': if (level == 0)
						return(--s);
					else
						--level;
					break;
			default:	break;
		}
		s--;
	}

	return(s);
}
