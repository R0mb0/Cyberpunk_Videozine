#include "lsystem.h"


typedef struct {vector dir, pos; matrix4 mat; int tstat; float tvars[10];}
	   tsentry;

tsentry *tstack;
int tstackp;

int tstatus;
matrix4 tmat, drmat[6];



void initturtle(int mode, char *n)
{
	int i;

	m4ident(tmat);

	tdir.x = 1.0;
	tdir.y = 0.0;
	tdir.z = 0.0;

	tpos.x = 0.0;
	tpos.y = 0.0;
	tpos.z = 0.0;

	tstack = (tsentry *) malloc(MAX_STACKENTRIES * sizeof(tsentry));

	if (tstack == NULL) {
		puts("Couldn't allocate turtle stack.");
		exit(-1);
		}

	tstackp = 0;

	if (mode == 0) { /* art output */
		output_begin = art_init_output;
		output_move = art_output_move;
		output_rotate = art_output_rotate;
		output_end = art_end_output;

	} else if (mode ==1) { /* depthb output */
		output_begin = depthb_init_output;
		output_move = depthb_output_move;
		output_rotate = depthb_output_rotate;
		output_end = depthb_end_output;
	} else {
		puts("Illegal turtle mode.");
		exit(-1);
	}

	output_begin(n);
	set_defaultrot(0.0);

	tstatus = T_NOMOVE;

	for (i=0; i<10; i++)
		tvars[i] = 0.0;

	tvars[2] = 1.0;

	tvars[5] = TO_CYLINDER;
	tvars[6] = TO_SPHERE;

	tvars[10] = diststrength;
}



void set_defaultrot(float a)
{
	m4rotate(drmat[0], X_AXIS, a);
	m4rotate(drmat[1], X_AXIS, -a);
	m4rotate(drmat[2], Y_AXIS, a);
	m4rotate(drmat[3], Y_AXIS, -a);
	m4rotate(drmat[4], Z_AXIS, a);
	m4rotate(drmat[5], Z_AXIS, -a);
}



void endturtle(void)
{
	free(tstack);

	output_end();
}



void get_axis(int ax, vector *a)
{
	if (ax == X_AXIS)
		(*a) = tdir;
	else
		m4apply(a, tmat, &axes[ax]);
}



void move_forward(vector *from, vector *to, float mov)
{
	vector mv;

	*from = tpos;

	VECSCALE(mv, mov, tdir);

	VECADD(tpos, mv, tpos);

	*to = tpos;
}



void rotate_turtle(vector *od, vector *nd, int axis, float ang)
{
	matrix4 m, m1;

	(*od) = tdir;

	if (axis >= XP_DEFAULT && axis <= ZM_DEFAULT)
		m4copy(m, drmat[axis-XP_DEFAULT]);
	else
		m4rotate(m, axis, ang);

	m4copy(m1, tmat);

	m4mult(tmat, m1, m);

	m4apply(&tdir, tmat, &axes[X_AXIS]);

	(*nd) = tdir;
}



void apply_distortion(vector *f, vector *t)
{
	if (distmode == TD_NONE)
		return;

	else if (distmode == TD_ROTATE) {

		vector v1, ra, t1;
		matrix4 m1d, m1i, m2, tm;
		float ang, c, s;

		VECSUB(v1, *t, *f);

		CROSS(ra, distdir, v1);

		ang = tvars[10] * DOT(ra, ra);

		normalize(&ra);

		get_axis(Y_AXIS, &v1);

		/* Why this normalize is needed isn't easy to explain */
		normalize(&v1);

		/* generate the rotation to align Y axis */
		m4ident(m1d);
		m4ident(m1i);

		c = DOT(v1, ra);

		s = 1.0 - c*c;

		if (s<0.0)
			s = 0.0;

		s = sqrt(s);

		CROSS(t1, v1, ra);

		if (DOT(tdir, t1) < 0.0)
			s = -s;

		m1d[1][1] = c;
		m1d[1][2] = -s;
		m1d[2][1] = s;
		m1d[2][2] = c;

		m1i[1][1] = c;
		m1i[1][2] = s;
		m1i[2][1] = -s;
		m1i[2][2] = c;

		m4rotate(m2, Y_AXIS, -ang);

		m4copy(tm, tmat);
		m4mult(tmat, tm, m1d);
		m4mult(tm, tmat, m2);
		m4mult(tmat, tm, m1i);

		m4apply(&tdir, tmat, &axes[X_AXIS]);
	}
}



int push_turtle(void)
{
	if (tstackp == MAX_STACKENTRIES)
		return 0;

	tstack[tstackp].dir = tdir;
	tstack[tstackp].pos = tpos;
	m4copy(tstack[tstackp].mat, tmat);
	tstack[tstackp].tstat = tstatus;
	memcpy(tstack[tstackp].tvars, tvars, 10 * sizeof(float));

	tstackp++;

	return 1;
}



int pull_turtle(void)
{
	if (tstackp == 0)
		return 0;

	tstackp--;

	tdir = tstack[tstackp].dir;
	tpos = tstack[tstackp].pos;
	m4copy(tmat, tstack[tstackp].mat);
	tstatus = tstack[tstackp].tstat;
	memcpy(tvars, tstack[tstackp].tvars, 10 * sizeof(float));

	return 1;
}



void flush_output(void)
{
	if (tstatus == T_DOPOLY)
		operate_turtle(T_ENDPOLY, 0, 0.0);

	tstatus = T_NOMOVE;
}



void operate_turtle(int what, int par1, float par2)
{
	static float oparms[6];
	vector v1, v2;

	switch(what) {
	case T_ROTATE:
		rotate_turtle(&v1, &v2, par1, par2);

		if (tstatus == T_NOMOVE) {

			oparms[0] = tvars[6];
			oparms[1] = tvars[2] * tvars[7];
			oparms[2] = tvars[2] * tvars[8];
			oparms[3] = tvars[2] * tvars[9];

			oparms[4] = tvars[4];
			oparms[5] = tvars[3];

			output_rotate(v1, v2, oparms);
			tstatus = T_ROTATE;
		}
		break;

	case T_DRAW:
	case T_MOVE:
		move_forward(&v1, &v2, par2);

		if (tstatus == T_NOMOVE || tstatus == T_ROTATE) {
			if (what == T_DRAW) {
				apply_distortion(&v1, &v2);

				oparms[0] = tvars[5];
				oparms[1] = tvars[2] * tvars[7];
				oparms[2] = tvars[2] * tvars[8];
				oparms[3] = tvars[2] * tvars[9];

				oparms[4] = tvars[4];
				oparms[5] = tvars[3];

				output_move(v1, v2, oparms);
			}
			tstatus = T_NOMOVE;

		} else if (tstatus == T_DOPOLY)
			output_move(v1, v2, oparms);

		break;

	case T_SETPOINT:
		v1 = tpos;
		v2 = tpos;

		output_move(v1, v2, oparms);
		break;

	case T_BEGPOLY:
		oparms[0] = TO_POLYEDGE;

		oparms[4] = tvars[4];
		oparms[5] = tvars[3];

		tstatus = T_DOPOLY;
		break;

	case T_ENDPOLY:
		oparms[0] = TO_POLYEND;

		output_move(v1, v2, oparms);

		tstatus = T_NOMOVE;
		break;

	case T_BEGUPOLY:
		oparms[0] = TO_POLYEDGE;

		oparms[4] = tvars[4];
		oparms[5] = tvars[3];

		tstatus = T_DOUPOLY;
		break;
	}
}
