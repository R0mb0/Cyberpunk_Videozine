#include "lsystem.h"

/* output to file in art format */

float polyparms[6];
int outpoly;
FILE *artf;

void art_init_output(char *fn)
{
	artf = fopen(fn, "w");

	if (artf == NULL) {
		puts("Couldn't open output file.");
		exit(-1);
	}

	outpoly = 0;
}



void art_output_details(float *p)
{
	int i;

	i = (int) p[0];

	fprintf(artf, "\tcolor %g, %g, %g\n", colortable[i].r, colortable[i].g,
			    colortable[i].b);

	i = (int) p[1];

	fprintf(artf, descr[i]);
}



void art_output_move(vector f, vector t, float *p)
{
	int prim;

	prim = (int) p[0];

	switch(prim) {
	case TO_NULL:
		break;

	case TO_CYLINDER:
		fprintf(artf, "cylinder {\n");
		art_output_details(p+4);
		fprintf(artf, "\tcenter(%f, %f, %f)\n", f.x, f.y, f.z);
		fprintf(artf, "\tcenter(%f, %f, %f)\n", t.x, t.y, t.z);
		fprintf(artf, "\tradius %f\n}\n\n", p[1]);
		break;

	case TO_POLYEDGE:
		if (!outpoly) {
			outpoly = 1;
			fprintf(artf, "polygon {\n");
			memcpy(polyparms, p, 6*sizeof(float));
			art_output_details(p+4);
			}

		fprintf(artf, "\tvertex(%f, %f, %f)\n", f.x, f.y, f.z);
		break;

	case TO_POLYEND:
		if (outpoly)
			fprintf(artf, "}\n\n");

		outpoly = 0;
		break;
	}
}



void art_output_rotate(vector f, vector t, float *p)
{
	int prim;

	prim = (int) p[0];

	if (prim == TO_NULL)
		return;

	switch(prim) {
	case TO_SPHERE:
		fprintf(artf, "sphere {\n");
		art_output_details(p+4);
		fprintf(artf, "\tcenter(%f, %f, %f)\n", tpos.x, tpos.y, tpos.z);
		fprintf(artf, "\tradius %f\n}\n\n", p[1]);
		break;
	}
}



void art_end_output(void)
{
	fclose(artf);
}




/* output on screen/pix via depthb.c routines */

dbpoly *dbp;


void depthb_init_output(char *vf)
{
	if (!read_parfile(vf)) {
		printf("Error reading view file %s.\n", vf);
		exit(-1);
	}

	if (!start_db_graphics(8, colortable, "lsystem.pix")) {
		puts("Couldn't start depth buffer.");
		exit(-1);
	}

	set_projection(ORTHOGRAPHIC);

	dbp = alloc_dbpoly(MAX_POLYSIDES);
}



void depthb_output_move(vector f, vector t, float *p)
{
	int prim;

	prim = (int) p[0];

	switch(prim) {
	case TO_NULL:
	    break;

	case TO_CYLINDER:
		db_drawcylinder(f, t, p[1], (int)p[4], BAD_CYLINDER);
		break;

	case TO_POLYEDGE:
		if (!outpoly) {
			outpoly = 1;

			dbp->sides = 0;
			dbp->trf = 0;
			dbp->col = (int) p[4];
		}

		dbp->v[dbp->sides++] = f;

		if (dbp->sides == MAX_POLYSIDES) {
			sprintf(errstr, "Too many edges in filled polygon");
			do_error();
		}
		break;

	case TO_POLYEND:
		if (outpoly)
			if (dbp->sides > 2) {
				set_dbpolynormal(dbp, 0);
				db_drawpolygon(dbp);
			}

		outpoly = 0;
		break;
	}
}



void depthb_output_rotate(vector f, vector t, float *p)
{
	int prim;

	prim = (int) p[0];

	switch(prim) {
	case TO_NULL:
		break;

	case TO_SPHERE:
		db_drawsphere(tpos, p[1], (int)p[4], BAD_SPHERE);
		break;
	}
}



void depthb_end_output(void)
{
	free_dbpoly(dbp);
	end_db_graphics();
}

