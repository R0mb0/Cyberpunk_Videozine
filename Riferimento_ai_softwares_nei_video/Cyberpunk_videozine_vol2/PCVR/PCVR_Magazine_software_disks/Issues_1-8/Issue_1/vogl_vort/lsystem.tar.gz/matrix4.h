#ifndef VECTOR_DEFINED
typedef struct {float x, y, z;} vector;
#define VECTOR_DEFINED
#endif
typedef struct {float x, y, z, w;} vector4;

typedef float matrix4[4][4];

#define VECADD(r, v1, v2) { (r).x = (v1).x + (v2).x; (r).y = (v1).y + (v2).y; \
					   (r).z = (v1).z + (v2).z; }
#define VECSUB(r, v1, v2) { (r).x = (v1).x - (v2).x; (r).y = (v1).y - (v2).y; \
					   (r).z = (v1).z - (v2).z; }
#define VECCOPY(r, v1) { (r).x = (v1).x; (r).y = (v1).y; (r).z = (v1).z; }
#define VECSCALE(r, s, v1) { (r).x = s * (v1).x;	(r).y = s * (v1).y; \
					    (r).z = s * (v1).z; }
#define DOT(v1, v2) ( (v1).x * (v2).x + (v1).y * (v2).y + (v1).z * (v2).z )
#define CROSS(r, v1, v2) { (r).x = (v1).y * (v2).z - (v1).z * (v2).y; \
					  (r).y = (v1).z * (v2).x - (v1).x * (v2).z; \
					  (r).z = (v1).x * (v2).y - (v1).y * (v2).x; }
#define NORM(v1) sqrt(DOT(v1, v1))


#ifndef PI
#define PI 3.14159265358979323846
#endif

#ifndef PI2
#define PI2 6.28318530717958647692
#endif


#define X_AXIS 0
#define Y_AXIS 1
#define Z_AXIS 2

#ifndef MATRIX4_MODULE
extern vector axes[3];
#endif


void normalize(vector *);
void m4ident(matrix4);
void m4transl(matrix4, vector *);
void m4rotate(matrix4, int, float);
void m4perspective(matrix4, float, float, float);
void m4orthographic(matrix4, float, float, float);
void m4print(matrix4);
void m4apply(vector *, matrix4, vector *);
void m4apply4(vector4 *, matrix4, vector4 *);
void m4add(matrix4, matrix4, matrix4);
void m4copy(matrix4, matrix4);
void m4sub(matrix4, matrix4, matrix4);
void m4mult(matrix4, matrix4, matrix4);
