#include "lsystem.h"



void inititoken(void)
{
	int i;

	for (i = 0; i < MAX_ITOKEN; i++) {
		itoken[i].type = UNDEF;
		itoken[i].curr = 0;
	}

	i = 0;

	strcpy(itoken[i].name, "#INIT_STRING:"); itoken[i++].evaluate = getstring;
	strcpy(itoken[i].name, "#TITLE:"); itoken[i++].evaluate = getstring;
	strcpy(itoken[i].name, "#AXIOM:"); itoken[i++].evaluate = getstring;
	strcpy(itoken[i].name, "#IGNORE:"); itoken[i++].evaluate = getstring;
	strcpy(itoken[i].name, "#RAND_SEED:"); itoken[i++].evaluate = getinteger;
	strcpy(itoken[i].name, "#DEPTH_LEVEL:"); itoken[i++].evaluate = getinteger;
	strcpy(itoken[i].name, "#PRODUCTIONS1:"); itoken[i++].evaluate = getprod;
	strcpy(itoken[i].name, "#PRODUCTIONS2:"); itoken[i++].evaluate = getprod;
	strcpy(itoken[i].name, "#PRODUCTIONS3:"); itoken[i++].evaluate = getprod;
	strcpy(itoken[i].name, "#PRODUCTIONS4:"); itoken[i++].evaluate = getprod;
	strcpy(itoken[i].name, "#COLORS:"); itoken[i++].evaluate = getcol;
	strcpy(itoken[i].name, "#MATERIALS:"); itoken[i++].evaluate = getmat;
	strcpy(itoken[i].name, "#SUBROUTINES:"); itoken[i++].evaluate = getsub;
	strcpy(itoken[i].name, "#DISTORTION:"); itoken[i++].evaluate = getdist;
	strcpy(itoken[i].name, ""); itoken[i++].evaluate = NULL;
}



void readinfile(char *fn)
{
	inf = fopen(fn, "r");

	if (inf == NULL) {
		printf("Couldn't read l-system file %s.\n", fn);
		exit(-1);
	}

	printf("Reading L-system definition from %s.\n", fn);

	inititoken();

	infline = 0;
	alreadygotline = FALSE;

	parseinput();

	setinput();

	fclose(inf);
}




void writelfile(char HUGE *hstr, char *fn)
{
	FILE *f;
	long int l, o;
	char temp[1030];

	f = fopen(fn, "w");

	if (f == NULL) {
		printf("Couldn't open %s for output.\n", fn);
		exit(-1);
	}

	printf("Writing L-system data to %s.\n", fn);

#ifdef MSC
	l = hstrlen(hstr);

	fprintf(f, "%ld\n", l);

	for (o=0L; l>=1024; o+=1024, l-=1024) {
		hstrncpy(temp, hstr+o, 1024);
		fwrite(temp, 1, 1024, f);
	}

	if (l != 0L) {
		hstrcpy(temp, hstr+o);
		fwrite(temp, 1, (int)l, f);
	}
#else
	l = strlen(lstring);

	fprintf(f, "%ld\n", l);

	fwrite(hstr, 1, l, f);
#endif

	fclose(f);
}



char HUGE *readlfile(char *fn)
{
	FILE *f;
	long int l, o;
	char temp[1030];
	char HUGE *hstr;

	hstr = alloc_string();

	f = fopen(fn, "r");

	if (f == NULL) {
		printf("Couldn't open %s for input.\n", fn);
		exit(-1);
	}

	printf("Reading L-system data from %s.\n", fn);

#ifdef MSC
	if (1 != fscanf(f, "%ld\n", &l)) {
		printf("%s is not a valid data file\n", fn);
		exit(-1);
	}

	for (o=0L; l>=1024; o+=1024, l-=1024) {
		fread(temp, 1, 1024, f);
		hstrcpy(hstr+o, temp);
	}

	if (l != 0L) {
		fread(temp, 1, (int)l, f);
		temp[(int)l] = 0;
		hstrcpy(hstr+o, temp);
	} else
		hstr[o]=0;
#else
	fscanf(f, "%ld\n", &l);

	fread(hstr, 1, l, f);
	hstr[l]=0;
#endif

	fclose(f);

	return hstr;
}



char getichar(void)
{
	char c;

	if (gicgetline)
		getdataline();

	c = iline[ilineptr++];
	if (c == '\n')
		gicgetline = TRUE;

	return c;
}


void getdataline(void)
{
	do
		getnextline();
	while (iline[0] == '\n');
}



void getnextline(void)
{
	do
		if (!alreadygotline) {
			fgets(iline, MAXINSTR, inf);

			if (feof(inf)) {
				sprintf(errstr, "EOF encountered before '&' terminator");
				ERROR;
			}

			infline++;
		}
		else
			alreadygotline = FALSE;
	while (iline[0] == '%'); /* skip comment lines */

	ilineptr = 0;

	gicgetline = FALSE;
}



void parseinput(void)
{
	char token[MAX_LENTOKEN];
	int tk;

	alreadygotline = FALSE;

	while (1) {
		getnextline();

		if (iline[0] == '\n')  /* skip blank lines */
			continue;

		if (iline[0] == '&')
			break;

		if (iline[0] != '#') {
			sprintf(errstr, "Token expected");
			ERROR;
		}

		for (ilineptr = 0; (ilineptr < MAX_LENTOKEN) &&
			(!isspace(token[ilineptr] = iline[ilineptr]));
			ilineptr++);

		token[ilineptr] = 0;

		tk = recontoken(token);

		if (tk == -1) {
			sprintf(errstr, "%s: Unknown token", token);
			ERROR;
		}

		(itoken[tk].evaluate)(tk);
	}
}




void proceedtotoken(void)
{
	while(iline[0] != '#')
		getnextline();

	alreadygotline = TRUE;
}



int recontoken(char *tokens)
{
	int tkn;

	for (tkn = 0; itoken[tkn].name[0] != 0; tkn++)
		if (0 == strcmp(tokens, itoken[tkn].name))
			break;

	if (itoken[tkn].name[0] == 0)
		tkn = -1;

	return tkn;
}



int checkdefine(int tkp)   /* token list is assumed to be itoken */
{
	if (itoken[tkp].type != UNDEF) {
		printf("\"%s\" Redefinition at line %d\n", itoken[tkp].name, infline);
		return TRUE;
	}
	return FALSE;
}



int pullstring(char *s, int slim, int eol)
{
	char c;
	int i, skip;

	c = getichar();

	while (isspace(c))
		c = getichar();

	i = 0;
	skip = 0;

	if (c == '"') {
		eol = 2;
		c = getichar();
	}

	while (TRUE) {
		if ((eol == 0) && isspace(c))
			break;
		if ((eol == 1) && (c == '\n'))
			break;
		if ((eol == 2) && (c == '"'))
			break;
/*
		if ((c == '\n') && (eol == 2) && (skip == 0)) {
			sprintf(errstr, "Newline in delimited string");
			WARNING;
			c=' ';
		}
*/

		if (skip == 0) {
			s[i++] = c;

			if (i == slim) {
				skip = 1;
				sprintf(errstr, "String too long, truncating");
				WARNING;
			}
		}

		c = getichar();
	}

	s[i] = 0;

	return strlen(s);
}



int pullinteger(void)
{
	char idat[20], c;
	int i;

	c = getichar();

	while (isspace(c))
		c = getichar();

	i = 0;

	while (isdigit(c) || (c == '+') || (c == '-')) {
		idat[i++] = c;
		c = getichar();
	}

	if (i == 0) {
		sprintf(errstr, "Error getting integer value: 0 assumed");
		WARNING;
		return 0;
	}

	idat[i] = 0;

	return atoi(idat);
}


float pullfloat(void)
{
	char fdat[20], c;
	int i;

	c = getichar();

	while (isspace(c))
		c = getichar();

	i = 0;

	while (isdigit(c) || (c=='.') || (c=='+') || (c=='-')) {
		fdat[i++] = c;
		c = getichar();
	}

	if (i == 0) {
		sprintf(errstr, "Error getting float value: 0 assumed");
		WARNING;
		return 0.0f;
	}

	fdat[i] = 0;

	return atof(fdat);
}


/*
** function for input of:
** strings, integers, productions, colors, materials, subroutines.
** A redefinition of string, integer, production erase the old values.
** color and materials have default values.
** A redefinition of subroutines stop the program.
*/

void getstring(int tkp)
{
	char str[MAX_LINE];
	int i;

	if (checkdefine(tkp))
		free(itoken[tkp].v.str);

	i = pullstring(str, MAX_LINE, 1);

	if (strlen(str) == 0) {
		sprintf(errstr, "%s 0-len string argument", itoken[tkp].name);
		WARNING;
	}
	itoken[tkp].type = STRING;
	itoken[tkp].v.str = memrequest(i+1);
	strcpy(itoken[tkp].v.str, str);

}



void getinteger(int tkp)
{
	if (checkdefine(tkp))
		free(itoken[tkp].v.val);

	itoken[tkp].type = INTEGER;
	itoken[tkp].v.val = (int *)memrequest(sizeof(int));
	*itoken[tkp].v.val = pullinteger();
}




void getprod(int tkp)
{
	production *ppntr;
	char str[MAX_LINE];
	int len;
	int i = 0;
	int j;
	int stoc;
	float probab;
	char c;
	char *ch;


/*
** Here we read the productions; their format is:
**
** string < string > string --> <float> string
**				<float> string <-
**	 ^	  ^	   ^ ^	   ^ 	|
**	 |	|	   | |	   | 	|
**	 |---+	   +----|    |------------+
**	 |			|	   |
**	 ---------------------------------------- optional
*/

	if (checkdefine(tkp))
		free(itoken[tkp].v.prod);

	itoken[tkp].type = PRODUCTION;
	itoken[tkp].v.prod = (production *)memrequest(sizeof(production) * MAX_PROD);
	ppntr = itoken[tkp].v.prod;

	while (TRUE) {
		getdataline();

		if ((iline[0] == '#') || (iline[0] == '&')) {
			alreadygotline = TRUE;
			break;
		}

		if (i == MAX_PROD) {
			sprintf(errstr, "Production limit exceeded, skipping");
			WARNING;

			proceedtotoken();
			break;
		}

		/* eol = 0: any piece of a production end to a blank */
		/* but if it's length more then a line we can use "" */
		len = pullstring(str, MAX_LINE, 0);

		c = getichar();
		while (isspace(c))
			c = getichar();

		if (c != '<') {
			if ((c != '-') && (c != '>')){
				fprintf (stderr, "Syntax error at line %d\n", infline);
				exit (-3);
			}
			/* there is no left context, what we read was predecessor */

			ppntr->lcon = memrequest(2);
			ppntr->lcon[0] = '\0';
			ppntr->lcon[1] = '\0';
			ppntr->lcon++;
			ppntr->lconlen = 0;

			ppntr->pred = memrequest(len + 1);
			strcpy(ppntr->pred, str);
			ppntr->predlen = len;
		}
		else {
			/* we use one char more to check the left end */
			ppntr->lcon = memrequest(len + 2);
			ppntr->lcon[0] = '\0';
			ppntr->lcon++;
			strcpy(ppntr->lcon, str);
			ppntr->lconlen = len;

			/* now we read predecessor if there is one */
			/* and it must be there ! */
			len = pullstring(str, MAX_LINE, 0);
/* ?????????????????? */
			if (len == 0) {
				fprintf (stderr, "Error at line %d: predecessor is empty\n", infline);
				exit (-3);
			}
			ppntr->pred = memrequest(len + 1);
			strcpy(ppntr->pred, str);
			ppntr->predlen = len;

			/* c was '<', now we prepare c for next test */
			c = getichar();
			while (isspace(c))
				c = getichar();
		}

		if (c != '>') {
		/* there is no right context */

			ppntr->rcon = memrequest(1);
			ppntr->rcon[0] = '\0';
			ppntr->rconlen = 0;

			len = pullstring(str, MAX_LINE, 0);
			if ((c != '-') || (strcmp(str, "->") != 0)) {
				fprintf (stderr, "Syntax error at line %d\n", infline);
				exit (-3);
			}

		}
		else {
			len = pullstring(str, MAX_LINE, 0);
			ppntr->rcon = memrequest(len + 1);
			strcpy(ppntr->rcon, str);
			ppntr->rconlen = len;

			len = pullstring(str, MAX_LINE, 0);
			if (strcmp(str, "-->") != 0) {
				fprintf (stderr, "Syntax error at line %d\n", infline);
				exit (-3);
			}
		}
		/* end of predecessor part */

		j = 0;
		/* here we read a line till the \n */
		len = pullstring(str, MAX_LINE, 1);
		/* if the first char is '<', we have some stocastic choiches */
		stoc = (str[0] == '<');
		while (stoc) {
			if (j == MAX_SUCCESSOR) {
				fprintf (stderr, "Too much stocastic successor\n");
				exit(-2);
			}

			if ((ch = strchr(str, '>')) == str) {
				fprintf (stderr, "Syntax error at line %d\n", infline);
				exit (-3);
			}
			while (isspace(*(++ch)));

			if (sscanf(str, " <%f> ", &probab) == 0) {
				fprintf (stderr, "Syntax error at line %d\n", infline);
				exit (-3);
			}
			enterr(&probab, ch, &ppntr->listsucc[j++]);

			len = pullstring(str, MAX_LINE, 1);
			/* if the first char is '<', we have another stocastic choiches */
			if (str[0] != '<') {
				stoc = FALSE;
				alreadygotline = TRUE;
			}

		}

		if (j == 0) {
			probab = 1.0f;
			enterr(&probab, str, &ppntr->listsucc[j++]);
		}
		else normalizeprob(ppntr->listsucc, j);

		ppntr->numsucc = j;
		ppntr++;
		i++;

	}
	ppntr->predlen = 0;
	printf("%s %d productions read\n",itoken[tkp].name, i);
}



void getcol(int tkp)
{
	int i = 0;

	checkdefine(tkp);

	itoken[tkp].type = COLOR;

	while (TRUE) {
		getnextline();

		if ((iline[0] == '#') || (iline[0] == '&')) {
			alreadygotline = TRUE;
			break;
		}

		/* so retain the value defined before for this entry */
		if (iline[0] == '\n') {
			i++;
			continue;
		}

		if (i == MAX_COLORS) {
			sprintf(errstr, "Color limit exceeded, skipping");
			WARNING;

			proceedtotoken();
			break;
		}

		colortable[i].r = pullfloat();
		colortable[i].g = pullfloat();
		colortable[i].b = pullfloat();

		i++;

	}

}



void getsub(int tkp)
{
	int i = 0;
	char str[MAX_LINE];
	int len;

	if (checkdefine(tkp)) {
		sprintf(errstr, "Program halted");
		ERROR;
	}

	itoken[tkp].type = SUBROUTINE;

	while (TRUE) {
		getdataline();

		if ((iline[0] == '#') || (iline[0] == '&')) {
			alreadygotline = TRUE;
			break;
		}


		if (i == (MAX_SUBROUTINES - 1)) {
			sprintf(errstr, "Subroutines limit exceeded, skipping");
			WARNING;

			proceedtotoken();
			break;
		}
		/* eol = 0 so we can find name" */
		len = pullstring(str, MAX_LINE, 0);
		/* a name of a subroutine end with ':', but ':' isn't part of the name */
		if (str[len - 1] != ':') {
			fprintf (stderr, "Syntax error at line %d\n", infline);
			exit (-3);
		}
		else str[len - 1] = '\0';
		subs[i][0] = memrequest(len);
		strcpy(subs[i][0], str);

		/* eol = 1, we end at \n */
		len = pullstring(str, MAX_LINE, 1);
		subs[i][1] = memrequest(len + 1);
		strcpy(subs[i][1], str);

		i++;

	}
	subs[i][0] = NULL;
}



void getmat(int tkp)
{
	int i = 0, t1, t2;

	checkdefine(tkp);

	itoken[tkp].type = MATERIAL;

	while (TRUE) {
		getnextline();

		if ((iline[0] == '#') || (iline[0] == '&')) {
			alreadygotline = TRUE;
			break;
		}

		/* so retain the value defined before for this entry */
		if (iline[0] == '\n') {
			i++;
			continue;
		}

		if (i == MAX_MATERIALS) {
			sprintf(errstr, "Material limit exceeded, skipping");
			WARNING;

			proceedtotoken();
			break;
		}
		/* eol = 1 so if material is long a line we don't need "" */
		pullstring(descr[i], MAX_LENMAT, 1);

		/* convert \n and \t into EOL and TAB */
		for (t1=0, t2=0; descr[i][t1] != 0; t1++, t2++)
			if (descr[i][t1] == '\\') {
				if (descr[i][t1+1] == 'n') {
					descr[i][t2] = '\n';
					t1++;
				} else if (descr[i][t1+1] == 't') {
					descr[i][t2] = '\t';
					t1++;
				}
			} else
				descr[i][t2] = descr[i][t1];

		descr[i][t2] = 0;

		i++;
	}
}



void getdist(int tkp)
{
	char str[16];

	if (checkdefine(tkp))

	itoken[tkp].type = DISTORTION;

	pullstring(str, 16, 0);

	diststrength = pullfloat();

	distdir.x = pullfloat();
	distdir.y = pullfloat();
	distdir.z = pullfloat();

	normalize(&distdir);

	distmode = TD_ROTATE;
}



void normalizeprob(successor listpntr[], int nsucc)
{
	int i,j;
	double total = 0.0;
	int index;
	double max;
	char *tmp;

	/* normalize probabilities */
	for (i = 0; i < nsucc; i++)
		total += listpntr[i].prob;

	for (i = 0; i < nsucc; i++)
		listpntr[i].prob /= total;

	/* order from max to min probabilities */
	for (i = 0; i < nsucc; i++) {
		max = listpntr[i].prob;
		index = i;
		for (j = (i + 1); j < nsucc; j++)
			if (max < listpntr[j].prob) {
				max = listpntr[j].prob;
				index = j;
			}
		if (index != i) {
			/* swap probabilities */
			listpntr[index].prob = listpntr[i].prob;
			listpntr[i].prob = max;
			/* swap strings */
			tmp = listpntr[index].succ;
			listpntr[index].succ = listpntr[i].succ;
			listpntr[i].succ = tmp;
			/* swap lengths */
			j = listpntr[index].succlen;
			listpntr[index].succlen = listpntr[i].succlen;
			listpntr[i].succlen = j;
		}
	}
	/* prepare probabilities like interval */
	for (i = 1; i < (nsucc - 1); i++)
		listpntr[i].prob += listpntr[i - 1].prob;
	listpntr[nsucc - 1].prob = 1.0;
}



void enterr(float *probab, char *string, successor *succel)
{
	succel->succlen = strlen(string);
	if ((succel->succ = memrequest((succel->succlen) + 1)) == NULL) {
		fprintf(stderr, "Can't allocate %d chars for successor\n",
			((succel->succlen) + 1));
		exit(-1);
	}
	strcpy(succel->succ, string);
	succel->prob = *probab;
}
