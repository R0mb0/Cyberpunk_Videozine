// ===================================================================
// colors.h: Header file containing all kinds of colors for OORT.
//
//	     The Object-Oriented Ray Tracer (OORT)
//            Copyright (C) 1993 by Nicholas Wilt.
//
// This software product may be freely copied and distributed in
// unmodified form but may not be sold.  A nominal distribution
// fee may be charged for media and handling by freeware and
// shareware distributors.  The software product may not be
// included in whole or in part into any commercial package
// without the express written consent of the author.
// 
// This software product is provided as is without warranty of
// any kind, express or implied, including but not limited to
// the implied warranties of merchantability and fitness for a
// particular purpose.  The author assumes no liability for any
// alleged or actual damages arising from the use of this
// software.  The author is under no obligation to provide 
// service, corrections or upgrades to the software.
//
// ------------------------------------------------------------
//
// Please contact me with questions, comments, suggestions or
// other input about OORT.  My Compuserve account number is
// [75210,2455] (Internet sites can reach me at 
// 75210.2455@compuserve.com).
//					--Nicholas Wilt
// ===================================================================

#define Black RGBColor(0, 0, 0)
#define White RGBColor(1, 1, 1)
#define Red RGBColor(1, 0, 0)
#define Green RGBColor(0, 1, 0)
#define Blue RGBColor(0, 0, 1)
#define Yellow RGBColor(1, 1, 0)
#define Cyan RGBColor(0, 1, 1)
#define Magenta RGBColor(1, 0, 1)
#define Aquamarine RGBColor(0.439216, 0.858824, 0.576471)
#define BlueViolet RGBColor(0.62352, 0.372549, 0.623529)
#define Brown RGBColor(0.647059, 0.164706, 0.164706)
#define CadetBlue RGBColor(0.372549, 0.623529, 0.623529)
#define Coral RGBColor(1.0, 0.498039, 0.0)
#define CornflowerBlue RGBColor(0.258824, 0.258824, 0.435294)
#define DarkGreen RGBColor(0.184314, 0.309804, 0.184314)
#define DarkOliveGreen RGBColor(0.309804, 0.309804, 0.184314)
#define DarkOrchid RGBColor(0.6, 0.196078, 0.8)
#define DarkSlateBlue RGBColor(0.419608, 0.137255, 0.556863)
#define DarkSlateGray RGBColor(0.184314, 0.309804, 0.309804)
#define DarkSlateGrey RGBColor(0.184314, 0.309804, 0.309804)
#define DarkTurquoise RGBColor(0.439216, 0.576471, 0.858824)
#define DimGray RGBColor(0.329412, 0.329412, 0.329412)
#define DimGrey RGBColor(0.329412, 0.329412, 0.329412)
#define Firebrick RGBColor(0.556863, 0.137255, 0.137255)
#define ForestGreen RGBColor(0.137255, 0.556863, 0.137255)
#define Gold RGBColor(0.8, 0.498039, 0.196078)
#define Goldenrod RGBColor(0.858824, 0.858824, 0.439216)
#define Gray RGBColor(0.752941, 0.752941, 0.752941)
#define GreenYellow RGBColor(0.576471, 0.858824, 0.439216)
#define Grey RGBColor(0.752941, 0.752941, 0.752941)
#define IndianRed RGBColor(0.309804, 0.184314, 0.184314)
#define Khaki RGBColor(0.623529, 0.623529, 0.372549)
#define LightBlue RGBColor(0.74902, 0.847059, 0.847059)
#define LightGray RGBColor(0.658824, 0.658824, 0.658824)
#define LightGrey RGBColor(0.658824, 0.658824, 0.658824)
#define LightSteelBlue RGBColor(0.560784, 0.560784, 0.737255)
#define LimeGreen RGBColor(0.196078, 0.8, 0.196078)
#define Maroon RGBColor(0.556863, 0.137255, 0.419608)
#define MediumAquamarine RGBColor(0.196078, 0.8, 0.6)
#define MediumBlue RGBColor(0.196078, 0.196078, 0.8)
#define MediumForestGreen RGBColor(0.419608, 0.556863, 0.137255)
#define MediumGoldenrod RGBColor(0.917647, 0.917647, 0.678431)
#define MediumOrchid RGBColor(0.576471, 0.439216, 0.858824)
#define MediumSeaGreen RGBColor(0.258824, 0.435294, 0.258824)
#define MediumSlateBlue RGBColor(0.498039, 0.0, 1.0)
#define MediumSpringGreen RGBColor(0.498039, 1.0, 0.0)
#define MediumTurquoise RGBColor(0.439216, 0.858824, 0.858824)
#define MediumVioletRed RGBColor(0.858824, 0.439216, 0.576471)
#define MidnightBlue RGBColor(0.184314, 0.184314, 0.309804)
#define Navy RGBColor(0.137255, 0.137255, 0.556863)
#define NavyBlue RGBColor(0.137255, 0.137255, 0.556863)
#define Orange RGBColor(0.8, 0.196078, 0.196078)
#define OrangeRed RGBColor(1.0, 0.0, 0.498039)
#define Orchid RGBColor(0.858824, 0.439216, 0.858824)
#define PaleGreen RGBColor(0.560784, 0.737255, 0.560784)
#define Pink RGBColor(0.737255, 0.560784, 0.560784)
#define Plum RGBColor(0.917647, 0.678431, 0.917647)
#define Salmon RGBColor(0.435294, 0.258824, 0.258824)
#define SeaGreen RGBColor(0.137255, 0.556863, 0.419608)
#define Sienna RGBColor(0.556863, 0.419608, 0.137255)
#define SkyBlue RGBColor(0.196078, 0.6, 0.8)
#define SlateBlue RGBColor(0.0, 0.498039, 1.0)
#define SpringGreen RGBColor(0.0, 1.0, 0.498039)
#define SteelBlue RGBColor(0.137255, 0.419608, 0.556863)
#define Tan RGBColor(0.858824, 0.576471, 0.439216)
#define Thistle RGBColor(0.847059, 0.74902, 0.847059)
#define Turquoise RGBColor(0.678431, 0.917647, 0.917647)
#define Violet RGBColor(0.309804, 0.184314, 0.309804)
#define VioletRed RGBColor(0.8, 0.196078, 0.6)
#define Wheat RGBColor(0.847059, 0.847059, 0.74902)
#define YellowGreen RGBColor(0.6, 0.8, 0.196078)
