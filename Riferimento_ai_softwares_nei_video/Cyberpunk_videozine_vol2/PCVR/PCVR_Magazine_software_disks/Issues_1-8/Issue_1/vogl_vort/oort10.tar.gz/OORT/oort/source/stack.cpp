#include <iostream.h>
#include <stdlib.h>

#include "stack.h"

int
main()
{
	SimpleStack<int> stk;
	int i;

	for (i = 0; i < 10; i++) {
		int tmp = rand();
		stk.Push(tmp);
		cout << tmp << ' ';
	}
	cout << '\n';
	while (! stk.Pop(&i))
		cout << i << ' ';
	cout << '\n';
}
