class Histogram {
private:
  int dim;
  long ***hist;

public:
  Histogram(int Dimension);
  ~Histogram();
  inline void SetElement(int x, int y, int z, long newval);
  inline long GetElement(int x, int y, int z);
  inline void IncElement(int x, int y, int z);
};

inline void Histogram::SetElement(int x, int y, int z, long newval)
{
  hist[x][y][z] = newval;
}

inline long Histogram::GetElement(int x, int y, int z)
{
  return hist[x][y][z];
}

inline void Histogram::IncElement(int x, int y, int z)
{
  hist[x][y][z]++;
}
