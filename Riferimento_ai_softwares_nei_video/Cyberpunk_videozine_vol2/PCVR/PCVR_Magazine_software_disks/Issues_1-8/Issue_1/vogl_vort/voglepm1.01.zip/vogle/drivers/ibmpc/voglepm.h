/****************************************************************************

    VoglePM.h - A VOGLE driver for OS/2 Presentation Manager
    Version 1.0  (4/17/94)
    (C) Copyright Claudio Fahey, 1994

    e-mail: claudio@uclink.berkeley.edu

    Permission granted to use, distribute, and modify, provided that this
    notice remains intact.  If you distribute a modified version, you must
    identify your modifications as such.

****************************************************************************/

#define VOGLEPM_VERSION         "1.01"
#define VOGLEPM_DATE            __DATE__
#define VOGLEPM_FULLVERSION     VOGLEPM_VERSION " (" VOGLEPM_DATE ")"

// Resource ID's

// To prevent the default icon from being written, define RID_FRAME
// as 100 instead of 1.
#define RID_FRAME       1
#define RID_ABOUTDLG    200

