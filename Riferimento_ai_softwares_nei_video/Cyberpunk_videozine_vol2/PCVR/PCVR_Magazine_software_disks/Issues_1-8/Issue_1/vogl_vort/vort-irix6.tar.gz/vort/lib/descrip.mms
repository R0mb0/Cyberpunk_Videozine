! vort VAX make file [vort.lib]descrip.mms

! should be the default - but sometimes does NOT work
CFLAGS = /DEFINE="VMS=1"

HEAD =		vort.h, -
		features.h

libvort :	libvort(hdr), -
		libvort(imagepos), -
		libvort(imageio), -
		libvort(readmapl), -
		libvort(readrgb), -
		libvort(readrgba), - 
		libvort(writmapl), -
		libvort(writrgb), -
		libvort(writrgba)
	! libvort built

! the above comment 'libvort built' is printed after
! libvort has completed - leave it out and you get a warning from mms

! it may be a bit overbearing to use HEAD for all the objects below
! since not all use the 'features.h' - but better to be safe than sorry

hdr.obj :	hdr.c $(HEAD)
		cc $(CFLAGS) hdr

imagepos.obj :	imagepos.c $(HEAD)
		cc $(CFLAGS) imagepos

imageio.obj :	imageio.c $(HEAD)
		cc $(CFLAGS) imageio

readmapl.obj :	readmapl.c $(HEAD)
		cc $(CFLAGS) readmapl

readrgb.obj :	readrgb.c $(HEAD)
		cc $(CFLAGS) readrgb

readrgba.obj :	readrgba.c $(HEAD)
		cc $(CFLAGS) readrgba

writmapl.obj :	writmapl.c $(HEAD)
		cc $(CFLAGS) writmapl

writrgb.obj :	writrgb.c $(HEAD)
		cc $(CFLAGS) writrgb

writrgba.obj :	writrgba.c $(HEAD)
		cc $(CFLAGS) writrgba
