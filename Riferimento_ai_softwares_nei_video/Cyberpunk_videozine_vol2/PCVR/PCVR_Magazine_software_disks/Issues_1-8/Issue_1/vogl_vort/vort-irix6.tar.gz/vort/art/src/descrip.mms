! vort VAX/VMS make file [vort.art.src]descrip.mms
!

.FIRST
 DEFINE C$INCLUDE [--.lib]

! should not be necessary to define the vax option in cflags - the default
! but sometimes it does not work

! if no optimisation wanted and NO debug planned
CFLAGS = /DEFINE="VMS=1"/NOOPT

! define where to look for usr include files (due to lex.c)
! USRINCLUDE =

! use this version of cflags if no optimisation wanted and debug planned
! CFLAGS = /DEFINE="VMS=1"/DEBUG/NOOPT

LFLAGS =	c$include:libvort/lib, -
		c$include:clib/opt

LIB =	[--.lib]libvort.olb

HEAD =	[--.lib]vort.h, -
	[--.lib]features.h

OBJS = gram.obj, -
	main.obj, -
	lex.obj, -
	prepro.obj, -
	repeat.obj, -
	message.obj, -
	matrix.obj, -
	solve.obj, -
	rt.obj, -
	stree.obj, -
	shade.obj, -
	light.obj, -
	expr.obj, -
	symbol.obj, -
	object.obj, -
	tile.obj, -
	bbox.obj, -
	comp.obj, -
	csg.obj, -
	sphere.obj, -
	blob.obj, -
	patch.obj, -
	box.obj, -
	grid.obj, -
	geom.obj, -
	interp.obj, -
	polygon.obj, -
	alg.obj, -
	torus.obj, -
	ellipse.obj, -
	cone.obj, -
	cylinder.obj, -
	ring.obj, -
	super.obj, -
	smalloc.obj, -
	util.obj, -
	map.obj, -
	texture.obj, -
	noise.obj, -
	twentyf.obj

art.exe :	$(OBJS)
! use this version if debug NOT planned
		link/exec=art.exe $(OBJS), $(LFLAGS)
! use this link if debug planned
!		link/debug/exec=art.exe $(OBJS), $(LFLAGS)


! slight overkill including HEAD rather than the required '.h' files
! in each of the objects below - but better to be safe than sorry
                
gram.obj :	gram.c $(LIB) $(HEAD)
		cc $(CFLAGS) gram 

main.obj :	main.c $(LIB) $(HEAD)
		cc $(CFLAGS) main

lex.obj :	lex.c $(LIB) $(HEAD)
		cc $(CFLAGS) -I$(USRINCLUDE) lex

prepro.obj :	prepro.c $(LIB) $(HEAD)
		cc $(CFLAGS) -I$(USRINCLUDE) prepro

repeat.obj :	repeat.c $(LIB) $(HEAD)
		cc $(CFLAGS) -I$(USRINCLUDE) repeat

message.obj :	message.c $(LIB) $(HEAD)
		cc $(CFLAGS) message

matrix.obj :	matrix.c $(LIB) $(HEAD)
		cc $(CFLAGS) matrix

solve.obj :	solve.c $(LIB) $(HEAD)
		cc $(CFLAGS) solve

rt.obj :	rt.c $(LIB) $(HEAD)
		cc $(CFLAGS) rt

stree.obj :	stree.c $(LIB) $(HEAD)
		cc $(CFLAGS) stree

shade.obj :	shade.c $(LIB) $(HEAD)
		cc $(CFLAGS) shade

light.obj :	light.c $(LIB) $(HEAD)
		cc $(CFLAGS) light

expr.obj :	expr.c $(LIB) $(HEAD)
		cc $(CFLAGS) expr

symbol.obj :	symbol.c $(LIB) $(HEAD)
		cc $(CFLAGS) symbol

object.obj :	object.c $(LIB) $(HEAD)
		cc $(CFLAGS) object

tile.obj :	tile.c $(LIB) $(HEAD)
		cc $(CFLAGS) tile

grid.obj :	grid.c $(LIB) $(HEAD)
		cc $(CFLAGS) grid

bbox.obj :	bbox.c $(LIB) $(HEAD)
		cc $(CFLAGS) bbox

comp.obj :	comp.c $(LIB) $(HEAD)
		cc $(CFLAGS) comp

csg.obj :	csg.c $(LIB) $(HEAD)
		cc $(CFLAGS) csg

sphere.obj :	sphere.c $(LIB) $(HEAD)
		cc $(CFLAGS) sphere

blob.obj :	blob.c $(LIB) $(HEAD)
		cc $(CFLAGS) blob

patch.obj :	patch.c $(LIB) $(HEAD)
		cc $(CFLAGS) patch

box.obj :	box.c $(LIB) $(HEAD)
		cc $(CFLAGS) box

geom.obj :	geom.c $(LIB) $(HEAD)
		cc $(CFLAGS) geom

interp.obj :	interp.c $(LIB) $(HEAD)
		cc $(CFLAGS) interp

polygon.obj :	polygon.c $(LIB) $(HEAD)
		cc $(CFLAGS) polygon

alg.obj :	alg.c $(LIB) $(HEAD)
		cc $(CFLAGS) alg

torus.obj :	torus.c $(LIB) $(HEAD)
		cc $(CFLAGS) torus

ellipse.obj :	ellipse.c $(LIB) $(HEAD)
		cc $(CFLAGS) ellipse

cone.obj :	cone.c $(LIB) $(HEAD)
		cc $(CFLAGS) cone

cylinder.obj :	cylinder.c $(LIB) $(HEAD)
		cc $(CFLAGS) cylinder

ring.obj :	ring.c $(LIB) $(HEAD)
		cc $(CFLAGS) ring

super.obj :	super.c $(LIB) $(HEAD)
		cc $(CFLAGS) super

smalloc.obj :	smalloc.c $(LIB) $(HEAD)
		cc $(CFLAGS) smalloc

util.obj :	util.c $(LIB) $(HEAD)
		cc $(CFLAGS) util

map.obj :	map.c $(LIB) $(HEAD)
		cc $(CFLAGS) map

texture.obj :	texture.c $(LIB) $(HEAD)
		cc $(CFLAGS) texture

noise.obj :	noise.c $(LIB) $(HEAD)
		cc $(CFLAGS) noise

twentyf.obj :	twentyf.c $(LIB) $(HEAD)
		cc $(CFLAGS) twentyf
