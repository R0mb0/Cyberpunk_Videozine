
typedef union {
	object		*y_obj;
	vector		*y_pnt;
	details		*y_det;
	char		*y_str;
	eqn		*y_eqn;
	term		*y_trm;
	expression	*y_exp;
	symbol		*y_sym;
	csgnode		*y_csg;
	float		y_flt;
	int		y_int;
} YYSTYPE;
extern YYSTYPE yylval;
# define CSG 257
# define COMPOSITE 258
# define OBJECT_TYPE 259
# define FLOAT 260
# define INTEGER 261
# define FILETYPE 262
# define OPTION 263
# define NAME 264
# define LBRACE 265
# define RBRACE 266
# define LP 267
# define RP 268
# define RADIUS 269
# define RADII 270
# define COLOUR 271
# define CENTER 272
# define VERTEX 273
# define COMMA 274
# define PCENT 275
# define MATERIAL 276
# define REFI 277
# define MINUS 278
# define AMBIENT 279
# define INTENSITY 280
# define LOCATION 281
# define DOLS 282
# define EQUATION 283
# define OFFFILE 284
# define BASE 285
# define TOP 286
# define CONST 287
# define COEFFS 288
# define SCALE 289
# define ROTATE 290
# define TRANSLATE 291
# define TITLE 292
# define REFLECTANCE 293
# define DOT 294
# define ON 295
# define OFF 296
# define LOOKAT 297
# define FIELDOFVIEW 298
# define TRANSPARENCY 299
# define RAYSPERPIXEL 300
# define BACKGROUND 301
# define SIZE 302
# define MAXHITLEVEL 303
# define OUTPUT 304
# define ORDER 305
# define ABSORPTION 306
# define VREF1 307
# define VREF2 308
# define NUMRAYS 309
# define OBJECT 310
# define TEXTURE 311
# define DIRECTION 312
# define ANGLE 313
# define UP 314
# define TWENTYFIVEBIT 315
# define RANGE 316
# define MAP 317
# define BLENDCOLOR 318
# define SCALEFACTORS 319
# define VORTFILE 320
# define HAZECOLOUR 321
# define FOGFACTOR 322
# define RFACTOR 323
# define FALLOFF 324
# define QUOTE 325
# define REPEAT 326
# define SHADOWS 327
# define COLOURFILE 328
# define VNORMALFILE 329
# define SCALEFACTOR 330
# define SOURCE 331
# define AMPLITUDE 332
# define WAVELENGTH 333
# define PHASE 334
# define TURBULENCE 335
# define SQUEEZE 336
# define DAMPING 337
# define SOURCERADIUS 338
# define NORMAL 339
# define COMPLEXVERTEX 340
# define SCREENSIZE 341
# define MAXTREEDEPTH 342
# define BLEND 343
# define COLOURMAP 344
# define MAPVALUES 345
# define PIXELGRID 346
# define RI 347
# define COLOURBLEND 348
# define NORMALFILE 349
# define BEAMDISTRIBUTION 350
# define INSIDEANGLE 351
# define PROJECTION 352
# define PERSPECTIVE 353
# define ORTHOGRAPHIC 354
# define STRIP 355
# define VCOLOURFILE 356
# define TRANSFORM 357
# define MINDIST 358
# define CLIPVOLUME 359
# define HEIGHTFIELD 360
# define FRAMENO 361
# define BLOCKSIZE 362
# define GAPCOLOUR 363
# define GAPSIZE 364
# define COLOURFIELD 365
# define ALPHA 366
# define GEOMX 367
# define GEOMY 368
# define GEOMZ 369
# define ANTIALIASING 370
# define ADAPTIVE 371
# define BRUTE 372
# define THRESHOLD 373
# define METABALL 374
# define BASIS 375
# define MAXSUBLEVEL 376
# define SUBDIVISION 377
# define GRID 378
# define KDTREE 379
# define PLUS 380
# define MULT 381
# define DIV 382
# define POWER 383
# define UMINUS 384
# define EQUALS 385
