echo off
echo Building vort and art using kmake with Floating point option %1
if "%1" == "" goto err
cd lib
kmake -f makefile.msc F=%1
cd ..\tools
kmake -f makefile.msc F=%1
cd ..\pc
kmake -f makefile.msc F=%1
cd ..\art\src
kmake -f makefile.msc F=%1
goto end
:err
echo "Usage: buildm -FPi87 | -FPa | -FPc | -FPi"
:end
