echo Building vort and art using Turbo make 
cd lib
make -fmakefile.tc > g:\bernie\vort\lib.err
cd ..\tools
make -fmakefile.tc > g:\bernie\vort\tools.err
cd ..\pc
make -fmakefile.tc > g:\bernie\vort\pc.err
cd ..\art\src
make -fmakefile.tc > g:\bernie\vort\src.err
