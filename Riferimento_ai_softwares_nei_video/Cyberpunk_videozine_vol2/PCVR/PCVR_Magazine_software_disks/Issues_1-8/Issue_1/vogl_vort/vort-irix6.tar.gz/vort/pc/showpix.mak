.c.obj:
        cl -AM -Gs -c -Ot -W1 $*.c

# note that the use of -AM requires you to have libraries created for this model
# (the included fgraph.lib is in fact in medium model)

LIB = c:\lib
# where to find setargv.obj

.asm.obj:
        masm -ML $*;

showpix.obj : showpix.c showpix.h

savegif.obj : savegif.c showpix.h

shcline.obj : shcline.c showpix.h

shdisp.obj : shdisp.c showpix.h

extra.obj : extra.asm

showpix.exe : showpix.obj savegif.obj extra.obj shcline.obj shdisp.obj
        LINK /NOE /NOI /STACK:12000 showpix+savegif+shcline+extra+shdisp\
+$(LIB)\setargv,,,fgraph vort;
