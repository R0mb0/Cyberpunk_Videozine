echo off
echo Building vort and art using microsoft make with Floating point option %1
if "%1" == "" goto err
cd lib
make F=%1 make.msc
cd ..\tools
make F=%1 make.msc
cd ..\pc
make F=%1 make.msc
cd ..\art\src
make F=%1 make.msc
goto end
:err
echo "Usage: buildm -FPi87 | -FPa | -FPc | -FPi"
:end
