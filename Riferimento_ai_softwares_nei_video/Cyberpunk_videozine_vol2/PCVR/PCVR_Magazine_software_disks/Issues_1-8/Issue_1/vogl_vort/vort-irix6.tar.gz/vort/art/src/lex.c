#include <stdio.h>
# define U(x) x
# define NLSTATE yyprevious=YYNEWLINE
# define BEGIN yybgin = yysvec + 1 +
# define INITIAL 0
# define YYLERR yysvec
# define YYSTATE (yyestate-yysvec-1)
# define YYOPTIM 1
# define YYLMAX BUFSIZ
#ifndef __cplusplus
# define output(c) (void)putc(c,yyout)
#else
# define lex_output(c) (void)putc(c,yyout)
#endif

#if defined(__cplusplus) || defined(__STDC__)

#if defined(__cplusplus) && defined(__EXTERN_C__)
extern "C" {
#endif
	int yyback(int *, int);
	int yyinput(void);
	int yylook(void);
	void yyoutput(int);
	int yyracc(int);
	int yyreject(void);
	void yyunput(int);
	int yylex(void);
#ifdef YYLEX_E
	void yywoutput(wchar_t);
	wchar_t yywinput(void);
#endif
#ifndef yyless
	void yyless(int);
#endif
#ifndef yywrap
	int yywrap(void);
#endif
#ifdef LEXDEBUG
	void allprint(char);
	void sprint(char *);
#endif
#if defined(__cplusplus) && defined(__EXTERN_C__)
}
#endif

#ifdef __cplusplus
extern "C" {
#endif
	void exit(int);
#ifdef __cplusplus
}
#endif

#endif
# define unput(c) {yytchar= (c);if(yytchar=='\n')yylineno--;*yysptr++=yytchar;}
# define yymore() (yymorfg=1)
#ifndef __cplusplus
# define input() (((yytchar=yysptr>yysbuf?U(*--yysptr):getc(yyin))==10?(yylineno++,yytchar):yytchar)==EOF?0:yytchar)
#else
# define lex_input() (((yytchar=yysptr>yysbuf?U(*--yysptr):getc(yyin))==10?(yylineno++,yytchar):yytchar)==EOF?0:yytchar)
#endif
#define ECHO fprintf(yyout, "%s",yytext)
# define REJECT { nstr = yyreject(); goto yyfussy;}
int yyleng; extern char yytext[];
int yymorfg;
extern char *yysptr, yysbuf[];
int yytchar;
FILE *yyin = {stdin}, *yyout = {stdout};
extern int yylineno;
struct yysvf { 
	struct yywork *yystoff;
	struct yysvf *yyother;
	int *yystops;};
struct yysvf *yyestate;
extern struct yysvf yysvec[], *yybgin;
#include <math.h>
#include "art.h"
#include "objs.h"
#include "gram.h"

extern int	linecount;

extern char	currentfile[];

extern symbol	*lookup();

extern double	atof();

# define YYNEWLINE 10
yylex(){
int nstr; extern int yyprevious;
#ifdef __cplusplus
/* to avoid CC and lint complaining yyfussy not being used ...*/
static int __lex_hack = 0;
if (__lex_hack) goto yyfussy;
#endif
while((nstr = yylook()) >= 0)
yyfussy: switch(nstr){
case 0:
if(yywrap()) return(0); break;
case 1:

# line 24 "lex.l"
	return(KDTREE);
break;
case 2:

# line 26 "lex.l"
	return(GRID);
break;
case 3:

# line 28 "lex.l"
return(SUBDIVISION);
break;
case 4:

# line 30 "lex.l"
return(MAXSUBLEVEL);
break;
case 5:

# line 32 "lex.l"
	return(BASIS);
break;
case 6:

# line 34 "lex.l"
return(METABALL);
break;
case 7:

# line 36 "lex.l"
return(THRESHOLD);
break;
case 8:

# line 38 "lex.l"
return(GAPCOLOUR);
break;
case 9:

# line 40 "lex.l"
	return(GAPSIZE);
break;
case 10:

# line 42 "lex.l"
return(MAXTREEDEPTH);
break;
case 11:

# line 44 "lex.l"
return(SCREENSIZE);
break;
case 12:

# line 46 "lex.l"
	return(SOURCE);
break;
case 13:

# line 48 "lex.l"
return(AMPLITUDE);
break;
case 14:

# line 50 "lex.l"
return(WAVELENGTH);
break;
case 15:

# line 52 "lex.l"
	return(DAMPING);
break;
case 16:

# line 54 "lex.l"
	return(PHASE);
break;
case 17:

# line 56 "lex.l"
	return(ALPHA);
break;
case 18:

# line 58 "lex.l"
return(SCALEFACTOR);
break;
case 19:

# line 60 "lex.l"
	return(SCALEFACTOR);
break;
case 20:

# line 62 "lex.l"
return(SOURCERADIUS);
break;
case 21:

# line 64 "lex.l"
return(TURBULENCE);
break;
case 22:

# line 66 "lex.l"
	return(SQUEEZE);
break;
case 23:

# line 68 "lex.l"
	return(OFFFILE);
break;
case 24:

# line 70 "lex.l"
	return(OFFFILE);
break;
case 25:

# line 72 "lex.l"
return(COLOURFIELD);
break;
case 26:

# line 74 "lex.l"
return(HEIGHTFIELD);
break;
case 27:

# line 76 "lex.l"
return(PROJECTION);
break;
case 28:

# line 78 "lex.l"
return(ORTHOGRAPHIC);
break;
case 29:

# line 80 "lex.l"
return(PERSPECTIVE);
break;
case 30:

# line 82 "lex.l"
return(COLOURFILE);
break;
case 31:

# line 84 "lex.l"
return(NORMALFILE);
break;
case 32:

# line 86 "lex.l"
return(VNORMALFILE);
break;
case 33:

# line 88 "lex.l"
return(VCOLOURFILE);
break;
case 34:

# line 90 "lex.l"
return(VORTFILE);
break;
case 35:

# line 92 "lex.l"
return(ANTIALIASING);
break;
case 36:

# line 94 "lex.l"
return(ADAPTIVE);
break;
case 37:

# line 96 "lex.l"
return(THRESHOLD);
break;
case 38:

# line 98 "lex.l"
	return(BRUTE);
break;
case 39:

# line 100 "lex.l"
	return(TOP);
break;
case 40:

# line 102 "lex.l"
	return(BASE);
break;
case 41:

# line 104 "lex.l"
return(CONST);
break;
case 42:

# line 106 "lex.l"
return(CLIPVOLUME);
break;
case 43:

# line 108 "lex.l"
return(COEFFS);
break;
case 44:

# line 110 "lex.l"
	return(ORDER);
break;
case 45:

# line 112 "lex.l"
	return(CSG);
break;
case 46:

# line 114 "lex.l"
return(COMPOSITE);
break;
case 47:

# line 116 "lex.l"
return(TRANSFORM);
break;
case 48:

# line 118 "lex.l"
	return(FRAMENO);
break;
case 49:

# line 120 "lex.l"
{
			yylval.y_int = PHONGSHADING;
			return(OPTION);
		}
break;
case 50:

# line 125 "lex.l"
{
			yylval.y_int = BACKFACING;
			return(OPTION);
		}
break;
case 51:

# line 130 "lex.l"
	return(ON);
break;
case 52:

# line 132 "lex.l"
	return(OFF);
break;
case 53:

# line 134 "lex.l"
return(MATERIAL);
break;
case 54:

# line 136 "lex.l"
	return(CENTER);
break;
case 55:

# line 138 "lex.l"
	return(CENTER);
break;
case 56:

# line 140 "lex.l"
	return(COLOUR);
break;
case 57:

# line 142 "lex.l"
	return(AMBIENT);
break;
case 58:

# line 144 "lex.l"
return(REFLECTANCE);
break;
case 59:

# line 146 "lex.l"
return(ABSORPTION);
break;
case 60:

# line 148 "lex.l"
return(TRANSPARENCY);
break;
case 61:

# line 150 "lex.l"
return(HAZECOLOUR);
break;
case 62:

# line 152 "lex.l"
return(FOGFACTOR);
break;
case 63:

# line 154 "lex.l"
	return(RFACTOR);
break;
case 64:

# line 156 "lex.l"
	return(FALLOFF);
break;
case 65:

# line 158 "lex.l"
	return(RI);
break;
case 66:

# line 160 "lex.l"
	return(REPEAT);
break;
case 67:

# line 162 "lex.l"
	return(RADIUS);
break;
case 68:

# line 164 "lex.l"
	return(RADII);
break;
case 69:

# line 166 "lex.l"
	return(STRIP);
break;
case 70:

# line 168 "lex.l"
return(DIRECTION);
break;
case 71:

# line 170 "lex.l"
	return(ANGLE);
break;
case 72:

# line 172 "lex.l"
return(INSIDEANGLE);
break;
case 73:

# line 174 "lex.l"
return(BEAMDISTRIBUTION);
break;
case 74:

# line 176 "lex.l"
	return(MINDIST);
break;
case 75:

# line 178 "lex.l"
	return(NUMRAYS);
break;
case 76:

# line 180 "lex.l"
	return(GEOMX);
break;
case 77:

# line 182 "lex.l"
	return(GEOMY);
break;
case 78:

# line 184 "lex.l"
	return(GEOMZ);
break;
case 79:

# line 186 "lex.l"
	return(VERTEX);
break;
case 80:

# line 188 "lex.l"
return(LOCATION);
break;
case 81:

# line 190 "lex.l"
	return(TEXTURE);
break;
case 82:

# line 192 "lex.l"
	return(MAP);
break;
case 83:

# line 194 "lex.l"
return(COLOURMAP);
break;
case 84:

# line 196 "lex.l"
	return(RANGE);
break;
case 85:

# line 198 "lex.l"
	return(BLEND);
break;
case 86:

# line 200 "lex.l"
return(BLENDCOLOR);
break;
case 87:

# line 202 "lex.l"
return(SCALEFACTORS);
break;
case 88:

# line 204 "lex.l"
return(BLOCKSIZE);
break;
case 89:

# line 206 "lex.l"
return(BLOCKSIZE);
break;
case 90:

# line 208 "lex.l"
	return(SIZE);
break;
case 91:

# line 210 "lex.l"
return(EQUATION);
break;
case 92:

# line 212 "lex.l"
return(TRANSLATE);
break;
case 93:

# line 214 "lex.l"
	return(ROTATE);
break;
case 94:

# line 216 "lex.l"
	return(SCALE);
break;
case 95:

# line 218 "lex.l"
	return(LOOKAT);
break;
case 96:

# line 220 "lex.l"
	return(UP);
break;
case 97:

# line 222 "lex.l"
return(FIELDOFVIEW);
break;
case 98:

# line 224 "lex.l"
return(RAYSPERPIXEL);
break;
case 99:

# line 226 "lex.l"
return(PIXELGRID);
break;
case 100:

# line 228 "lex.l"
	return(SHADOWS);
break;
case 101:

# line 230 "lex.l"
	return(TITLE);
break;
case 102:

# line 232 "lex.l"
return(BACKGROUND);
break;
case 103:

# line 234 "lex.l"
return(MAXHITLEVEL);
break;
case 104:

# line 236 "lex.l"
	return(OUTPUT);
break;
case 105:

# line 238 "lex.l"
return(TWENTYFIVEBIT);
break;
case 106:

# line 240 "lex.l"
	{
			yylval.y_int = PIX_RGB;
			return(FILETYPE);
		}
break;
case 107:

# line 245 "lex.l"
	{
			yylval.y_int = PIX_RLE;
			return(FILETYPE);
		}
break;
case 108:

# line 250 "lex.l"
	{
			yylval.y_int = PIX_RGBA;
			return(FILETYPE);
		}
break;
case 109:

# line 255 "lex.l"
	{
			yylval.y_int = PIX_RLEA;
			return(FILETYPE);
		}
break;
case 110:

# line 260 "lex.l"
{
			if ((yylval.y_sym = lookup(yytext)) != (symbol *)NULL)
				return(OBJECT_TYPE);
			else {
				yylval.y_str = (char *)smalloc(strlen(yytext) + 1);
				strcpy(yylval.y_str, yytext);

				return(NAME);
			}
		}
break;
case 111:

# line 271 "lex.l"
{
			yylval.y_int = atoi(yytext);
			return(INTEGER);
		}
break;
case 112:

# line 276 "lex.l"
{
			yylval.y_flt = atof(yytext);
			return(FLOAT);
		}
break;
case 113:

# line 281 "lex.l"
{
			yylval.y_flt = atof(yytext);
			return(FLOAT);
		}
break;
case 114:

# line 286 "lex.l"
	return(PLUS);
break;
case 115:

# line 288 "lex.l"
	return(MINUS);
break;
case 116:

# line 290 "lex.l"
	return(DIV);
break;
case 117:

# line 292 "lex.l"
	return(MULT);
break;
case 118:

# line 294 "lex.l"
	return(PCENT);
break;
case 119:

# line 296 "lex.l"
	return(POWER);
break;
case 120:

# line 298 "lex.l"
	return(COMMA);
break;
case 121:

# line 300 "lex.l"
	return(LP);
break;
case 122:

# line 302 "lex.l"
	return(RP);
break;
case 123:

# line 304 "lex.l"
	return(EQUALS);
break;
case 124:

# line 306 "lex.l"
	return(DOLS);
break;
case 125:

# line 308 "lex.l"
	{
			char	buf[BUFSIZ], *p;
			
			for (p = buf; (*p = input()) != '"'; p++)
				if (*p == '\n' || *p == EOF)
					yyerror("syntax error");

			*p = 0;

			yylval.y_str = (char *)smalloc(strlen(buf) + 1);
			strcpy(yylval.y_str, buf);

			return(NAME);
		}
break;
case 126:

# line 323 "lex.l"
	{
			return(LBRACE);
		}
break;
case 127:

# line 327 "lex.l"
	{
			return(RBRACE);
		}
break;
case 128:

# line 331 "lex.l"
	return(QUOTE);
break;
case 129:

# line 333 "lex.l"
	{
			linecount++;
		}
break;
case 130:

# line 337 "lex.l"
	{
			;
		}
break;
case 131:

# line 341 "lex.l"
	{
			int	c, i, j;
			char	buf[BUFSIZ], *p;

			i = 0;
			while ((buf[i] = input()) != '\n' && !feof(yyin))
				i++;

			if (sscanf(buf, "%d", &linecount) != 1)
				linecount++;
			else {
				for (p = buf; p != &buf[i]; p++)
					if (*p == '"')
						break;

				if (p == &buf[i])
					linecount++;
				else {
					j = 0;
					p++;
					while (*p != '"' && p != &buf[i])
						currentfile[j++] = *p++;
					currentfile[j] = 0;
				}
			}
		}
break;
case 132:

# line 368 "lex.l"
	{
			int	c1, c2;
			int	comline, incomment = 1;
			char	buf[BUFSIZ];

			comline = linecount;

			do {
				while ((c1 = input()) != '*' && c1 != '/' && c1 != EOF)
					if (c1 == '\n')
						linecount++;

				c2 = input();
				if (c2 == '\n')
					linecount++;

				if (c1 == '*' && c2 == '/')
					incomment--;

				if (c1 == '/' && c2 == '*') {
					incomment++;
					comline = linecount;
				}

			} while (incomment && c2 != EOF);

			if (c1 == EOF || c2 == EOF) {
				sprintf(buf, "art: unterminated comment - started line %d.\n", comline);
				fatal(buf);
			}
		}
break;
case -1:
break;
default:
(void)fprintf(yyout,"bad switch yylook %d",nstr);
} return(0); }
/* end of yylex */
int yyvstop[] = {
0,

111,
0,

111,
0,

130,
0,

129,
0,

125,
0,

131,
0,

118,
0,

128,
0,

121,
0,

122,
0,

117,
0,

114,
0,

120,
0,

115,
0,

112,
0,

116,
0,

111,
0,

123,
0,

110,
0,

119,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

126,
0,

127,
0,

124,
0,

113,
0,

132,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

51,
110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

65,
110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

96,
110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

113,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

45,
110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

82,
110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

52,
110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

106,
110,
0,

107,
110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

39,
110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

40,
110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

2,
110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

108,
110,
0,

109,
110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

90,
110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

17,
110,
0,

110,
0,

110,
0,

71,
110,
0,

110,
0,

110,
0,

110,
0,

5,
110,
0,

110,
0,

85,
110,
0,

110,
0,

110,
0,

38,
110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

56,
110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

76,
110,
0,

77,
110,
0,

78,
110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

44,
110,
0,

110,
0,

110,
0,

110,
0,

16,
110,
0,

110,
0,

110,
0,

110,
0,

68,
110,
0,

110,
0,

84,
110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

94,
110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

69,
110,
0,

110,
0,

110,
0,

110,
0,

101,
110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

54,
110,
0,

55,
110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

1,
110,
0,

110,
0,

95,
110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

19,
110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

104,
110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

67,
110,
0,

110,
0,

110,
0,

66,
110,
0,

110,
0,

93,
110,
0,

110,
0,

110,
0,

110,
0,

12,
110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

79,
110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

57,
110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

15,
110,
0,

110,
0,

110,
0,

64,
110,
0,

110,
0,

110,
0,

48,
110,
0,

110,
0,

9,
110,
0,

23,
110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

74,
110,
0,

110,
0,

75,
110,
0,

24,
110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

63,
110,
0,

110,
0,

110,
0,

100,
110,
0,

110,
0,

22,
110,
0,

110,
0,

81,
110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

36,
110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

83,
110,
0,

110,
0,

41,
110,
0,

110,
0,

91,
110,
0,

110,
0,

110,
0,

8,
110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

80,
110,
0,

53,
110,
0,

110,
0,

110,
0,

110,
0,

6,
110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

34,
110,
0,

110,
0,

110,
0,

13,
110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

88,
110,
0,

89,
110,
0,

110,
0,

110,
0,

110,
0,

30,
110,
0,

46,
110,
0,

70,
110,
0,

110,
0,

62,
110,
0,

61,
110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

99,
110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

7,
37,
110,
0,

47,
110,
0,

92,
110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

59,
110,
0,

110,
0,

50,
110,
0,

102,
110,
0,

110,
0,

86,
110,
0,

110,
0,

42,
110,
0,

110,
0,

25,
110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

110,
0,

31,
110,
0,

110,
0,

110,
0,

110,
0,

27,
110,
0,

110,
0,

110,
0,

110,
0,

11,
110,
0,

110,
0,

110,
0,

110,
0,

21,
110,
0,

110,
0,

33,
110,
0,

110,
0,

14,
110,
0,

110,
0,

110,
0,

110,
0,

97,
110,
0,

26,
110,
0,

72,
110,
0,

103,
110,
0,

4,
110,
0,

110,
0,

110,
0,

29,
110,
0,

110,
0,

110,
0,

58,
110,
0,

18,
110,
0,

110,
0,

3,
110,
0,

110,
0,

110,
0,

32,
110,
0,

35,
110,
0,

110,
0,

43,
110,
0,

10,
110,
0,

28,
110,
0,

49,
110,
0,

98,
110,
0,

87,
110,
0,

20,
110,
0,

60,
110,
0,

110,
0,

110,
0,

105,
110,
0,

110,
0,

110,
0,

73,
110,
0,
0};
# define YYTYPE int
struct yywork { YYTYPE verify, advance; } yycrank[] = {
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	1,3,	1,4,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	1,3,	0,0,	1,5,	
1,6,	1,7,	1,8,	7,45,	
1,9,	1,10,	1,11,	1,12,	
1,13,	1,14,	1,15,	1,16,	
1,17,	1,18,	1,18,	1,18,	
1,18,	1,18,	1,18,	1,18,	
1,18,	1,18,	1,18,	17,47,	
0,0,	0,0,	1,19,	0,0,	
0,0,	0,0,	1,20,	1,20,	
1,20,	1,20,	1,20,	1,20,	
1,20,	1,20,	1,20,	1,20,	
1,20,	1,20,	1,20,	1,20,	
1,20,	1,20,	1,20,	1,20,	
1,20,	1,20,	1,20,	1,20,	
1,20,	1,20,	1,20,	1,20,	
0,0,	0,0,	0,0,	1,21,	
1,20,	0,0,	1,22,	1,23,	
1,24,	1,25,	1,26,	1,27,	
1,28,	1,29,	1,30,	1,20,	
1,31,	1,32,	1,33,	1,34,	
1,35,	1,36,	1,20,	1,37,	
1,38,	1,39,	1,40,	1,41,	
1,42,	1,20,	1,20,	1,20,	
1,43,	26,63,	1,44,	16,16,	
16,16,	16,16,	16,16,	16,16,	
16,16,	16,16,	16,16,	16,16,	
16,16,	25,61,	30,73,	29,71,	
31,74,	32,75,	28,68,	29,72,	
40,110,	25,62,	28,69,	18,16,	
16,46,	18,18,	18,18,	18,18,	
18,18,	18,18,	18,18,	18,18,	
18,18,	18,18,	18,18,	28,70,	
42,115,	48,117,	20,20,	20,20,	
20,20,	20,20,	20,20,	20,20,	
20,20,	20,20,	20,20,	20,20,	
20,20,	20,20,	49,118,	50,119,	
54,126,	57,131,	58,132,	60,137,	
16,46,	20,20,	20,20,	20,20,	
20,20,	20,20,	20,20,	20,20,	
20,20,	20,20,	20,20,	20,20,	
20,20,	20,20,	20,20,	20,20,	
20,20,	20,20,	20,20,	20,20,	
20,20,	20,20,	20,20,	20,20,	
20,20,	20,20,	20,20,	61,138,	
62,139,	63,140,	64,141,	20,20,	
65,142,	20,20,	20,20,	20,20,	
20,20,	20,20,	20,20,	20,20,	
20,20,	20,20,	20,20,	20,20,	
20,20,	20,20,	20,20,	20,20,	
20,20,	20,20,	20,20,	20,20,	
20,20,	20,20,	20,20,	20,20,	
20,20,	20,20,	20,20,	22,48,	
66,143,	22,49,	23,53,	67,144,	
68,145,	69,146,	23,54,	24,57,	
27,64,	22,50,	22,51,	22,52,	
34,79,	23,55,	24,58,	35,81,	
27,65,	24,59,	34,80,	23,56,	
33,76,	24,60,	27,66,	35,82,	
33,77,	27,67,	70,147,	35,83,	
33,78,	36,85,	35,84,	71,148,	
36,86,	36,87,	72,149,	37,89,	
41,111,	73,150,	41,112,	37,90,	
37,91,	37,92,	36,88,	37,93,	
51,120,	38,96,	37,94,	41,113,	
41,114,	37,95,	38,97,	38,98,	
53,124,	52,122,	74,151,	56,129,	
77,157,	38,99,	51,121,	38,100,	
55,127,	39,103,	38,101,	38,102,	
39,104,	39,105,	52,123,	56,130,	
53,125,	79,160,	55,128,	39,106,	
80,161,	81,162,	39,107,	84,165,	
46,46,	39,108,	46,46,	39,109,	
75,152,	46,116,	46,116,	46,116,	
46,116,	46,116,	46,116,	46,116,	
46,116,	46,116,	46,116,	59,133,	
75,153,	76,154,	78,158,	83,163,	
85,166,	76,155,	59,134,	59,135,	
59,136,	76,156,	86,167,	87,169,	
78,159,	88,170,	91,176,	89,171,	
90,174,	92,177,	94,178,	83,164,	
95,179,	96,180,	97,182,	98,183,	
86,168,	89,172,	90,175,	99,184,	
100,185,	101,186,	102,187,	103,188,	
104,189,	105,190,	106,191,	107,192,	
89,173,	108,193,	96,181,	109,194,	
111,195,	112,196,	113,197,	114,198,	
115,199,	116,116,	116,116,	116,116,	
116,116,	116,116,	116,116,	116,116,	
116,116,	116,116,	116,116,	117,200,	
118,201,	119,202,	120,203,	121,204,	
122,205,	123,206,	124,207,	125,208,	
126,210,	127,211,	128,212,	125,209,	
129,213,	130,214,	131,215,	132,216,	
133,217,	134,218,	135,219,	136,220,	
138,221,	139,222,	140,223,	141,224,	
142,225,	143,226,	144,227,	145,228,	
146,230,	147,232,	148,233,	149,234,	
150,235,	151,236,	152,237,	146,231,	
153,238,	155,239,	156,240,	157,243,	
158,244,	159,245,	160,246,	145,229,	
161,247,	162,248,	163,249,	164,250,	
165,251,	156,241,	156,242,	166,252,	
167,253,	168,254,	169,255,	170,256,	
171,257,	172,258,	173,259,	174,260,	
175,261,	176,262,	177,263,	178,264,	
179,265,	180,266,	181,267,	182,268,	
183,269,	184,270,	185,271,	186,272,	
187,273,	188,274,	189,275,	190,276,	
192,277,	193,278,	194,279,	195,280,	
196,281,	197,282,	198,283,	199,284,	
200,285,	201,286,	202,287,	203,288,	
204,289,	205,290,	206,291,	207,292,	
207,293,	209,294,	210,295,	211,296,	
212,297,	213,298,	214,299,	215,300,	
216,302,	217,303,	218,304,	219,306,	
220,307,	218,305,	221,308,	222,309,	
223,310,	224,311,	225,312,	226,313,	
215,301,	227,314,	228,315,	229,316,	
230,317,	231,318,	231,319,	231,320,	
233,321,	234,322,	235,323,	236,324,	
237,325,	238,326,	239,327,	240,328,	
241,329,	242,330,	243,331,	244,332,	
245,333,	246,334,	247,335,	248,336,	
249,337,	250,338,	251,339,	252,340,	
253,341,	254,342,	255,343,	256,344,	
257,345,	258,347,	259,348,	260,349,	
261,350,	262,351,	265,352,	266,353,	
267,354,	268,355,	270,356,	271,357,	
257,346,	272,358,	273,359,	274,360,	
275,361,	276,362,	277,363,	278,364,	
279,365,	280,366,	281,367,	282,368,	
283,369,	284,370,	285,371,	286,372,	
288,373,	289,374,	291,375,	292,376,	
293,377,	295,378,	296,379,	297,380,	
298,381,	300,382,	301,383,	302,384,	
303,385,	304,386,	305,304,	306,388,	
307,389,	308,390,	309,391,	310,392,	
304,387,	311,393,	312,394,	313,395,	
314,396,	315,397,	316,398,	317,399,	
321,400,	322,401,	323,402,	324,403,	
325,404,	326,405,	327,406,	328,407,	
329,408,	330,409,	331,410,	332,411,	
333,412,	334,413,	335,414,	336,415,	
338,416,	339,417,	340,418,	342,419,	
343,420,	344,421,	346,422,	348,423,	
349,424,	350,425,	351,426,	352,427,	
353,428,	354,429,	355,430,	356,431,	
357,432,	359,433,	360,434,	361,435,	
363,436,	364,439,	365,440,	367,443,	
366,441,	368,444,	363,437,	366,442,	
369,445,	370,446,	363,438,	371,447,	
372,448,	373,449,	374,450,	375,451,	
376,452,	377,453,	378,454,	379,455,	
380,456,	381,457,	384,458,	385,459,	
386,460,	387,461,	388,462,	389,463,	
390,464,	391,465,	392,466,	393,467,	
394,468,	395,469,	396,470,	397,471,	
398,472,	399,473,	400,474,	401,475,	
402,476,	404,477,	406,478,	407,479,	
408,480,	409,481,	410,482,	411,483,	
413,484,	414,485,	415,486,	416,487,	
418,488,	419,489,	420,490,	421,491,	
423,492,	424,493,	426,494,	428,495,	
429,496,	430,497,	431,498,	432,499,	
433,500,	434,501,	435,502,	436,503,	
437,504,	438,505,	439,506,	440,507,	
441,508,	442,441,	444,509,	445,510,	
446,511,	447,512,	448,513,	450,514,	
451,515,	452,516,	453,517,	454,518,	
455,519,	456,520,	457,521,	458,522,	
459,523,	460,524,	461,526,	462,527,	
463,528,	465,529,	466,530,	468,531,	
460,525,	469,532,	471,533,	474,535,	
475,536,	471,534,	476,537,	477,538,	
478,539,	479,540,	480,541,	481,542,	
482,543,	484,544,	487,545,	488,546,	
489,547,	490,548,	491,549,	492,550,	
493,551,	495,552,	496,553,	498,554,	
500,555,	502,556,	503,557,	504,558,	
505,559,	506,560,	507,561,	508,562,	
509,563,	510,564,	511,565,	512,566,	
514,567,	515,568,	516,569,	517,570,	
518,571,	519,572,	520,573,	521,574,	
522,575,	523,576,	524,577,	525,578,	
527,579,	529,580,	531,581,	532,582,	
534,533,	535,583,	536,585,	537,586,	
535,584,	540,587,	541,588,	542,589,	
544,590,	545,591,	546,592,	547,593,	
548,594,	549,595,	550,596,	551,597,	
552,598,	553,599,	554,600,	555,601,	
556,602,	557,603,	558,604,	559,605,	
560,606,	561,607,	562,608,	563,609,	
565,610,	566,611,	568,612,	569,613,	
570,614,	571,615,	572,616,	575,618,	
576,619,	572,617,	577,620,	581,621,	
584,583,	585,622,	586,623,	587,624,	
588,625,	589,626,	590,627,	591,628,	
592,629,	593,630,	595,631,	596,632,	
597,633,	598,634,	599,635,	600,636,	
601,637,	605,638,	606,639,	607,640,	
608,641,	609,642,	610,643,	612,644,	
615,645,	617,616,	619,646,	621,647,	
622,648,	623,649,	624,650,	625,651,	
626,652,	628,653,	629,654,	630,655,	
632,656,	633,657,	634,658,	636,659,	
637,660,	638,661,	640,662,	642,663,	
644,664,	645,665,	646,666,	652,667,	
653,668,	655,669,	656,670,	658,671,	
659,672,	661,673,	662,674,	665,675,	
674,676,	675,677,	677,678,	678,679,	
0,0};
struct yysvf yysvec[] = {
0,	0,	0,
yycrank+1,	0,		yyvstop+1,
yycrank+0,	yysvec+1,	yyvstop+3,
yycrank+0,	0,		yyvstop+5,
yycrank+0,	0,		yyvstop+7,
yycrank+0,	0,		yyvstop+9,
yycrank+0,	0,		yyvstop+11,
yycrank+3,	0,		0,	
yycrank+0,	0,		yyvstop+13,
yycrank+0,	0,		yyvstop+15,
yycrank+0,	0,		yyvstop+17,
yycrank+0,	0,		yyvstop+19,
yycrank+0,	0,		yyvstop+21,
yycrank+0,	0,		yyvstop+23,
yycrank+0,	0,		yyvstop+25,
yycrank+0,	0,		yyvstop+27,
yycrank+79,	0,		yyvstop+29,
yycrank+17,	0,		yyvstop+31,
yycrank+101,	0,		yyvstop+33,
yycrank+0,	0,		yyvstop+35,
yycrank+116,	0,		yyvstop+37,
yycrank+0,	0,		yyvstop+39,
yycrank+141,	yysvec+20,	yyvstop+41,
yycrank+145,	yysvec+20,	yyvstop+43,
yycrank+146,	yysvec+20,	yyvstop+45,
yycrank+40,	yysvec+20,	yyvstop+47,
yycrank+12,	yysvec+20,	yyvstop+49,
yycrank+151,	yysvec+20,	yyvstop+51,
yycrank+45,	yysvec+20,	yyvstop+53,
yycrank+42,	yysvec+20,	yyvstop+55,
yycrank+28,	yysvec+20,	yyvstop+57,
yycrank+40,	yysvec+20,	yyvstop+59,
yycrank+30,	yysvec+20,	yyvstop+61,
yycrank+163,	yysvec+20,	yyvstop+63,
yycrank+141,	yysvec+20,	yyvstop+65,
yycrank+153,	yysvec+20,	yyvstop+67,
yycrank+168,	yysvec+20,	yyvstop+69,
yycrank+178,	yysvec+20,	yyvstop+71,
yycrank+186,	yysvec+20,	yyvstop+73,
yycrank+200,	yysvec+20,	yyvstop+75,
yycrank+32,	yysvec+20,	yyvstop+77,
yycrank+177,	yysvec+20,	yyvstop+79,
yycrank+63,	yysvec+20,	yyvstop+81,
yycrank+0,	0,		yyvstop+83,
yycrank+0,	0,		yyvstop+85,
yycrank+0,	0,		yyvstop+87,
yycrank+273,	0,		yyvstop+89,
yycrank+0,	0,		yyvstop+91,
yycrank+46,	yysvec+20,	yyvstop+93,
yycrank+77,	yysvec+20,	yyvstop+95,
yycrank+63,	yysvec+20,	yyvstop+97,
yycrank+186,	yysvec+20,	yyvstop+99,
yycrank+190,	yysvec+20,	yyvstop+101,
yycrank+193,	yysvec+20,	yyvstop+103,
yycrank+79,	yysvec+20,	yyvstop+105,
yycrank+199,	yysvec+20,	yyvstop+107,
yycrank+190,	yysvec+20,	yyvstop+109,
yycrank+67,	yysvec+20,	yyvstop+111,
yycrank+73,	yysvec+20,	yyvstop+113,
yycrank+230,	yysvec+20,	yyvstop+115,
yycrank+76,	yysvec+20,	yyvstop+117,
yycrank+98,	yysvec+20,	yyvstop+119,
yycrank+94,	yysvec+20,	yyvstop+121,
yycrank+92,	yysvec+20,	yyvstop+123,
yycrank+102,	yysvec+20,	yyvstop+125,
yycrank+111,	yysvec+20,	yyvstop+127,
yycrank+137,	yysvec+20,	yyvstop+129,
yycrank+146,	yysvec+20,	yyvstop+131,
yycrank+132,	yysvec+20,	yyvstop+133,
yycrank+134,	yysvec+20,	yyvstop+135,
yycrank+161,	yysvec+20,	yyvstop+137,
yycrank+149,	yysvec+20,	yyvstop+139,
yycrank+169,	yysvec+20,	yyvstop+141,
yycrank+162,	yysvec+20,	yyvstop+143,
yycrank+178,	yysvec+20,	yyvstop+145,
yycrank+221,	yysvec+20,	yyvstop+147,
yycrank+221,	yysvec+20,	yyvstop+149,
yycrank+180,	yysvec+20,	yyvstop+151,
yycrank+224,	yysvec+20,	yyvstop+153,
yycrank+195,	yysvec+20,	yyvstop+155,
yycrank+203,	yysvec+20,	yyvstop+157,
yycrank+211,	yysvec+20,	yyvstop+159,
yycrank+0,	yysvec+20,	yyvstop+161,
yycrank+235,	yysvec+20,	yyvstop+164,
yycrank+199,	yysvec+20,	yyvstop+166,
yycrank+222,	yysvec+20,	yyvstop+168,
yycrank+245,	yysvec+20,	yyvstop+170,
yycrank+223,	yysvec+20,	yyvstop+172,
yycrank+234,	yysvec+20,	yyvstop+174,
yycrank+247,	yysvec+20,	yyvstop+176,
yycrank+246,	yysvec+20,	yyvstop+178,
yycrank+249,	yysvec+20,	yyvstop+180,
yycrank+251,	yysvec+20,	yyvstop+182,
yycrank+0,	yysvec+20,	yyvstop+184,
yycrank+249,	yysvec+20,	yyvstop+187,
yycrank+236,	yysvec+20,	yyvstop+189,
yycrank+256,	yysvec+20,	yyvstop+191,
yycrank+257,	yysvec+20,	yyvstop+193,
yycrank+233,	yysvec+20,	yyvstop+195,
yycrank+242,	yysvec+20,	yyvstop+197,
yycrank+243,	yysvec+20,	yyvstop+199,
yycrank+247,	yysvec+20,	yyvstop+201,
yycrank+264,	yysvec+20,	yyvstop+203,
yycrank+243,	yysvec+20,	yyvstop+205,
yycrank+250,	yysvec+20,	yyvstop+207,
yycrank+249,	yysvec+20,	yyvstop+209,
yycrank+254,	yysvec+20,	yyvstop+211,
yycrank+270,	yysvec+20,	yyvstop+213,
yycrank+255,	yysvec+20,	yyvstop+215,
yycrank+270,	yysvec+20,	yyvstop+217,
yycrank+0,	yysvec+20,	yyvstop+219,
yycrank+261,	yysvec+20,	yyvstop+222,
yycrank+259,	yysvec+20,	yyvstop+224,
yycrank+263,	yysvec+20,	yyvstop+226,
yycrank+261,	yysvec+20,	yyvstop+228,
yycrank+258,	yysvec+20,	yyvstop+230,
yycrank+329,	0,		yyvstop+232,
yycrank+276,	yysvec+20,	yyvstop+234,
yycrank+276,	yysvec+20,	yyvstop+236,
yycrank+285,	yysvec+20,	yyvstop+238,
yycrank+285,	yysvec+20,	yyvstop+240,
yycrank+283,	yysvec+20,	yyvstop+242,
yycrank+284,	yysvec+20,	yyvstop+244,
yycrank+288,	yysvec+20,	yyvstop+246,
yycrank+287,	yysvec+20,	yyvstop+248,
yycrank+294,	yysvec+20,	yyvstop+250,
yycrank+287,	yysvec+20,	yyvstop+252,
yycrank+287,	yysvec+20,	yyvstop+254,
yycrank+299,	yysvec+20,	yyvstop+256,
yycrank+301,	yysvec+20,	yyvstop+258,
yycrank+285,	yysvec+20,	yyvstop+260,
yycrank+286,	yysvec+20,	yyvstop+262,
yycrank+291,	yysvec+20,	yyvstop+264,
yycrank+302,	yysvec+20,	yyvstop+266,
yycrank+294,	yysvec+20,	yyvstop+268,
yycrank+294,	yysvec+20,	yyvstop+270,
yycrank+292,	yysvec+20,	yyvstop+272,
yycrank+0,	yysvec+20,	yyvstop+274,
yycrank+296,	yysvec+20,	yyvstop+277,
yycrank+308,	yysvec+20,	yyvstop+279,
yycrank+313,	yysvec+20,	yyvstop+281,
yycrank+303,	yysvec+20,	yyvstop+283,
yycrank+304,	yysvec+20,	yyvstop+285,
yycrank+311,	yysvec+20,	yyvstop+287,
yycrank+305,	yysvec+20,	yyvstop+289,
yycrank+316,	yysvec+20,	yyvstop+291,
yycrank+314,	yysvec+20,	yyvstop+293,
yycrank+317,	yysvec+20,	yyvstop+295,
yycrank+317,	yysvec+20,	yyvstop+297,
yycrank+316,	yysvec+20,	yyvstop+299,
yycrank+315,	yysvec+20,	yyvstop+301,
yycrank+307,	yysvec+20,	yyvstop+303,
yycrank+325,	yysvec+20,	yyvstop+305,
yycrank+317,	yysvec+20,	yyvstop+307,
yycrank+0,	yysvec+20,	yyvstop+309,
yycrank+324,	yysvec+20,	yyvstop+312,
yycrank+322,	yysvec+20,	yyvstop+314,
yycrank+330,	yysvec+20,	yyvstop+316,
yycrank+328,	yysvec+20,	yyvstop+318,
yycrank+311,	yysvec+20,	yyvstop+320,
yycrank+321,	yysvec+20,	yyvstop+322,
yycrank+318,	yysvec+20,	yyvstop+324,
yycrank+331,	yysvec+20,	yyvstop+326,
yycrank+333,	yysvec+20,	yyvstop+329,
yycrank+331,	yysvec+20,	yyvstop+331,
yycrank+324,	yysvec+20,	yyvstop+333,
yycrank+324,	yysvec+20,	yyvstop+335,
yycrank+325,	yysvec+20,	yyvstop+337,
yycrank+331,	yysvec+20,	yyvstop+339,
yycrank+341,	yysvec+20,	yyvstop+341,
yycrank+337,	yysvec+20,	yyvstop+343,
yycrank+339,	yysvec+20,	yyvstop+345,
yycrank+342,	yysvec+20,	yyvstop+347,
yycrank+331,	yysvec+20,	yyvstop+349,
yycrank+339,	yysvec+20,	yyvstop+351,
yycrank+347,	yysvec+20,	yyvstop+353,
yycrank+350,	yysvec+20,	yyvstop+355,
yycrank+353,	yysvec+20,	yyvstop+357,
yycrank+354,	yysvec+20,	yyvstop+360,
yycrank+355,	yysvec+20,	yyvstop+363,
yycrank+345,	yysvec+20,	yyvstop+365,
yycrank+353,	yysvec+20,	yyvstop+367,
yycrank+355,	yysvec+20,	yyvstop+369,
yycrank+355,	yysvec+20,	yyvstop+371,
yycrank+343,	yysvec+20,	yyvstop+373,
yycrank+357,	yysvec+20,	yyvstop+375,
yycrank+354,	yysvec+20,	yyvstop+377,
yycrank+360,	yysvec+20,	yyvstop+379,
yycrank+345,	yysvec+20,	yyvstop+381,
yycrank+361,	yysvec+20,	yyvstop+383,
yycrank+355,	yysvec+20,	yyvstop+385,
yycrank+0,	yysvec+20,	yyvstop+387,
yycrank+354,	yysvec+20,	yyvstop+390,
yycrank+367,	yysvec+20,	yyvstop+392,
yycrank+356,	yysvec+20,	yyvstop+394,
yycrank+359,	yysvec+20,	yyvstop+396,
yycrank+352,	yysvec+20,	yyvstop+398,
yycrank+355,	yysvec+20,	yyvstop+400,
yycrank+354,	yysvec+20,	yyvstop+402,
yycrank+370,	yysvec+20,	yyvstop+404,
yycrank+358,	yysvec+20,	yyvstop+406,
yycrank+357,	yysvec+20,	yyvstop+408,
yycrank+377,	yysvec+20,	yyvstop+410,
yycrank+374,	yysvec+20,	yyvstop+412,
yycrank+371,	yysvec+20,	yyvstop+414,
yycrank+376,	yysvec+20,	yyvstop+416,
yycrank+381,	yysvec+20,	yyvstop+418,
yycrank+377,	yysvec+20,	yyvstop+420,
yycrank+0,	yysvec+20,	yyvstop+422,
yycrank+366,	yysvec+20,	yyvstop+425,
yycrank+382,	yysvec+20,	yyvstop+427,
yycrank+383,	yysvec+20,	yyvstop+429,
yycrank+377,	yysvec+20,	yyvstop+431,
yycrank+378,	yysvec+20,	yyvstop+433,
yycrank+385,	yysvec+20,	yyvstop+435,
yycrank+386,	yysvec+20,	yyvstop+437,
yycrank+370,	yysvec+20,	yyvstop+439,
yycrank+387,	yysvec+20,	yyvstop+441,
yycrank+376,	yysvec+20,	yyvstop+443,
yycrank+380,	yysvec+20,	yyvstop+445,
yycrank+376,	yysvec+20,	yyvstop+447,
yycrank+389,	yysvec+20,	yyvstop+449,
yycrank+396,	yysvec+20,	yyvstop+451,
yycrank+380,	yysvec+20,	yyvstop+453,
yycrank+386,	yysvec+20,	yyvstop+455,
yycrank+398,	yysvec+20,	yyvstop+457,
yycrank+402,	yysvec+20,	yyvstop+459,
yycrank+400,	yysvec+20,	yyvstop+461,
yycrank+391,	yysvec+20,	yyvstop+463,
yycrank+398,	yysvec+20,	yyvstop+465,
yycrank+399,	yysvec+20,	yyvstop+467,
yycrank+385,	yysvec+20,	yyvstop+469,
yycrank+0,	yysvec+20,	yyvstop+471,
yycrank+409,	yysvec+20,	yyvstop+474,
yycrank+405,	yysvec+20,	yyvstop+476,
yycrank+410,	yysvec+20,	yyvstop+478,
yycrank+410,	yysvec+20,	yyvstop+480,
yycrank+396,	yysvec+20,	yyvstop+482,
yycrank+416,	yysvec+20,	yyvstop+484,
yycrank+400,	yysvec+20,	yyvstop+486,
yycrank+410,	yysvec+20,	yyvstop+488,
yycrank+399,	yysvec+20,	yyvstop+490,
yycrank+403,	yysvec+20,	yyvstop+492,
yycrank+420,	yysvec+20,	yyvstop+494,
yycrank+414,	yysvec+20,	yyvstop+496,
yycrank+423,	yysvec+20,	yyvstop+498,
yycrank+424,	yysvec+20,	yyvstop+500,
yycrank+425,	yysvec+20,	yyvstop+502,
yycrank+418,	yysvec+20,	yyvstop+504,
yycrank+410,	yysvec+20,	yyvstop+506,
yycrank+414,	yysvec+20,	yyvstop+508,
yycrank+409,	yysvec+20,	yyvstop+510,
yycrank+415,	yysvec+20,	yyvstop+512,
yycrank+427,	yysvec+20,	yyvstop+514,
yycrank+426,	yysvec+20,	yyvstop+516,
yycrank+422,	yysvec+20,	yyvstop+518,
yycrank+430,	yysvec+20,	yyvstop+520,
yycrank+427,	yysvec+20,	yyvstop+522,
yycrank+432,	yysvec+20,	yyvstop+524,
yycrank+422,	yysvec+20,	yyvstop+526,
yycrank+434,	yysvec+20,	yyvstop+528,
yycrank+439,	yysvec+20,	yyvstop+530,
yycrank+421,	yysvec+20,	yyvstop+532,
yycrank+0,	yysvec+20,	yyvstop+534,
yycrank+0,	yysvec+20,	yyvstop+537,
yycrank+422,	yysvec+20,	yyvstop+540,
yycrank+438,	yysvec+20,	yyvstop+542,
yycrank+439,	yysvec+20,	yyvstop+544,
yycrank+430,	yysvec+20,	yyvstop+546,
yycrank+0,	yysvec+20,	yyvstop+548,
yycrank+443,	yysvec+20,	yyvstop+551,
yycrank+442,	yysvec+20,	yyvstop+553,
yycrank+433,	yysvec+20,	yyvstop+555,
yycrank+441,	yysvec+20,	yyvstop+557,
yycrank+430,	yysvec+20,	yyvstop+559,
yycrank+433,	yysvec+20,	yyvstop+561,
yycrank+448,	yysvec+20,	yyvstop+563,
yycrank+435,	yysvec+20,	yyvstop+565,
yycrank+434,	yysvec+20,	yyvstop+567,
yycrank+436,	yysvec+20,	yyvstop+569,
yycrank+442,	yysvec+20,	yyvstop+571,
yycrank+453,	yysvec+20,	yyvstop+573,
yycrank+446,	yysvec+20,	yyvstop+575,
yycrank+454,	yysvec+20,	yyvstop+577,
yycrank+449,	yysvec+20,	yyvstop+579,
yycrank+446,	yysvec+20,	yyvstop+581,
yycrank+454,	yysvec+20,	yyvstop+583,
yycrank+0,	yysvec+20,	yyvstop+585,
yycrank+450,	yysvec+20,	yyvstop+588,
yycrank+445,	yysvec+20,	yyvstop+590,
yycrank+0,	yysvec+20,	yyvstop+592,
yycrank+454,	yysvec+20,	yyvstop+595,
yycrank+466,	yysvec+20,	yyvstop+597,
yycrank+450,	yysvec+20,	yyvstop+599,
yycrank+0,	yysvec+20,	yyvstop+601,
yycrank+460,	yysvec+20,	yyvstop+604,
yycrank+467,	yysvec+20,	yyvstop+606,
yycrank+452,	yysvec+20,	yyvstop+609,
yycrank+453,	yysvec+20,	yyvstop+611,
yycrank+0,	yysvec+20,	yyvstop+613,
yycrank+455,	yysvec+20,	yyvstop+616,
yycrank+469,	yysvec+20,	yyvstop+618,
yycrank+460,	yysvec+20,	yyvstop+620,
yycrank+467,	yysvec+20,	yyvstop+622,
yycrank+471,	yysvec+20,	yyvstop+624,
yycrank+460,	yysvec+20,	yyvstop+627,
yycrank+460,	yysvec+20,	yyvstop+629,
yycrank+479,	yysvec+20,	yyvstop+631,
yycrank+467,	yysvec+20,	yyvstop+633,
yycrank+462,	yysvec+20,	yyvstop+635,
yycrank+474,	yysvec+20,	yyvstop+637,
yycrank+479,	yysvec+20,	yyvstop+639,
yycrank+471,	yysvec+20,	yyvstop+641,
yycrank+484,	yysvec+20,	yyvstop+643,
yycrank+474,	yysvec+20,	yyvstop+645,
yycrank+477,	yysvec+20,	yyvstop+647,
yycrank+464,	yysvec+20,	yyvstop+649,
yycrank+479,	yysvec+20,	yyvstop+651,
yycrank+0,	yysvec+20,	yyvstop+653,
yycrank+0,	yysvec+20,	yyvstop+656,
yycrank+0,	yysvec+20,	yyvstop+659,
yycrank+477,	yysvec+20,	yyvstop+662,
yycrank+473,	yysvec+20,	yyvstop+664,
yycrank+489,	yysvec+20,	yyvstop+666,
yycrank+490,	yysvec+20,	yyvstop+668,
yycrank+487,	yysvec+20,	yyvstop+670,
yycrank+477,	yysvec+20,	yyvstop+672,
yycrank+489,	yysvec+20,	yyvstop+674,
yycrank+479,	yysvec+20,	yyvstop+676,
yycrank+498,	yysvec+20,	yyvstop+678,
yycrank+496,	yysvec+20,	yyvstop+680,
yycrank+501,	yysvec+20,	yyvstop+682,
yycrank+484,	yysvec+20,	yyvstop+684,
yycrank+492,	yysvec+20,	yyvstop+686,
yycrank+493,	yysvec+20,	yyvstop+688,
yycrank+481,	yysvec+20,	yyvstop+690,
yycrank+495,	yysvec+20,	yyvstop+692,
yycrank+0,	yysvec+20,	yyvstop+694,
yycrank+501,	yysvec+20,	yyvstop+697,
yycrank+489,	yysvec+20,	yyvstop+699,
yycrank+505,	yysvec+20,	yyvstop+701,
yycrank+0,	yysvec+20,	yyvstop+703,
yycrank+492,	yysvec+20,	yyvstop+706,
yycrank+505,	yysvec+20,	yyvstop+708,
yycrank+510,	yysvec+20,	yyvstop+710,
yycrank+0,	yysvec+20,	yyvstop+712,
yycrank+495,	yysvec+20,	yyvstop+715,
yycrank+0,	yysvec+20,	yyvstop+717,
yycrank+510,	yysvec+20,	yyvstop+720,
yycrank+513,	yysvec+20,	yyvstop+722,
yycrank+497,	yysvec+20,	yyvstop+724,
yycrank+503,	yysvec+20,	yyvstop+726,
yycrank+514,	yysvec+20,	yyvstop+728,
yycrank+514,	yysvec+20,	yyvstop+730,
yycrank+507,	yysvec+20,	yyvstop+733,
yycrank+499,	yysvec+20,	yyvstop+735,
yycrank+518,	yysvec+20,	yyvstop+737,
yycrank+498,	yysvec+20,	yyvstop+739,
yycrank+0,	yysvec+20,	yyvstop+741,
yycrank+503,	yysvec+20,	yyvstop+744,
yycrank+508,	yysvec+20,	yyvstop+746,
yycrank+519,	yysvec+20,	yyvstop+748,
yycrank+0,	yysvec+20,	yyvstop+750,
yycrank+522,	yysvec+20,	yyvstop+753,
yycrank+517,	yysvec+20,	yyvstop+755,
yycrank+505,	yysvec+20,	yyvstop+757,
yycrank+514,	yysvec+20,	yyvstop+759,
yycrank+507,	yysvec+20,	yyvstop+761,
yycrank+532,	yysvec+20,	yyvstop+763,
yycrank+527,	yysvec+20,	yyvstop+765,
yycrank+532,	yysvec+20,	yyvstop+767,
yycrank+519,	yysvec+20,	yyvstop+769,
yycrank+518,	yysvec+20,	yyvstop+771,
yycrank+521,	yysvec+20,	yyvstop+773,
yycrank+521,	yysvec+20,	yyvstop+775,
yycrank+534,	yysvec+20,	yyvstop+777,
yycrank+541,	yysvec+20,	yyvstop+779,
yycrank+530,	yysvec+20,	yyvstop+781,
yycrank+527,	yysvec+20,	yyvstop+783,
yycrank+532,	yysvec+20,	yyvstop+785,
yycrank+539,	yysvec+20,	yyvstop+787,
yycrank+540,	yysvec+20,	yyvstop+789,
yycrank+0,	yysvec+20,	yyvstop+791,
yycrank+0,	yysvec+20,	yyvstop+794,
yycrank+538,	yysvec+20,	yyvstop+797,
yycrank+548,	yysvec+20,	yyvstop+799,
yycrank+543,	yysvec+20,	yyvstop+801,
yycrank+552,	yysvec+20,	yyvstop+803,
yycrank+545,	yysvec+20,	yyvstop+805,
yycrank+541,	yysvec+20,	yyvstop+807,
yycrank+549,	yysvec+20,	yyvstop+809,
yycrank+548,	yysvec+20,	yyvstop+811,
yycrank+543,	yysvec+20,	yyvstop+813,
yycrank+553,	yysvec+20,	yyvstop+815,
yycrank+554,	yysvec+20,	yyvstop+817,
yycrank+541,	yysvec+20,	yyvstop+819,
yycrank+547,	yysvec+20,	yyvstop+821,
yycrank+548,	yysvec+20,	yyvstop+823,
yycrank+559,	yysvec+20,	yyvstop+825,
yycrank+560,	yysvec+20,	yyvstop+827,
yycrank+554,	yysvec+20,	yyvstop+829,
yycrank+561,	yysvec+20,	yyvstop+831,
yycrank+567,	yysvec+20,	yyvstop+833,
yycrank+0,	yysvec+20,	yyvstop+835,
yycrank+554,	yysvec+20,	yyvstop+838,
yycrank+0,	yysvec+20,	yyvstop+840,
yycrank+569,	yysvec+20,	yyvstop+843,
yycrank+559,	yysvec+20,	yyvstop+845,
yycrank+560,	yysvec+20,	yyvstop+847,
yycrank+568,	yysvec+20,	yyvstop+849,
yycrank+562,	yysvec+20,	yyvstop+851,
yycrank+555,	yysvec+20,	yyvstop+853,
yycrank+0,	yysvec+20,	yyvstop+855,
yycrank+570,	yysvec+20,	yyvstop+858,
yycrank+558,	yysvec+20,	yyvstop+860,
yycrank+573,	yysvec+20,	yyvstop+862,
yycrank+561,	yysvec+20,	yyvstop+864,
yycrank+0,	yysvec+20,	yyvstop+866,
yycrank+577,	yysvec+20,	yyvstop+869,
yycrank+573,	yysvec+20,	yyvstop+871,
yycrank+564,	yysvec+20,	yyvstop+873,
yycrank+563,	yysvec+20,	yyvstop+875,
yycrank+0,	yysvec+20,	yyvstop+877,
yycrank+566,	yysvec+20,	yyvstop+880,
yycrank+565,	yysvec+20,	yyvstop+882,
yycrank+0,	yysvec+20,	yyvstop+884,
yycrank+568,	yysvec+20,	yyvstop+887,
yycrank+0,	yysvec+20,	yyvstop+889,
yycrank+586,	yysvec+20,	yyvstop+892,
yycrank+569,	yysvec+20,	yyvstop+894,
yycrank+570,	yysvec+20,	yyvstop+896,
yycrank+572,	yysvec+20,	yyvstop+898,
yycrank+586,	yysvec+20,	yyvstop+901,
yycrank+583,	yysvec+20,	yyvstop+903,
yycrank+588,	yysvec+20,	yyvstop+905,
yycrank+579,	yysvec+20,	yyvstop+907,
yycrank+580,	yysvec+20,	yyvstop+909,
yycrank+595,	yysvec+20,	yyvstop+911,
yycrank+596,	yysvec+20,	yyvstop+913,
yycrank+593,	yysvec+20,	yyvstop+915,
yycrank+593,	yysvec+20,	yyvstop+917,
yycrank+594,	yysvec+20,	yyvstop+919,
yycrank+583,	yysvec+20,	yyvstop+921,
yycrank+0,	yysvec+20,	yyvstop+923,
yycrank+590,	yysvec+20,	yyvstop+926,
yycrank+591,	yysvec+20,	yyvstop+928,
yycrank+590,	yysvec+20,	yyvstop+930,
yycrank+596,	yysvec+20,	yyvstop+932,
yycrank+601,	yysvec+20,	yyvstop+934,
yycrank+0,	yysvec+20,	yyvstop+936,
yycrank+603,	yysvec+20,	yyvstop+939,
yycrank+607,	yysvec+20,	yyvstop+941,
yycrank+600,	yysvec+20,	yyvstop+943,
yycrank+589,	yysvec+20,	yyvstop+945,
yycrank+591,	yysvec+20,	yyvstop+947,
yycrank+600,	yysvec+20,	yyvstop+949,
yycrank+587,	yysvec+20,	yyvstop+951,
yycrank+588,	yysvec+20,	yyvstop+953,
yycrank+594,	yysvec+20,	yyvstop+955,
yycrank+607,	yysvec+20,	yyvstop+957,
yycrank+612,	yysvec+20,	yyvstop+959,
yycrank+602,	yysvec+20,	yyvstop+961,
yycrank+599,	yysvec+20,	yyvstop+963,
yycrank+600,	yysvec+20,	yyvstop+965,
yycrank+0,	yysvec+20,	yyvstop+967,
yycrank+606,	yysvec+20,	yyvstop+970,
yycrank+608,	yysvec+20,	yyvstop+972,
yycrank+0,	yysvec+20,	yyvstop+974,
yycrank+601,	yysvec+20,	yyvstop+977,
yycrank+610,	yysvec+20,	yyvstop+979,
yycrank+0,	yysvec+20,	yyvstop+981,
yycrank+608,	yysvec+20,	yyvstop+984,
yycrank+0,	yysvec+20,	yyvstop+986,
yycrank+0,	yysvec+20,	yyvstop+989,
yycrank+612,	yysvec+20,	yyvstop+992,
yycrank+619,	yysvec+20,	yyvstop+994,
yycrank+616,	yysvec+20,	yyvstop+996,
yycrank+617,	yysvec+20,	yyvstop+998,
yycrank+620,	yysvec+20,	yyvstop+1000,
yycrank+628,	yysvec+20,	yyvstop+1002,
yycrank+629,	yysvec+20,	yyvstop+1004,
yycrank+631,	yysvec+20,	yyvstop+1006,
yycrank+624,	yysvec+20,	yyvstop+1008,
yycrank+0,	yysvec+20,	yyvstop+1010,
yycrank+628,	yysvec+20,	yyvstop+1013,
yycrank+0,	yysvec+20,	yyvstop+1015,
yycrank+0,	yysvec+20,	yyvstop+1018,
yycrank+637,	yysvec+20,	yyvstop+1021,
yycrank+619,	yysvec+20,	yyvstop+1023,
yycrank+639,	yysvec+20,	yyvstop+1025,
yycrank+632,	yysvec+20,	yyvstop+1027,
yycrank+633,	yysvec+20,	yyvstop+1029,
yycrank+627,	yysvec+20,	yyvstop+1031,
yycrank+643,	yysvec+20,	yyvstop+1033,
yycrank+0,	yysvec+20,	yyvstop+1035,
yycrank+642,	yysvec+20,	yyvstop+1038,
yycrank+637,	yysvec+20,	yyvstop+1040,
yycrank+0,	yysvec+20,	yyvstop+1042,
yycrank+646,	yysvec+20,	yyvstop+1045,
yycrank+0,	yysvec+20,	yyvstop+1047,
yycrank+629,	yysvec+20,	yyvstop+1050,
yycrank+0,	yysvec+20,	yyvstop+1052,
yycrank+637,	yysvec+20,	yyvstop+1055,
yycrank+632,	yysvec+20,	yyvstop+1057,
yycrank+631,	yysvec+20,	yyvstop+1059,
yycrank+634,	yysvec+20,	yyvstop+1061,
yycrank+639,	yysvec+20,	yyvstop+1063,
yycrank+645,	yysvec+20,	yyvstop+1065,
yycrank+646,	yysvec+20,	yyvstop+1067,
yycrank+650,	yysvec+20,	yyvstop+1069,
yycrank+652,	yysvec+20,	yyvstop+1071,
yycrank+651,	yysvec+20,	yyvstop+1073,
yycrank+644,	yysvec+20,	yyvstop+1075,
yycrank+0,	yysvec+20,	yyvstop+1077,
yycrank+655,	yysvec+20,	yyvstop+1080,
yycrank+642,	yysvec+20,	yyvstop+1082,
yycrank+648,	yysvec+20,	yyvstop+1084,
yycrank+649,	yysvec+20,	yyvstop+1086,
yycrank+646,	yysvec+20,	yyvstop+1088,
yycrank+650,	yysvec+20,	yyvstop+1090,
yycrank+661,	yysvec+20,	yyvstop+1092,
yycrank+662,	yysvec+20,	yyvstop+1094,
yycrank+655,	yysvec+20,	yyvstop+1096,
yycrank+664,	yysvec+20,	yyvstop+1098,
yycrank+658,	yysvec+20,	yyvstop+1100,
yycrank+666,	yysvec+20,	yyvstop+1102,
yycrank+0,	yysvec+20,	yyvstop+1104,
yycrank+667,	yysvec+20,	yyvstop+1107,
yycrank+0,	yysvec+20,	yyvstop+1109,
yycrank+659,	yysvec+20,	yyvstop+1112,
yycrank+0,	yysvec+20,	yyvstop+1114,
yycrank+665,	yysvec+20,	yyvstop+1117,
yycrank+657,	yysvec+20,	yyvstop+1119,
yycrank+0,	yysvec+20,	yyvstop+1121,
yycrank+658,	yysvec+20,	yyvstop+1124,
yycrank+659,	yysvec+20,	yyvstop+1126,
yycrank+673,	yysvec+20,	yyvstop+1128,
yycrank+672,	yysvec+20,	yyvstop+1130,
yycrank+0,	yysvec+20,	yyvstop+1132,
yycrank+0,	yysvec+20,	yyvstop+1135,
yycrank+659,	yysvec+20,	yyvstop+1138,
yycrank+660,	yysvec+20,	yyvstop+1140,
yycrank+678,	yysvec+20,	yyvstop+1142,
yycrank+0,	yysvec+20,	yyvstop+1144,
yycrank+672,	yysvec+20,	yyvstop+1147,
yycrank+669,	yysvec+20,	yyvstop+1149,
yycrank+677,	yysvec+20,	yyvstop+1151,
yycrank+683,	yysvec+20,	yyvstop+1153,
yycrank+684,	yysvec+20,	yyvstop+1155,
yycrank+674,	yysvec+20,	yyvstop+1157,
yycrank+681,	yysvec+20,	yyvstop+1159,
yycrank+677,	yysvec+20,	yyvstop+1161,
yycrank+672,	yysvec+20,	yyvstop+1163,
yycrank+667,	yysvec+20,	yyvstop+1165,
yycrank+690,	yysvec+20,	yyvstop+1167,
yycrank+686,	yysvec+20,	yyvstop+1169,
yycrank+692,	yysvec+20,	yyvstop+1171,
yycrank+684,	yysvec+20,	yyvstop+1173,
yycrank+693,	yysvec+20,	yyvstop+1175,
yycrank+694,	yysvec+20,	yyvstop+1177,
yycrank+697,	yysvec+20,	yyvstop+1179,
yycrank+679,	yysvec+20,	yyvstop+1181,
yycrank+690,	yysvec+20,	yyvstop+1183,
yycrank+694,	yysvec+20,	yyvstop+1185,
yycrank+0,	yysvec+20,	yyvstop+1187,
yycrank+684,	yysvec+20,	yyvstop+1190,
yycrank+691,	yysvec+20,	yyvstop+1192,
yycrank+0,	yysvec+20,	yyvstop+1194,
yycrank+697,	yysvec+20,	yyvstop+1197,
yycrank+700,	yysvec+20,	yyvstop+1199,
yycrank+704,	yysvec+20,	yyvstop+1201,
yycrank+700,	yysvec+20,	yyvstop+1203,
yycrank+692,	yysvec+20,	yyvstop+1205,
yycrank+0,	yysvec+20,	yyvstop+1207,
yycrank+0,	yysvec+20,	yyvstop+1210,
yycrank+706,	yysvec+20,	yyvstop+1213,
yycrank+698,	yysvec+20,	yyvstop+1215,
yycrank+710,	yysvec+20,	yyvstop+1217,
yycrank+0,	yysvec+20,	yyvstop+1219,
yycrank+0,	yysvec+20,	yyvstop+1222,
yycrank+0,	yysvec+20,	yyvstop+1225,
yycrank+710,	yysvec+20,	yyvstop+1228,
yycrank+0,	yysvec+20,	yyvstop+1230,
yycrank+0,	yysvec+20,	yyvstop+1233,
yycrank+698,	yysvec+20,	yyvstop+1236,
yycrank+705,	yysvec+20,	yyvstop+1238,
yycrank+706,	yysvec+20,	yyvstop+1240,
yycrank+714,	yysvec+20,	yyvstop+1242,
yycrank+715,	yysvec+20,	yyvstop+1244,
yycrank+705,	yysvec+20,	yyvstop+1246,
yycrank+717,	yysvec+20,	yyvstop+1248,
yycrank+715,	yysvec+20,	yyvstop+1250,
yycrank+702,	yysvec+20,	yyvstop+1252,
yycrank+716,	yysvec+20,	yyvstop+1254,
yycrank+0,	yysvec+20,	yyvstop+1256,
yycrank+712,	yysvec+20,	yyvstop+1259,
yycrank+703,	yysvec+20,	yyvstop+1261,
yycrank+725,	yysvec+20,	yyvstop+1263,
yycrank+714,	yysvec+20,	yyvstop+1265,
yycrank+725,	yysvec+20,	yyvstop+1267,
yycrank+722,	yysvec+20,	yyvstop+1269,
yycrank+717,	yysvec+20,	yyvstop+1271,
yycrank+0,	yysvec+20,	yyvstop+1273,
yycrank+0,	yysvec+20,	yyvstop+1277,
yycrank+0,	yysvec+20,	yyvstop+1280,
yycrank+719,	yysvec+20,	yyvstop+1283,
yycrank+729,	yysvec+20,	yyvstop+1285,
yycrank+730,	yysvec+20,	yyvstop+1287,
yycrank+731,	yysvec+20,	yyvstop+1289,
yycrank+725,	yysvec+20,	yyvstop+1291,
yycrank+730,	yysvec+20,	yyvstop+1293,
yycrank+0,	yysvec+20,	yyvstop+1295,
yycrank+725,	yysvec+20,	yyvstop+1298,
yycrank+0,	yysvec+20,	yyvstop+1300,
yycrank+0,	yysvec+20,	yyvstop+1303,
yycrank+738,	yysvec+20,	yyvstop+1306,
yycrank+0,	yysvec+20,	yyvstop+1308,
yycrank+723,	yysvec+20,	yyvstop+1311,
yycrank+0,	yysvec+20,	yyvstop+1313,
yycrank+722,	yysvec+20,	yyvstop+1316,
yycrank+0,	yysvec+20,	yyvstop+1318,
yycrank+720,	yysvec+20,	yyvstop+1321,
yycrank+740,	yysvec+20,	yyvstop+1323,
yycrank+740,	yysvec+20,	yyvstop+1325,
yycrank+734,	yysvec+20,	yyvstop+1327,
yycrank+735,	yysvec+20,	yyvstop+1329,
yycrank+728,	yysvec+20,	yyvstop+1331,
yycrank+0,	yysvec+20,	yyvstop+1333,
yycrank+740,	yysvec+20,	yyvstop+1336,
yycrank+745,	yysvec+20,	yyvstop+1338,
yycrank+737,	yysvec+20,	yyvstop+1340,
yycrank+0,	yysvec+20,	yyvstop+1342,
yycrank+747,	yysvec+20,	yyvstop+1345,
yycrank+748,	yysvec+20,	yyvstop+1347,
yycrank+736,	yysvec+20,	yyvstop+1349,
yycrank+0,	yysvec+20,	yyvstop+1351,
yycrank+734,	yysvec+20,	yyvstop+1354,
yycrank+742,	yysvec+20,	yyvstop+1356,
yycrank+754,	yysvec+20,	yyvstop+1358,
yycrank+0,	yysvec+20,	yyvstop+1360,
yycrank+756,	yysvec+20,	yyvstop+1363,
yycrank+0,	yysvec+20,	yyvstop+1365,
yycrank+754,	yysvec+20,	yyvstop+1368,
yycrank+0,	yysvec+20,	yyvstop+1370,
yycrank+753,	yysvec+20,	yyvstop+1373,
yycrank+740,	yysvec+20,	yyvstop+1375,
yycrank+743,	yysvec+20,	yyvstop+1377,
yycrank+0,	yysvec+20,	yyvstop+1379,
yycrank+0,	yysvec+20,	yyvstop+1382,
yycrank+0,	yysvec+20,	yyvstop+1385,
yycrank+0,	yysvec+20,	yyvstop+1388,
yycrank+0,	yysvec+20,	yyvstop+1391,
yycrank+755,	yysvec+20,	yyvstop+1394,
yycrank+761,	yysvec+20,	yyvstop+1396,
yycrank+0,	yysvec+20,	yyvstop+1398,
yycrank+758,	yysvec+20,	yyvstop+1401,
yycrank+754,	yysvec+20,	yyvstop+1403,
yycrank+0,	yysvec+20,	yyvstop+1405,
yycrank+748,	yysvec+20,	yyvstop+1408,
yycrank+749,	yysvec+20,	yyvstop+1411,
yycrank+0,	yysvec+20,	yyvstop+1413,
yycrank+744,	yysvec+20,	yyvstop+1416,
yycrank+761,	yysvec+20,	yyvstop+1418,
yycrank+0,	yysvec+20,	yyvstop+1420,
yycrank+0,	yysvec+20,	yyvstop+1423,
yycrank+751,	yysvec+20,	yyvstop+1426,
yycrank+0,	yysvec+20,	yyvstop+1428,
yycrank+0,	yysvec+20,	yyvstop+1431,
yycrank+0,	yysvec+20,	yyvstop+1434,
yycrank+0,	yysvec+20,	yyvstop+1437,
yycrank+0,	yysvec+20,	yyvstop+1440,
yycrank+0,	yysvec+20,	yyvstop+1443,
yycrank+0,	yysvec+20,	yyvstop+1446,
yycrank+0,	yysvec+20,	yyvstop+1449,
yycrank+752,	yysvec+20,	yyvstop+1452,
yycrank+764,	yysvec+20,	yyvstop+1454,
yycrank+0,	yysvec+20,	yyvstop+1456,
yycrank+759,	yysvec+20,	yyvstop+1459,
yycrank+761,	yysvec+20,	yyvstop+1461,
yycrank+0,	yysvec+20,	yyvstop+1463,
0,	0,	0};
struct yywork *yytop = yycrank+871;
struct yysvf *yybgin = yysvec+1;
char yymatch[] = {
  0,   1,   1,   1,   1,   1,   1,   1, 
  1,   9,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  9,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,  43,   1,  43,  46,  46, 
 48,  48,  48,  48,  48,  48,  48,  48, 
 48,  48,   1,   1,   1,   1,   1,   1, 
  1,  65,  65,  65,  65,  69,  65,  65, 
 65,  65,  65,  65,  65,  65,  65,  65, 
 65,  65,  65,  65,  65,  65,  65,  65, 
 65,  65,  65,   1,   1,   1,   1,  65, 
  1,  65,  65,  65,  65,  69,  65,  65, 
 65,  65,  65,  65,  65,  65,  65,  65, 
 65,  65,  65,  65,  65,  65,  65,  65, 
 65,  65,  65,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
0};
char yyextra[] = {
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0};
/*	Copyright (c) 1989 AT&T	*/
/*	  All Rights Reserved  	*/

/*	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF AT&T	*/
/*	The copyright notice above does not evidence any   	*/
/*	actual or intended publication of such source code.	*/

#pragma ident	"@(#)ncform	6.7	93/06/07 SMI"

int yylineno =1;
# define YYU(x) x
# define NLSTATE yyprevious=YYNEWLINE
char yytext[YYLMAX];
struct yysvf *yylstate [YYLMAX], **yylsp, **yyolsp;
char yysbuf[YYLMAX];
char *yysptr = yysbuf;
int *yyfnd;
extern struct yysvf *yyestate;
int yyprevious = YYNEWLINE;
#if defined(__cplusplus) || defined(__STDC__)
int yylook(void)
#else
yylook()
#endif
{
	register struct yysvf *yystate, **lsp;
	register struct yywork *yyt;
	struct yysvf *yyz;
	int yych, yyfirst;
	struct yywork *yyr;
# ifdef LEXDEBUG
	int debug;
# endif
	char *yylastch;
	/* start off machines */
# ifdef LEXDEBUG
	debug = 0;
# endif
	yyfirst=1;
	if (!yymorfg)
		yylastch = yytext;
	else {
		yymorfg=0;
		yylastch = yytext+yyleng;
		}
	for(;;){
		lsp = yylstate;
		yyestate = yystate = yybgin;
		if (yyprevious==YYNEWLINE) yystate++;
		for (;;){
# ifdef LEXDEBUG
			if(debug)fprintf(yyout,"state %d\n",yystate-yysvec-1);
# endif
			yyt = yystate->yystoff;
			if(yyt == yycrank && !yyfirst){  /* may not be any transitions */
				yyz = yystate->yyother;
				if(yyz == 0)break;
				if(yyz->yystoff == yycrank)break;
				}
#ifndef __cplusplus
			*yylastch++ = yych = input();
#else
			*yylastch++ = yych = lex_input();
#endif
			if(yylastch > &yytext[YYLMAX]) {
				fprintf(yyout,"Input string too long, limit %d\n",YYLMAX);
				exit(1);
			}
			yyfirst=0;
		tryagain:
# ifdef LEXDEBUG
			if(debug){
				fprintf(yyout,"char ");
				allprint(yych);
				putchar('\n');
				}
# endif
			yyr = yyt;
			if ( (int)yyt > (int)yycrank){
				yyt = yyr + yych;
				if (yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transitions */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					if(lsp > &yylstate[YYLMAX]) {
						fprintf(yyout,"Input string too long, limit %d\n",YYLMAX);
						exit(1);
					}
					goto contin;
					}
				}
# ifdef YYOPTIM
			else if((int)yyt < (int)yycrank) {		/* r < yycrank */
				yyt = yyr = yycrank+(yycrank-yyt);
# ifdef LEXDEBUG
				if(debug)fprintf(yyout,"compressed state\n");
# endif
				yyt = yyt + yych;
				if(yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transitions */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					if(lsp > &yylstate[YYLMAX]) {
						fprintf(yyout,"Input string too long, limit %d\n",YYLMAX);
						exit(1);
					}
					goto contin;
					}
				yyt = yyr + YYU(yymatch[yych]);
# ifdef LEXDEBUG
				if(debug){
					fprintf(yyout,"try fall back character ");
					allprint(YYU(yymatch[yych]));
					putchar('\n');
					}
# endif
				if(yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transition */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					if(lsp > &yylstate[YYLMAX]) {
						fprintf(yyout,"Input string too long, limit %d\n",YYLMAX);
						exit(1);
					}
					goto contin;
					}
				}
			if ((yystate = yystate->yyother) && (yyt= yystate->yystoff) != yycrank){
# ifdef LEXDEBUG
				if(debug)fprintf(yyout,"fall back to state %d\n",yystate-yysvec-1);
# endif
				goto tryagain;
				}
# endif
			else
				{unput(*--yylastch);break;}
		contin:
# ifdef LEXDEBUG
			if(debug){
				fprintf(yyout,"state %d char ",yystate-yysvec-1);
				allprint(yych);
				putchar('\n');
				}
# endif
			;
			}
# ifdef LEXDEBUG
		if(debug){
			fprintf(yyout,"stopped at %d with ",*(lsp-1)-yysvec-1);
			allprint(yych);
			putchar('\n');
			}
# endif
		while (lsp-- > yylstate){
			*yylastch-- = 0;
			if (*lsp != 0 && (yyfnd= (*lsp)->yystops) && *yyfnd > 0){
				yyolsp = lsp;
				if(yyextra[*yyfnd]){		/* must backup */
					while(yyback((*lsp)->yystops,-*yyfnd) != 1 && lsp > yylstate){
						lsp--;
						unput(*yylastch--);
						}
					}
				yyprevious = YYU(*yylastch);
				yylsp = lsp;
				yyleng = yylastch-yytext+1;
				yytext[yyleng] = 0;
# ifdef LEXDEBUG
				if(debug){
					fprintf(yyout,"\nmatch ");
					sprint(yytext);
					fprintf(yyout," action %d\n",*yyfnd);
					}
# endif
				return(*yyfnd++);
				}
			unput(*yylastch);
			}
		if (yytext[0] == 0  /* && feof(yyin) */)
			{
			yysptr=yysbuf;
			return(0);
			}
#ifndef __cplusplus
		yyprevious = yytext[0] = input();
		if (yyprevious>0)
			output(yyprevious);
#else
		yyprevious = yytext[0] = lex_input();
		if (yyprevious>0)
			lex_output(yyprevious);
#endif
		yylastch=yytext;
# ifdef LEXDEBUG
		if(debug)putchar('\n');
# endif
		}
	}
#if defined(__cplusplus) || defined(__STDC__)
int yyback(int *p, int m)
#else
yyback(p, m)
	int *p;
#endif
{
	if (p==0) return(0);
	while (*p) {
		if (*p++ == m)
			return(1);
	}
	return(0);
}
	/* the following are only used in the lex library */
#if defined(__cplusplus) || defined(__STDC__)
int yyinput(void)
#else
yyinput()
#endif
{
#ifndef __cplusplus
	return(input());
#else
	return(lex_input());
#endif
	}
#if defined(__cplusplus) || defined(__STDC__)
void yyoutput(int c)
#else
yyoutput(c)
  int c; 
#endif
{
#ifndef __cplusplus
	output(c);
#else
	lex_output(c);
#endif
	}
#if defined(__cplusplus) || defined(__STDC__)
void yyunput(int c)
#else
yyunput(c)
   int c; 
#endif
{
	unput(c);
	}
