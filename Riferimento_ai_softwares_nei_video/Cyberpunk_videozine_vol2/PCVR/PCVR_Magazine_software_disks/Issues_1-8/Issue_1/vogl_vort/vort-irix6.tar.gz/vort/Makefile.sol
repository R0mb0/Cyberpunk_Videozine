#
# Makefile for vort
#
#
############################################################
#
# Notes:
#	If you have an equivalent to SUNS -fsingle option, then it would
# be a good idea to use it. If not, you should use -Dfloat=double
#
CC=cc
#CC=gcc
LIBS=-lsocket -lnsl
RANLIB = ranlib
# Or for SYSV types
RANLIB = echo

X11FLAGS = -O -DSYSV -I/usr/openwin/include
X11LIBS = -L/usr/openwin/lib -R/usr/openwin/lib -lX11

all:	x11

x11:
	cd lib; make RANLIB="$(RANLIB)" MFLAGS="$(X11FLAGS)" CC="$(CC)"
	cd art/src; make MFLAGS="$(X11FLAGS)" CC="$(CC)" LIBS="$(LIBS)"
	cd tools; make MFLAGS="$(X11FLAGS)" CC="$(CC)"
	cd X11; make MFLAGS="$(X11FLAGS)" MLIBS="$(X11LIBS)" CC="$(CC)"

clobber:
	cd lib; rm -f core *.o *.lint libvort.a
	cd tools; rm -f median greyscale vortinfo gamma targ2vort vort2ps mulmcut imtools impaste imcreate nff2art vort2pcx pcx2vort ppm2vort vort2ppm background vort2simp *.o *.lint core
	cd art/src; rm -f core *.o *.lint art artd dart
	cd sun; rm -f core *.o *.lint ?disp disp
	cd apollo; rm -f core *.o *.lint ?disp disp
	cd X11; rm -f core *.o *.lint ?disp disp
