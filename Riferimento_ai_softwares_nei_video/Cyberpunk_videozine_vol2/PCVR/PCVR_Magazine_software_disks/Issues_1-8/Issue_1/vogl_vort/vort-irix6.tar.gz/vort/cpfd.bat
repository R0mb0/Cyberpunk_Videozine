echo Making directories
md %1\vort
md %1\vort\art
md %1\vort\art\docs
md %1\vort\art\src
md %1\vort\art\scenes
md %1\vort\lib
md %1\vort\docs
md %1\vort\tools
md %1\vort\sun
md %1\vort\pc
md %1\vort\iris
md %1\vort\apollo
md %1\vort\old
md %1\vort\x11
md %1\vort\movies
md %1\vort\movies\mech
md %1\vort\movies\crank
md %1\vort\movies\chess
md %1\vort\movies\cylinder
md %1\vort\movies\superq
md %1\vort\tutes
copy *.* %1\vort
copy art\*.* %1\vort\art
copy art\docs\*.* %1\vort\art\docs
copy art\src\*.* %1\vort\art\src
copy art\scenes\*.* %1\vort\art\scenes
copy lib\*.* %1\vort\lib
copy docs\*.* %1\vort\docs
copy tools\*.* %1\vort\tools
copy sun\*.* %1\vort\sun
copy pc\*.* %1\vort\pc
copy iris\*.* %1\vort\iris
copy apollo\*.* %1\vort\apollo
copy old\*.* %1\vort\old
copy x11\*.* %1\vort\x11
copy movies\*.* %1\vort\movies
copy movies\mech\*.* %1\vort\movies\mech
copy movies\crank\*.* %1\vort\movies\crank
copy movies\chess\*.* %1\vort\movies\chess
copy movies\cylinder\*.* %1\vort\movies\cylinder
copy movies\superq\*.* %1\vort\movies\superq
copy tutes\*.* %1\vort\tutes
