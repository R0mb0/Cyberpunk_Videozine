! vort VAX make file [vort.x11]descrip.mms
!

.FIRST
 DEFINE C$INCLUDE [-.lib]

! should be the default - but sometimes does not seem to work properly
CFLAGS = /DEFINE="VMS=1"

LFLAGS = xlib/opt, -
	c$include:libvort/lib, -
	c$include:clib/opt

LIB =	[-.lib]libvort.olb

HEAD =	[-.lib]vort.h, -
	[-.lib]features.h

all :	disp.exe, -
	movie.exe, -
	rdisp.exe
	!all vort x11 files updated

! the above comment about 'all files updated' is printed after
! all has completed - leave it out and you get a warning from mms

disp.exe :	disp.c $(LIB) $(HEAD)
		cc $(CFLAGS) disp
           	link disp.obj, $(LFLAGS)

movie.exe :	movie.c $(LIB) $(HEAD)
		cc $(CFLAGS) movie
        	link movie.obj, $(LFLAGS)

rdisp.exe :	rdisp.c $(LIB) $(HEAD)
		cc $(CFLAGS) rdisp
                link rdisp.obj, $(LFLAGS)
