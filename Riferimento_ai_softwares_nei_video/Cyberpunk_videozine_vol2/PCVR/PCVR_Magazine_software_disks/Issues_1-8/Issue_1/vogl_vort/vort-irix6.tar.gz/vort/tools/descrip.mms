! vort VMS make file [vort.tools]descrip.mms
!

.FIRST
 DEFINE C$INCLUDE [-.lib]

!should be the default - but sometimes does NOT work
CFLAGS = /DEFINE="VMS=1"

LFLAGS =	c$include:libvort/lib, -
		c$include:clib/opt

LIB =	[-.lib]libvort.olb

HEAD =	[-.lib]vort.h, -
	[-.lib]features.h

all :	gamma.exe, -
	greyscale.exe, -
	median.exe, -
	mulmcut.exe, -
	vort2ps.exe, -
	vort2simp.exe, -
	vortinfo.exe, -
	nff2art.exe, -
	vort2pcx.exe, -
	pcx2vort.exe, -
	imcreate.exe, -
	impaste.exe, -
	targ2vort.exe
	!all vort tool files updated

! the above comment about 'all tool files updated' is printed after
! all has completed - leave it out and you get a warning from mms

! not all the objects below use all the '.h' files in HEAD
! but it is better to be safe than sorry

gamma.exe :	gamma.c $(LIB) $(HEAD)
		cc $(CFLAGS) gamma
           	link gamma.obj, $(LFLAGS)

greyscale.exe :	greyscale.c $(LIB) $(HEAD)
		cc $(CFLAGS) greyscale
                link greyscale.obj, $(LFLAGS)

median.exe :	median.c $(LIB) $(HEAD)
		cc $(CFLAGS) median
        	link median.obj, $(LFLAGS)

mulmcut.exe :	mulmcut.c $(LIB) $(HEAD)
		cc $(CFLAGS) mulmcut
		link mulmcut.obj, $(LFLAGS)

vort2ps.exe :	vort2ps.c $(LIB) $(HEAD)
		cc $(CFLAGS) vort2ps
		link vort2ps.obj, $(LFLAGS)

vort2simp.exe :	vort2simp.c $(LIB) $(HEAD)
		cc $(CFLAGS) vort2simp
		link vort2simp.obj, $(LFLAGS)

vortinfo.exe :	vortinfo.c $(LIB) $(HEAD)
		cc $(CFLAGS) vortinfo
		link vortinfo.obj, $(LFLAGS)

targ2vort.exe :	targ2vort.c $(LIB) $(HEAD)
		cc $(CFLAGS) targ2vort
		link targ2vort.obj, $(LFLAGS)

nff2art.exe :	nff2art.c $(LIB) $(HEAD)
		cc $(CFLAGS) nff2art
		link nff2art.obj, $(LFLAGS)

vort2pcx.exe :	vort2pcx.c $(LIB) $(HEAD)
		cc $(CFLAGS) vort2pcx
		link vort2pcx.obj, $(LFLAGS)

pcx2vort.exe :	pcx2vort.c $(LIB) $(HEAD)
		cc $(CFLAGS) pcx2vort
		link pcx2vort.obj, $(LFLAGS)

imcreate.exe :	imcreate.c $(LIB) $(HEAD)
		cc $(CFLAGS) imcreate
		link imcreate.obj, $(LFLAGS)

impaste.exe :	impaste.c $(LIB) $(HEAD)
		cc $(CFLAGS) impaste
		link impaste.obj, $(LFLAGS)

