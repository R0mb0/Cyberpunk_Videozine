#include "vogle.h"

/*
 * CirclePrecision
 */
void
CirclePrecision(prec)
	int	prec;
{
	circleprecision(prec);
}

/*
 * ArcPrecision
 */
void
ArcPrecision(prec)
	int	prec;
{
	circleprecision(prec);
}

/*
 * Arc
 */
void
Arc(x, y, radius, startang, endang)
	float	x, y, radius;
	float	startang, endang;
{
	arc(x, y, radius, startang, endang);
}

/*
 * Sector
 */
void
Sector(x, y, radius, startang, endang)
	float	x, y, radius;
	float	startang, endang;
{
	sector(x, y, radius, startang, endang);
}

/*
 * Circle
 */
void
Circle(x, y, radius)
	float	x, y, radius;
{
	circle(x, y, radius);
}

