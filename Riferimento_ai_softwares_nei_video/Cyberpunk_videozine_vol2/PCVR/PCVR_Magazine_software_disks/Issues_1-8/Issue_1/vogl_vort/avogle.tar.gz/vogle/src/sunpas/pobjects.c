#include <stdio.h>
#include "vogle.h"

#define COPYANDTERMINATE(buf, s, l)	strncpy(buf, s, l); buf[l] = '\0';

/*
 * MakeObj
 */
void
MakeObj(n)
	int	n;
{
	makeobj(n);
}

/*
 * CloseObj
 */
void
CloseObj()
{
	closeobj();
}

/*
 * DelObj
 */
void
DelObj(n)
	int	n;
{
	delobj(n);
}

/*
 * GenObj
 */
int
GenObj()
{
	return(genobj());
}

/*
 * GetOpenObj
 */
int
GetOpenObj()
{
	return(getopenobj());
}

/*
 * CallObj
 */
void
CallObj(n)
	int	n;
{
	callobj(n);
}

/*
 * IsObj
 */
int
IsObj(n)
	int	n;
{
	return(isobj(n));
}

/*
 * SaveObj
 */
void
SaveObj(n, len)
	int	n;
	int	len;
{
	char	*p = (char *)&len + sizeof(int);
	char	buf[BUFSIZ];

        COPYANDTERMINATE(buf, p, len);

	saveobj(n, buf);
}

/*
 * LoadObj
 */
void
LoadObj(n, len)
	int	n;
	int	len;
{
	char	*p = (char *)&len + sizeof(int);
	char	buf[BUFSIZ];

        COPYANDTERMINATE(buf, p, len);

	loadobj(n, buf);
}

