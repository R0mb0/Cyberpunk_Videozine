
/*
 * Yobbarays
 *
 */
void
Yobbarays(onoff)
	int	onoff;
{
	yobbarays(onoff);
}
