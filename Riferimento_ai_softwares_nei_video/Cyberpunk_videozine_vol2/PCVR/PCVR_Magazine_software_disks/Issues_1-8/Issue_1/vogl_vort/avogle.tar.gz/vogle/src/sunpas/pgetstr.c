#include <stdio.h>
#include "vogle.h"

/*
 * GetString
 */
int
GetString(bcol, len)
	int	bcol;
	int	*len;
{
	char	*p = (char *)len + sizeof(int);

	*len = getstring(bcol, p);

	return (*len);
}
