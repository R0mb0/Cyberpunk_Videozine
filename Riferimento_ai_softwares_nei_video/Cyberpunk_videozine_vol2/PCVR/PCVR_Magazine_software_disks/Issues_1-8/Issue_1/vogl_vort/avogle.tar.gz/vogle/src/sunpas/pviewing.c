#include "vogle.h"

/*
 * PolarView
 */
PolarView(dist, azim, inc, twist)
	float	dist, azim, inc, twist;
{
	polarview(dist, azim, inc, twist);
}

/*
 * Up
 */
Up(x, y, z)
	float	x, y, z;
{
	up(x, y, z);
}

/*
 * LookAt
 */
LookAt(vx, vy, vz, px, py, pz, twist)
	float  vx, vy, vz, px, py, pz, twist;
{
	lookat(vx, vy, vz, px, py, pz, twist);
}

/*
 * Perspective
 */
Perspective(fov, aspect, hither, yon)
	float 	fov, aspect, hither, yon;
{
	perspective(fov, aspect, hither, yon);
}

/*
 * Window
 */
Window(left, right, bottom, top, hither, yon)
	float 	left, right, bottom, top, hither, yon;
{
	window(left, right, bottom, top, hither, yon);
}

/*
 * Ortho
 */
Ortho(left, right, bottom, top, hither, yon)
	float 	left, right, bottom, top, hither, yon;
{
	ortho(left, right, bottom, top, hither, yon);
}

/*
 * Ortho2
 */
Ortho2(left, right, bottom, top)
	float	left, right, bottom, top;
{
	ortho2(left, right, bottom, top);
}
