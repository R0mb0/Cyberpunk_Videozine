#include "vogle.h"

/*
 * PatchBasis
 */
void
PatchBasis(ubasis, vbasis)
        float	*ubasis, *vbasis;
{
	patchbasis(ubasis, vbasis);
}

/*
 * PatchPrecision
 */
void
PatchPrecision(useg, vseg)
        int     useg, vseg;
{
	patchprecision(useg, vseg);
}

/* 
 * PatchCurves
 */
void
PatchCurves(nu, nv)
	int	nu, nv;
{
	patchcurves(nu, nv);
}

/*
 * Patch
 */
void
Patch(geomx, geomy, geomz)
	float	*geomx, *geomy, *geomz;
{
	patch(geomx, geomy, geomz);
}

/*
 * Rpatch
 */
void
Rpatch(geomx, geomy, geomz, geomw)
	float	*geomx, *geomy, *geomz, *geomw;
{
	rpatch(geomx, geomy, geomz, geomw);
}
