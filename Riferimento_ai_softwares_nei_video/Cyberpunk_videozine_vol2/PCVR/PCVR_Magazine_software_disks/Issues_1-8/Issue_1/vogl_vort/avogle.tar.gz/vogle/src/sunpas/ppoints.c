#include "vogle.h"

/*
 * Point
 */
void
Point(x, y, z)
	float 	x, y, z;
{
	point(x, y, z);
}

/*
 * Point2
 */
void
Point2(x, y)
	float	x, y;
{
	point(x, y, 0.0);
}

