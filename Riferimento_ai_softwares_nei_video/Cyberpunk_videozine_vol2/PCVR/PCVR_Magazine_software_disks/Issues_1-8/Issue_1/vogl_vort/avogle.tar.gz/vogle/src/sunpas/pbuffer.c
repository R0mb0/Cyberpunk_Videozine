/*
 * BackBuffer
 */
int
BackBuffer()
{
	return(backbuffer());
}

/*
 * FrontBuffer
 */
void
FrontBuffer()
{
	frontbuffer();
}

/*
 * SwapBuffers
 */
int
SwapBuffers()
{
	return(swapbuffers());
}
