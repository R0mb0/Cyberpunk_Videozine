#include "vogle.h"

/*
 * PushViewPort
 */
void
PushViewPort()
{
	pushviewport();
}

/*
 * PopViewPort
 */
void
PopViewPort()
{
	popviewport();
}

/*
 * ViewPort
 */
void
ViewPort(xlow, xhigh, ylow, yhigh)
	float	xlow, ylow, xhigh, yhigh;
{
	viewport(xlow, xhigh, ylow, yhigh);
}

/*
 * GetViewPort
 */
void
GetViewPort(left, right, bottom, top)
	double	*left, *right, *bottom, *top;
{
	getviewport(left, right, bottom, top);
}

