/*
 * PushAttributes
 */
void
PushAttributes()
{
	pushattributes();
}

/*
 * PopAttributes
 */
void
PopAttributes()
{
	popattributes();
}

