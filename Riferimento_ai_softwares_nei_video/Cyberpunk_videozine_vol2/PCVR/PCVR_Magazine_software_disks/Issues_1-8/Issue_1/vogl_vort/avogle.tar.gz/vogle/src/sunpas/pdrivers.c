#include <stdio.h>
#include "vogle.h"

#define COPYANDTERMINATE(buf, s, l)	strncpy(buf, s, l); buf[l] = '\0';

/*
 * Voutput
 */
void
Voutput(len)
	int	len;
{
	char	*p = (char *)&len + sizeof(int);
	char	buf[BUFSIZ];

        COPYANDTERMINATE(buf, p, len);
	voutput(buf);
}

/*
 * Vinit
 */
void
Vinit(len)
	int	len;
{
	char	*p = (char *)&len + sizeof(int);
	char	buf[BUFSIZ];

        COPYANDTERMINATE(buf, p, len);
        vinit(buf);
}

/*
 * VnewDev
 */
void
VnewDev(len)
	int	len;
{
	char	*p = (char *)&len + sizeof(int);
	char	buf[BUFSIZ];

        COPYANDTERMINATE(buf, p, len);
	vnewdev(buf);
}

/*
 * VgetDev
 */
void
VgetDev(len)
	int	*len;
{
	char	*p = (char *)len + sizeof(int);
	int	i;

	(void)vgetdev(p);

	*len = i = strlen(p);
}
	
/*
 * Vexit
 */
void
Vexit()
{
	vexit();
}

/*
 * Clear
 */
void
Clear()
{
	clear();
}

/*
 * Color
 */
void
Color(col)
	int	col;
{
	color(col);
}

/*
 * MapColor
 */
void
MapColor(indx, red, green, blue)
	int	indx, red, green, blue;
{
	mapcolor(indx, red, green, blue);
}

/*
 * GetKey
 */
int
GetKey()
{
	return(getkey());
}

/*
 * CheckKey
 */
int
CheckKey()
{
	return(checkkey());
}

/*
 * GetDepth
 */
int
GetDepth()
{
	return(getdepth());
}

/*
 * Locator
 */
int
Locator(xaddr, yaddr)
	double	*xaddr, *yaddr;
{
	float	x, y;
	int	i;

	i = locator(&x, &y);

	*xaddr = x;
	*yaddr = y;

	return(i);
}

/*
 * Slocator
 */
int
Slocator(xaddr, yaddr)
	double	*xaddr, *yaddr;
{
	float	x, y;
	int	i;

	i = slocator(&x, &y);

	*xaddr = x;
	*yaddr = y;

	return(i);
}
