program lcube;

#include <Vogle.h>

const
	CUBE_SIZE =	200.0;
	TRANS =		25.0;
	SCAL =		0.1;


var

	device: string_t;
	x, y, tdir, scal: real;
	but, nplanes, i, n: integer;

	procedure makecubes(fill: integer);
	begin
		MakeObj(fill + 2);
			PolyFill(fill > 0);
			if fill = 0 then
				Color(BLACK);

			PushMatrix;
				Translate(0.0, 0.0, CUBE_SIZE);
				if fill <> 0 then
					Color(RED);
				CallObj(1);
			PopMatrix;

			PushMatrix;
				Translate(CUBE_SIZE, 0.0, 0.0);
				Rotate(90.0, 'y');
				if fill > 0 then
					Color(GREEN);
				CallObj(1);
			PopMatrix;

			PushMatrix;
				Translate(0.0, 0.0, -CUBE_SIZE);
				Rotate(180.0, 'y');
				if fill > 0 then
					Color(BLUE);
				CallObj(1);
			PopMatrix;

			PushMatrix;
				Translate(-CUBE_SIZE, 0.0, 0.0);
				Rotate(-90.0, 'y');
				if fill > 0 then
					Color(CYAN);
				CallObj(1);
			PopMatrix;

			PushMatrix;
				Translate(0.0, CUBE_SIZE, 0.0);
				Rotate(-90.0, 'x');
				if fill > 0 then
					Color(MAGENTA);
				CallObj(1);
			PopMatrix;

			PushMatrix;
				Translate(0.0, -CUBE_SIZE, 0.0);
				Rotate(90.0, 'x');
				if fill > 0 then
					Color(YELLOW);
				CallObj(1);
			PopMatrix;

		CloseObj
	end;

begin
	tdir := TRANS;
	scal := 1.0 + SCAL;

	write('Enter output device: ');
	readln(device);

	PrefPosition(50, 50);
	PrefSize(500, 500);

	Vinit(device);

	Window(-800.0, 800.0, -800.0, 800.0, -800.0, 800.0);
	LookAt(0.0, 0.0, 1500.0, 0.0, 0.0, 0.0, 0.0);


	MakeObj(1);
		MakePoly;
			Rect(-CUBE_SIZE, -CUBE_SIZE, CUBE_SIZE, CUBE_SIZE);
		ClosePoly;
	CloseObj;

	nplanes := GetDepth;

	if nplanes = 1 then
		makecubes(0);

	makecubes(1);

	BackFace(true);
		
	if BackBuffer < 0 then begin
		VgetDev(device);
		Vexit;
		writeln('lcube: device ', device, ' doesn''t support double buffering.'); 
		halt
	end;     

	but := 0;
	while  but <> 44 do begin (* Basically forever *)
		but := Slocator(x, y);
		PushMatrix;
			Rotate(100.0 * x, 'y');
			Rotate(100.0 * y, 'x');
			Color(BLACK);
			Clear;
			CallObj(3);
			if nplanes = 1 then
				CallObj(2);
		PopMatrix;
		SwapBuffers;

		but := CheckKey;
		case but of
		ord('p'):
			begin
				Voutput('lcube.ps');
				VnewDev('postscript');
				PushMatrix;
					Rotate(100.0 * x, 'y');
					Rotate(100.0 * y, 'x');
					Color(BLACK);
					Clear;
					CallObj(3);
					if nplanes = 1 then
						CallObj(2);
				PopMatrix;
				VnewDev(device);
			end;
		ord('s'):
			Scale(scal, scal, scal);
		ord('x'):
			Translate(tdir, 0.0, 0.0);
		ord('y'):
			Translate(0.0, tdir, 0.0);
		ord('z'):
			Translate(0.0, 0.0, tdir);
		ord('-'):
			begin
				tdir := -tdir;
				if scal < 1.0 then
					scal := 1.0 + SCAL
				else
					scal := 1.0 - SCAL

			end;
		ord('+'):
			tdir := TRANS;
		27: begin (* ESC *)
				Vexit;
				halt;
			end;
		ord('q'): begin
				Vexit;
				halt;
			end;
		otherwise
		end;
	end;

	Vexit;
end.

