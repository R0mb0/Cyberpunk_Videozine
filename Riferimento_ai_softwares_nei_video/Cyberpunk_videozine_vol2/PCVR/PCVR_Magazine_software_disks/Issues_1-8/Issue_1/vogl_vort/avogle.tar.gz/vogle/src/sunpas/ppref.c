
/*
 * PrefPosition
 */
void
PrefPosition(x, y)
	int	x, y;
{
	prefposition(x, y);
}

/*
 * PrefSize
 */
void
PrefSize(x, y)
	int	x, y;
{
	prefsize(x, y);
}
