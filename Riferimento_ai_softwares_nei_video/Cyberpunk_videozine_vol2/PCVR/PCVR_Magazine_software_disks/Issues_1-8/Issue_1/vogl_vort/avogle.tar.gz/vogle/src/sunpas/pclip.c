#include "vogle.h"

/*
 * Clipping
 *
 *	turn clipping on/off
 */
void
Clipping(onoff)
	int	onoff;
{
	vdevice.clipoff = !onoff;
}
