#include "vogle.h"

/*
 * Move
 */
void
Move(x, y, z)
	float 	x, y, z;
{
	move(x, y, z);
}


/*
 * Move2
 */
void
Move2(x, y)
	float	x, y;
{
	move2(x, y);
}

/*
 * Rmove
 */
void
Rmove(dx, dy, dz)
	float	dx, dy, dz;
{
	rmove(dx, dy, dz);
}

/*
 * Rmove2
 */
void
Rmove2(dx, dy)
	float	dx, dy;
{
	rmove2(dx, dy);
}

/*
 * Smove2
 */
void
Smove2(xs, ys)
	float 	xs, ys;
{
	smove2(xs, ys);
}

/*
 * Rsmove2
 */
void
Rsmove2(dxs, dys)
	float	dxs, dys;
{
	rsmove2(dxs, dys);
}

