/*
 * Draw
 */
void
Draw(x, y, z)
	float	x, y, z;
{
	draw(x, y, z);
}

/*
 * Draw2
 */
void
Draw2(x, y)
	float	x, y;
{
	draw2(x, y);
}

/*
 * Rdraw
 */
void
Rdraw(dx, dy, dz)
	float	dx, dy, dz;
{
	rdraw(dx, dy, dz);
}

/*
 * Rdraw2
 */
void
Rdraw2(dx, dy)
	float	dx, dy;
{
	rdraw2(dx, dy);
}

/*
 * Sdraw2
 */
void
Sdraw2(xs, ys)
	float 	xs, ys;
{
	sdraw2(xs, ys);
}

/*
 * Rsdraw2
 */
void
Rsdraw2(dxs, dys)
	float	dxs, dys;
{
	rsdraw2(dxs, dys);
}
