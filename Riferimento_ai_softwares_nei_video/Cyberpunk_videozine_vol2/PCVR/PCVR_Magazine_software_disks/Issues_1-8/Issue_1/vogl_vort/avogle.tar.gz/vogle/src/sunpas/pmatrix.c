#include "vogle.h"

/*
 * PushMatrix
 */
void
PushMatrix()
{
	pushmatrix();
}

/*
 * PopMatrix
 */
void
PopMatrix()
{
	popmatrix();
}

/*
 * GetMatrix
 */
void
GetMatrix(mat)
	float	*mat;
{
	getmatrix(mat);
}

/*
 * LoadMatrix
 */
void
LoadMatrix(mat)
	float	*mat;
{
	loadmatrix(mat);
}

/*
 * MultMatrix
 */
void
MultMatrix(mat)
	float	*mat;
{
	multmatrix(mat);
}
