#include "vogle.h"

/*
 * PolyFill
 */
void
PolyFill(onoff)
	int	onoff;
{
	polyfill(onoff);
}

/*
 * HatchAng
 */
void
HatchAng(ang)
	float	ang;
{
	hatchang(ang);
}

/*
 * HatchPitch
 */
void
HatchPitch(pitch)
	float	pitch;
{
	hatchpitch(pitch);
}

/*
 * PolyHatch
 */
void
PolyHatch(onoff)
	int	onoff;
{
	polyhatch(onoff);
}

/*
 * Poly2
 */
void
Poly2(n, parray)
	int	n;
	double	parray[][2];
{
	poly2(n, parray);
}

/*
 * Poly
 */
void
Poly(n, parray)
	int	n;
	float	**parray;
{
	poly(n, parray);
}

/*
 * MakePoly
 */
void
MakePoly()
{
	makepoly();
}

/*
 * ClosePoly
 */
void
ClosePoly()
{
	closepoly();
}

/*
 * BackFace
 */
void
BackFace(onoff)
	int	onoff;
{
	backface(onoff);
}

/*
 * BackFaceDir
 */
void
BackFaceDir(clockwise)
	int	clockwise;
{
	backfacedir(clockwise);
}
