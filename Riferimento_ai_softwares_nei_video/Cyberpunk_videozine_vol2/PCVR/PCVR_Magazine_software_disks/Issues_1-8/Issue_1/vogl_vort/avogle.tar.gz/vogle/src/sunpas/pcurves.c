#include "vogle.h"

/*
 * CurveBasis
 */
void
CurveBasis(basis)
	float	basis[4][4];
{
	curvebasis(basis);
}

/*
 * CurvePrecision
 */
void
CurvePrecision(nsegments)
	int	nsegments;
{
	curveprecision(nsegments);
}

/*
 * Rcurve
 */
void
Rcurve(geom)
	float	geom[4][4];
{
	rcurve(geom);
}

/*
 * curve
 */
void
Curve(geom)
	float	geom[4][3];
{
	curve(geom);
}

/*
 * Curven
 */
void
Curven(n, geom)
	int	n;
	float	geom[][3];
{
	curven(n, geom);
}
