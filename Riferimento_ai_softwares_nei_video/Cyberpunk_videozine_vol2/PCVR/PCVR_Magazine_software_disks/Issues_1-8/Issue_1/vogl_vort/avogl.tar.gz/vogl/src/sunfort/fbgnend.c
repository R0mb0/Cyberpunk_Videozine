#include "vogl.h"

/*
 * bgnpoint_
 */
void
bgnpoint_()
{
	bgnpoint();
}

/*
 * bgnpoi_	(same as bgnpoint_)
 */
void
bgnpoi_()
{
	bgnpoint();
}

/*
 * bgnline_
 */
void
bgnline_()
{
	bgnline();
}

/*
 * bgnlin_	(same as bgnline_)
 */
void
bgnlin_()
{
	bgnline();
}

/*
 * bgnclosedline_
 */
void
bgnclosedline_()
{
	bgnclosedline();
}

/*
 * bgnclo_	(same as bgnclosedline_)
 */
void
bgnclo_()
{
	bgnclosedline();
}

/*
 * bgnpolygon_
 */
void
bgnpolygon_()
{
	bgnpolygon();
}

/*
 * bgnpol_	(same as bgnpolygon_)
 */
void
bgnpol_()
{
	bgnpolygon();
}

/*
 * endpoint_ 
 */
void
endpoint_()
{
	endpoint();
}

/*
 * endpoi_ 	(same as endpoint)
 */
void
endpoi_()
{
	endpoint();
}

/*
 * endline_ 
 */
void
endline_()
{
	endline();
}

/*
 * endlin_ 	(same as endline_)
 */
void
endlin_()
{
	endclosedline();
}

/*
 * endclosedline_ 
 */
void
endclosedline_()
{
	endclosedline();
}

/*
 * endclo_ 	(same as endclosedline_)
 */
void
endclo_()
{
	endclosedline();
}

/*
 * endpolygon_ 
 */
void
endpolygon_()
{
	endpolygon();
}

/*
 * endpol_ 	(same as endpolygon_)
 */
void
endpol_()
{
	endpolygon();
}
