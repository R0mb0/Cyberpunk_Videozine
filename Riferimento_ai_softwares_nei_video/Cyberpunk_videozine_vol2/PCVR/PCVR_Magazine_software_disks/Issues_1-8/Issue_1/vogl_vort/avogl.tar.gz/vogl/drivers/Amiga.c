    /*
 * Driver for the Amiga computer
 *
 * Compiled with gcc 2.2.2 (GNU)  or dcc (DICE)  under Amiga OS 2.04
 *
 *  Oliver Schersand  elm: scher@orion.informatik.uni-freiburg.de
 *
 */

#include "vogl.h"
#include <stdio.h>
#include <stdlib.h>

#include <intuition/intuition.h>
#include <intuition/Screens.h>
#include <graphics/gfxbase.h>
#include <graphics/rastport.h>
#include <graphics/gfxmacros.h>
#include <graphics/text.h>
#include <graphics/displayinfo.h>
#include <libraries/diskfont.h>
#include <utility/tagitem.h>
#include <exec/memory.h>
#include <dos/dos.h>

#ifdef AMIGAGCC
#include <inline/intuition.h>
#include <inline/graphics.h>
#include <inline/exec.h>
#include <inline/diskfont.h>
#endif

#define LARGE_AMIGA_FONT "Courier.font,15"
#define SMALL_AMIGA_FONT "topaz.font,8"

static struct Window   *win;
static struct RastPort *rp;
static struct RastPort *BackRast;
static struct BitMap   *BackMap,*toggle[2];
static int colour;
static short  Buffer[128*5];
static struct AreaInfo AInfo;
static struct TmpRas TRas;
static int x,y,w,h,tog,depth,type,mode,monitor;
static char pubscreen[40];
static int LDown,MDown,RDown;
static char input[256];
static int  pos = 0, inget = 0,ownscr;
int pens[] = {~0};
static long col[32];
static struct Screen *scr;

#define am2error(string) { fprintf(stderr,"Am2:%s\n",string); Am2_exit(); return 0;}
#define am1error(string) { fprintf(stderr,"Am1:%s\n",string); Am1_exit(); return 0;}


void Clear()

{
   win =0;
   rp = 0;
   BackRast = 0;
   BackMap = 0;
   toggle[0] = 0;
   toggle[1] = 0;
}


void ReadConfig(char *name)

{
   FILE *config;
   char key[40],*env;


    monitor = 0;
    mode    = HIRESLACE_KEY;
    depth   = 2;
    type = OSCAN_STANDARD;


    GetDefaultPubScreen(pubscreen);

    config = NULL;
    env = getenv(name);
    if (env != NULL)
           config = fopen(env,"r");

    if (config == NULL) {
       sprintf(key,"s:%s.config",name);
       config = fopen(key,"r");
       if (config == NULL) return;
    }

    do {
        key[0] = (char)0;
        fscanf(config,"%s",key);

        if (strcmp(key,"Screen") == 0) {
            fscanf(config,"%s",pubscreen);
        } else if (strcmp(key,"Size") == 0) {
            fscanf(config,"%s",key);
            if (strcmp(key,"Overscan") == 0) {
                type = OSCAN_STANDARD;
            } else if (strcmp(key,"Standart") == 0) {
                type = 0;
            }
        } else if (strcmp(key,"Top") == 0) {
            fscanf(config,"%i",&y);
        } else if (strcmp(key,"Left") == 0) {
            fscanf(config,"%i",&x);
        } else if (strcmp(key,"Width") == 0) {
            fscanf(config,"%i",&w);
        } else if (strcmp(key,"Height") == 0) {
            fscanf(config,"%i",&h);
        } else if (strcmp(key,"Depth") == 0) {
            fscanf(config,"%i",&depth);
        } else if (strcmp(key,"Monitor") == 0) {
            fscanf(config,"%x",&monitor);
        } else if (strcmp(key,"Mode") == 0) {
            fscanf(config,"%x",&mode);
        } else if (strcmp(key,"End") == 0) {
        } else {
            fprintf(stderr,"Unknown keyword > %s <\n",key);
            return;
        }
    } while (strcmp(key,"End") != 0);
    close(config);
}

int Am2_init()

/* DOUBLE BUFFERING SCREEN BASED ON AN EXAMPLE OF RKM-LIBRARY */

{
    int i;
    vdevice.initialised = TRUE;

    Clear();
    ReadConfig("AM2");

    BackRast = AllocMem(sizeof(struct RastPort),MEMF_CHIP|MEMF_CLEAR);
    if (BackRast == 0) am2error("no chimpmem");
    BackMap  = AllocMem(sizeof(struct BitMap),MEMF_CHIP|MEMF_CLEAR);
    if (BackRast == 0) am2error("no chipmem");
    if (type != 0) {
        scr = OpenScreenTags(NULL,SA_Depth,depth,
                                  SA_Title,NULL,
                                  SA_Height,STDSCREENHEIGHT,
                                  SA_Width,STDSCREENWIDTH,
                                  SA_DisplayID,mode | monitor,
                                  SA_Type,SCREENQUIET | CUSTOMSCREEN,
                                  SA_Overscan,type,
                                  TAG_DONE);
    } else {
        scr = OpenScreenTags(NULL,SA_Depth,depth,
                                  SA_Title,NULL,
                                  SA_DisplayID,mode | monitor,
                                  SA_Height,STDSCREENHEIGHT,
                                  SA_Width,STDSCREENWIDTH,
                                  SA_Type,SCREENQUIET | CUSTOMSCREEN,
                                  TAG_DONE);
   }
   if (scr == NULL) am2error("no screen");

    x = 0;
    y = 0;
    h = scr->Height;
    w = scr->Width;

    win = OpenWindowTags(NULL,WA_Left,x,
                              WA_Top,y,
                              WA_Width,w,
                              WA_Height,h,
                              WA_IDCMP, IDCMP_VANILLAKEY|
                                        IDCMP_MOUSEBUTTONS,
                              WA_CustomScreen,(int)scr,
                              WA_ReportMouse,TRUE,
                              WA_NoCareRefresh,TRUE,
                              WA_Borderless,TRUE,
                              WA_Backdrop,TRUE,
                              WA_Activate,TRUE,
                              WA_RMBTrap,TRUE,
                              TAG_DONE);

    /* I need the window to get the input */


    if (win == NULL) am2error("no backdropwindow");

    vdevice.depth =  depth;
    vdevice.sizeX =  w - 1;
    vdevice.sizeY =  h - 1;
    vdevice.sizeSx = w - 1;
    vdevice.sizeSy = h - 1;

    InitArea(&AInfo,Buffer,128);
    rp = &(scr->RastPort);
    rp->AreaInfo = &AInfo;
    rp->TmpRas = (struct TmpRas *) InitTmpRas(&TRas,AllocRaster(w,h),RASSIZE(w,h));
    if (rp->TmpRas == NULL) am2error("no tempras");
    if (rp->TmpRas->RasPtr == NULL) am2error("no tempbitmap");
    InitRastPort(BackRast);
    InitBitMap(BackMap,depth,w,h);
    BackRast->BitMap = BackMap;
    for (i=0;i<depth;i++) {
        BackMap->Planes[i] = AllocRaster(w,h);
        if (BackMap->Planes[i] == NULL) am2error("no bitmap");
    }
    BackRast->TmpRas = rp->TmpRas;
    BackRast->AreaInfo = &AInfo;

    SetAPen(rp,1);
    SetBPen(rp,0);

    SetAPen(BackRast,1);
    SetBPen(BackRast,0);

    SetDrMd(BackRast,JAM1);
    SetDrMd(rp,JAM1);

    toggle[0] = rp->BitMap;
    toggle[1] = BackRast->BitMap;
    SetRGB4(&scr->ViewPort,0,0,0,0);
    SetRGB4(&scr->ViewPort,1,15,0,0);
    SetRGB4(&scr->ViewPort,2,0,15,0);
    SetRGB4(&scr->ViewPort,3,15,15,0);
    SetRGB4(&scr->ViewPort,4,0,0,15);
    SetRGB4(&scr->ViewPort,5,15,0,15);
    SetRGB4(&scr->ViewPort,6,0,15,15);
    SetRGB4(&scr->ViewPort,7,15,15,15);

    tog = 1;

    return (1);

}


int Am1_init()

{
 int prefx,prefy,prefxs,prefys,i;

  vdevice.initialised = TRUE;

 Clear();
 BackRast = AllocMem(sizeof(struct RastPort),MEMF_CHIP|MEMF_CLEAR);
 BackMap  = AllocMem(sizeof(struct BitMap), MEMF_CHIP|MEMF_CLEAR);

 getprefposandsize(&prefx, &prefy, &prefxs, &prefys);


 x = 0; y = 0; w = 0; h = 0;

 if (prefx > -1) {
          x = prefx;
          y = prefy;
  }

  if (prefxs > -1) {
          w = prefxs;
          h = prefys;
  }

  ReadConfig("AM1");

  ownscr = 0;
  scr = LockPubScreen(pubscreen);

  if (scr == NULL) {
        if (type != 0) {
            scr = OpenScreenTags(NULL,SA_Depth,depth,
                                  SA_Title,  (int )pubscreen,
                                  SA_PubName,(int )pubscreen,
                                  SA_DisplayID,mode | monitor,
                                  SA_Type,PUBLICSCREEN,
                                  SA_Overscan,type,
                                  SA_Pens,(int)pens,
                                  SA_Height,STDSCREENHEIGHT,
                                  SA_Width,STDSCREENWIDTH,
                                   TAG_DONE);
        } else {
            scr = OpenScreenTags(NULL,SA_Depth,depth,
                                  SA_Title,  (int )pubscreen,
                                  SA_PubName,(int )pubscreen,
                                  SA_DisplayID,mode | monitor,
                                  SA_Height,STDSCREENHEIGHT,
                                  SA_Width,STDSCREENWIDTH,
                                  SA_Type,PUBLICSCREEN,
                                  SA_Pens,(int)pens,
                                  TAG_DONE);
        }

        ownscr = 1;
        PubScreenStatus(scr,0);
  }  else {
        UnlockPubScreen(pubscreen,scr);
  }

  if (scr == 0) am1error("Cannot open public screen");

  if (w + x > scr->Width) {
    if (w > scr->Width) {
          x = 0; w = scr->Width;
    } else {
          x = scr->Width - w;
    }
  }


  if (h + y > scr->Height) {
    if (w > scr->Height) {
          y = 0; h = scr->Height;
    } else {
          y = scr->Height - h;
    }
  }

  if (w == 0) w = scr->Width;
  if (h == 0) h = scr->Height;

  win = OpenWindowTags (NULL,
                         WA_Title,vdevice.wintitle,
                         WA_Left,x,
                         WA_Top,y,
                         WA_Width,w,
                         WA_Height,h,
                         WA_CustomScreen,(int)scr,
                         WA_Flags,WFLG_DRAGBAR|
                                  WFLG_DEPTHGADGET|
                                  WFLG_SMART_REFRESH|
                                  WFLG_REPORTMOUSE|
                                  WFLG_ACTIVATE|
                                  WFLG_RMBTRAP|
                                  WFLG_NOCAREREFRESH,
                         WA_IDCMP, IDCMP_VANILLAKEY|
                                   IDCMP_MOUSEBUTTONS,
                         WA_WindowName,(int)"Am1-Vogle-Output",
                         TAG_END);

    if (win == 0) am1error("Unable to open a Window");

    vdevice.depth =  scr->BitMap.Depth;
    depth = scr->BitMap.Depth;
    vdevice.sizeX =  w - win->BorderLeft - win->BorderRight  - 1;
    vdevice.sizeY =  h - win->BorderTop  - win->BorderBottom - 1;
    vdevice.sizeSx = w - win->BorderLeft - win->BorderRight  - 1;
    vdevice.sizeSy = h - win->BorderTop  - win->BorderBottom - 1;

    InitArea(&AInfo,Buffer,128);
    rp = win->RPort;
    rp->AreaInfo = &AInfo;
    rp->TmpRas = (struct TmpRas *) InitTmpRas(&TRas,AllocRaster(w,h),RASSIZE(w,h));
    InitRastPort(BackRast);
    InitBitMap(BackMap,depth,w,h);
    BackRast->BitMap = BackMap;

    for (i=0;i<depth;i++) {
        BackMap->Planes[i] = AllocRaster(w,h);
        if (BackMap->Planes[i] == NULL) am1error("No Bitmap");
    }

    BackRast->TmpRas = rp->TmpRas;
    BackRast->AreaInfo = &AInfo;
    SetBPen(rp,0);
    SetBPen(BackRast,0);
    SetDrMd(BackRast,JAM1);
    SetDrMd(rp,JAM1);

    for (i = 0;i < 32; i++)               /* Save the old colormap */
        col[i] = GetRGB4(scr->ViewPort.ColorMap,i);


    SetRGB4(&scr->ViewPort,4,0,0,0);
    SetRGB4(&scr->ViewPort,5,15,0,0);
    SetRGB4(&scr->ViewPort,6,0,15,0);
    SetRGB4(&scr->ViewPort,7,15,15,0);
    SetRGB4(&scr->ViewPort,8,0,0,15);
    SetRGB4(&scr->ViewPort,9,15,0,15);
    SetRGB4(&scr->ViewPort,10,0,15,15);
    SetRGB4(&scr->ViewPort,11,15,15,15);
    return(1);
 }

int Am1_exit()

{
 int i;
 struct EasyStruct er =
    { sizeof(struct EasyStruct),
      0,
      "Vogle Request",
      "Close windows on public screen %s .",
      "Ok",
    };
 if (BackRast->Font != NULL) CloseFont(BackRast->Font);
 if (rp->Font != NULL) CloseFont(rp->Font);
 if (TRas.RasPtr != NULL) FreeRaster(TRas.RasPtr,w,h);
 if (BackMap != 0) {
     for (i = 0;i < BackMap->Depth;i++)
         if (BackMap->Planes[i] != 0) FreeRaster(BackMap->Planes[i],w,h);
     FreeMem(BackMap,sizeof(struct BitMap));
 }
 if (BackRast != NULL) FreeMem(BackRast,sizeof(struct RastPort));
 if (win != NULL) CloseWindow(win);
  for (i = 0; i <32; i++)
       SetRGB4(&scr->ViewPort,i,(col[i]>>8) & 15,
                               (col[i]>>4) & 15,
                                col[i] & 15);
  if (ownscr == 1) {
      while (TRUE != CloseScreen(scr))
         EasyRequestArgs(NULL,&er,NULL,pubscreen);
  }
 return (1);
}


int Am2_exit()

{
 int i;

 if (toggle[0] != 0) {
     BackRast->BitMap              = toggle[1];
     scr->RastPort.BitMap          = toggle[0];
     scr->ViewPort.RasInfo->BitMap = toggle[0];
     MakeScreen(scr);
     RethinkDisplay();
  }

 if (BackRast->Font != NULL) CloseFont(BackRast->Font);
 if (rp->Font != NULL) CloseFont(rp->Font);
 if (TRas.RasPtr != NULL) FreeRaster(TRas.RasPtr,w,h);
 if (BackMap != 0) {
     for (i = 0;i < BackMap->Depth;i++)
         if (BackMap->Planes[i] != 0) FreeRaster(BackMap->Planes[i],w,h);
     FreeMem(BackMap,sizeof(struct BitMap));
 }
 if (BackRast != NULL) FreeMem(BackRast,sizeof(struct RastPort));
 if (win != NULL) CloseWindow(win);
 if (scr != NULL) CloseScreen(scr);

 return (1);
}


int Am1_char(char c)

{
  Move(rp,vdevice.cpVx + win->BorderLeft,
          (int)(vdevice.sizeSy - vdevice.cpVy) + win->BorderTop);
  Text(rp, &c, 1);
  return 1;
}

int Am2_char(char c)

{
  Move(rp,vdevice.cpVx ,
          (int)(vdevice.sizeSy - vdevice.cpVy));
  Text(rp, &c, 1);
  return 1;
}

int Am1_clear()
{
        SetAPen(rp, colour);
        RectFill(rp, win->BorderLeft,
                     win->BorderTop,
                     vdevice.sizeSx + win->BorderLeft ,
                     vdevice.sizeSy + win->BorderTop
        );
        return 1;
}


int Am2_clear()
{

        SetAPen(rp, colour);
        RectFill(rp, 0,
                     0,
                     vdevice.sizeSx,
                     vdevice.sizeSy
        );
        return 1;
}

int Am1_color(int color)

{
   colour = (color + 4);
   SetAPen(win->RPort, colour);
   SetAPen(BackRast,   colour);
   return 1;
}


int Am2_color(int color)

{
   colour = color;
   SetAPen(&scr->RastPort, colour);
   SetAPen(BackRast, colour);
   return 1;
}

Am2_draw(int px, int py)

{
        Move(rp, vdevice.cpVx ,
                  vdevice.sizeSy - vdevice.cpVy);
        Draw(rp, px  ,
                 vdevice.sizeSy - py);
        return 1;
}


Am1_draw(int px, int py)

{
        Move(rp, vdevice.cpVx + win->BorderLeft,
                  vdevice.sizeSy - vdevice.cpVy + win->BorderTop);
        Draw(rp, px  + win->BorderLeft,
                 vdevice.sizeSy - py + win->BorderTop);
        return 1;
}

Am2_fill(int n, int *fx,int *fy)

{
  int i;

  if (n > 128)
     verror("vogle: more than 128 points in a polygon");

  AreaMove(rp,fx[0],vdevice.sizeSy - fy[0]);

  for (i = 1; i < n; i++)
    AreaDraw(rp,fx[i],vdevice.sizeSy - fy[i]);

  AreaEnd(rp);
}

Am1_fill(int n, int *x,int *y)

{
  int i;

  if (n > 128)
     verror("vogle: more than 128 points in a polygon");

  AreaMove(rp,x[0] + win->BorderLeft,vdevice.sizeSy - y[0] + win->BorderTop);

  for (i = 1; i < n; i++)
    AreaDraw(rp,x[i] + win->BorderLeft,vdevice.sizeSy - y[i] + win->BorderTop);

  AreaEnd(rp);
}


int Am1_font(char *font)

{
    char name[40],attr[4][20];
    int res = 8,i;
    UWORD style = 0;
    struct TextAttr ta;
    struct TextFont *tf;

    *name  = (char)0;
    *attr[0] = (char)0;
    *attr[1] = (char)0;
    *attr[2] = (char)0;
    *attr[3] = (char)0;

    sscanf(font ,"%[^,],%i,%[^,],%[^,],%[^,],%[^,]",
                  name,&res,attr[0],attr[1],attr[2],attr[3]);

    if (strcmp(name,"large") == 0) {
        sscanf(font ,"%[^,],%[^,],%[^,],%[^,],%[^,]",
                  name,attr[0],attr[1],attr[2],attr[3]);
        sscanf(LARGE_AMIGA_FONT,"%[^,],%i",name,&res);
    }

    if (strcmp(name,"small") == 0) {
        sscanf(font ,"%[^,],%[^,],%[^,],%[^,],%[^,]",
                name,attr[0],attr[1],attr[2],attr[3]);
        sscanf(SMALL_AMIGA_FONT,"%[^,],%i",name,&res);
    }

    for (i=0;i < 4; i++) {
        if (strcmp(attr[i],"bold") == 0)       style   |= FSF_BOLD;
        if (strcmp(attr[i],"italic") == 0)     style   |= FSF_ITALIC;
        if (strcmp(attr[i],"underlined") == 0) style   |= FSF_UNDERLINED;
    }

    ta.ta_Name = name;
    ta.ta_YSize = res;
    ta.ta_Style = 0;
    ta.ta_Flags = 0;


    tf = OpenDiskFont(&ta);
    if (tf == 0) return 0;

    if (BackRast->Font != NULL) CloseFont(BackRast->Font);
    if (rp->Font != NULL) CloseFont(rp->Font);

    SetFont(rp,tf); SetSoftStyle(rp,style,255);
    SetFont(BackRast,tf); SetSoftStyle(BackRast,style,255);
    vdevice.hheight = tf->tf_YSize;
    vdevice.hwidth = tf->tf_XSize;
    return (1);
}

TestInput()

{
   if (win->UserPort->mp_MsgList.lh_Head->ln_Succ == NULL)
      return;
   else {
      struct IntuiMessage *msg;
      for (;;) {
          msg = (struct IntuiMessage *)GetMsg(win->UserPort); if (msg == NULL) return ;
          if (msg->Class == IDCMP_VANILLAKEY) {
               input[pos] = msg->Code; pos ++;
               if (pos == inget) pos--;
               if (pos > 256) pos = 0;
               ReplyMsg((struct Message *)msg);
               return;
          } else if (msg->Class == IDCMP_MOUSEBUTTONS) {
               switch (msg->Code) {
                   case SELECTDOWN: LDown = 1; break;
                   case SELECTUP  : LDown = 0; break;
                   case MENUUP    : RDown = 4; break;
                   case MENUDOWN  : RDown = 0; break;
               }
          }
          ReplyMsg((struct Message  *)msg);
      }
   }
}


Am1_checkkey()

{ char c = 0;
  TestInput();
  if (pos != inget) { c = input[inget]; inget++;}
  if (inget > 256) inget = 0;
  return c;
}


Am1_getkey()

{
    char c;
    for (;;) {
       c = Am1_checkkey();
       if (c != 0) return c;
       WaitPort(win->UserPort);
    }

}

Am1_locator(int *mx,int *my)

{
  TestInput();
  *mx = win->MouseX - win->BorderLeft;
  *my = vdevice.sizeSy - (win->MouseY - win->BorderTop );
  return LDown + RDown;
}


Am2_locator(int *mx,int *my)

{
  TestInput();
  *mx = win->MouseX ;
  *my = vdevice.sizeSy - (win->MouseY);
  return LDown + RDown;
}

int Am2_mapcolor(int i,int r,int g,int b)

{
  if (i > 31) return 0;
  SetRGB4(&scr->ViewPort,i,r / 16,g / 16, b / 16);
  return 1;
 }


int Am1_mapcolor(int i,int r,int g,int b)

{
  i += 4;
  if (i > 31) return 0;
  SetRGB4(&scr->ViewPort,i,r / 16,g / 16, b / 16);
  return 1;
 }


int Am1_string(char *str)

{
   Move(rp,vdevice.cpVx + win->BorderLeft,
           (int)(vdevice.sizeSy - vdevice.cpVy) + win->BorderTop);
   Text(rp, str, strlen(str));
   return 1;
}


int Am2_string(char *str)

{
   Move(rp,vdevice.cpVx ,
           (int)(vdevice.sizeSy - vdevice.cpVy));
   Text(rp, str, strlen(str));
   return 1;
}

int Am1_backbuf()

{
  rp = BackRast;
  return 1;
}

int Am1_frontbuf()

{
  rp = win->RPort;
  return 1;

}

int Am1_swapbuf()

{
 WaitTOF();
 ClipBlit(BackRast,win->BorderLeft,win->BorderTop,
           win->RPort,win->BorderLeft,win->BorderTop,
           vdevice.sizeX,vdevice.sizeY,0XC0);
  return 1;
}


int Am2_backbuf()

{
    rp = BackRast;
    return 1;
}

int Am2_frontbuf()

{
    rp = &scr->RastPort;
    return 1;
}

Am2_swapbuf()

{
    scr->RastPort.BitMap          = toggle[tog];
    scr->ViewPort.RasInfo->BitMap = toggle[tog];
    MakeScreen(scr);
    RethinkDisplay();
    if (tog == 1) tog = 0; else tog = 1; /* Oh Gott ich komme von Pascal */
    BackRast->BitMap = toggle[tog];

}

static DevEntry Am1dev = {
        "Am1",
        "large",
        "small",
        Am1_backbuf,
        Am1_char,
        Am1_checkkey,
        Am1_clear,
        Am1_color,
        Am1_draw,
        Am1_exit,
        Am1_fill,
        Am1_font,
        Am1_frontbuf,
        Am1_getkey,
        Am1_init,
        Am1_locator,
        Am1_mapcolor,
        Am1_string,
        Am1_swapbuf
      };


static DevEntry Am2dev = {
        "Am2",
        "large",
        "small",
        Am2_backbuf,
        Am2_char,
        Am1_checkkey,
        Am2_clear,
        Am2_color,
        Am2_draw,
        Am2_exit,
        Am2_fill,
        Am1_font,
        Am2_frontbuf,
        Am1_getkey,
        Am2_init,
        Am2_locator,
        Am2_mapcolor,
        Am2_string,
        Am2_swapbuf
      };


_Am1_devcpy()
{
        vdevice.dev = Am1dev;
}
_Am2_devcpy()
{
        vdevice.dev = Am2dev;
}
