#include <stdio.h>
#include <math.h>
#include "macro.h"
#include "rt.h"

extern float	tolerance;

extern mats	*mstackp;

extern oentry	*ostackp;

extern long	objtests[], inttests[], hits[], bboxtests[];

/*
 * conei
 *
 *	returns a list of intersection points for the ray r and cone o.
 *
 */
int
conei(r, o, bboxtest)
	ray	*r;
	object	*o;
	int	bboxtest;
{
	float	a, b, c, d, t, t1, t2;
	float	tipval, ax1, ax2, x, y, z;
	int	face, entry, exit;
	ray	nr;

	if (o == r->orgobj && r->type != TRANSPARENCY_RAY)
		return(RT_FALSE);

	if (bboxtest) {
		bboxtests[o->type]++;
		if (missedbbox(r, &o->bb))
			return(RT_FALSE);
	}

	inttests[o->type]++;

	transray(o, nr, *r);

	a = nr.dir[X] * nr.dir[X] + nr.dir[Y] * nr.dir[Y] - nr.dir[Z] * nr.dir[Z];
	b = nr.org[X] * nr.dir[X] + nr.org[Y] * nr.dir[Y] - nr.dir[Z] * nr.org[Z];
	c = nr.org[X] * nr.org[X] + nr.org[Y] * nr.org[Y] - nr.org[Z] * nr.org[Z];

	d = b * b - a * c;

	if (d < 0.0)
		return(RT_FALSE);
	
	tipval = o->obj.cne_tipval;

	if (fabs(a) == 0.0) {
		t1 = -c / b;
		entry = SIDE;

		z = nr.org[Z] + t1 * nr.dir[Z];

		if (z <= 1.0 && z >= tipval) {
			t2 = (1.0 - nr.org[Z]) / nr.dir[Z];
			exit = PZFACE;
		} else {
			t1 = (tipval - nr.org[Z]) / nr.dir[Z];
			t2 = (1.0 - nr.org[Z]) / nr.dir[Z];

			if (t1 < tolerance && t2 < tolerance)
				return(RT_FALSE);

			x = t2 * nr.dir[X] + nr.org[X];
			y = t2 * nr.dir[Y] + nr.org[Y];
			if (x * x + y * y > 1.0)
				return(RT_FALSE);

			entry = NZFACE;
			exit = PZFACE;
		}
	} else {
		d = sqrt((double)d);

		entry = exit = SIDE;

		t1 = (-b - d) / a;
		t2 = (-b + d) / a;

		ax1 = t1 * nr.dir[Z] + nr.org[Z];
		ax2 = t2 * nr.dir[Z] + nr.org[Z];

		/*
		 * both hits outside range of z in -1.0 to 1.0
		 */
		if (fabs(ax1) >= 1.0 && fabs(ax2) >= 1.0)
			return(RT_FALSE);

		/*
		 * both hits in range of z < 0.0
		 */
		if (ax1 <= 0.0 && ax2 <= 0.0)
			return(RT_FALSE);

		if (ax1 < tipval && ax2 < tipval) {
			/*
			 * we pass through truncated section
			 */
			if (ax1 > 0.0 && ax2 > 0.0)
				return(RT_FALSE);

			/*
			 * we must pass through top and base faces
			 * of truncated cone.
			 */
			entry = PZFACE;
			t1 = (1.0 - nr.org[Z]) / nr.dir[Z];
			exit = NZFACE;
			t2 = (tipval - nr.org[Z]) / nr.dir[Z];

		} else if (ax1 >= 1.0) {
			/*
			 * must hit base of cone.
			 */
			entry = PZFACE;
			t1 = (1.0 - nr.org[Z]) / nr.dir[Z];

						/* do we hit top? */
			if (ax2 <= tipval) {
				/*
				 * check that we have really hit base
				 */
				x = t1 * nr.dir[X] + nr.org[X];
				y = t1 * nr.dir[Y] + nr.org[Y];
				if (x * x + y * y > 1.0)
					return(RT_FALSE);

				exit = NZFACE;
				t2 = (tipval - nr.org[Z]) / nr.dir[Z];
			}

		} else if (ax1 <= tipval) {
			/*
			 * must hit top of cone
			 */
			entry = NZFACE;
			t1 = (tipval - nr.org[Z]) / nr.dir[Z];

			x = t1 * nr.dir[X] + nr.org[X];
			y = t1 * nr.dir[Y] + nr.org[Y];
			if (x * x + y * y > tipval * tipval) {

				if (ax2 >= 1.0)
					return(RT_FALSE);

				entry = PZFACE;
				t1 = (1.0 - nr.org[Z]) / nr.dir[Z];

			} else if (ax2 >= 1.0) {
				exit = PZFACE;
				t2 = (1.0 - nr.org[Z]) / nr.dir[Z];
			}
		} else {
			/*
			 * must have hit in the middle, check that
			 * the ax2 value is in range.
			 */
			if (ax2 >= 1.0) {
				exit = PZFACE;
				t2 = (1.0 - nr.org[Z]) / nr.dir[Z];
			} else if (ax2 <= tipval) {
				exit = NZFACE;
				t2 = (tipval - nr.org[Z]) / nr.dir[Z];

				x = t2 * nr.dir[X] + nr.org[X];
				y = t2 * nr.dir[Y] + nr.org[Y];
				if (x * x + y * y > tipval * tipval) {
									/* must hit base */
					exit = PZFACE;
					t2 = (1.0 - nr.org[Z]) / nr.dir[Z];
				}
			}
		}
	}

	if (t1 > t2) {
		t = t1;
		t1 = t2;
		t2 = t;
		face = entry;
		entry = exit;
		exit = face;
	}

	if (t1 >= tolerance) {
		r->hit.t = t1;
		r->hit.obj = o;
		r->hit.type = entry;
		r->hit.vals[X] = r->org[X] + r->dir[X] * t1;
		r->hit.vals[Y] = r->org[Y] + r->dir[Y] * t1;
		r->hit.vals[Z] = r->org[Z] + r->dir[Z] * t1;

		hits[o->type]++;

		return(RT_TRUE);
	} else if (t2 >= tolerance) {
		r->hit.t = t2;
		r->hit.obj = o;
		r->hit.type = exit;
		r->hit.vals[X] = r->org[X] + r->dir[X] * t2;
		r->hit.vals[Y] = r->org[Y] + r->dir[Y] * t2;
		r->hit.vals[Z] = r->org[Z] + r->dir[Z] * t2;

		hits[o->type]++;

		return(RT_TRUE);
	}

	return(RT_FALSE);
}

/*
 * conen
 *
 *	returns the normal to the cone o
 */
void
conen(n, l, o, type)
	vector	n;
	vector	l;
	object	*o;
	int	type;
{
	if (type == SIDE) {
		toobject(o, n, l);

		n[Z] = -n[Z];
		
		normalise(n);
	} else if (type == PZFACE) {
		n[X] = 0.0;
		n[Y] = 0.0;
		n[Z] = 1.0;
	} else {
		n[X] = 0.0;
		n[Y] = 0.0;
		n[Z] = -1.0;
	}
}

/*
 * cyli
 *
 *	returns true if the ray r hits, leaving the hit details in
 * the ray hit value.
 *
 */
int
cyli(r, o, bboxtest)
	ray	*r;
	object	*o;
	int	bboxtest;
{
	float	ax1, ax2;
	int	entry, exit;
	ray	nr;
	float	a, b, c, d, t, t1, t2;

	if (o == r->orgobj && r->type != TRANSPARENCY_RAY)
		return(RT_FALSE);

	if (bboxtest) {
		bboxtests[o->type]++;
		if (missedbbox(r, &o->bb))
			return(RT_FALSE);
	}

	inttests[o->type]++;

	transray(o, nr, *r);

	a = nr.dir[X] * nr.dir[X] + nr.dir[Y] * nr.dir[Y];
	b = -(nr.org[X] * nr.dir[X] + nr.org[Y] * nr.dir[Y]);
	c = nr.org[X] * nr.org[X] + nr.org[Y] * nr.org[Y] - 1.0;

	d = b * b - a * c;

	if (d < 0.0 || a == 0.0) {

		if (c > 0.0 || nr.dir[Z] == 0.0)
			return(RT_FALSE);

		t1 = -nr.org[Z] / nr.dir[Z];
		t2 = (1.0 - nr.org[Z]) / nr.dir[Z];

		if (t1 < tolerance && t2 < tolerance)
			return(RT_FALSE);

		if (t1 > t2) {
			t = t1;
			t1 = t2;
			t2 = t;
			entry = PZFACE;
			exit = NZFACE;
		} else {
			entry = NZFACE;
			exit = PZFACE;
		}
	} else {
		entry = exit = SIDE;

		d = sqrt((double)d);

		t1 = (b - d) / a;
		t2 = (b + d) / a;

		ax1 = t1 * nr.dir[Z] + nr.org[Z];
		ax2 = t2 * nr.dir[Z] + nr.org[Z];

		if (ax1 < 0.0 && ax2 < 0.0)
			return(RT_FALSE);

		if (ax1 > 1.0 && ax2 > 1.0)
			return(RT_FALSE);

		if (ax1 > 1.0) {
			entry = PZFACE;
			t1 = (1.0 - nr.org[Z]) / nr.dir[Z];
		} else if (ax1 < 0.0) {
			entry = NZFACE;
			t1 = -nr.org[Z] / nr.dir[Z];
		} 

		if (ax2 > 1.0) {
			exit = PZFACE;
			t2 = (1.0 - nr.org[Z]) / nr.dir[Z];
		} else if (ax2 < 0.0) {
			exit = NZFACE;
			t2 = -nr.org[Z] / nr.dir[Z];
		}
	}

	if (t1 >= tolerance) {
		r->hit.t = t1;
		r->hit.obj = o;
		r->hit.type = entry;
		r->hit.vals[X] = r->org[X] + r->dir[X] * t1;
		r->hit.vals[Y] = r->org[Y] + r->dir[Y] * t1;
		r->hit.vals[Z] = r->org[Z] + r->dir[Z] * t1;

		hits[o->type]++;

		return(RT_TRUE);
	} else if (t2 >= tolerance) {
		r->hit.t = t2;
		r->hit.obj = o;
		r->hit.type = exit;
		r->hit.vals[X] = r->org[X] + r->dir[X] * t2;
		r->hit.vals[Y] = r->org[Y] + r->dir[Y] * t2;
		r->hit.vals[Z] = r->org[Z] + r->dir[Z] * t2;

		hits[o->type]++;

		return(RT_TRUE);
	}

	return(RT_FALSE);
}

/*
 * cyln
 *
 *	returns the normal to the cylinder o
 */
void
cyln(n, l, o, type)
	vector	n;
	vector	l;
	object	*o;
	int	type;
{
	if (type == SIDE) {
		toobject(o, n, l);

		n[Z] = 0.0;

		normalise(n);
	} else if (type == PZFACE) {
		n[X] = 0.0;
		n[Y] = 0.0;
		n[Z] = 1.0;
	} else {
		n[X] = 0.0;
		n[Y] = 0.0;
		n[Z] = -1.0;
	}
}

/*
 * conecylinit
 *
 *	initialise a cone or cylinder.
 */
void
conecylinit(bx, by, bz, br, ax, ay, az, ar)
	float	bx, by, bz, br;
	float	ax, ay, az, ar;
{
	vector	b, a;
	float	rad, apexr, baser, grad, base;
	object	*o;

	pushmatrix();

	o = (object *)smalloc(sizeof(object));

	if (br != ar) {
		o->type = CONEOBJ;
		if (ar > br) {
			a[X] = bx; a[Y] = by; a[Z] = bz;
			b[X] = ax; b[Y] = ay; b[Z] = az;
			baser = ar;
			apexr = br;
		} else {
			a[X] = ax; a[Y] = ay; a[Z] = az;
			b[X] = bx; b[Y] = by; b[Z] = bz;
			baser = br;
			apexr = ar;
		}
		o->obj.cne_tipval = apexr / baser;
		grad = (a[X] - b[X]) / (baser - apexr);
		a[X] += grad * apexr;
		grad = (a[Y] - b[Y]) / (baser - apexr);
		a[Y] += grad * apexr;
		grad = (a[Z] - b[Z]) / (baser - apexr);
		a[Z] += grad * apexr;
		rad = baser;
		base = o->obj.cne_tipval;
	} else {
		o->type = CYLINDEROBJ;
		rad = br;
		a[X] = ax; a[Y] = ay; a[Z] = az;
		b[X] = bx; b[Y] = by; b[Z] = bz;
		base = 0.0;
	}

	translate(a[X], a[Y], a[Z]);

	alignzaxis(a[X] - b[X], a[Y] - b[Y], a[Z] - b[Z]);

	scale(rad, rad, sqrt((b[X] - a[X]) * (b[X] - a[X]) + (b[Y] - a[Y]) * (b[Y] - a[Y]) + (b[Z] - a[Z]) * (b[Z] - a[Z])));

	setattributes(o);

	makebbox(o, -1.0, -1.0, base, 1.0, 1.0, 1.0);

	o->nxt = ostackp->objs;
	ostackp->objs = o;

	popmatrix();
}

/*
 * cone
 *
 *	initialise a cone.
 */
void
cone(bx, by, bz, br, ax, ay, az, ar)
	float	bx, by, bz, br;
	float	ax, ay, az, ar;
{
	conecylinit(bx, by, bz, br, ax, ay, az, ar);
}

/*
 * cylinder
 *
 *	initialise a cylinder.
 */
void
cylinder(bx, by, bz, tx, ty, tz, r)
	float	bx, by, bz;
	float	tx, ty, tz, r;
{
	conecylinit(bx, by, bz, r, tx, ty, tz, r);
}

/*
 * conecyltabinit
 *
 *	set the table of function pointers for the cylinder.
 */
void
conecyltabinit(intersects, normals, checkbbox, selfshadowing)
	int	(*intersects[])();
	void	(*normals[])();
	int	checkbbox[];
	int	selfshadowing[];
{
	normals[CONEOBJ] = conen;
	intersects[CONEOBJ] = conei;
	checkbbox[CONEOBJ] = RT_TRUE;
	selfshadowing[CONEOBJ] = RT_FALSE;

	normals[CYLINDEROBJ] = cyln;
	intersects[CYLINDEROBJ] = cyli;
	checkbbox[CYLINDEROBJ] = RT_TRUE;
	selfshadowing[CYLINDEROBJ] = RT_FALSE;
}
