#include <stdio.h>
#include <math.h>
#include "rt.h"
#include "macro.h"

extern int	maxtreedepth;
extern float	tolerance;
extern float	focallength;
extern float	falloff;

extern int	iwidth, iheight, ibase;
extern int	iwoff, ihoff;

extern vector	up;

extern colour	backcol;

extern int	(*intersects[])();
extern int	checkbbox[];

extern float	*erandp, *randp, randtable[];

extern oentry	*ostackp;

extern long	bboxtests[];

extern mat4x4	wtrans;
extern mat4x4	rtrans;

/*
 * splitleaf
 *
 *	find the "optimum" splitting value and divide the leaf
 * along an axis.
 */
static void
splitleaf(leaf)
	bvtree	*leaf;
{
	object		*o, *nxto;
	int		xdbl, xright, ydbl, yright, zdbl, zright, tot;
	int		code, mask, leftmask;
	float		xsplit, ysplit, zsplit, splitval;
	bvtree		*left, *mid, *right;
	object		*leftobjs, *midobjs, *rightobjs;
	bbox		leftbb, rightbb, midbb;

	if (leaf->u.leaf.oblist->nxt == (object *)NULL) {
		leaf->type = LEAF;
		return;
	}

	xsplit = leaf->bb.min[X] + (leaf->bb.max[X] - leaf->bb.min[X]) / 2.0;
	ysplit = leaf->bb.min[Y] + (leaf->bb.max[Y] - leaf->bb.min[Y]) / 2.0;
	zsplit = leaf->bb.min[Z] + (leaf->bb.max[Z] - leaf->bb.min[Z]) / 2.0;

	xdbl = xright = ydbl = yright = zdbl = zright = tot = 0;

	for (o = leaf->u.leaf.oblist; o != (object *)NULL; o = o->nxt) {

		if (xsplit < o->bb.min[X])
			xright++;
		else if (xsplit < o->bb.max[X])
			xdbl++;

		if (ysplit < o->bb.min[Y])
			yright++;
		else if (ysplit < o->bb.max[Y])
			ydbl++;

		if (zsplit < o->bb.min[Z])
			zright++;
		else if (zsplit < o->bb.max[Z])
			zdbl++;
			
		tot++;
	}

	/*
	 * Check for funny circumstances
	 */

	/*
	if (tot <= 5) {
		leaf->type = LEAF;
		return;
	}
	*/

	/*
	 * can't split further
	 */
	if (xdbl == tot && ydbl == tot && zdbl == tot) {
		leaf->type = LEAF;
		return;
	}

	/*
	 * empty sub branch so increase doubling cost
	 */
	if ((xright == 0 || xright == tot || xdbl == tot))
		xdbl += tot;
	if ((yright == 0 || yright == tot || ydbl == tot))
		ydbl += tot;
	if ((zright == 0 || zright == tot || zdbl == tot))
		zdbl += tot;
		
	/*
	printf("splitleaf: %d %f, %d %f, %d %f - %d, %d\n", xdbl, xsplit, ydbl, ysplit, zdbl, zsplit, tot, leaf->u.leaf.depth);
	*/

	if (xdbl < ydbl)
		if (xdbl < zdbl) {
			leaf->splitval = xsplit;
			leaf->type = X;
		} else {
			leaf->splitval = zsplit;
			leaf->type = Z;
		}
	else
		if (ydbl < zdbl) {
			leaf->splitval = ysplit;
			leaf->type = Y;
		} else {
			leaf->splitval = zsplit;
			leaf->type = Z;
		}

	code = leaf->type;
	splitval = leaf->splitval;
	leftobjs = midobjs = rightobjs = (object *)NULL;
			 
	for (o = leaf->u.leaf.oblist; o != (object *)NULL; o = nxto) {
		nxto = o->nxt;
		if (splitval < o->bb.min[code]) {
			if (rightobjs == (object *)NULL)
				rightbb = o->bb;
			else {
				if (o->bb.min[X] < rightbb.min[X])
					rightbb.min[X] = o->bb.min[X];
				if (o->bb.max[X] > rightbb.max[X])
					rightbb.max[X] = o->bb.max[X];

				if (o->bb.min[Y] < rightbb.min[Y])
					rightbb.min[Y] = o->bb.min[Y];
				if (o->bb.max[Y] > rightbb.max[Y])
					rightbb.max[Y] = o->bb.max[Y];

				if (o->bb.min[Z] < rightbb.min[Z])
					rightbb.min[Z] = o->bb.min[Z];
				if (o->bb.max[Z] > rightbb.max[Z])
					rightbb.max[Z] = o->bb.max[Z];
			}
			o->nxt = rightobjs;
			rightobjs = o;
		} else if (splitval < o->bb.max[code]) {
			if (midobjs == (object *)NULL)
				midbb = o->bb;
			else {
				if (o->bb.min[X] < midbb.min[X])
					midbb.min[X] = o->bb.min[X];
				if (o->bb.max[X] > midbb.max[X])
					midbb.max[X] = o->bb.max[X];

				if (o->bb.min[Y] < midbb.min[Y])
					midbb.min[Y] = o->bb.min[Y];
				if (o->bb.max[Y] > midbb.max[Y])
					midbb.max[Y] = o->bb.max[Y];

				if (o->bb.min[Z] < midbb.min[Z])
					midbb.min[Z] = o->bb.min[Z];
				if (o->bb.max[Z] > midbb.max[Z])
					midbb.max[Z] = o->bb.max[Z];
			}
			o->nxt = midobjs;
			midobjs = o;
		} else {
			if (leftobjs == (object *)NULL)
				leftbb = o->bb;
			else {
				if (o->bb.min[X] < leftbb.min[X])
					leftbb.min[X] = o->bb.min[X];
				if (o->bb.max[X] > leftbb.max[X])
					leftbb.max[X] = o->bb.max[X];

				if (o->bb.min[Y] < leftbb.min[Y])
					leftbb.min[Y] = o->bb.min[Y];
				if (o->bb.max[Y] > leftbb.max[Y])
					leftbb.max[Y] = o->bb.max[Y];

				if (o->bb.min[Z] < leftbb.min[Z])
					leftbb.min[Z] = o->bb.min[Z];
				if (o->bb.max[Z] > leftbb.max[Z])
					leftbb.max[Z] = o->bb.max[Z];
			}
			o->nxt = leftobjs;
			leftobjs = o;
		}
	}

	left = (bvtree *)smalloc(sizeof(bvtree));

	left->bb = leftbb;
	left->u.leaf.oblist = leftobjs;

	mid = (bvtree *)smalloc(sizeof(bvtree));

	mid->bb = midbb;
	mid->u.leaf.oblist = midobjs;

	right = (bvtree *)smalloc(sizeof(bvtree));

	right->bb = rightbb;
	right->u.leaf.oblist = rightobjs;

	/*
	 * check type and set up parent
	 */
	if (leaf->u.leaf.depth == maxtreedepth)
		left->type = mid->type = right->type = LEAF;
	else {
		left->u.leaf.depth = mid->u.leaf.depth = right->u.leaf.depth = leaf->u.leaf.depth + 1;
		left->type = mid->type = right->type = SPLITABLELEAF;
	}

	leaf->u.branch.left = left;
	leaf->u.branch.mid = mid;
	leaf->u.branch.right = right;

	if (left->u.leaf.oblist == (object *)NULL) {
		left->type = LEAF;
		leaf->u.branch.left = (bvtree *)NULL;
	} else if (left->u.leaf.oblist->nxt == (object *)NULL) {
		left->type = LEAF;
	}

	if (mid->u.leaf.oblist == (object *)NULL) {
		mid->type = LEAF;
		leaf->u.branch.mid = (bvtree *)NULL;
	} else if (mid->u.leaf.oblist->nxt == (object *)NULL) {
		mid->type = LEAF;
	}

	if (right->u.leaf.oblist == (object *)NULL) {
		right->type = LEAF;
		leaf->u.branch.right = (bvtree *)NULL;
	} else if (right->u.leaf.oblist->nxt == (object *)NULL) {
		right->type = LEAF;
	}

	treenodes += 3;
}

/*
 * wtreetrace
 *
 *	returns the first hit on the tree pointed to by root.
 */
int
wtreetrace(r, root)
	ray	*r;
	bvtree	*root;
{
	int		hit, hit1, hit2;
	bvtree		*nxtbranch, *lastbranch;
	int		leftfirst, i, p, u, v, bboxcheck;
	float		t1, t2, othert1, othert2, org, dir;
	object		**ptr, *o;


	if (root->type == LEAF) {
		bboxcheck = (root->u.leaf.oblist->nxt != (object *)NULL);
		hit = RT_FALSE;
		for (o = root->u.leaf.oblist; o != (object *)NULL; o = o->nxt) {

			if ((intersects[o->type](r, o, bboxcheck))) {
				hit = RT_TRUE;
				if (r->thehit.obj == (object *)NULL) {
					r->thehit = r->hit;
				} else if (r->thehit.t >= r->hit.t) {
					r->thehit = r->hit;
				}
				if (r->type == SHADOW_RAY && r->hit.t <= r->maxt
				   && o->s->T == 0.0) {
					r->done = RT_TRUE;
					return(RT_TRUE);
				}
			}
		}
		return(hit);
	} else if (root->type == SPLITABLELEAF) {
		splitleaf(root);
		return(wtreetrace(r, root));
	} else {
		p = root->type;

		org = r->org[p];
		dir = r->dir[p];

		if (org < root->splitval) {
			nxtbranch = root->u.branch.left;

			if (nxtbranch != (bvtree *)NULL) {
				if (org >= nxtbranch->bb.max[p] && dir > 0.0)
					hit1 = RT_FALSE;
				else if (!cmissedbbox(r, &nxtbranch->bb))
					hit1 = wtreetrace(r, nxtbranch);
				else
					hit1 = RT_FALSE;
			} else
				hit1 = RT_FALSE;

			nxtbranch = root->u.branch.mid;

			if (r->done)
				return(RT_TRUE);

			if (nxtbranch != (bvtree *)NULL) {
				if (((r->thehit.obj != (object *)NULL && r->thehit.vals[p] < nxtbranch->bb.min[p]) || dir <= 0.0) && org < nxtbranch->bb.min[p])
					return(hit1);

				if (!cmissedbbox(r, &nxtbranch->bb))
					hit2 = wtreetrace(r, nxtbranch);
				else
					hit2 = RT_FALSE;
			} else
				hit2 = RT_FALSE;

			if (hit1 || r->done)
				return(RT_TRUE);

			if (dir <= 0.0)
				return(hit2);

			lastbranch = root->u.branch.right;

			if (lastbranch == (bvtree *)NULL || (((r->thehit.obj != (object *)NULL && r->thehit.vals[p] < lastbranch->bb.min[p]))))
				return(hit2);
		} else {
			nxtbranch = root->u.branch.right;

			if (nxtbranch != (bvtree *)NULL) {
				if (org < nxtbranch->bb.min[p] && dir < 0.0)
					hit1 = RT_FALSE;
				else if (!cmissedbbox(r, &nxtbranch->bb))
					hit1 = wtreetrace(r, nxtbranch);
				else
					hit1 = RT_FALSE;
			} else
				hit1 = RT_FALSE;

			if (r->done)
				return(RT_TRUE);

			nxtbranch = root->u.branch.mid;

			if (nxtbranch != (bvtree *)NULL) {
				if (((r->thehit.obj != (object *)NULL && r->thehit.vals[p] > nxtbranch->bb.max[p]) || dir >= 0.0) && org > nxtbranch->bb.max[p])
					return(hit1);

				if (!cmissedbbox(r, &nxtbranch->bb))
					hit2 = wtreetrace(r, nxtbranch);
				else
					hit2 = RT_FALSE;

			} else
				hit2 = RT_FALSE;

			if (hit1 || r->done)
				return(RT_TRUE);

			if (dir >= 0.0)
				return(hit2);

			lastbranch = root->u.branch.left;

			if (lastbranch == (bvtree *)NULL || (((r->thehit.obj != (object *)NULL && r->thehit.vals[p] > lastbranch->bb.max[p]))))
				return(hit2);
		}

		if (cmissedbbox(r, &lastbranch->bb))
			hit = RT_FALSE;
		else
			hit = wtreetrace(r, lastbranch);

		return(hit | hit2);
	}

	return(RT_FALSE);
}

/*
 * bvtreei
 * 
 *	intersect an bvtree.
 *
 */
int
bvtreei(r, o)
	ray	*r;
	object	*o;
{
	bboxtests[o->type]++;

	if (!missedbbox(r, &o->bb)) {
		if (wtreetrace(r, o->obj.bvt)) {
			r->hit = r->thehit;
			return(RT_TRUE);
		}
	}

	return(RT_FALSE);
}

/*
 * openbvtree
 *
 *	start the collecting object for a bvtree, all we need to
 * do here is push the object stack and start afresh.
 */
void
openbvtree()
{
	/*
	 * check we have more room on stack...
	 */
	if (ostackp->nxt == (oentry *)NULL) {
		ostackp->nxt = (oentry *)smalloc(sizeof(oentry));
		ostackp->nxt->lst = ostackp;
		ostackp->nxt->nxt = (oentry *)NULL;
	}

	/*
	 * push stack - clearing the object pointer.
	 */
	ostackp = ostackp->nxt;
	ostackp->objs = (object *)NULL;
}

/*
 * closebvtree
 *
 *	grab whatever is sitting on the object stack, pop the stack, and
 * add a bvtree object containing what we collected since the last openkdtree.
 */
void
closebvtree()
{
	object		*obj, *o, *nxto;
	olist		*ol;
	bvtree		*tree;

	/*
	 * set up the bvtree object
	 */
	obj = (object *)smalloc(sizeof(object));

	obj->type = BVTREEOBJ;
	obj->obj.bvt = tree = (bvtree *)smalloc(sizeof(bvtree));

	treenodes = 1;

	tree->type = SPLITABLELEAF;

	tree->u.leaf.oblist = (object *)NULL;
	tree->u.leaf.depth = 0;

	tree->bb.min[X] = ostackp->objs->bb.min[X];
	tree->bb.max[X] = ostackp->objs->bb.max[X];

	tree->bb.min[Y] = ostackp->objs->bb.min[Y];
	tree->bb.max[Y] = ostackp->objs->bb.max[Y];

	tree->bb.min[Z] = ostackp->objs->bb.min[Z];
	tree->bb.max[Z] = ostackp->objs->bb.max[Z];

	for (o = ostackp->objs; o != (object *)NULL; o = nxto) {
		nxto = o->nxt;
		o->nxt = tree->u.leaf.oblist;
		adjustbbox(&tree->bb, o);
		tree->u.leaf.oblist = o;
	}

	obj->bb = tree->bb;

	/*
	 * pop stack and add bvtree.
	 */
	ostackp = ostackp->lst;

	obj->nxt = ostackp->objs;
	ostackp->objs = obj;
}

/*
 * bvtreetabinit
 *
 *	set the table of function pointers for the tree.
 */
bvtreetabinit(intersects, normals, checkbbox, selfshadowing)
	int	(*intersects[])();
	void	(*normals[])();
	int	checkbbox[];
	int	selfshadowing[];
{
	normals[BVTREEOBJ] = (void (*)())NULL;
	intersects[BVTREEOBJ] = bvtreei;
	checkbbox[BVTREEOBJ] = RT_TRUE;
	selfshadowing[BVTREEOBJ] = RT_TRUE;
}
