#include <stdio.h>
#include <math.h>
#include <vort.h>
#include <sys/times.h>
#include "macro.h"
#include "rt.h"

extern FILE	*yyin;

extern float	*erandp, *randp, randtable[];
extern mat4x4	rtrans;

extern float	focallength;
extern float	ri;

extern hlist	*fhlist;

/*
 * pixel space...
 */
extern pixel	*topline, others[];

/*
 * the log file.
 */
extern FILE	*logfp;

extern object	*objlist;
extern oentry	*ostackp;

static int	width = 512, height = 512;

extern hlist *trace();

/*
 * imagesize
 *
 *	set the width and height of the image
 */
imagesize(w, h)
	int	w, h;
{
	width = w;
	height = h;
}

/*
 * render
 *
 *	render up the data-base into file named imname at a resolution
 * of width and height pixels.
 */
render(imname)
	char	*imname;
{
	int		i;
	image		*im;
	char		logname[100], buf[100];
	unsigned char	*red, *green, *blue, *alpha;

	tolerance = TOLERANCE;

	xsize = width;
	ysize = height;

	imagebufsize(512);
	if ((im = openimage(imname, "w")) == (image *)NULL) {
		sprintf(buf, "rend: unable to open %s for writing\n", imname);
		fatal(buf);
	}

	imagetype(im) = PIX_RLE;

	imagewidth(im) = xsize;
	imageheight(im) = ysize;

	imagedepth(im) = 24;

	imagedate(im) = time((time_t *)NULL);

	imagebackgnd(im).r = backcol[RED] * 255.0;
	imagebackgnd(im).g = backcol[GREEN] * 255.0;
	imagebackgnd(im).b = backcol[BLUE] * 255.0;

	titlelength(im) = 0;

	writeheader(im);

	xoff = xsize / 2;
	yoff = ysize / 2;

	if (xsize > ysize)
		xscale = yscale = ysize / 2;
	else
		xscale = yscale = xsize / 2;

	red = (unsigned char *)scalloc(xsize, 1);
	green = (unsigned char *)scalloc(xsize, 1);
	blue = (unsigned char *)scalloc(xsize, 1);
	alpha = (unsigned char *)scalloc(xsize, 1);

	topline = (pixel *)scalloc(sizeof(pixel), xsize + 1);

	k2 = (ysize - yoff) / yscale;

	for (i = 0; i <= xsize; i++)
		gensample((i - xoff) / xscale, k2, &topline[i]);

	k1 = -xoff / xscale;

	rendsettime();

	objlist = ostackp->objs;

	for (y = ysize - 1; y >= 0; y--) {

		gensample(k1, (y - yoff) / yscale, &others[0]);

		for (x = 1; x <= xsize; x++)
			dotrace(x, y, &red[x], &green[x], &blue[x], &alpha[x]);

		/*
		if (y % 10 == 0)
			printf("%d\n", y);
			*/

		if (alphachannel(im))
			writergbaline(im, red, green, blue, alpha);
		else
			writergbline(im, red, green, blue);
	}

	rendprinttime("Rendering time taken: ");

	closeimage(im);

	if (logfp != (FILE *)NULL) {
		printstats(logfp);

		fclose(logfp);
	}

	exit(0);
}

/*
 * gensample
 *
 *	generate a sample value for a given ray
 */
gensample(k1, k2, sample)
	float	k1, k2;
	pixel	*sample;
{
	ray	ir;
	hlist	*hit, *lp, *p;
	float	fact;

	ir.dir[X] = k1 * rtrans[0][0] + k2 * rtrans[1][0];
	ir.dir[Y] = k1 * rtrans[0][1] + k2 * rtrans[1][1];
	ir.dir[Z] = k1 * rtrans[0][2] + k2 * rtrans[1][2];

	ir.dir[X] += focallength * rtrans[2][0];
	ir.dir[Y] += focallength * rtrans[2][1];
	ir.dir[Z] += focallength * rtrans[2][2];

	ir.org[X] = rtrans[3][0];
	ir.org[Y] = rtrans[3][1];
	ir.org[Z] = rtrans[3][2];

	normalise(ir.dir);

	ir.ri = ri;
	ir.raynumber = raynumber++;
	ir.orgobj = (object *)NULL;
	ir.type = PRIMARY_RAY;

	if ((hit = trace(&ir, objlist)) != (hlist *)NULL) {
		shade(sample, &ir, hit, 0);
		sample->a = 1.0;
		eyehitrays++;
	} else {
		sample->r = backcol[RED];
		sample->g = backcol[GREEN];
		sample->b = backcol[BLUE];
		sample->a = 0.0;
		eyebackrays++;
	}

	for (lp = hit; lp != (hlist *)NULL; lp = p) {
		p = lp->nxt;
		release(lp);
	}
}

/*
 * dotrace
 *
 *	traces the neccessary number of rays and calculates r,
 * g, b, and alpha info averaging the samples at the end.
 */
dotrace(x, y, r, g, b, a)
	int		x, y;
	unsigned char	*r, *g, *b, *a;
{
	int	i;
	pixel	sample;
	float	red, green, blue, alpha;
	object	*o;

	red = green = blue = alpha = 0.0;

	gensample((x - xoff) / xscale, (y - yoff) / yscale, &others[1]);

	red = (topline[x - 1].r + topline[x].r + others[0].r + others[1].r);
	green = (topline[x - 1].g + topline[x].g + others[0].g + others[1].g);
	blue = (topline[x - 1].b + topline[x].b + others[0].b + others[1].b);
	alpha = (topline[x - 1].a + topline[x].a + others[0].a + others[1].a);

	topline[x - 1] = others[0];
	others[0] = others[1];

	if (alpha != 0.0) {
		*r = red * 255.0 / 4.0 + randnum();
		*g = green * 255.0 / 4.0 + randnum();
		*b = blue * 255.0 / 4.0 + randnum();
		*a = alpha * 255.0 / 4.0;
	} else {
		*r = red * 255.0 / 4.0;
		*g = green * 255.0 / 4.0;
		*b = blue * 255.0 / 4.0;
		*a = alpha * 255.0 / 4.0;
	}
}
