#include <math.h>
#include <stdio.h>
#include "rt.h"
#include "macro.h"

extern long	bboxtests[];

/*
 * cmissedbbox
 *
 *	checks a ray against a bounding box returning RT_FALSE if it intersects
 * RT_TRUE otherwise. Increments the bbox count for an oxtree as well.
 */
int
cmissedbbox(r, bb)
	register ray	*r;
	register bbox	*bb;
{
	register float	d, o, t, t1, t2, b1, b2;
	
	if (r->org[X] >= bb->min[X] && r->org[X] <= bb->max[X]
	   && r->org[Y] >= bb->min[Y] && r->org[Y] <= bb->max[Y]
	   && r->org[Z] >= bb->min[Z] && r->org[Z] <= bb->max[Z])
		return(RT_FALSE);

	t1 = 0.0;
	t2 = HUGE_DIST;

	d = r->dir[X];
	o = r->org[X];
	if (d != 0.0) {

		if (d < 0.0) {
			b2 = bb->min[X] - o;
			if (b2 > 0.0)
				return(RT_TRUE);
			b1 = bb->max[X] - o;
		} else {
			b2 = bb->max[X] - o;
			if (b2 < 0.0)
				return(RT_TRUE);
			b1 = bb->min[X] - o;
		}
			
		t2 = b2 / d;
		t1 = b1 / d;
		if (t1 < 0.0)
			t1 = 0.0;
	} else if (o < bb->min[X] || o > bb->max[X])
		return(RT_TRUE);

	d = r->dir[Y];
	o = r->org[Y];
	if (d != 0.0) {

		if (d < 0.0) {
			b2 = bb->min[Y] - o;
			if (b2 > 0.0)
				return(RT_TRUE);
			b1 = bb->max[Y] - o;
		} else {
			b2 = bb->max[Y] - o;
			if (b2 < 0.0)
				return(RT_TRUE);
			b1 = bb->min[Y] - o;
		}
			
		if ((t = b2 / d) < t1)
			return(RT_TRUE);

		if (t < t2)
			t2 = t;

		if ((t = b1 / d) > t2)
			return(RT_TRUE);

		if (t > t1)
			t1 = t;
	} else if (o < bb->min[Y] || o > bb->max[Y])
		return(RT_TRUE);

	d = r->dir[Z];
	o = r->org[Z];
	if (d != 0.0) {
		if (d < 0.0) {
			b2 = bb->min[Z] - o;
			if (b2 > 0.0)
				return(RT_TRUE);
			b1 = bb->max[Z] - o;
		} else {
			b2 = bb->max[Z] - o;
			if (b2 < 0.0)
				return(RT_TRUE);
			b1 = bb->min[Z] - o;
		}

		if (b2 / d < t1)
			return(RT_TRUE);

		if (b1 / d > t2)
			return(RT_TRUE);

	} else if (o < bb->min[Z] || o > bb->max[Z])
		return(RT_TRUE);

	return(RT_FALSE);
}

/*
 * missedbbox
 *
 *	checks a ray against a bounding box returning RT_FALSE if it intersects
 * RT_TRUE otherwise. 
 */
int
missedbbox(r, bb)
	register ray	*r;
	register bbox	*bb;
{
	register float	d, o, t, t1, t2, b1, b2;
	
	if (r->org[X] >= bb->min[X] && r->org[X] <= bb->max[X]
	   && r->org[Y] >= bb->min[Y] && r->org[Y] <= bb->max[Y]
	   && r->org[Z] >= bb->min[Z] && r->org[Z] <= bb->max[Z])
		return(RT_FALSE);

	t1 = 0.0;
	t2 = HUGE_DIST;

	d = r->dir[X];
	o = r->org[X];
	if (d != 0.0) {

		if (d < 0.0) {
			b2 = bb->min[X] - o;
			if (b2 > 0.0)
				return(RT_TRUE);
			b1 = bb->max[X] - o;
		} else {
			b2 = bb->max[X] - o;
			if (b2 < 0.0)
				return(RT_TRUE);
			b1 = bb->min[X] - o;
		}
			
		t2 = b2 / d;
		t1 = b1 / d;
		if (t1 < 0.0)
			t1 = 0.0;
	} else if (o < bb->min[X] || o > bb->max[X])
		return(RT_TRUE);

	d = r->dir[Y];
	o = r->org[Y];
	if (d != 0.0) {

		if (d < 0.0) {
			b2 = bb->min[Y] - o;
			if (b2 > 0.0)
				return(RT_TRUE);
			b1 = bb->max[Y] - o;
		} else {
			b2 = bb->max[Y] - o;
			if (b2 < 0.0)
				return(RT_TRUE);
			b1 = bb->min[Y] - o;
		}
			
		if ((t = b2 / d) < t1)
			return(RT_TRUE);

		if (t < t2)
			t2 = t;

		if ((t = b1 / d) > t2)
			return(RT_TRUE);

		if (t > t1)
			t1 = t;
	} else if (o < bb->min[Y] || o > bb->max[Y])
		return(RT_TRUE);

	d = r->dir[Z];
	o = r->org[Z];
	if (d != 0.0) {
		if (d < 0.0) {
			b2 = bb->min[Z] - o;
			if (b2 > 0.0)
				return(RT_TRUE);
			b1 = bb->max[Z] - o;
		} else {
			b2 = bb->max[Z] - o;
			if (b2 < 0.0)
				return(RT_TRUE);
			b1 = bb->min[Z] - o;
		}

		if (b2 / d < t1)
			return(RT_TRUE);

		if (b1 / d > t2)
			return(RT_TRUE);
	} else if (o < bb->min[Z] || o > bb->max[Z])
		return(RT_TRUE);

	return(RT_FALSE);
}

/*
 * inbbox
 *
 *	checks a ray against a bounding box returning RT_TRUE if it intersects
 * RT_FALSE otherwise. *pt1 and *pt2 are returned with the entry and exit
 * distances of the ray. If the ray is in the box *pt1 represents the
 * distance to the box in front of the observer, *pt2 the distance behind.
 */
int
inbbox(r, bb, pt1, pt2)
	register ray	*r;
	register bbox	*bb;
	float		*pt1, *pt2;
{
	register float	d, o, t, t1, t2, b1, b2;

	t1 = 0.0;
	t2 = HUGE_DIST;

	d = r->dir[X];
	o = r->org[X];
	if (d != 0.0) {

		if (d < 0.0) {
			b2 = bb->min[X] - o;
			if (b2 > 0.0)
				return(RT_FALSE);
			b1 = bb->max[X] - o;
		} else {
			b2 = bb->max[X] - o;
			if (b2 < 0.0)
				return(RT_FALSE);
			b1 = bb->min[X] - o;
		}
			
		t2 = b2 / d;
		t1 = b1 / d;
		if (t1 < 0.0)
			t1 = 0.0;
	} else if (o < bb->min[X] || o > bb->max[X])
		return(RT_FALSE);

	d = r->dir[Y];
	o = r->org[Y];
	if (d != 0.0) {

		if (d < 0.0) {
			b2 = bb->min[Y] - o;
			if (b2 > 0.0)
				return(RT_FALSE);
			b1 = bb->max[Y] - o;
		} else {
			b2 = bb->max[Y] - o;
			if (b2 < 0.0)
				return(RT_FALSE);
			b1 = bb->min[Y] - o;
		}
			
		if ((t = b2 / d) < t1)
			return(RT_FALSE);

		if (t < t2)
			t2 = t;

		if ((t = b1 / d) > t2)
			return(RT_FALSE);

		if (t > t1)
			t1 = t;
	} else if (o < bb->min[Y] || o > bb->max[Y])
		return(RT_FALSE);

	d = r->dir[Z];
	o = r->org[Z];
	if (d != 0.0) {
		if (d < 0.0) {
			b2 = bb->min[Z] - o;
			if (b2 > 0.0)
				return(RT_FALSE);
			b1 = bb->max[Z] - o;
		} else {
			b2 = bb->max[Z] - o;
			if (b2 < 0.0)
				return(RT_FALSE);
			b1 = bb->min[Z] - o;
		}

		if ((t = (b2 / d)) < t1)
			return(RT_FALSE);
		
		if (t < t2)
			t2 = t;

		if ((t = (b1 / d)) > t2)
			return(RT_FALSE);

		if (t > t1)
			t1 = t;
	} else if (o < bb->min[Z] || o > bb->max[Z])
		return(RT_FALSE);

	*pt1 = t1;
	*pt2 = t2;

	return(RT_TRUE);
}

/*
 * adjustbbox
 *
 *	adjust the bounding box so it contains the object o.
 */
adjustbbox(bb, o)
	bbox	*bb;
	object	*o;
{
	if (o->bb.min[X] < bb->min[X])
		bb->min[X] = o->bb.min[X];
	if (o->bb.max[X] > bb->max[X])
		bb->max[X] = o->bb.max[X];

	if (o->bb.min[Y] < bb->min[Y])
		bb->min[Y] = o->bb.min[Y];
	if (o->bb.max[Y] > bb->max[Y])
		bb->max[Y] = o->bb.max[Y];

	if (o->bb.min[Z] < bb->min[Z])
		bb->min[Z] = o->bb.min[Z];
	if (o->bb.max[Z] > bb->max[Z])
		bb->max[Z] = o->bb.max[Z];
}
