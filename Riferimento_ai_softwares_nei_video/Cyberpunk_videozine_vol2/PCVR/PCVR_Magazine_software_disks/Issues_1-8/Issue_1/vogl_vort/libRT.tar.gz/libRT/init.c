#include <stdio.h>
#include "random.h"
#include "rt.h"

float	tolerance;

object	*objlist;
surface	*cursurf;

oentry		*ostackp;
mentry		*mstackp;
lightobj	*lights;

/*
 * background
 */
colour	backcol;

/*
 * ambient
 */
colour	amblight;

/*
 * refractive index.
 */
float	ri = 1.0;

/*
 * surface stack
 */
shadedata	*sstackp, *sstack;

/*
 * function pointer tables for intersections, normals, etc...
 */
int	(*intersects[NUM_OBJS])();
void	(*normal[NUM_OBJS])();
void	(*tilefun[NUM_OBJS])();

int	checkbbox[NUM_OBJS];	/* should we check bounding box of this type */
int	selfshadowing[NUM_OBJS];	/* is this object self shadowing? */

int	maxhitlevel = 4;

int	maxtreedepth = 30;
int	maxoctreedepth = 10;

/* 
 * world up and the ray to world and world to ray transformation
 * matrices.
 */
vector	up;
mat4x4	rtrans, wtrans;

float	focallength;

/*
 * image related factors...
 */
float	xscale, yscale, k1, k2;
int	xsize, ysize, xoff, yoff, x, y;

/*
 * pixel space...
 */
pixel	*topline, others[2];

/*
 * ray stats.
 */
long	raynumber = 0;
long	shadrays = 0;
long	transrays = 0;
long	hitrays = 0;

long	eyehitrays = 0;
long	eyebackrays = 0;

long	reflectionhitrays = 0;
long	reflectionmissrays = 0;

long	refractionhitrays = 0;
long	refractionmissrays = 0;

long	shadowtests, shadowhits;

long	treenodes = 0;

long	objtests[NUM_OBJS];
long	inttests[NUM_OBJS];
long	hits[NUM_OBJS];
long	bboxtests[NUM_OBJS];

/*
 * object stats...
 */
long	totobjs;

extern hlist	*trace();

hlist		*fhlist;

float	*randp = randtable,
	*erandp = &randtable[sizeof(randtable) / sizeof(float)];

/*
 * rendinit
 *
 *	initialise the stacks, etc, for the rendering.
 */
rendinit()
{
	sstack = (shadedata *)smalloc(maxhitlevel * sizeof(shadedata));
	sstackp = sstack;
	sstackp->ri = ri;

	ostackp = (oentry *)smalloc(sizeof(oentry));
	ostackp->objs = (object *)NULL;
	ostackp->lst = ostackp->nxt = (oentry *)NULL;

	mstackp = (mentry *)smalloc(sizeof(mentry));
	mstackp->lst = mstackp->nxt = (mentry *)NULL;

	lights = (lightobj *)NULL;

	makeident4x4(mstackp->m.obj2ray);
	makeident4x4(mstackp->m.ray2obj);

	/*
	 * set up intersection and normal function pointers
	 */
	polytabinit(intersects, normal, checkbbox, selfshadowing);
	spheretabinit(intersects, normal, checkbbox, selfshadowing);
	conecyltabinit(intersects, normal, checkbbox, selfshadowing);

	gridtabinit(intersects, normal, checkbbox, selfshadowing);
	kdtreetabinit(intersects, normal, checkbbox, selfshadowing);
	octreetabinit(intersects, normal, checkbbox, selfshadowing);
	bvtreetabinit(intersects, normal, checkbbox, selfshadowing);

	/*
	 * set up default ambient and background.
	 */
	ambient(0.05, 0.05, 0.05);
	background(0.0, 0.0, 0.0);
}
