#include <stdio.h>
#include <math.h>
#include "rt.h"
#include "macro.h"

extern hlist	*fhlist;
extern int	maxhitlevel;

extern double	power();

extern int	*(*intersects[NUM_OBJS])();

/*
 * trace
 *
 *	returns a list of hits on the first object hit by r
 */
hlist *
trace(r, oblist)
	ray	*r;
	object	*oblist;
{
	object	*o;
	hlist	*hit, *prevhits, *p, *np;
	hlist	*end;

	prevhits = (hlist *)NULL;

	r->thehit.obj = (object *)NULL;
	r->done = RT_FALSE;

	for (o = oblist; o != (object *)NULL; o = o->nxt)
		if (intersects[o->type](r, o)) {

			fetch(hit);
			*hit = r->hit;
			hit->nxt = (hlist *)NULL;

			if (prevhits == (hlist *)NULL)
				prevhits = hit;
			else {
				if (prevhits->t > hit->t) {
					for (p = prevhits; p != (hlist *)NULL; p = np) {
						np = p->nxt;
						release(p);
					}
					prevhits = hit;
				} else {
					for (p = hit; p != (hlist *)NULL; p = np) {
						np = p->nxt;
						release(p);
					}
				}
			}
		}

	return(prevhits);
}
