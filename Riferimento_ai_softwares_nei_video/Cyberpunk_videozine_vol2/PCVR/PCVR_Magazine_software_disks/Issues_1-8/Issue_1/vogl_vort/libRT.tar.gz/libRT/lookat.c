#include <stdio.h>
#include <math.h>
#include "rt.h"
#include "macro.h"

extern vector	up;
extern mat4x4	rtrans, wtrans;

extern float	focallength;

/*
 * viewup
 *
 *	set the up vector.
 */
viewup(x, y, z)
	float	x, y, z;
{
	up[X] = x;
	up[Y] = y;
	up[Z] = z;

	normalise(up);
}

/*
 * viewlookat
 *
 *	do the look at.
 */
viewlookat(eyex, eyey, eyez, refx, refy, refz)
	float		eyex, eyey, eyez;
	float		refx, refy, refz;
{
	vector	t, u, s;
	mat4x4	m, tmp;
	double	val, vy, vz, sinval, cosval;

	makeident4x4(rtrans);

	/*
	 * calculate the lookat
	 */
	t[X] = eyex - refx;
	t[Y] = eyey - refy;
	t[Z] = eyez - refz;

	u[X] = up[X];
	u[Y] = up[Y];
	u[Z] = up[Z];

	normalise(t);

	normalise(u);

	vz = dprod(t, u);

	if (fabs(vz) == 1.0)
		fatal("viewlookat: up vector and direction of view are the same.\n");

	vy = sqrt(1.0 - vz * vz);

	u[X] = (u[X] - vz * t[X]) / vy;
	u[Y] = (u[Y] - vz * t[Y]) / vy;
	u[Z] = (u[Z] - vz * t[Z]) / vy;

	xprod(s, u, t);

	makeident4x4(m);

	m[0][0] = s[X];
	m[0][1] = s[Y];
	m[0][2] = s[Z];

	m[1][0] = u[X];
	m[1][1] = u[Y];
	m[1][2] = u[Z];

	m[2][0] = t[X];
	m[2][1] = t[Y];
	m[2][2] = t[Z];

	copy4x4(tmp, rtrans);
	mult4x4(rtrans, tmp, m);

	makeident4x4(wtrans);

	cp3x3t(wtrans, rtrans);

	makeident4x4(m);
	m[3][0] = eyex;
	m[3][1] = eyey;
	m[3][2] = eyez;
	copy4x4(tmp, rtrans);
	mult4x4(rtrans, tmp, m);

	makeident4x4(m);
	m[3][0] = -eyex;
	m[3][1] = -eyey;
	m[3][2] = -eyez;
	copy4x4(tmp, wtrans);
	mult4x4(wtrans, m, tmp);
}



/*
 * viewfov
 *
 *	set the fieldofview
 */
viewfov(fov)
	float	fov;
{
	focallength = -1.0 / tan(M_PI / 360.0 * fov);
}
