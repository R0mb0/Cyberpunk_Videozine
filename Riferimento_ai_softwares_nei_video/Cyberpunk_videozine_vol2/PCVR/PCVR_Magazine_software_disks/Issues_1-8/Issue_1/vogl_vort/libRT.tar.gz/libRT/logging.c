#include <stdio.h>
#include <math.h>
#include <vort.h>
#include <sys/times.h>
#include "macro.h"
#include "rt.h"

extern FILE	*yyin;

char *objnames[NUM_OBJS] = {
		"Sphere",
		"Cylinder",
		"Cone", 
		"Polygon",
		"Triangle",
		"Triangle patch",
		"K-d tree",
		"Bv-tree",
		"Oc-tree",
		"Uniform grid"
};

/*
 * the log file.
 */
extern object	*objlist;
extern oentry	*ostackp;

/*
 * printstats
 *
 *	print out the stats gathered during the rendering.
 */
void
printstats(logfp)
	FILE	*logfp;
{
	int		i;
	long		tot;

	fprintf(logfp, "Eye rays that hit:\t\t%ld\n", eyehitrays);
	fprintf(logfp, "Eye rays that missed:\t\t%ld\n", eyebackrays);
	fprintf(logfp, "Total eye rays:\t\t\t%ld\n", eyehitrays + eyebackrays);
	fprintf(logfp, "Reflection rays that hit:\t%ld\n", reflectionhitrays);
	fprintf(logfp, "Reflection rays that missed:\t%ld\n", reflectionmissrays);
	fprintf(logfp, "Total reflection rays:\t\t%ld\n", reflectionhitrays + reflectionmissrays);
	fprintf(logfp, "Refraction rays that hit:\t%ld\n", refractionhitrays);
	fprintf(logfp, "Refraction rays that missed:\t%ld\n", refractionmissrays);
	fprintf(logfp, "Total refraction rays:\t\t%ld\n", refractionhitrays + refractionmissrays);
	fprintf(logfp, "Shadow cache tests %ld, hits %ld.\n", shadowtests, shadowhits);
	fprintf(logfp, "Total number of rays:\t\t%ld\n", raynumber);

	if (treenodes != 0)
		fprintf(logfp, "Total number of tree nodes:\t\t%ld\n", treenodes);

	tot = 0;
	for (i = 0; i != NUM_OBJS; i++) {
		if (i < 6)
			tot += inttests[i] + bboxtests[i];

		if (inttests[i] != 0)
			fprintf(logfp, "%s intersection tests:\t%ld (hits %ld %%%f).\n", objnames[i], inttests[i], hits[i], (float)hits[i] / inttests[i] * 100.0);
		if (bboxtests[i] != 0)
			fprintf(logfp, "%s bounding box tests %ld\n", objnames[i], bboxtests[i]);
	}

	fprintf(logfp, "Total object intersections tests %ld\n", tot);
}
