
# line 6 "gram.y"
#include <stdio.h>
#include <rt.h>
#include "rend.h"

static vector	up, eye, ref;


# line 14 "gram.y"
typedef union
#ifdef __cplusplus
	YYSTYPE
#endif
 {
	int	y_int;
	float	y_flt;
	vnode	*y_vnd;
	vnnode	*y_vnn;
} YYSTYPE;
# define VIEWING 257
# define FROM 258
# define AT 259
# define UP 260
# define ANGLE 261
# define HITHER 262
# define RESOLUTION 263
# define BACKGROUND 264
# define LIGHT 265
# define MATERIAL 266
# define POLYGON 267
# define CONE 268
# define SPHERE 269
# define POLYGONPATCH 270
# define FLOAT 271

#include <malloc.h>
#include <memory.h>
#include <unistd.h>
#include <values.h>

#ifdef __cplusplus

#ifndef yyerror
	void yyerror(const char *);
#endif
#ifndef yylex
	extern "C" int yylex(void);
#endif
	int yyparse(void);

#endif
#define yyclearin yychar = -1
#define yyerrok yyerrflag = 0
extern int yychar;
extern int yyerrflag;
YYSTYPE yylval;
YYSTYPE yyval;
typedef int yytabelem;
#ifndef YYMAXDEPTH
#define YYMAXDEPTH 150
#endif
#if YYMAXDEPTH > 0
int yy_yys[YYMAXDEPTH], *yys = yy_yys;
YYSTYPE yy_yyv[YYMAXDEPTH], *yyv = yy_yyv;
#else	/* user does initial allocation */
int *yys;
YYSTYPE *yyv;
#endif
static int yymaxdepth = YYMAXDEPTH;
# define YYERRCODE 256
yytabelem yyexca[] ={
-1, 1,
	0, -1,
	-2, 0,
	};
# define YYNPROD 24
# define YYLAST 92
yytabelem yyact[]={

     3,    21,     1,    13,     2,    11,    41,     4,     5,     6,
     9,     7,     8,    10,    14,    15,    16,    17,    18,    19,
    20,    40,     0,     0,     0,     0,    22,    23,    24,    25,
    26,    27,     0,    12,     0,    29,    30,    31,    32,    33,
    34,    35,     0,    36,    37,    38,    39,    28,     0,     0,
    42,    43,    44,     0,     0,    45,    46,    47,    48,    49,
    50,    51,    52,    53,    54,    55,     0,     0,     0,    56,
    57,    58,    59,    60,     0,     0,     0,    61,    62,     0,
    63,    64,    65,    66,     0,    67,    68,    69,    70,    71,
    72,    73 };
yytabelem yypact[]={

  -257,-10000000,  -257,  -244,  -270,  -270,  -270,  -270,  -270,  -270,
  -270,-10000000,-10000000,  -244,  -270,  -270,  -270,  -270,  -270,  -270,
  -270,-10000000,  -270,  -270,  -270,  -270,-10000000,-10000000,-10000000,  -270,
  -270,  -270,-10000000,-10000000,  -270,  -270,  -270,  -270,  -270,  -270,
  -270,  -270,  -270,  -270,  -270,-10000000,-10000000,-10000000,  -270,  -270,
  -270,  -270,  -270,-10000000,-10000000,-10000000,  -270,  -270,-10000000,  -270,
  -270,  -270,  -270,-10000000,  -270,  -270,  -270,  -270,  -270,  -270,
  -270,-10000000,-10000000,-10000000 };
yytabelem yypgo[]={

     0,    20,    21,     6,     2,     4,    33,     3 };
yytabelem yyr1[]={

     0,     4,     4,     5,     5,     5,     5,     5,     5,     5,
     5,     6,     6,     7,     7,     7,     7,     7,     7,     2,
     2,     3,     3,     1 };
yytabelem yyr2[]={

     0,     0,     4,     5,     9,     9,    19,    19,    11,     7,
     7,     0,     4,     9,     9,     9,     5,     5,     7,     1,
     9,     1,    15,     3 };
yytabelem yychk[]={

-10000000,    -4,    -5,   257,   264,   265,   266,   268,   269,   267,
   270,    -4,    -6,    -7,   258,   259,   260,   261,   262,   263,
    -1,   271,    -1,    -1,    -1,    -1,    -1,    -1,    -6,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -2,    -3,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1 };
yytabelem yydef[]={

     1,    -2,     1,    11,     0,     0,     0,     0,     0,     0,
     0,     2,     3,    11,     0,     0,     0,     0,     0,     0,
     0,    23,     0,     0,     0,     0,    19,    21,    12,     0,
     0,     0,    16,    17,     0,     0,     0,     0,     0,     0,
     9,    10,     0,     0,     0,    18,     4,     5,     0,     0,
     0,     0,     0,    13,    14,    15,     0,     0,     8,     0,
     0,     0,     0,    20,     0,     0,     0,     0,     0,     0,
     0,     6,     7,    22 };
typedef struct
#ifdef __cplusplus
	yytoktype
#endif
{ char *t_name; int t_val; } yytoktype;
#ifndef YYDEBUG
#	define YYDEBUG	0	/* don't allow debugging */
#endif

#if YYDEBUG

yytoktype yytoks[] =
{
	"VIEWING",	257,
	"FROM",	258,
	"AT",	259,
	"UP",	260,
	"ANGLE",	261,
	"HITHER",	262,
	"RESOLUTION",	263,
	"BACKGROUND",	264,
	"LIGHT",	265,
	"MATERIAL",	266,
	"POLYGON",	267,
	"CONE",	268,
	"SPHERE",	269,
	"POLYGONPATCH",	270,
	"FLOAT",	271,
	"-unknown-",	-1	/* ends search */
};

char * yyreds[] =
{
	"-no such reduction-",
	"input : /* empty */",
	"input : inputitem input",
	"inputitem : VIEWING viewinfo",
	"inputitem : BACKGROUND expr expr expr",
	"inputitem : LIGHT expr expr expr",
	"inputitem : MATERIAL expr expr expr expr expr expr expr expr",
	"inputitem : CONE expr expr expr expr expr expr expr expr",
	"inputitem : SPHERE expr expr expr expr",
	"inputitem : POLYGON expr vertlist",
	"inputitem : POLYGONPATCH expr vertnormlist",
	"viewinfo : /* empty */",
	"viewinfo : viewitem viewinfo",
	"viewitem : FROM expr expr expr",
	"viewitem : AT expr expr expr",
	"viewitem : UP expr expr expr",
	"viewitem : ANGLE expr",
	"viewitem : HITHER expr",
	"viewitem : RESOLUTION expr expr",
	"vertlist : /* empty */",
	"vertlist : vertlist expr expr expr",
	"vertnormlist : /* empty */",
	"vertnormlist : vertnormlist expr expr expr expr expr expr",
	"expr : FLOAT",
};
#endif /* YYDEBUG */
/* 
 *	Copyright 1987 Silicon Graphics, Inc. - All Rights Reserved
 */

/* #ident	"@(#)yacc:yaccpar	1.10" */
#ident	"$Revision: 1.9 $"

/*
** Skeleton parser driver for yacc output
*/

/*
** yacc user known macros and defines
*/
#define YYERROR		goto yyerrlab
#define YYACCEPT	return(0)
#define YYABORT		return(1)
#ifdef __cplusplus
#define YYBACKUP( newtoken, newvalue )\
{\
	if ( yychar >= 0 || ( yyr2[ yytmp ] >> 1 ) != 1 )\
	{\
		yyerror( gettxt("uxlibc:78", "syntax error - cannot backup") );\
		goto yyerrlab;\
	}\
	yychar = newtoken;\
	yystate = *yyps;\
	yylval = newvalue;\
	goto yynewstate;\
}
#else
#define YYBACKUP( newtoken, newvalue )\
{\
	if ( yychar >= 0 || ( yyr2[ yytmp ] >> 1 ) != 1 )\
	{\
		yyerror( gettxt("uxlibc:78", "Syntax error - cannot backup") );\
		goto yyerrlab;\
	}\
	yychar = newtoken;\
	yystate = *yyps;\
	yylval = newvalue;\
	goto yynewstate;\
}
#endif
#define YYRECOVERING()	(!!yyerrflag)
#define YYNEW(type)	malloc(sizeof(type) * yynewmax)
#define YYCOPY(to, from, type) \
	(type *) memcpy(to, (char *) from, yynewmax * sizeof(type))
#define YYENLARGE( from, type) \
	(type *) realloc((char *) from, yynewmax * sizeof(type))
#ifndef YYDEBUG
#	define YYDEBUG	1	/* make debugging available */
#endif

/*
** user known globals
*/
int yydebug;			/* set to 1 to get debugging */

/*
** driver internal defines
*/
#define YYFLAG		(-10000000)

/*
** global variables used by the parser
*/
YYSTYPE *yypv;			/* top of value stack */
int *yyps;			/* top of state stack */

int yystate;			/* current state */
int yytmp;			/* extra var (lasts between blocks) */

int yynerrs;			/* number of errors */
int yyerrflag;			/* error recovery flag */
int yychar;			/* current input token number */



/*
** yyparse - return 0 if worked, 1 if syntax error not recovered from
*/
#if defined(__STDC__) || defined(__cplusplus)
int yyparse(void)
#else
int yyparse()
#endif
{
	register YYSTYPE *yypvt;	/* top of value stack for $vars */

	/*
	** Initialize externals - yyparse may be called more than once
	*/
	yypv = &yyv[-1];
	yyps = &yys[-1];
	yystate = 0;
	yytmp = 0;
	yynerrs = 0;
	yyerrflag = 0;
	yychar = -1;

#if YYMAXDEPTH <= 0
	if (yymaxdepth <= 0)
	{
		if ((yymaxdepth = YYEXPAND(0)) <= 0)
		{
#ifdef __cplusplus
			yyerror(gettxt("uxlibc:79", "yacc initialization error"));
#else
			yyerror(gettxt("uxlibc:79", "Yacc initialization error"));
#endif
			YYABORT;
		}
	}
#endif

	goto yystack;
	{
		register YYSTYPE *yy_pv;	/* top of value stack */
		register int *yy_ps;		/* top of state stack */
		register int yy_state;		/* current state */
		register int  yy_n;		/* internal state number info */

		/*
		** get globals into registers.
		** branch to here only if YYBACKUP was called.
		*/
	yynewstate:
		yy_pv = yypv;
		yy_ps = yyps;
		yy_state = yystate;
		goto yy_newstate;

		/*
		** get globals into registers.
		** either we just started, or we just finished a reduction
		*/
	yystack:
		yy_pv = yypv;
		yy_ps = yyps;
		yy_state = yystate;

		/*
		** top of for (;;) loop while no reductions done
		*/
	yy_stack:
		/*
		** put a state and value onto the stacks
		*/
#if YYDEBUG
		/*
		** if debugging, look up token value in list of value vs.
		** name pairs.  0 and negative (-1) are special values.
		** Note: linear search is used since time is not a real
		** consideration while debugging.
		*/
		if ( yydebug )
		{
			register int yy_i;

			printf( "State %d, token ", yy_state );
			if ( yychar == 0 )
				printf( "end-of-file\n" );
			else if ( yychar < 0 )
				printf( "-none-\n" );
			else
			{
				for ( yy_i = 0; yytoks[yy_i].t_val >= 0;
					yy_i++ )
				{
					if ( yytoks[yy_i].t_val == yychar )
						break;
				}
				printf( "%s\n", yytoks[yy_i].t_name );
			}
		}
#endif /* YYDEBUG */
		if ( ++yy_ps >= &yys[ yymaxdepth ] )	/* room on stack? */
		{
			int yynewmax, yys_off;

			/* The following pointer-differences are safe, since
			 * yypvt, yy_pv, and yypv all are a multiple of
			 * sizeof(YYSTYPE) bytes from yyv.
			 */
			int yypvt_off = yypvt - yyv;
			int yy_pv_off = yy_pv - yyv;
			int yypv_off = yypv - yyv;

			int *yys_base = yys;
#ifdef YYEXPAND
			yynewmax = YYEXPAND(yymaxdepth);
#else
			yynewmax = 2 * yymaxdepth;	/* double table size */
			if (yymaxdepth == YYMAXDEPTH)	/* first time growth */
			{
				void *newyys = YYNEW(int);
				void *newyyv = YYNEW(YYSTYPE);
				if (newyys != 0 && newyyv != 0)
				{
					yys = YYCOPY(newyys, yys, int);
					yyv = YYCOPY(newyyv, yyv, YYSTYPE);
				}
				else
					yynewmax = 0;	/* failed */
			}
			else				/* not first time */
			{
				yys = YYENLARGE(yys, int);
				yyv = YYENLARGE(yyv, YYSTYPE);
				if (yys == 0 || yyv == 0)
					yynewmax = 0;	/* failed */
			}
#endif
			if (yynewmax <= yymaxdepth)	/* tables not expanded */
			{
#ifdef __cplusplus
				yyerror( gettxt("uxlibc:80", "yacc stack overflow") );
#else
				yyerror( gettxt("uxlibc:80", "Yacc stack overflow") );
#endif
				YYABORT;
			}
			yymaxdepth = yynewmax;

			/* reset pointers into yys */
			yys_off = yys - yys_base;
			yy_ps = yy_ps + yys_off;
			yyps = yyps + yys_off;

			/* reset pointers into yyv */
			yypvt = yyv + yypvt_off;
			yy_pv = yyv + yy_pv_off;
			yypv = yyv + yypv_off;
		}
		*yy_ps = yy_state;
		*++yy_pv = yyval;

		/*
		** we have a new state - find out what to do
		*/
	yy_newstate:
		if ( ( yy_n = yypact[ yy_state ] ) <= YYFLAG )
			goto yydefault;		/* simple state */
#if YYDEBUG
		/*
		** if debugging, need to mark whether new token grabbed
		*/
		yytmp = yychar < 0;
#endif
		if ( ( yychar < 0 ) && ( ( yychar = yylex() ) < 0 ) )
			yychar = 0;		/* reached EOF */
#if YYDEBUG
		if ( yydebug && yytmp )
		{
			register int yy_i;

			printf( "Received token " );
			if ( yychar == 0 )
				printf( "end-of-file\n" );
			else if ( yychar < 0 )
				printf( "-none-\n" );
			else
			{
				for ( yy_i = 0; yytoks[yy_i].t_val >= 0;
					yy_i++ )
				{
					if ( yytoks[yy_i].t_val == yychar )
						break;
				}
				printf( "%s\n", yytoks[yy_i].t_name );
			}
		}
#endif /* YYDEBUG */
		if ( ( ( yy_n += yychar ) < 0 ) || ( yy_n >= YYLAST ) )
			goto yydefault;
		if ( yychk[ yy_n = yyact[ yy_n ] ] == yychar )	/*valid shift*/
		{
			yychar = -1;
			yyval = yylval;
			yy_state = yy_n;
			if ( yyerrflag > 0 )
				yyerrflag--;
			goto yy_stack;
		}

	yydefault:
		if ( ( yy_n = yydef[ yy_state ] ) == -2 )
		{
#if YYDEBUG
			yytmp = yychar < 0;
#endif
			if ( ( yychar < 0 ) && ( ( yychar = yylex() ) < 0 ) )
				yychar = 0;		/* reached EOF */
#if YYDEBUG
			if ( yydebug && yytmp )
			{
				register int yy_i;

				printf( "Received token " );
				if ( yychar == 0 )
					printf( "end-of-file\n" );
				else if ( yychar < 0 )
					printf( "-none-\n" );
				else
				{
					for ( yy_i = 0;
						yytoks[yy_i].t_val >= 0;
						yy_i++ )
					{
						if ( yytoks[yy_i].t_val
							== yychar )
						{
							break;
						}
					}
					printf( "%s\n", yytoks[yy_i].t_name );
				}
			}
#endif /* YYDEBUG */
			/*
			** look through exception table
			*/
			{
				register int *yyxi = yyexca;

				while ( ( *yyxi != -1 ) ||
					( yyxi[1] != yy_state ) )
				{
					yyxi += 2;
				}
				while ( ( *(yyxi += 2) >= 0 ) &&
					( *yyxi != yychar ) )
					;
				if ( ( yy_n = yyxi[1] ) < 0 )
					YYACCEPT;
			}
		}

		/*
		** check for syntax error
		*/
		if ( yy_n == 0 )	/* have an error */
		{
			/* no worry about speed here! */
			switch ( yyerrflag )
			{
			case 0:		/* new error */
#ifdef __cplusplus
				yyerror( gettxt("uxlibc:81", "syntax error") );
#else
				yyerror( gettxt("uxlibc:81", "Syntax error") );
#endif
				goto skip_init;
			yyerrlab:
				/*
				** get globals into registers.
				** we have a user generated syntax type error
				*/
				yy_pv = yypv;
				yy_ps = yyps;
				yy_state = yystate;
				yynerrs++;
				/* FALLTHRU */
			skip_init:
			case 1:
			case 2:		/* incompletely recovered error */
					/* try again... */
				yyerrflag = 3;
				/*
				** find state where "error" is a legal
				** shift action
				*/
				while ( yy_ps >= yys )
				{
					yy_n = yypact[ *yy_ps ] + YYERRCODE;
					if ( yy_n >= 0 && yy_n < YYLAST &&
						yychk[yyact[yy_n]] == YYERRCODE)					{
						/*
						** simulate shift of "error"
						*/
						yy_state = yyact[ yy_n ];
						goto yy_stack;
					}
					/*
					** current state has no shift on
					** "error", pop stack
					*/
#if YYDEBUG
#	define _POP_ "Error recovery pops state %d, uncovers state %d\n"
					if ( yydebug )
						printf( _POP_, *yy_ps,
							yy_ps[-1] );
#	undef _POP_
#endif
					yy_ps--;
					yy_pv--;
				}
				/*
				** there is no state on stack with "error" as
				** a valid shift.  give up.
				*/
				YYABORT;
			case 3:		/* no shift yet; eat a token */
#if YYDEBUG
				/*
				** if debugging, look up token in list of
				** pairs.  0 and negative shouldn't occur,
				** but since timing doesn't matter when
				** debugging, it doesn't hurt to leave the
				** tests here.
				*/
				if ( yydebug )
				{
					register int yy_i;

					printf( "Error recovery discards " );
					if ( yychar == 0 )
						printf( "token end-of-file\n" );
					else if ( yychar < 0 )
						printf( "token -none-\n" );
					else
					{
						for ( yy_i = 0;
							yytoks[yy_i].t_val >= 0;
							yy_i++ )
						{
							if ( yytoks[yy_i].t_val
								== yychar )
							{
								break;
							}
						}
						printf( "token %s\n",
							yytoks[yy_i].t_name );
					}
				}
#endif /* YYDEBUG */
				if ( yychar == 0 )	/* reached EOF. quit */
					YYABORT;
				yychar = -1;
				goto yy_newstate;
			}
		}/* end if ( yy_n == 0 ) */
		/*
		** reduction by production yy_n
		** put stack tops, etc. so things right after switch
		*/
#if YYDEBUG
		/*
		** if debugging, print the string that is the user's
		** specification of the reduction which is just about
		** to be done.
		*/
		if ( yydebug )
			printf( "Reduce by (%d) \"%s\"\n",
				yy_n, yyreds[ yy_n ] );
#endif
		yytmp = yy_n;			/* value to switch over */
		yypvt = yy_pv;			/* $vars top of value stack */
		/*
		** Look in goto table for next state
		** Sorry about using yy_state here as temporary
		** register variable, but why not, if it works...
		** If yyr2[ yy_n ] doesn't have the low order bit
		** set, then there is no action to be done for
		** this reduction.  So, no saving & unsaving of
		** registers done.  The only difference between the
		** code just after the if and the body of the if is
		** the goto yy_stack in the body.  This way the test
		** can be made before the choice of what to do is needed.
		*/
		{
			/* length of production doubled with extra bit */
			register int yy_len = yyr2[ yy_n ];

			if ( !( yy_len & 01 ) )
			{
				yy_len >>= 1;
				yyval = ( yy_pv -= yy_len )[1];	/* $$ = $1 */
				yy_state = yypgo[ yy_n = yyr1[ yy_n ] ] +
					*( yy_ps -= yy_len ) + 1;
				if ( yy_state >= YYLAST ||
					yychk[ yy_state =
					yyact[ yy_state ] ] != -yy_n )
				{
					yy_state = yyact[ yypgo[ yy_n ] ];
				}
				goto yy_stack;
			}
			yy_len >>= 1;
			yyval = ( yy_pv -= yy_len )[1];	/* $$ = $1 */
			yy_state = yypgo[ yy_n = yyr1[ yy_n ] ] +
				*( yy_ps -= yy_len ) + 1;
			if ( yy_state >= YYLAST ||
				yychk[ yy_state = yyact[ yy_state ] ] != -yy_n )
			{
				yy_state = yyact[ yypgo[ yy_n ] ];
			}
		}
					/* save until reenter driver code */
		yystate = yy_state;
		yyps = yy_ps;
		yypv = yy_pv;
	}
	/*
	** code supplied by user is placed in this switch
	*/
	switch( yytmp )
	{
		
case 3:
# line 38 "gram.y"
{
		viewup(up[X], up[Y], up[Z]);
		viewlookat(eye[X], eye[Y], eye[Z], ref[X], ref[Y], ref[Z]);
	  } break;
case 4:
# line 43 "gram.y"
{
		background(yypvt[-2].y_flt, yypvt[-1].y_flt, yypvt[-0].y_flt);
	  } break;
case 5:
# line 47 "gram.y"
{
		light(yypvt[-2].y_flt, yypvt[-1].y_flt, yypvt[-0].y_flt, 0.5, 0.5, 0.5);
	  } break;
case 6:
# line 51 "gram.y"
{
			/* following tradition, calculate reflectance... */

		material(yypvt[-7].y_flt, yypvt[-6].y_flt, yypvt[-5].y_flt, yypvt[-4].y_flt, yypvt[-3].y_flt, yypvt[-2].y_flt, yypvt[-0].y_flt, yypvt[-1].y_flt, ((1.0 - yypvt[-1].y_flt) < yypvt[-3].y_flt) ? 1.0 - yypvt[-1].y_flt : yypvt[-3].y_flt);
	  } break;
case 7:
# line 57 "gram.y"
{
		cone(yypvt[-7].y_flt, yypvt[-6].y_flt, yypvt[-5].y_flt, yypvt[-4].y_flt, yypvt[-3].y_flt, yypvt[-2].y_flt, yypvt[-1].y_flt, yypvt[-0].y_flt);
	  } break;
case 8:
# line 61 "gram.y"
{
		sphere(yypvt[-3].y_flt, yypvt[-2].y_flt, yypvt[-1].y_flt, yypvt[-0].y_flt);
	  } break;
case 9:
# line 65 "gram.y"
{
		int	i;
		float	*xs, *ys, *zs;
		vnode	*v, *vnxt;

		xs = (float *)smalloc((int)yypvt[-1].y_flt * sizeof(float));
		ys = (float *)smalloc((int)yypvt[-1].y_flt * sizeof(float));
		zs = (float *)smalloc((int)yypvt[-1].y_flt * sizeof(float));

		for (i = 0, v = yypvt[-0].y_vnd; i != (int)yypvt[-1].y_flt; i++, v = vnxt) {
			xs[i] = v->v[X];
			ys[i] = v->v[Y];
			zs[i] = v->v[Z];
			vnxt = v->nxt;
			free(v);
		}

		polygon((int)yypvt[-1].y_flt, xs, ys, zs);

		free(xs);
		free(ys);
		free(zs);
	  } break;
case 10:
# line 89 "gram.y"
{
		int	i;
		float	*xs, *ys, *zs;
		float	*nxs, *nys, *nzs;
		vnnode	*v, *vnxt;

		xs = (float *)smalloc((int)yypvt[-1].y_flt * sizeof(float));
		ys = (float *)smalloc((int)yypvt[-1].y_flt * sizeof(float));
		zs = (float *)smalloc((int)yypvt[-1].y_flt * sizeof(float));
		nxs = (float *)smalloc((int)yypvt[-1].y_flt * sizeof(float));
		nys = (float *)smalloc((int)yypvt[-1].y_flt * sizeof(float));
		nzs = (float *)smalloc((int)yypvt[-1].y_flt * sizeof(float));

		for (i = 0, v = yypvt[-0].y_vnn; i != (int)yypvt[-1].y_flt; i++, v = vnxt) {
			xs[i] = v->v[X];
			ys[i] = v->v[Y];
			zs[i] = v->v[Z];
			nxs[i] = v->n[X];
			nys[i] = v->n[Y];
			nzs[i] = v->n[Z];
			vnxt = v->nxt;
			free(v);
		}

		polygonpatch((int)yypvt[-1].y_flt, xs, ys, zs, nxs, nys, nzs);

		free(xs);
		free(ys);
		free(zs);
		free(nxs);
		free(nys);
		free(nzs);
	  } break;
case 13:
# line 129 "gram.y"
{
		eye[X] = yypvt[-2].y_flt;
		eye[Y] = yypvt[-1].y_flt;
		eye[Z] = yypvt[-0].y_flt;
	  } break;
case 14:
# line 135 "gram.y"
{
		ref[X] = yypvt[-2].y_flt;
		ref[Y] = yypvt[-1].y_flt;
		ref[Z] = yypvt[-0].y_flt;
	  } break;
case 15:
# line 141 "gram.y"
{
		up[X] = yypvt[-2].y_flt;
		up[Y] = yypvt[-1].y_flt;
		up[Z] = yypvt[-0].y_flt;
	  } break;
case 16:
# line 147 "gram.y"
{
		viewfov(yypvt[-0].y_flt);
	  } break;
case 17:
# line 151 "gram.y"
{
		/* IGNORED - at the momemt!
		printf("hi %f\n", $2);
		*/
	  } break;
case 18:
# line 157 "gram.y"
{
		imagesize((int)yypvt[-1].y_flt, (int)yypvt[-0].y_flt);
	  } break;
case 19:
# line 163 "gram.y"
{
		yyval.y_vnd = (vnode *)NULL;
	  } break;
case 20:
# line 167 "gram.y"
{
		yyval.y_vnd = (vnode *)smalloc(sizeof(vnode));

		yyval.y_vnd->v[X] = yypvt[-2].y_flt;
		yyval.y_vnd->v[Y] = yypvt[-1].y_flt;
		yyval.y_vnd->v[Z] = yypvt[-0].y_flt;

		yyval.y_vnd->nxt = yypvt[-3].y_vnd;
	  } break;
case 21:
# line 179 "gram.y"
{
		yyval.y_vnn = (vnnode *)NULL;
	  } break;
case 22:
# line 183 "gram.y"
{
		yyval.y_vnn = (vnnode *)smalloc(sizeof(vnnode));

		yyval.y_vnn->v[X] = yypvt[-5].y_flt;
		yyval.y_vnn->v[Y] = yypvt[-4].y_flt;
		yyval.y_vnn->v[Z] = yypvt[-3].y_flt;

		yyval.y_vnn->n[X] = yypvt[-2].y_flt;
		yyval.y_vnn->n[Y] = yypvt[-1].y_flt;
		yyval.y_vnn->n[Z] = yypvt[-0].y_flt;

		yyval.y_vnn->nxt = yypvt[-6].y_vnn;
	  } break;
case 23:
# line 199 "gram.y"
{
		yyval.y_flt = yypvt[-0].y_flt;
	  } break;
	}
	goto yystack;		/* reset registers in driver code */
}
