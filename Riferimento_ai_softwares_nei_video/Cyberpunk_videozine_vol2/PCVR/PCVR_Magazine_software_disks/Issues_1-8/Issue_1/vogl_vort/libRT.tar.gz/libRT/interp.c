#include <math.h>
#include <stdio.h>
#include "rt.h"
#include "macro.h"

extern hlist	*fhlist;

/*
 * interp3
 *
 *	calculates the interpolated normal for the triangle described
 * by the normals norms. In this case we have to use area (barycentric)
 * coordinates. u and v represent the point we are on and m is the
 * precalculated solution matrix to give us the area coordinates.
 */
void
interp(p, l, n)
	polypatch	*p;
	vector		l, n;
{
	register float	a1, a2, a3;
	float		u, v;

	switch (p->axis) {
	case X:
		u = l[Y];
		v = l[Z];
		break;
	case Y:
		u = l[X];
		v = l[Z];
		break;
	case Z:
		u = l[X];
		v = l[Y];
		break;
	default:
		fatal("rend: bad axis in interp.\n");
	}

	a1 = v * p->mat[0][0] - u * p->mat[0][1] + p->mat[0][2];

	a2 = v * p->mat[1][0] - u * p->mat[1][1] + p->mat[1][2];

	a3 = v * p->mat[2][0] - u * p->mat[2][1] + p->mat[2][2];

	n[X] = a1 * p->norms[1][X] + a2 * p->norms[2][X] + a3 * p->norms[0][X];
	n[Y] = a1 * p->norms[1][Y] + a2 * p->norms[2][Y] + a3 * p->norms[0][Y];
	n[Z] = a1 * p->norms[1][Z] + a2 * p->norms[2][Z] + a3 * p->norms[0][Z];
}
