#include <stdio.h>
#include <math.h>
#include "rt.h"
#include "macro.h"

extern mats	mstack[];
extern mentry	*mstackp;
extern surface	*cursurf;

extern mat4x4	trans;
extern vector	org;
extern int	linecount;

/*
 * utility routines for adjusting transformations and other
 * object attributes.
 */

/*
 * pushmatrix
 *
 *	push the matrix stack.
 */
pushmatrix()
{
	if (mstackp->nxt == (mentry *)NULL) {
		mstackp->nxt = (mentry *)smalloc(sizeof(mentry));
		mstackp->nxt->lst = mstackp;
	}

	mstackp = mstackp->nxt;
	mstackp->m = mstackp->lst->m;
}

/*
 * popmatrix
 *
 *	pop the matrix stack.
 */
popmatrix()
{
	if (mstackp->lst != (mentry *)NULL)
		mstackp = mstackp->lst;
	else
		fatal("popmatrix: too many pops!\n");
}

/*
 * translate
 *
 *	translate 
 */
translate(x, y, z)
	float	x, y, z;
{
	/*
	 * Do the operations directly on the top matrix of
	 * the stack to speed things up.
	 */
	mstackp->m.obj2ray[3][0] += x * mstackp->m.obj2ray[0][0] +
			y * mstackp->m.obj2ray[1][0] + z * mstackp->m.obj2ray[2][0];
 
	mstackp->m.obj2ray[3][1] += x * mstackp->m.obj2ray[0][1] +
			y * mstackp->m.obj2ray[1][1] + z * mstackp->m.obj2ray[2][1];
 
	mstackp->m.obj2ray[3][2] += x * mstackp->m.obj2ray[0][2] +
			y * mstackp->m.obj2ray[1][2] + z * mstackp->m.obj2ray[2][2];
 
	mstackp->m.obj2ray[3][3] += x * mstackp->m.obj2ray[0][3] +
			y * mstackp->m.obj2ray[1][3] + z * mstackp->m.obj2ray[2][3];

	mstackp->m.tdcur = RT_FALSE;
}

/*
 * scale
 *
 *	scale routine 
 */
scale(x, y, z)
	float	x, y, z;
{
	/*
	 * Do the operations directly on the top matrix of
	 * the stack to speed things up.
	 */
 
	mstackp->m.obj2ray[0][0] *= x;
	mstackp->m.obj2ray[0][1] *= x;
	mstackp->m.obj2ray[0][2] *= x;
	mstackp->m.obj2ray[0][3] *= x;
 
	mstackp->m.obj2ray[1][0] *= y;
	mstackp->m.obj2ray[1][1] *= y;
	mstackp->m.obj2ray[1][2] *= y;
	mstackp->m.obj2ray[1][3] *= y;
 
	mstackp->m.obj2ray[2][0] *= z;
	mstackp->m.obj2ray[2][1] *= z;
	mstackp->m.obj2ray[2][2] *= z;
	mstackp->m.obj2ray[2][3] *= z;

	mstackp->m.tdcur = RT_FALSE;
}

/*
 * rotate
 * 
 * Set up a rotate matrix and premultiply it with 
 * the top matrix on the stack.
 *
 */
void
rotate(r, x, y, z)
	float	r, x, y, z;
{
	float		l2, l3, sinu, sinv, cosu, cosv;
	float		sinr, cosr, w, l;
	mat4x4		m, tmp;

	cosr = cos((double)(M_PI / 180.0 * r));
	sinr = sin((double)(M_PI / 180.0 * r));

	/*
	 * normalise the axis of rotation.
	 */
	l = sqrt(x * x + y * y + z * z);

	x = x / l;
	y = y / l;
	z = z / l;

	/*
	 * what follows is the following rotation matrices concatenated.
	 *
	 *	R1 * R2 * R * R2t * R1t
	 *
	 *	where R1 * R2 rotate us so that z has become the rotation
	 * axis, R is the actual rotation and R2t (inverse of R2) and R1t
	 * rotate us back into the right coordinate system. This not only
	 * saves on the computations but gets rid of a potential divide
	 * by zero.
	 */
	makeident4x4(m);

	m[0][0] = x * x + (1.0 - x * x) * cosr;
	m[0][1] = x * y * (1.0 - cosr) - z * sinr;
	m[0][2] = x * z * (1.0 - cosr) + y * sinr;

	m[1][0] = x * y * (1.0 - cosr) + z * sinr;
	m[1][1] = y * y + (1.0 - y * y) * cosr;
	m[1][2] = y * z * (1.0 - cosr) - x * sinr;

	m[2][0] = x * z * (1.0 - cosr) - y * sinr;
	m[2][1] = y * z * (1.0 - cosr) + x * sinr;
	m[2][2] = z * z + (1.0 - z * z) * cosr;

	mult4x4(tmp, m, mstackp->m.obj2ray);
	copy4x4(mstackp->m.obj2ray, tmp);

	mstackp->m.tdcur = RT_FALSE;
}

/*
 * alignzaxis
 *
 *	rotate our world so the z axis "becomes" the direction
 * vector represented x, y and z.
 */
void
alignzaxis(x, y, z)
	float	x, y, z;
{
	float	l2, l3, sintheta, sinphi, costheta, cosphi;
	mat4x4	m, tmp;

	l2 = sqrt(x * x + z * z);
	l3 = sqrt(x * x + y * y + z * z);

	if (l2 != 0.0) {
		sintheta = x / l2;
		costheta = -z / l2;

		/*
		 * Rotate about Y by theta
		 */
		makeident4x4(m);
		m[0][0] = m[2][2] = costheta;
		m[0][2] = sintheta;
		m[2][0] = -sintheta;

		mult4x4(tmp, m, mstackp->m.obj2ray);
		copy4x4(mstackp->m.obj2ray, tmp);
	}

	if (y != 0.0) {
		sinphi = -y / l3;
		cosphi = l2 / l3;

		/*
		 * Rotate about X by phi
		 */
		makeident4x4(m);
		m[1][1] = m[2][2] = cosphi;
		m[1][2] = -sinphi;
		m[2][1] = sinphi;

		mult4x4(tmp, m, mstackp->m.obj2ray);
		copy4x4(mstackp->m.obj2ray, tmp);
	}

	/* 
	 * show that trans data is now out of date
	 */
	mstackp->m.tdcur = RT_FALSE;
}

/*
 * background
 *
 *	set the background colour.
 */
background(r, g, b)
	float	r, g, b;
{
	backcol[RED] = r;
	backcol[GREEN] = g;
	backcol[BLUE] = b;
}

/*
 * ambient
 *
 *	set the ambient colour.
 */
ambient(r, g, b)
	float	r, g, b;
{
	amblight[RED] = r;
	amblight[GREEN] = g;
	amblight[BLUE] = b;
}

/*
 * material
 *
 *	set the current material properties.
 */
material(r, g, b, kd, ks, ksexp, ri, T, R)
	float	r, g, b;
	float	kd, ks, ksexp;
	float	ri, T, R;
{
	cursurf = (surface *)smalloc(sizeof(surface));

	cursurf->c[RED] = r;
	cursurf->c[GREEN] = g;
	cursurf->c[BLUE] = b;

	cursurf->a[RED] = amblight[RED] * r;
	cursurf->a[GREEN] = amblight[GREEN] * g;
	cursurf->a[BLUE] = amblight[BLUE] * b;

	cursurf->kd = kd;
	cursurf->ks = ks;
	cursurf->ksexp = ksexp;
	cursurf->T = T;

	cursurf->R = R;

	cursurf->ri = ri;
}

/*
 * setattributes
 *
 *	set the attributes and transformations for an object.
 */
setattributes(o)
	object	*o;
{
	mat4x4		txtmat, tmp;
	transdata	*txttd;

	o->s = cursurf;

	if (!mstackp->m.tdcur) {
		invert4x4(mstackp->m.ray2obj, mstackp->m.obj2ray);
		mstackp->m.td = (transdata *)smalloc(sizeof(transdata));
		copy3x3(mstackp->m.td->mat, mstackp->m.ray2obj);
		mstackp->m.td->trans[X] = mstackp->m.ray2obj[3][0];
		mstackp->m.td->trans[Y] = mstackp->m.ray2obj[3][1];
		mstackp->m.td->trans[Z] = mstackp->m.ray2obj[3][2];
	}

	o->td = mstackp->m.td;
}

/*
 * makebbox
 *
 *	make a bounding box for the object o.
 *
 */
makebbox(o, x1, y1, z1, x2, y2, z2)
	object	*o;
	float	x1, y1, z1, x2, y2, z2;
{
	vector	c, v;

	v[X] = x1; v[Y] = y1; v[Z] = z1;

	vmmult(c, v, mstackp->m.obj2ray);

	o->bb.min[X] = o->bb.max[X] = c[X];
	o->bb.min[Y] = o->bb.max[Y] = c[Y];
	o->bb.min[Z] = o->bb.max[Z] = c[Z];

	v[X] = x2; v[Y] = y2; v[Z] = z2;

	vmmult(c, v, mstackp->m.obj2ray);

	minmax(o->bb.min[X], o->bb.max[X], c[X]);
	minmax(o->bb.min[Y], o->bb.max[Y], c[Y]);
	minmax(o->bb.min[Z], o->bb.max[Z], c[Z]);

	v[X] = x1; v[Y] = y2; v[Z] = z2;

	vmmult(c, v, mstackp->m.obj2ray);

	minmax(o->bb.min[X], o->bb.max[X], c[X]);
	minmax(o->bb.min[Y], o->bb.max[Y], c[Y]);
	minmax(o->bb.min[Z], o->bb.max[Z], c[Z]);

	v[X] = x2; v[Y] = y1; v[Z] = z2;

	vmmult(c, v, mstackp->m.obj2ray);

	minmax(o->bb.min[X], o->bb.max[X], c[X]);
	minmax(o->bb.min[Y], o->bb.max[Y], c[Y]);
	minmax(o->bb.min[Z], o->bb.max[Z], c[Z]);

	v[X] = x2; v[Y] = y2; v[Z] = z1;

	vmmult(c, v, mstackp->m.obj2ray);

	minmax(o->bb.min[X], o->bb.max[X], c[X]);
	minmax(o->bb.min[Y], o->bb.max[Y], c[Y]);
	minmax(o->bb.min[Z], o->bb.max[Z], c[Z]);

	v[X] = x1; v[Y] = y1; v[Z] = z2;

	vmmult(c, v, mstackp->m.obj2ray);

	minmax(o->bb.min[X], o->bb.max[X], c[X]);
	minmax(o->bb.min[Y], o->bb.max[Y], c[Y]);
	minmax(o->bb.min[Z], o->bb.max[Z], c[Z]);

	v[X] = x1; v[Y] = y2; v[Z] = z1;

	vmmult(c, v, mstackp->m.obj2ray);

	minmax(o->bb.min[X], o->bb.max[X], c[X]);
	minmax(o->bb.min[Y], o->bb.max[Y], c[Y]);
	minmax(o->bb.min[Z], o->bb.max[Z], c[Z]);

	v[X] = x2; v[Y] = y1; v[Z] = z1;

	vmmult(c, v, mstackp->m.obj2ray);

	minmax(o->bb.min[X], o->bb.max[X], c[X]);
	minmax(o->bb.min[Y], o->bb.max[Y], c[Y]);
	minmax(o->bb.min[Z], o->bb.max[Z], c[Z]);

	o->bb.min[X] -= TOLERANCE;
	o->bb.min[Y] -= TOLERANCE;
	o->bb.min[Z] -= TOLERANCE;

	o->bb.max[X] += TOLERANCE;
	o->bb.max[Y] += TOLERANCE;
	o->bb.max[Z] += TOLERANCE;
}

