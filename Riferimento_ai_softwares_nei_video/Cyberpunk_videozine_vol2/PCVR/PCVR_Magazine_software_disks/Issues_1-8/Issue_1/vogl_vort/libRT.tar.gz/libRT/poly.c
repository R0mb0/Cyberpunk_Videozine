#include <math.h>
#include <stdio.h>
#include "rt.h"
#include "macro.h"

extern mentry	*mstackp;
extern oentry	*ostackp;
extern float	tolerance;

extern hlist	*fhlist;

extern long	objtests[], inttests[], hits[], bboxtests[];

/*
 * trianglei
 *
 *	intersect a triangle, we calculate the barycentric coordinates using
 * the coefficients in the matrix we pre calculated in the initialisation
 * routine. This owes a bit to Didier Badouel from his article in Graphics 
 * Gems.
 */
int
trianglei(r, o, bboxtest)
	ray	*r;
	object	*o;
	int	bboxtest;
{
	poly		*p;
	mat3x3		*m;
	hlist		*hp, *hitlist;
	float		t, pu, pv, a1, a2;

	if (o == r->orgobj)
		return(RT_FALSE);

	inttests[o->type]++;

	p = o->obj.ply;

	t = dprod(p->n, r->dir);

	if (t == 0.0)
		return(RT_FALSE);

	t = -(dprod(p->n, r->org) + p->cnst) / t;

	if (t < tolerance)
		return(RT_FALSE);

	switch (p->axis) {
	case X:
		pu = r->org[Y] + t * r->dir[Y];
		if (pu < o->bb.min[Y] || pu > o->bb.max[Y])
			return(RT_FALSE);
		pv = r->org[Z] + t * r->dir[Z];
		if (pv < o->bb.min[Z] || pv > o->bb.max[Z])
			return(RT_FALSE);
		break;
	case Y:
		pu = r->org[X] + t * r->dir[X];
		if (pu < o->bb.min[X] || pu > o->bb.max[X])
			return(RT_FALSE);
		pv = r->org[Z] + t * r->dir[Z];
		if (pv < o->bb.min[Z] || pv > o->bb.max[Z])
			return(RT_FALSE);
		break;
	case Z:
		pu = r->org[X] + t * r->dir[X];
		if (pu < o->bb.min[X] || pu > o->bb.max[X])
			return(RT_FALSE);
		pv = r->org[Y] + t * r->dir[Y];
		if (pv < o->bb.min[Y] || pv > o->bb.max[Y])
			return(RT_FALSE);
		break;
	default:
		fatal("rend: bad axis in inttri.\n");
	}

	m = p->u.mat;

	a1 = pv * (*m)[0][0] - pu * (*m)[0][1] + (*m)[0][2];
	if (a1 < 0.0 || a1 > 1.0)
		return(RT_FALSE);

	a2 = pv * (*m)[1][0] - pu * (*m)[1][1] + (*m)[1][2];
	if (a2 < 0.0 || a1 + a2 > 1.0)
		return(RT_FALSE);

	r->hit.t = t;
	r->hit.obj = o;
	r->hit.vals[X] = r->org[X] + r->dir[X] * t;
	r->hit.vals[Y] = r->org[Y] + r->dir[Y] * t;
	r->hit.vals[Z] = r->org[Z] + r->dir[Z] * t;

	hits[o->type]++;

	return(RT_TRUE);
}

/*
 * tripatchi
 *
 *	intersect a triangle, we calculate the barycentric coordinates using
 * the coefficients in the matrix we pre calculated in the initialisation
 * routine. This owes a bit to Didier Badouel from his article in Graphics 
 * Gems.
 */
int
tripatchi(r, o)
	ray	*r;
	object	*o;
{
	polypatch	*p;
	mat3x3		*m;
	hlist		*hp, *hitlist;
	float		t, pu, pv, a1, a2;

	if (o == r->orgobj)
		return(RT_FALSE);

	inttests[o->type]++;

	p = o->obj.plp;

	t = dprod(p->n, r->dir);

	if (t == 0.0)
		return(RT_FALSE);

	t = -(dprod(p->n, r->org) + p->cnst) / t;

	if (t < tolerance)
		return(RT_FALSE);

	switch (p->axis) {
	case X:
		pu = r->org[Y] + t * r->dir[Y];
		if (pu < o->bb.min[Y] || pu > o->bb.max[Y])
			return(RT_FALSE);
		pv = r->org[Z] + t * r->dir[Z];
		if (pv < o->bb.min[Z] || pv > o->bb.max[Z])
			return(RT_FALSE);
		break;
	case Y:
		pu = r->org[X] + t * r->dir[X];
		if (pu < o->bb.min[X] || pu > o->bb.max[X])
			return(RT_FALSE);
		pv = r->org[Z] + t * r->dir[Z];
		if (pv < o->bb.min[Z] || pv > o->bb.max[Z])
			return(RT_FALSE);
		break;
	case Z:
		pu = r->org[X] + t * r->dir[X];
		if (pu < o->bb.min[X] || pu > o->bb.max[X])
			return(RT_FALSE);
		pv = r->org[Y] + t * r->dir[Y];
		if (pv < o->bb.min[Y] || pv > o->bb.max[Y])
			return(RT_FALSE);
		break;
	default:
		fatal("rend: bad axis in inttripatch.\n");
	}

	a1 = pv * p->mat[0][0] - pu * p->mat[0][1] + p->mat[0][2];
	if (a1 < 0.0 || a1 > 1.0)
		return(RT_FALSE);

	a2 = pv * p->mat[1][0] - pu * p->mat[1][1] + p->mat[1][2];
	if (a2 < 0.0 || a1 + a2 > 1.0)
		return(RT_FALSE);

	r->hit.t = t;
	r->hit.obj = o;
	r->hit.vals[X] = r->org[X] + r->dir[X] * t;
	r->hit.vals[Y] = r->org[Y] + r->dir[Y] * t;
	r->hit.vals[Z] = r->org[Z] + r->dir[Z] * t;

	hits[o->type]++;

	return(RT_TRUE);
}

/*
 * polyi
 *
 *	intersect a polygon
 */
int
polyi(r, o, last)
	ray	*r;
	object	*o;
	hlist	**last;
{
	poly		*p;
	int		crosses;
	float		t, m, pu, pv;
	uvvec		*cp, *np;
	hlist		*hp, *hitlist;

	if (o == r->orgobj)
		return(RT_FALSE);

	inttests[o->type]++;

	p = o->obj.ply;

	t = dprod(p->n, r->dir);

	if (t == 0.0)
		return(RT_FALSE);

	t = -(dprod(p->n, r->org) + p->cnst) / t;

	if (t < tolerance)
		return(RT_FALSE);

	switch (p->axis) {
	case X:
		pu = r->org[Y] + t * r->dir[Y];
		if (pu < o->bb.min[Y] || pu > o->bb.max[Y])
			return(RT_FALSE);
		pv = r->org[Z] + t * r->dir[Z];
		if (pv < o->bb.min[Z] || pv > o->bb.max[Z])
			return(RT_FALSE);
		break;
	case Y:
		pu = r->org[X] + t * r->dir[X];
		if (pu < o->bb.min[X] || pu > o->bb.max[X])
			return(RT_FALSE);
		pv = r->org[Z] + t * r->dir[Z];
		if (pv < o->bb.min[Z] || pv > o->bb.max[Z])
			return(RT_FALSE);
		break;
	case Z:
		pu = r->org[X] + t * r->dir[X];
		if (pu < o->bb.min[X] || pu > o->bb.max[X])
			return(RT_FALSE);
		pv = r->org[Y] + t * r->dir[Y];
		if (pv < o->bb.min[Y] || pv > o->bb.max[Y])
			return(RT_FALSE);
		break;
	default:
		fatal("rend: bad axis in polyi.\n");
	}

	crosses = 0;

	for (cp = p->u.verts, np = &p->u.verts[p->nsides - 1];
		np >= p->u.verts; cp = np--) {

		/*
		 * If we are both above, or both below the intersection
		 * point, go onto the next one.
		 */

		if (cp->v < pv) {
			if (np->v < pv)
				continue;
		} else {
			if (np->v >= pv)
				continue;
		}

		/*
		 * Find out if we have crossed in the negative.
		 */
		if (cp->u < pu) {
			if (np->u < pu) {	/* crossed on left */
				crosses++;
				continue;
			}
		} else if (np->u >= pu)		/* both to right */
			continue;

		/* 
		 * We calculate the u at the intersection of the
		 * half-ray and the edge and test it against pu. 
		 */

		m = (np->u - cp->u) / (np->v - cp->v);
		if (((np->u - pu) - m * (np->v - pv)) < 0.0)
			crosses++;
	}

	if (!(crosses & 1))
		return(RT_FALSE);

	r->hit.t = t;
	r->hit.obj = o;
	r->hit.vals[X] = r->org[X] + r->dir[X] * t;
	r->hit.vals[Y] = r->org[Y] + r->dir[Y] * t;
	r->hit.vals[Z] = r->org[Z] + r->dir[Z] * t;

	hits[o->type]++;

	return(RT_TRUE);
}

/*
 * polyn
 *
 *	returns the normal to a polygon.
 */
void
polyn(n, l, o, indx)
	vector	n, l;
	object	*o;
	int	indx;
{
	poly	*ply;
	vector	col;

	ply = o->obj.ply;

	n[X] = ply->on[X];
	n[Y] = ply->on[Y];
	n[Z] = ply->on[Z];
}

/*
 * tripatchn
 *
 *	returns the normal to a polygon.
 */
void
tripatchn(n, l, o, indx)
	vector	n, l;
	object	*o;
	int	indx;
{
	polypatch	*pp;
	vector	col;

	pp = o->obj.plp;

	interp(pp, l, n);
	normalise(n);
}

/*
 * polygon
 *
 *	initialise the function pointers and fields for a polygon
 */
void
polygon(count, xs, ys, zs)
	int	count;
	float	*xs, *ys, *zs;
{
	poly		*pg;
	int		axis, i, ccount, ncount, dcount;
	mat4x4		m, tmp;
	vector		v, v1, v2, *ovt, *vt, norms[4];
	vector		xv, yv, zv;
	float		maxx, maxy, maxz, minx, miny, minz;
	float		vx, vz, radius, area, tolerance;
	vector		colours[4];
	char		buf[100];
	object		*o;
	surface		*news;

	o = (object *)smalloc(sizeof(object));
	pg = o->obj.ply = (poly *)smalloc(sizeof(poly));

	ovt = (vector *)smalloc(sizeof(vector) * count);
	vt = (vector *)smalloc(sizeof(vector) * count);

	for (i = 0; i != count; i++) {
		ovt[i][X] = xs[i];
		ovt[i][Y] = ys[i];
		ovt[i][Z] = zs[i];
		vmmult(vt[i], ovt[i], mstackp->m.obj2ray);
	}

	pg->nsides = count;

	vsub(v1, vt[1], vt[0]);
	vsub(v2, vt[2], vt[1]);

	xprod(pg->n, v1, v2);

	pg->cnst = -dprod(pg->n, vt[0]);

	if (fabs(pg->n[X]) > fabs(pg->n[Y]))
		if (fabs(pg->n[X]) > fabs(pg->n[Z]))
			pg->axis = X;
		else
			pg->axis = Z;
	else
		if (fabs(pg->n[Y]) > fabs(pg->n[Z]))
			pg->axis = Y;
		else
			pg->axis = Z;

	vsub(v1, ovt[1], ovt[0]);
	vsub(v2, ovt[2], ovt[1]);

	xprod(pg->on, v1, v2);

	if (pg->on[X] == 0.0 && pg->on[Y] == 0.0 && pg->on[Z] == 0.0) {
		printf("invalid polygon in file.\n");

		free(o);
		free(ovt);
		free(vt);

		return;
	} else
		normalise(pg->on);

	if (count > 3) {
		pg->u.verts = (uvvec *)scalloc(sizeof(uvvec), (unsigned int)count);

		switch (pg->axis) {
		case X:
			for (i = 0; i != count; i++) {
				pg->u.verts[i].u = vt[i][Y];
				pg->u.verts[i].v = vt[i][Z];
			}
			break;
		case Y:
			for (i = 0; i != count; i++) {
				pg->u.verts[i].u = vt[i][X];
				pg->u.verts[i].v = vt[i][Z];
			}
			break;
		case Z:
			for (i = 0; i != count; i++) {
				pg->u.verts[i].u = vt[i][X];
				pg->u.verts[i].v = vt[i][Y];
			}
			break;
		default:
			fatal("rend: bad axis in polygon.\n");
		}

		o->type = POLYOBJ;
	} else {
		/*
		 * as pg->n isn't normalised the magnitude of the
		 * normal in the part of 3 Space we ignore represents
		 * the area of the projected triangle. Dividing through
		 * by the component takes care of sign trouble we could
		 * have in the intersection test so we don't worry about
		 * taking the magnitude...
		 */
		switch (pg->axis) {
		case X:
			area = pg->n[X];
			m[0][0] = (vt[0][Y] - vt[2][Y]) / area;
			m[1][0] = (vt[1][Y] - vt[0][Y]) / area;
			m[2][0] = (vt[2][Y] - vt[1][Y]) / area;

			m[0][1] = (vt[0][Z] - vt[2][Z]) / area;
			m[1][1] = (vt[1][Z] - vt[0][Z]) / area;
			m[2][1] = (vt[2][Z] - vt[1][Z]) / area;

			m[0][2] = vt[2][Y] * m[0][1] - vt[2][Z] * m[0][0];
			m[1][2] = vt[0][Y] * m[1][1] - vt[0][Z] * m[1][0];
			m[2][2] = vt[1][Y] * m[2][1] - vt[1][Z] * m[2][0];
			break;
		case Y:
			area = pg->n[Y];
			m[0][0] = (vt[2][X] - vt[0][X]) / area;
			m[1][0] = (vt[0][X] - vt[1][X]) / area;
			m[2][0] = (vt[1][X] - vt[2][X]) / area;

			m[0][1] = (vt[2][Z] - vt[0][Z]) / area;
			m[1][1] = (vt[0][Z] - vt[1][Z]) / area;
			m[2][1] = (vt[1][Z] - vt[2][Z]) / area;

			m[0][2] = vt[2][X] * m[0][1] - vt[2][Z] * m[0][0];
			m[1][2] = vt[0][X] * m[1][1] - vt[0][Z] * m[1][0];
			m[2][2] = vt[1][X] * m[2][1] - vt[1][Z] * m[2][0];
			break;
		case Z:
			area = pg->n[Z];
			m[0][0] = (vt[0][X] - vt[2][X]) / area;
			m[1][0] = (vt[1][X] - vt[0][X]) / area;
			m[2][0] = (vt[2][X] - vt[1][X]) / area;

			m[0][1] = (vt[0][Y] - vt[2][Y]) / area;
			m[1][1] = (vt[1][Y] - vt[0][Y]) / area;
			m[2][1] = (vt[2][Y] - vt[1][Y]) / area;

			m[0][2] = vt[2][X] * m[0][1] - vt[2][Y] * m[0][0];
			m[1][2] = vt[0][X] * m[1][1] - vt[0][Y] * m[1][0];
			m[2][2] = vt[1][X] * m[2][1] - vt[1][Y] * m[2][0];
			break;
		default:
			fatal("rend: bad axis in polygon.\n");
		}

		pg->u.mat = (mat3x3 *)smalloc(sizeof(mat3x3));

		copy3x3((*pg->u.mat), m);

					/* flag special case */
		o->type = TRIOBJ;
	}

	minx = maxx = vt[0][X];
	miny = maxy = vt[0][Y];
	minz = maxz = vt[0][Z];
	for (i = 1; i != count; i++) {
		minmax(minx, maxx, vt[i][X]);
		minmax(miny, maxy, vt[i][Y]);
		minmax(minz, maxz, vt[i][Z]);
	}


	tolerance = sqrt(sqr(maxx - minx) + sqr(maxy - miny) + sqr(maxz - minz)) * TOLERANCE / 2;

	if (maxx - minx < TOLERANCE) {
		o->bb.min[X] = minx - tolerance;
		o->bb.max[X] = maxx + tolerance;
	} else {
		o->bb.min[X] = minx;
		o->bb.max[X] = maxx;
	}

	if (maxy - miny < TOLERANCE) {
		o->bb.min[Y] = miny - tolerance;
		o->bb.max[Y] = maxy + tolerance;
	} else {
		o->bb.min[Y] = miny;
		o->bb.max[Y] = maxy;
	}

	if (maxz - minz < TOLERANCE) {
		o->bb.min[Z] = minz - tolerance;
		o->bb.max[Z] = maxz + tolerance;
	} else {
		o->bb.min[Z] = minz;
		o->bb.max[Z] = maxz;
	}

	setattributes(o);

	o->nxt = ostackp->objs;
	ostackp->objs = o;

	free(ovt);
	free(vt);
}

/*
 * polygonpatch
 *
 *	set up a polygon patch - at the moment these are assumed
 * to have at most 3 sides. If a patch is passed with more than 3
 * sides the polygon routine is called.
 */
polygonpatch(count, xs, ys, zs, nxs, nys, nzs)
	int	count;
	float	*xs, *ys, *zs;
	float	*nxs, *nys, *nzs;
{
	polypatch	*pg;
	int		axis, i, ccount, ncount;
	mat4x4		m, tmp;
	vector		v, v1, v2, *ovt, *vt, norms[4];
	vector		xv, yv, zv;
	float		maxx, maxy, maxz, minx, miny, minz;
	float		vx, vz, radius, area, tolerance;
	vector		colours[4];
	char		buf[100];
	object		*o;
	surface		*news;

	if (count != 3) {
		polygon(count, xs, ys, zs);
		return;
	}

	o = (object *)smalloc(sizeof(object));
	pg = o->obj.plp = (polypatch *)smalloc(sizeof(polypatch));

	ovt = (vector *)smalloc(sizeof(vector) * count);
	vt = (vector *)smalloc(sizeof(vector) * count);

	for (i = 0; i != count; i++) {
		ovt[i][X] = xs[i];
		ovt[i][Y] = ys[i];
		ovt[i][Z] = zs[i];
		vmmult(vt[i], ovt[i], mstackp->m.obj2ray);
		pg->norms[i][X] = nxs[i];
		pg->norms[i][Y] = nys[i];
		pg->norms[i][Z] = nzs[i];
	}

	pg->nsides = count;

	vsub(v1, vt[1], vt[0]);
	vsub(v2, vt[2], vt[1]);

	xprod(pg->n, v1, v2);

	pg->cnst = -dprod(pg->n, vt[0]);

	if (fabs(pg->n[X]) > fabs(pg->n[Y]))
		if (fabs(pg->n[X]) > fabs(pg->n[Z]))
			pg->axis = X;
		else
			pg->axis = Z;
	else
		if (fabs(pg->n[Y]) > fabs(pg->n[Z]))
			pg->axis = Y;
		else
			pg->axis = Z;

	vsub(v1, ovt[1], ovt[0]);
	vsub(v2, ovt[2], ovt[1]);

	xprod(pg->on, v1, v2);

	if (pg->on[X] == 0.0 && pg->on[Y] == 0.0 && pg->on[Z] == 0.0) {
		printf("invalid polygon in file.\n");

		free(o);
		free(ovt);
		free(vt);

		return;
	} else
		normalise(pg->on);

	for (i = 0; i != count; i++) {
		if (pg->norms[i][X] != 0.0 || pg->norms[i][Y] != 0.0 || pg->norms[i][Z] != 0.0) {
			normalise(pg->norms[i]);
		} else {
			pg->norms[i][X] = pg->on[X];
			pg->norms[i][Y] = pg->on[Y];
			pg->norms[i][Z] = pg->on[Z];
		}
	}

	/*
	 * as pg->n isn't normalised the magnitude of the
	 * normal in the part of 3 Space we ignore represents
	 * the area of the projected triangle. Dividing through
	 * by the component takes care of sign trouble we could
	 * have in the intersection test so we don't worry about
	 * taking the magnitude...
	 */
	switch (pg->axis) {
	case X:
		area = pg->n[X];
		m[0][0] = (vt[0][Y] - vt[2][Y]) / area;
		m[1][0] = (vt[1][Y] - vt[0][Y]) / area;
		m[2][0] = (vt[2][Y] - vt[1][Y]) / area;

		m[0][1] = (vt[0][Z] - vt[2][Z]) / area;
		m[1][1] = (vt[1][Z] - vt[0][Z]) / area;
		m[2][1] = (vt[2][Z] - vt[1][Z]) / area;

		m[0][2] = vt[2][Y] * m[0][1] - vt[2][Z] * m[0][0];
		m[1][2] = vt[0][Y] * m[1][1] - vt[0][Z] * m[1][0];
		m[2][2] = vt[1][Y] * m[2][1] - vt[1][Z] * m[2][0];
		break;
	case Y:
		area = pg->n[Y];
		m[0][0] = (vt[2][X] - vt[0][X]) / area;
		m[1][0] = (vt[0][X] - vt[1][X]) / area;
		m[2][0] = (vt[1][X] - vt[2][X]) / area;

		m[0][1] = (vt[2][Z] - vt[0][Z]) / area;
		m[1][1] = (vt[0][Z] - vt[1][Z]) / area;
		m[2][1] = (vt[1][Z] - vt[2][Z]) / area;

		m[0][2] = vt[2][X] * m[0][1] - vt[2][Z] * m[0][0];
		m[1][2] = vt[0][X] * m[1][1] - vt[0][Z] * m[1][0];
		m[2][2] = vt[1][X] * m[2][1] - vt[1][Z] * m[2][0];
		break;
	case Z:
		area = pg->n[Z];
		m[0][0] = (vt[0][X] - vt[2][X]) / area;
		m[1][0] = (vt[1][X] - vt[0][X]) / area;
		m[2][0] = (vt[2][X] - vt[1][X]) / area;

		m[0][1] = (vt[0][Y] - vt[2][Y]) / area;
		m[1][1] = (vt[1][Y] - vt[0][Y]) / area;
		m[2][1] = (vt[2][Y] - vt[1][Y]) / area;

		m[0][2] = vt[2][X] * m[0][1] - vt[2][Y] * m[0][0];
		m[1][2] = vt[0][X] * m[1][1] - vt[0][Y] * m[1][0];
		m[2][2] = vt[1][X] * m[2][1] - vt[1][Y] * m[2][0];
		break;
	default:
		fatal("rend: bad axis in polygonpatch.\n");
	}

	copy3x3(pg->mat, m);

	o->type = TRIPATCHOBJ;

	minx = maxx = vt[0][X];
	miny = maxy = vt[0][Y];
	minz = maxz = vt[0][Z];
	for (i = 1; i != count; i++) {
		minmax(minx, maxx, vt[i][X]);
		minmax(miny, maxy, vt[i][Y]);
		minmax(minz, maxz, vt[i][Z]);
	}

	if (maxx - minx < TOLERANCE) {
		o->bb.min[X] = minx - TOLERANCE;
		o->bb.max[X] = maxx + TOLERANCE;
	} else {
		o->bb.min[X] = minx;
		o->bb.max[X] = maxx;
	}

	if (maxy - miny < TOLERANCE) {
		o->bb.min[Y] = miny - TOLERANCE;
		o->bb.max[Y] = maxy + TOLERANCE;
	} else {
		o->bb.min[Y] = miny;
		o->bb.max[Y] = maxy;
	}

	if (maxz - minz < TOLERANCE) {
		o->bb.min[Z] = minz - TOLERANCE;
		o->bb.max[Z] = maxz + TOLERANCE;
	} else {
		o->bb.min[Z] = minz;
		o->bb.max[Z] = maxz;
	}

	setattributes(o);

	o->nxt = ostackp->objs;
	ostackp->objs = o;

	free(ovt);
	free(vt);
}

/*
 * polytabinit
 *
 *	set the table of function pointers for the polygon.
 */
polytabinit(intersects, normals, checkbbox, selfshadowing)
	int	(*intersects[])();
	void	(*normals[])();
	int	checkbbox[];
	int	selfshadowing[];
{
	normals[POLYOBJ] = polyn;
	intersects[POLYOBJ] = polyi;
	checkbbox[POLYOBJ] = RT_FALSE;
	selfshadowing[POLYOBJ] = RT_FALSE;

	normals[TRIOBJ] = polyn;
	intersects[TRIOBJ] = trianglei;
	checkbbox[TRIOBJ] = RT_FALSE;
	selfshadowing[TRIOBJ] = RT_FALSE;

	normals[TRIPATCHOBJ] = tripatchn;
	intersects[TRIPATCHOBJ] = tripatchi;
	checkbbox[TRIPATCHOBJ] = RT_FALSE;
	selfshadowing[TRIPATCHOBJ] = RT_FALSE;
}
