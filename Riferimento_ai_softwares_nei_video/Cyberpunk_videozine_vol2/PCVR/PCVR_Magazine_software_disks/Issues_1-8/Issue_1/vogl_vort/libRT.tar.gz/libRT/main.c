#include <stdio.h>
#include <math.h>
#include <vort.h>
#include <sys/times.h>

extern FILE	*yyin;

/*
 * the log file.
 */
FILE		*logfp;

/*
 * main driver for the NFF renderer.
 */
main(ac, av)
	int	ac;
	char	*av[];
{
	image		*im;
	int		i;
	char		imname[100], logname[100], buf[100];

	if (av[1] != (char *)NULL) {
		if (strcmp(av[1], "bvtree") == 0) {
			strcpy(imname, av[2]);
			strcpy(strrchr(imname, '.'), ".bv.pix");

			strcpy(logname, av[2]);
			strcpy(strrchr(logname, '.'), ".bv.log");
		} else if (strcmp(av[1], "grid") == 0) {
			strcpy(imname, av[2]);
			strcpy(strrchr(imname, '.'), ".gr.pix");

			strcpy(logname, av[2]);
			strcpy(strrchr(logname, '.'), ".gr.log");

		} else if (strcmp(av[1], "kdtree") == 0) {
			strcpy(imname, av[2]);
			strcpy(strrchr(imname, '.'), ".kd.pix");

			strcpy(logname, av[2]);
			strcpy(strrchr(logname, '.'), ".kd.log");
		} else if (strcmp(av[1], "octree") == 0) {
			strcpy(imname, av[2]);
			strcpy(strrchr(imname, '.'), ".oc.pix");

			strcpy(logname, av[2]);
			strcpy(strrchr(logname, '.'), ".oc.log");
		} else {
			fprintf(stderr, "unknown tree type.\n");
			exit(1);
		}
	} else {
		fprintf(stderr, "don't know the structure type.\n");
		exit(1);
	}

	if ((logfp = fopen(logname, "w")) == (FILE *)NULL) {
		fprintf(stderr, "can't open log file %s\n", logname);
		exit(1);
	}

	if ((yyin = fopen(av[2], "r")) == (FILE *)NULL) {
		fprintf(stderr, "can't open input file %s\n", av[2]);
		exit(1);
	}

	rendsettime();

	rendinit();

	if (strcmp(av[1], "bvtree") == 0) {
		openbvtree();
			yyparse();
		closebvtree();
	} else if (strcmp(av[1], "grid") == 0) {
		if (av[3] == (char *)NULL) {
			opengrid();
				yyparse();
			closegrid();
		} else if (ac != 6) {
			fprintf(stderr, "grid requires x, y, and z resolution.\n");
			exit(1);
		} else {
			gridsize(atoi(av[3]), atoi(av[4]), atoi(av[5]));
			opengrid();
				yyparse();
			closegrid();
		}
	} else if (strcmp(av[1], "kdtree") == 0) {
		openkdtree();
			yyparse();
		closekdtree();
	} else if (strcmp(av[1], "octree") == 0) {
		openoctree();
			yyparse();
		closeoctree();
	} else {
		fprintf(stderr, "unknown tree type.\n");
		exit(1);
	}

	rendprinttime("Preprocessing time taken: ");

	render(imname);
}

