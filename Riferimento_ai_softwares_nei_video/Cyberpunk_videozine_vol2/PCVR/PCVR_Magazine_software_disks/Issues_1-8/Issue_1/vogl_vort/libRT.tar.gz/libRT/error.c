#include <stdio.h>

/*
 * yyerror
 *
 *	print the error message from yacc
 */
yyerror(s)
	char	*s;
{
	fprintf(stderr, "%s\n", s);
	exit(1);
}

/*
 * fatal
 *
 *	print out a fatal error and exit.
 */
fatal(s)
	char	*s;
{
	fprintf(stderr, "%s\n", s);
	exit(1);
}
