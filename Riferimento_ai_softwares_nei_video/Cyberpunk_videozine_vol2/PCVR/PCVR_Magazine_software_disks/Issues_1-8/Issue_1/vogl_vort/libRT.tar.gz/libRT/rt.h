#define	RT_TRUE		1
#define	RT_FALSE	0

#define	X		0
#define	Y		1
#define	Z		2

#define DIMS		3

#define	RED		0
#define	GREEN		1
#define	BLUE		2

#define	TOLERANCE	0.0001

#define	HUGE_DIST	1.0e24

/*
 * colour
 */
typedef float	colour[3];

/*
 * pixel structure.
 */
typedef struct p {
	float	r, g, b, a;
} pixel;

/*
 * matrix defs.
 */
typedef float	mat4x4[4][4];
typedef float	mat3x3[4][4];

/*
 * vector
 */
typedef float	vector[3];

/*
 * the bounding box.
 */
typedef struct b {
	vector	min, max;
} bbox;

/*
 * lights
 */
typedef struct l {
	vector		org;
	colour		c;
	struct o	**lasthits;
	struct l	*nxt;
} lightobj;

/*
 * shader stack structure
 */
typedef struct st {
	float	ri;
	float	falloff;
} shadedata;

/*
 * surface details
 */
typedef struct sf {
	vector	a, c;
	float	ri, kd, ks, ksexp, T, R;
} surface;

/*
 * packed transformation data.
 */
typedef struct td {
	vector		trans;
	mat3x3		mat;
} transdata;

/*
 * matrix stack.
 */
typedef struct mt {
	mat4x4		ray2obj,	/* ray to object transformation */
			obj2ray;	/* object to ray transformation */
	mat4x4		om;		/* current object matrix */
	char		omused;		/* was om used at this level? */
	mat4x4		vm;		/* current viewing matrix */
	char		vmused;		/* was vm used at this level? */
	float		maxscale;	/* maximum scale applied to an object */
	vector		nscales;	/* scaling factors for normals */
	transdata	*td;		/* transformation data */
	int		tdlevel;	/* level of most recent trans data */
} mats;

typedef struct me {
	struct {
		mat4x4		ray2obj,/* ray to object transformation */
				obj2ray;/* object to ray transformation */
		vector		nscales;/* scaling factors for normals */
		transdata	*td;	/* transformation data */
		char		tdcur;	/* is td current? */
		int		tdlevel;/* level of most recent trans data */
	} m;
	struct me	*lst, *nxt;
} mentry;

/*
* hit structure
 */
typedef struct hl {
	float		t;
	int		type;
	struct o	*obj;
	vector		vals;
	struct hl	*nxt;
} hlist;

/*
 * ray structure
 */

#define	PRIMARY_RAY		0
#define	SHADOW_RAY		1
#define	REFLECTION_RAY		2
#define	TRANSPARENCY_RAY	3

typedef struct r {
	int		type;
	int		done;		/* no further intersection required */
	float		ri;
	float		maxt;
	long		raynumber;
	vector		org, dir;
	struct o	*orgobj;
	hlist		hit;
	hlist		thehit;
} ray;

#define	PZFACE	0
#define	NZFACE	1
#define	SIDE	2

/*
 * object types
 */
#define	SPHEREOBJ	0
#define	CYLINDEROBJ	1
#define	CONEOBJ		2
#define	POLYOBJ		3
#define	TRIOBJ		4
#define	TRIPATCHOBJ	5
#define	KDTREEOBJ	6
#define	BVTREEOBJ	7
#define	OCTREEOBJ	8
#define	GRIDOBJ		9

#define NUM_OBJS	10

/*
 * kdtree
 */
#define LEAF		4
#define BRANCH		5
#define SPLITABLELEAF	(0x08 | LEAF)

#define SPLITCUTOFF1	40 /* below this value we use a more conservative splitting strategy */
#define SPLITCUTOFF2	3

#define splittable(a)	((a)->type & 0x08)

typedef struct ol {
	struct o	*obj;
	struct ol	*nxt;
} olist;

typedef struct kdt {
	unsigned char	type;
	float		splitval;
	bbox		bb;
	union {
		struct {
			int		depth;
			struct ol	*oblist;
		} leaf;
		struct {
			struct kdt	*left, *right;
		} branch;
	} u;
} kdtree;

/*
 * uniform grid
 */
typedef struct vx {
	bbox	bb;
	olist	*oblist;
} voxel;

typedef struct gd {
	bbox	bb;
	int	xdiv, ydiv, zdiv;
	float	deltax, deltay, deltaz;
	voxel	****voxs;
} grid;

/*
 * octree
 */
typedef struct oc {
	int	type;
	union {
		struct {
			int	depth;
			olist	*oblist;
		} leaf;
		struct oc	*branch;
	} u;
} ocnode;

/*
 * bvtree
 */
typedef struct dt {
	char	type;
	float	splitval;
	bbox	bb;
	union {
		struct {
			struct o        *oblist;
			int             depth;
		} leaf;
		struct {
			struct dt       *left, *mid, *right;
		} branch;
	} u;
} bvtree;

/*
 * bvnode
 */
typedef struct bt {
	char	type, partype;
	bbox	bb;
	struct bt	*prv, *nxt;
	union {
		struct {
			struct o        *oblist;
			int             depth;
		} leaf;
		struct {
			float	splitval;
			struct bt       *left, *mid, *right;
		} branch;
	} u;
} bvnode;

/*
 * the sphere
 */
typedef struct s {
	float	radsqu;
	vector	orig;
} sphr;

/*
 * typedefs for polygons and polygon models
 */
#define	MAXVERTS	256		/* maximum number of vertices */

#define	BACKFACING	0x1		/* backfacing bit */
#define	PHONGSHADING	0x2		/* phong shading bit */

typedef struct uvv {
	float	u, v;
} uvvec;

typedef struct pgy {
	unsigned char	axis;		/* major axis of normal */
	unsigned short	nsides;		/* number of sides */
	float		cnst;		/* const for the polygon's plane */
	vector		n, on;		/* normal - ray/object space */
	union {
		mat3x3	*mat;		/* 3x3 matrix for triangles */
		uvvec	*verts;		/* vertices in u, v space */
	} u;
} poly;

typedef struct pgp {
	unsigned char	axis;		/* major axis of normal */
	unsigned short	nsides;		/* number of sides */
	float		cnst;		/* const for the polygon's plane */
	vector		n, on;		/* normal - ray/object space */
	mat3x3		mat;		/* 3x3 matrix for triangles */
	vector		norms[3];	/* vertex normals */
} polypatch;

/*
 * ray mailbox data
 */
typedef struct rd {
	float	t;
	int	type;
	long	raynumber;
} raydata;

/*
 * object structure
 */
typedef struct o {
	char		type;
	bbox		bb;
	surface		*s;
	transdata	*td;
	raydata		lastray;
	union {
		float		cne_tipval;
		sphr		*sph;
		kdtree		*kdt;
		bvtree		*bvt;
		bvnode		*grv;
		ocnode		*oct;
		grid		*grd;
		poly		*ply;
		polypatch	*plp;
	} obj;
	struct o	*nxt;
} object;

/*
 * object stack.
 */
typedef struct oe {
	object		*objs;
	struct oe	*lst, *nxt;
} oentry;

extern float	xscale, yscale, k1, k2;
extern int	xsize, ysize, xoff, yoff, x, y;

/*
 * pixel space...
 */
extern pixel	*topline, others[2];

/*
 * ray stats.
 */
extern long	raynumber;
extern long	shadrays;
extern long	transrays;
extern long	hitrays;

extern long	eyehitrays;
extern long	eyebackrays;

extern long	reflectionhitrays;
extern long	reflectionmissrays;

extern long	refractionhitrays;
extern long	refractionmissrays;

extern long	shadowtests, shadowhits;

extern long	treenodes;

extern long	objtests[];
extern long	inttests[];
extern long	hits[];
extern long	bboxtests[];

extern float	tolerance;

extern colour	backcol, amblight;
