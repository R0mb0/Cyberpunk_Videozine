#include <stdio.h>
#include <math.h>
#include "rt.h"
#include "macro.h"

extern oentry	*ostackp;
extern lightobj	*lights;
extern int	maxhitlevel;

extern int	maxtreedepth;

extern int	shadow_rays;

extern int	(*intersects[])();
extern int	checkbbox[];

extern colour	ambient;

extern double	power();

#define	U	0
#define	V	1

extern object	*oblist;
extern int	maxhitlevel;

extern colour	ambient;

extern double	power();

extern float	tolerance;

/*
 * shrinkbbox
 *
 *	reduce the size of the bounding box for the leaf (if possible).
 */
shrinkbbox(leaf)
	kdtree	*leaf;
{
	register object	*o;
	register olist	*ol;
	register float	minx, miny, minz;
	register float	maxx, maxy, maxz;

	o = leaf->u.leaf.oblist->obj;

	minx = o->bb.min[X];
	miny = o->bb.min[Y];
	minz = o->bb.min[Z];

	maxx = o->bb.max[X];
	maxy = o->bb.max[Y];
	maxz = o->bb.max[Z];

	for (ol = leaf->u.leaf.oblist->nxt; ol != (olist *)NULL; ol = ol->nxt) {
		o = ol->obj;

		if (o->bb.min[X] < minx)
			minx = o->bb.min[X];
		if (o->bb.max[X] > maxx)
			maxx = o->bb.max[X];

		if (o->bb.min[Y] < miny)
			miny = o->bb.min[Y];
		if (o->bb.max[Y] > maxy)
			maxy = o->bb.max[Y];

		if (o->bb.min[Z] < minz)
			minz = o->bb.min[Z];
		if (o->bb.max[Z] > maxz)
			maxz = o->bb.max[Z];
	}

	if (minx > leaf->bb.min[X])
		leaf->bb.min[X] = minx;
	if (miny > leaf->bb.min[Y])
		leaf->bb.min[Y] = miny;
	if (minz > leaf->bb.min[Z])
		leaf->bb.min[Z] = minz;

	if (maxx < leaf->bb.max[X])
		leaf->bb.max[X] = maxx;
	if (maxy < leaf->bb.max[Y])
		leaf->bb.max[Y] = maxy;
	if (maxz < leaf->bb.max[Z])
		leaf->bb.max[Z] = maxz;
}

/*
 * splitleaf
 *
 *	split a leaf along the middle of an axis.
 */
splitleaf(axis, leaf, val)
	int	axis;
	kdtree	*leaf;
	float	val;
{
	register int	ax;
	register object	*o;
	register kdtree	*left, *right;
	register olist	*objs, *bothlist, *nxtobj, *tmpobj;

	if (leaf->type != SPLITABLELEAF)
		return;

	left = (kdtree *)smalloc(sizeof(kdtree));
	right = (kdtree *)smalloc(sizeof(kdtree));

	bothlist = left->u.leaf.oblist = right->u.leaf.oblist = (olist *)NULL;

	ax = axis;
	 
	for (objs = leaf->u.leaf.oblist; objs != (olist *)NULL; objs = nxtobj) {
		nxtobj = objs->nxt;
		o = objs->obj;

		if (o->bb.max[ax] < val) {		/* to the left */
			objs->nxt = left->u.leaf.oblist;
			left->u.leaf.oblist = objs;
		} else if (o->bb.min[ax] > val) {	/* to the right */
			objs->nxt = right->u.leaf.oblist;
			right->u.leaf.oblist = objs;
		} else {				/* in both (sigh) */
			objs->nxt = bothlist;
			bothlist = objs;
		}
	}

	if (bothlist != (olist *)NULL) {
		if (right->u.leaf.oblist == (olist *)NULL) {
			o = left->u.leaf.oblist->obj;

			val = o->bb.max[ax];

			objs = left->u.leaf.oblist->nxt;

			while (objs != (olist *)NULL) {
				o = objs->obj;

				if (o->bb.max[ax] > val)
					val = o->bb.max[ax];

				objs = objs->nxt;
			}

			for (objs = bothlist; objs != (olist *)NULL; objs = nxtobj) {
				nxtobj = objs->nxt;

				o = objs->obj;

				if (o->bb.min[ax] < val) {
					tmpobj = (olist *)smalloc(sizeof(olist));

					tmpobj->obj = objs->obj;

					tmpobj->nxt = left->u.leaf.oblist;
					left->u.leaf.oblist = tmpobj;
				}

				objs->nxt = right->u.leaf.oblist;
				right->u.leaf.oblist = objs;

			}
		} else if (left->u.leaf.oblist == (olist *)NULL) {
			o = right->u.leaf.oblist->obj;

			val = o->bb.min[axis];

			objs = right->u.leaf.oblist->nxt;

			while (objs != (olist *)NULL) {
				o = objs->obj;

				if (o->bb.min[ax] < val)
					val = o->bb.min[ax];

				objs = objs->nxt;
			}

			for (objs = bothlist; objs != (olist *)NULL; objs = nxtobj) {
				nxtobj = objs->nxt;

				o = objs->obj;

				if (o->bb.max[ax] > val) {
					tmpobj = (olist *)smalloc(sizeof(olist));

					tmpobj->obj = objs->obj;

					tmpobj->nxt = right->u.leaf.oblist;
					right->u.leaf.oblist = tmpobj;
				}

				objs->nxt = left->u.leaf.oblist;
				left->u.leaf.oblist = objs;
			}
		} else
			for (objs = bothlist; objs != (olist *)NULL; objs = nxtobj) {
				nxtobj = objs->nxt;

				tmpobj = (olist *)smalloc(sizeof(olist));

				tmpobj->obj = objs->obj;

				tmpobj->nxt = left->u.leaf.oblist;
				left->u.leaf.oblist = tmpobj;

				objs->nxt = right->u.leaf.oblist;
				right->u.leaf.oblist = objs;
			}
	}

	left->bb = right->bb = leaf->bb;
	left->bb.max[ax] = val;
	right->bb.min[ax] = val;
				  
	shrinkbbox(left);
	shrinkbbox(right);

	left->u.leaf.depth = right->u.leaf.depth = leaf->u.leaf.depth + 1;

	left->type = right->type = SPLITABLELEAF;

	leaf->type = axis;
	leaf->splitval = val;
	leaf->u.branch.left = left;
	leaf->u.branch.right = right;

	treenodes += 2;
}

/*
 * split
 *
 *	split a splittable leaf into two nodes.
 */
void
split(root)
	kdtree	*root;
{
	int		left[DIMS], right[DIMS], extras[DIMS], tot[DIMS];
	float		vals[DIMS], delta[DIMS];
	register olist	*ol;
	register object	*o;
	register int	total;

	if (root->u.leaf.oblist == (olist *)NULL || root->u.leaf.oblist->nxt == (olist *)NULL || root->u.leaf.depth == maxtreedepth) {
		root->type = LEAF;
		return;
	}

	vals[X] = (root->bb.max[X] + root->bb.min[X]) / 2;
	vals[Y] = (root->bb.max[Y] + root->bb.min[Y]) / 2;
	vals[Z] = (root->bb.max[Z] + root->bb.min[Z]) / 2;

	left[X] = right[X] = extras[X] = 0;
	left[Y] = right[Y] = extras[Y] = 0;
	left[Z] = right[Z] = extras[Z] = 0;

	for (ol = root->u.leaf.oblist; ol != (olist *)NULL; ol = ol->nxt) {
		o = ol->obj;

		if (o->bb.max[X] < vals[X])		/* to the left */
			left[X]++;
		else if (o->bb.min[X] > vals[X])	/* to the right */
			right[X]++;
		else
			extras[X]++;

		if (o->bb.max[Y] < vals[Y])		/* to the left */
			left[Y]++;
		else if (o->bb.min[Y] > vals[Y])	/* to the right */
			right[Y]++;
		else
			extras[Y]++;

		if (o->bb.max[Z] < vals[Z])		/* to the left */
			left[Z]++;
		else if (o->bb.min[Z] > vals[Z])	/* to the right */
			right[Z]++;
		else
			extras[Z]++;
	}

	/*
	 * we don't want data set to expand when we get to SPLITCUTOFF2
	 * and below...
	 */
	if ((total = left[X] + right[X] + extras[X]) > SPLITCUTOFF2) {
		if (total < SPLITCUTOFF1)
			total += total / 3;
		else
			total = (total - 1) * 2;
	}
	
	tot[X] = left[X] + right[X] + 2 * extras[X];
	tot[Y] = left[Y] + right[Y] + 2 * extras[Y];
	tot[Z] = left[Z] + right[Z] + 2 * extras[Z];

	if (tot[X] < tot[Y]) {
		if (tot[X] < tot[Z]) {
			if (tot[X] <= total)
				splitleaf(X, root, vals[X]);
			else
				root->type = LEAF;
		} else if (tot[X] == tot[Z]) {
			if (extras[X] < extras[Z]) {
				if (tot[X] <= total)
					splitleaf(X, root, vals[X]);
				else
					root->type = LEAF;
			} else {
				if (tot[Z] <= total)
					splitleaf(Z, root, vals[Z]);
				else
					root->type = LEAF;
			}
		} else {
			if (tot[Z] <= total)
				splitleaf(Z, root, vals[Z]);
			else
				root->type = LEAF;
		}
	} else {
		if (tot[Y] < tot[Z]) {
			if (tot[Y] == tot[X]) {
				if (extras[X] < extras[Y]) {
					if (tot[X] <= total)
						splitleaf(X, root, vals[X]);
					else
						root->type = LEAF;
				} else {
					if (tot[Y] <= total)
						splitleaf(Y, root, vals[Y]);
					else
						root->type = LEAF;
				}
			} else
				if (tot[Y] <= total)
					splitleaf(Y, root, vals[Y]);
				else
					root->type = LEAF;
		} else if (tot[Y] == tot[Z]) {
			if (extras[Y] < extras[Z]) {
				if (tot[Y] <= total)
					splitleaf(Y, root, vals[Y]);
				else
					root->type = LEAF;
			} else {
				if (tot[Z] <= total)
					splitleaf(Z, root, vals[Z]);
				else
					root->type = LEAF;
			}
		} else {
			if (tot[Z] <= total)
				splitleaf(Z, root, vals[Z]);
			else
				root->type = LEAF;
		}
	}
}

/*
 * checkleaf
 *
 *	check the objects in a leaf - returning a legal hit if there is
 * one
 */
int
checkleaf(r, leaf)
	ray	*r;
	kdtree	*leaf;
{
	olist	*ol;
	object	*o;
	float	val;
	int	bboxcheck;

	if (leaf->u.leaf.oblist == (olist *)NULL)
		return(RT_FALSE);

	bboxcheck = (leaf->u.leaf.oblist->nxt != (olist *)NULL);

	for (ol = leaf->u.leaf.oblist; ol != (olist *)NULL; ol = ol->nxt) {
		o = ol->obj;

		if (o->lastray.raynumber == r->raynumber) {
			if (o->lastray.t != 0.0) {
				r->hit.t = o->lastray.t;
				r->hit.type = o->lastray.type;
				r->hit.obj = o;
			} else
				continue;		/* go to next object */

		} else {

			o->lastray.raynumber = r->raynumber;
			o->lastray.t = 0.0;

			if (!intersects[o->type](r, o, bboxcheck))
				continue;		/* go to next object */

			o->lastray.t = r->hit.t;
			o->lastray.type = r->hit.type;
		}

		if (r->thehit.obj == (object *)NULL)
			r->thehit = r->hit;
		else if (r->thehit.t > r->hit.t)
			r->thehit = r->hit;

		if (r->type == SHADOW_RAY && r->hit.t <= r->maxt
		   && o->s->T == 0.0) {
			r->done = RT_TRUE;
			return(RT_TRUE);
		}
	}

	if (r->thehit.obj != (object *)NULL) {

		if (r->dir[X] < 0.0) {
			if (r->thehit.vals[X] < leaf->bb.min[X])
				return(RT_FALSE);
		} else {
			if (r->thehit.vals[X] > leaf->bb.max[X])
				return(RT_FALSE);
		}

		if (r->dir[Y] < 0.0) {
			if (r->thehit.vals[Y] < leaf->bb.min[Y])
				return(RT_FALSE);
		} else {
			if (r->thehit.vals[Y] > leaf->bb.max[Y])
				return(RT_FALSE);
		}

		if (r->dir[Z] < 0.0) {
			if (r->thehit.vals[Z] < leaf->bb.min[Z])
				return(RT_FALSE);
		} else {
			if (r->thehit.vals[Z] > leaf->bb.max[Z])
				return(RT_FALSE);
		}
	}

	return(r->thehit.obj != (object *)NULL);
}

/*
 * treetrace
 *
 *	returns the first hit on the kd tree pointed to by root.
 */
int
treetrace(r, root)
	ray	*r;
	kdtree	*root;
{
	int	hit;
	kdtree	*nxtbranch;
	int	p, u, v;
	float	t1, t2, othert1, othert2, org, dir;

	hit = RT_FALSE;

	if (root->type == LEAF)
		return(checkleaf(r, root));
	else if (root->type == SPLITABLELEAF) {
		split(root);
		hit = treetrace(r, root);
	} else {
		p = root->type;
		org = r->org[p];
		dir = r->dir[p];

		if (org < root->splitval) {

			if (!cmissedbbox(r, &root->u.branch.left->bb))
				hit = treetrace(r, root->u.branch.left);
			else
				hit = RT_FALSE;

			if (hit) {
				return(hit);
			} else if (dir <= 0.0)
				return(RT_FALSE);

			nxtbranch = root->u.branch.right;
			t1 = (nxtbranch->bb.min[p] - org) / dir;
			t2 = (nxtbranch->bb.max[p] - org) / dir;
			if (t1 < 0.0)
				t1 = 0.0;

		} else {

			if (!cmissedbbox(r, &root->u.branch.right->bb))
				hit = treetrace(r, root->u.branch.right);
			else
				hit = RT_FALSE;

			if (hit) {
				return(hit);
			} else if (dir >= 0.0)
				return(RT_FALSE);

			nxtbranch = root->u.branch.left;
			t1 = (nxtbranch->bb.max[p] - org) / dir;
			t2 = (nxtbranch->bb.min[p] - org) / dir;
			if (t1 < 0.0)
				t1 = 0.0;
		} 

		if (p == X) {
			u = Y;
			v = Z;
		} else if (p == Y) {
			u = Z;
			v = X;
		} else {
			u = X;
			v = Y;
		}

		org = r->org[u];
		dir = r->dir[u];

                if (dir != 0.0) {
                        othert1 = (nxtbranch->bb.min[u] - org) / dir;
                        othert2 = (nxtbranch->bb.max[u] - org) / dir;
                        if (othert1 > othert2) {
                                if (othert1 < t1 || othert2 > t2)
                                        return(RT_FALSE);
				if (othert2 > t1)
					t1 = othert2;
				if (othert1 < t2)
					t2 = othert1;
                        } else {
                                if (othert2 < t1 || othert1 > t2)
                                        return(RT_FALSE);
				if (othert1 > t1)
					t1 = othert1;
				if (othert2 < t2)
					t2 = othert2;
                        }
                } else {
                        if (nxtbranch->bb.min[u] > org)
                                return(RT_FALSE);
                        if (nxtbranch->bb.max[u] < org)
                                return(RT_FALSE);
                }

		org = r->org[v];
		dir = r->dir[v];

                if (dir != 0.0) {
                        othert1 = (nxtbranch->bb.min[v] - org) / dir;
                        othert2 = (nxtbranch->bb.max[v] - org) / dir;
                        if (othert1 > othert2) {
                                if (othert1 < t1 || othert2 > t2)
                                        return(RT_FALSE);
                        } else {
                                if (othert2 < t1 || othert1 > t2)
                                        return(RT_FALSE);
                        }
                } else {
                        if (nxtbranch->bb.min[v] > org)
                                return(RT_FALSE);
                        if (nxtbranch->bb.max[v] < org)
                                return(RT_FALSE);
                }

		hit = treetrace(r, nxtbranch);
	}

	return(hit);
}

/*
 * kdtreei
 *
 *	return the intersections between the ray r and the kd tree in o.
 */
int
kdtreei(r, o, last)
	ray	*r;
	object	*o;
	hlist	**last;
{
	int	hit;

	hit = treetrace(r, o->obj.kdt);

	if (hit) {
		r->hit = r->thehit;
		return(RT_TRUE);
	}

	return(RT_FALSE);
}

/*
 * openkdtree
 *
 *	start the collecting object for a kdtree, all we need to
 * do here is push the object stack and start afresh.
 */
void
openkdtree()
{
	/*
	 * check we have more room on stack...
	 */
	if (ostackp->nxt == (oentry *)NULL) {
		ostackp->nxt = (oentry *)smalloc(sizeof(oentry));
		ostackp->nxt->lst = ostackp;
	}

	/*
	 * push stack - clearing the object pointer.
	 */
	ostackp = ostackp->nxt;
	ostackp->objs = (object *)NULL;
}

/*
 * closekdtree
 *
 *	grab whatever is sitting on the object stack, pop the stack, and
 * add a kdtree object containing what we collected since the last openkdtree.
 */
void
closekdtree()
{
	object		*obj, *o;
	olist		*ol;
	kdtree		*tree;

	/*
	 * set up the kdtree object
	 */
	obj = (object *)smalloc(sizeof(object));

	obj->type = KDTREEOBJ;
	obj->obj.kdt = tree = (kdtree *)smalloc(sizeof(kdtree));

	treenodes = 1;

	tree->type = SPLITABLELEAF;

	tree->u.leaf.oblist = (olist *)NULL;
	tree->u.leaf.depth = 0;

	tree->bb.min[X] = ostackp->objs->bb.min[X];
	tree->bb.max[X] = ostackp->objs->bb.max[X];

	tree->bb.min[Y] = ostackp->objs->bb.min[Y];
	tree->bb.max[Y] = ostackp->objs->bb.max[Y];

	tree->bb.min[Z] = ostackp->objs->bb.min[Z];
	tree->bb.max[Z] = ostackp->objs->bb.max[Z];

	for (o = ostackp->objs; o != (object *)NULL; o = o->nxt) {
		ol = (olist *)smalloc(sizeof(olist));
		ol->nxt = tree->u.leaf.oblist;
		ol->obj = o;
		adjustbbox(&tree->bb, o);
		tree->u.leaf.oblist = ol;
	}

	obj->bb = tree->bb;

	/*
	 * pop stack and add kdtree.
	 */
	ostackp = ostackp->lst;

	obj->nxt = ostackp->objs;
	ostackp->objs = obj;
}

/*
 * kdtreetabinit
 *
 *	set the table of function pointers for the tree.
 */
kdtreetabinit(intersects, normals, checkbbox, selfshadowing)
	int	(*intersects[])();
	void	(*normals[])();
	int	checkbbox[];
	int	selfshadowing[];
{
	normals[KDTREEOBJ] = (void (*)())NULL;
	intersects[KDTREEOBJ] = kdtreei;
	checkbbox[KDTREEOBJ] = RT_TRUE;
	selfshadowing[KDTREEOBJ] = RT_TRUE;
}
