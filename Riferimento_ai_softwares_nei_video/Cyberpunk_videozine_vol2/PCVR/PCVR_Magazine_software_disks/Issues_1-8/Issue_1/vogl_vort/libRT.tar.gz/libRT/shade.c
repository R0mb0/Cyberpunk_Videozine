/*
 * the shading routines and their utilities
 */
#include <stdio.h>
#include <math.h>
#include "rt.h"
#include "macro.h"

extern object	*objlist;
extern lightobj	*lights;
extern hlist	*fhlist;
extern int	maxhitlevel;

extern colour	backcol;
extern colour	ambient;

extern double	power();

extern hlist	*trace();

extern float	randtable[], *randp, *erandp;

extern float    fogfactor, rfactor;
extern colour	hazecolour;

extern float    falloff, ri;

extern long	raynumber, reflectionhitrays, reflectionmissrays;
extern long	refractionhitrays, refractionmissrays;
extern long	shadowtests, shadowhits;

extern hlist	*(*intersects[])();

extern int	selfshadowing[];

extern void	(*normal[])();

extern shadedata        *sstackp, *sstack;

/*
 * checklight
 *
 *	is the light l visible to us from loc? RT_TRUE if
 * it is, RT_FALSE if it isn't. lr is returned as the ray
 * hitting l from loc, and col is the intensity value of
 * the light.
 */
int
checklight(obj, l, loc, lr, col, n, prod, hitlevel)
	object	 	*obj;
	lightobj	*l;
	vector		loc;
	ray		*lr;
	pixel	*col;
	vector	n;
	float	*prod;
	int	hitlevel;
{
	object	*o;
	vector	nalt;
	ray	tmp;
	surface	sp;
	hlist	*hit, *p, *lp, *end;
	float	dist, fact, t, peturb, lastt, cosang;
	colour	base;

	vsub(lr->dir, l->org, loc);

	dist = sqrt(dprod(lr->dir, lr->dir));

	lr->dir[X] = lr->dir[X] / dist;
	lr->dir[Y] = lr->dir[Y] / dist;
	lr->dir[Z] = lr->dir[Z] / dist;

	if ((*prod = dprod(n, lr->dir)) < 0.0)
		return(RT_FALSE);

	lr->org[X] = loc[X];
	lr->org[Y] = loc[Y];
	lr->org[Z] = loc[Z];

	lr->maxt = dist;
	lr->raynumber = raynumber++;

	o = l->lasthits[hitlevel];

	if (o != (object *)NULL) {
		o->lastray.raynumber = lr->raynumber;
		o->lastray.t = 0.0;

		shadowtests++;

		if (!intersects[o->type](lr, o, RT_TRUE)) {
			hit = trace(lr, objlist);
		} else if (lr->hit.t >= dist) {
			hit = trace(lr, objlist);
		} else {
			shadowhits++;
			fetch(hit);
			*hit = lr->hit;
			hit->nxt = (hlist *)NULL;
		}
	} else
		hit = trace(lr, objlist);

	base[RED] = l->c[RED];
	base[GREEN] = l->c[GREEN];
	base[BLUE] = l->c[BLUE];

	if (hit != (hlist *)NULL) {

		t = hit->t;

		if (t >= dist)
			l->lasthits[hitlevel] = (object *)NULL;
		else
			l->lasthits[hitlevel] = hit->obj;

		for (lp = hit; lp != (hlist *)NULL; lp = p) {
			p = lp->nxt;
			release(lp);
		}
	} else {
		l->lasthits[hitlevel] = (object *)NULL;
		t = dist;
	}

	col->r = base[RED];
	col->g = base[GREEN];
	col->b = base[BLUE];

				/* maybe the light is closer */
	return(t >= dist);
}

/*
 * shade
 *
 *	returns the shading info for an object with reflection and/or
 * transparency.
 */
void
shade(pix, i, hit, hitlevel)
	pixel		*pix;
	register ray	*i;
	hlist		*hit;
	int		hitlevel;
{
	hlist		*nxthit, *p, *lp;
	lightobj	*l;
	pixel		objcol, othercol;
	ray		lr, ir;
	vector		n, ns, mid, cv, sv, objn, nalt;
	vector		*vcolp, vcol, rvcol;
	surface		sp;
	transdata	*td;
	register object	*o;
	register int	count, leaving;
	float		prod;
	register float	fact, ksfact, kdfact, ndoti, lensvsqu;

	ir.dir[X] = i->dir[X];
	ir.dir[Y] = i->dir[Y];
	ir.dir[Z] = i->dir[Z];

	smult(ir.dir, hit->t);
	vadd(ir.org, i->org, ir.dir);

	o = hit->obj;
	sp = *o->s;

	/*
	 * calculate the normal and object colour if necessary
	 */
	normal[o->type](objn, ir.org, o, hit->type);

	td = o->td;

	v3x3tmult(n, objn, td->mat);

	normalise(n);

	if ((ndoti = dprod(n, i->dir)) > 0.0) { /* normal facing away from us */
		smult(n, -1.0);
		ndoti = -ndoti;
		leaving = RT_TRUE;
	} else
		leaving = RT_FALSE;

	kdfact = sp.kd;
	ksfact = sp.ks;

	objcol.r = sp.c[RED];
	objcol.g = sp.c[GREEN];
	objcol.b = sp.c[BLUE];

	pix->r = objcol.r * sp.a[RED];
	pix->g = objcol.g * sp.a[GREEN];
	pix->b = objcol.b * sp.a[BLUE];

	for (l = lights; l != (lightobj *)NULL; l = l->nxt) {
		lr.type = SHADOW_RAY;
		if (!selfshadowing[o->type])
			lr.orgobj = o;
		else
			lr.orgobj = (object *)NULL;
		if (checklight(o, l, ir.org, &lr, &othercol, n, &prod, hitlevel)) {
			fact = prod * kdfact;
			pix->r += fact * objcol.r * othercol.r;
			pix->g += fact * objcol.g * othercol.g;
			pix->b += fact * objcol.b * othercol.b;
			if (ksfact != 0.0) {
				ns[X] = n[X];
				ns[Y] = n[Y];
				ns[Z] = n[Z];
				smult(ns, -2 * prod);
				vadd(mid, lr.dir, ns);
				normalise(mid);
				fact = dprod(i->dir, mid);
				if (fact > 0.0) {
					fact = pow(fact, sp.ksexp) * ksfact;
					pix->r += fact * othercol.r;
					pix->g += fact * othercol.g;
					pix->b += fact * othercol.b;
				}
			}
		}
	}

	/*
	 * refraction  - Roy Hall's method.
	 */
	if (sp.ri != 0.0 && hitlevel < maxhitlevel && sp.T != 0.0) {

		cv[X] = ndoti * n[X];
		cv[Y] = ndoti * n[Y];
		cv[Z] = ndoti * n[Z];

		if (leaving) {
					/* 
					 * just in case ray starts in an object
					 */
			if (sstackp != sstack)
				ir.ri = (sstackp - 1)->ri;
			else
				ir.ri = ri;
		} else
			ir.ri = sp.ri;

		fact = i->ri / ir.ri;
		 
		sv[X] = fact * (i->dir[X] - cv[X]);
		sv[Y] = fact * (i->dir[Y] - cv[Y]);
		sv[Z] = fact * (i->dir[Z] - cv[Z]);

		/*
		 * greater than or equal 1.0 means internal reflection
		 */
		if ((lensvsqu = dprod(sv, sv)) < 1.0) {

			fact = sqrt(1.0 - lensvsqu);

			ir.dir[X] = sv[X] - (n[X] * fact);
			ir.dir[Y] = sv[Y] - (n[Y] * fact);
			ir.dir[Z] = sv[Z] - (n[Z] * fact);

			ir.raynumber = raynumber++;
			ir.orgobj = (object *)NULL;
			ir.type = TRANSPARENCY_RAY;

			nxthit = trace(&ir, objlist);

			if (nxthit != (hlist *)NULL) {

				refractionhitrays++;
				sstackp++;
				sstackp->ri = sp.ri;

				shade(&objcol, &ir, nxthit, hitlevel + 1);

				sstackp--;

				pix->r += sp.T * objcol.r;
				pix->g += sp.T * objcol.g;
				pix->b += sp.T * objcol.b;
			} else {
				refractionmissrays++;
				/*
				 * assume we get lost in the object...
				pix->r += sp.c[RED] * (1.0 - sp.T);
				pix->g += sp.c[GREEN] * (1.0 - sp.T);
				pix->b += sp.c[BLUE] * (1.0 - sp.T);
				 */
			}

			for (lp = nxthit; lp != (hlist *)NULL; lp = p) {
				p = lp->nxt;
				release(lp);
			}
		}
	}

	if (hitlevel < maxhitlevel && sp.R != 0.0) {

		smult(n, 2 * ndoti);
		vsub(ir.dir, i->dir, n);

		ir.raynumber = raynumber++;
		ir.ri = i->ri;
		ir.type = REFLECTION_RAY;

		if (!selfshadowing[o->type])
			ir.orgobj = o;

		nxthit = trace(&ir, objlist);

		if (nxthit != (hlist *)NULL) {
			reflectionhitrays++;

			shade(&objcol, &ir, nxthit, hitlevel + 1);
			pix->r += sp.R * objcol.r;
			pix->g += sp.R * objcol.g;
			pix->b += sp.R * objcol.b;
		} else {
			reflectionmissrays++;

			pix->r += sp.R * backcol[RED];
			pix->g += sp.R * backcol[GREEN];
			pix->b += sp.R * backcol[BLUE];
		}

		for (lp = nxthit; lp != (hlist *)NULL; lp = p) {
			p = lp->nxt;
			release(lp);
		}
	}

	pix->r = clamp(pix->r);
	pix->g = clamp(pix->g);
	pix->b = clamp(pix->b);
}
