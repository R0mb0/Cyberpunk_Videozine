#include <stdio.h>
#include <math.h>
#include <sys/types.h>
#include <sys/times.h>

static float    prev_time;
static time_t  last_time, rprev_time, tstart_time;
static struct tms       buffer;

extern time_t   time();

extern FILE	*logfp;

/*
 * rendsettime
 *
 *	set the intial value of last_time.
 */
rendsettime()
{
	times(&buffer);

	last_time = buffer.tms_utime + buffer.tms_stime;
}

/*
 * rendprinttime
 *
 *      print out how much time has been taken up.
 */
rendprinttime(s)
	char    *s;
{
	float           diff;
	time_t          now;
	char            buf[BUFSIZ];

	times(&buffer);

	diff = buffer.tms_utime + buffer.tms_stime - last_time;

	fprintf(logfp, "%s %.2f seconds.\n", s, diff / 60.0);       

	last_time = buffer.tms_utime + buffer.tms_stime;
}
