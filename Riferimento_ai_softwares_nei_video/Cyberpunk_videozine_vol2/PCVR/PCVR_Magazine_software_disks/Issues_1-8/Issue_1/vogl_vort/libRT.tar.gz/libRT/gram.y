/*
 * parser for NFF grammer
 */

%{
#include <stdio.h>
#include <rt.h>
#include "rend.h"

static vector	up, eye, ref;

%}

%union {
	int	y_int;
	float	y_flt;
	vnode	*y_vnd;
	vnnode	*y_vnn;
}

%token VIEWING FROM AT UP ANGLE HITHER RESOLUTION BACKGROUND
%token LIGHT MATERIAL POLYGON CONE SPHERE POLYGONPATCH

%token <y_flt>	FLOAT

%type  <y_flt>	expr

%type  <y_vnd>	vertlist
%type  <y_vnn>	vertnormlist

%%

input	: /* NULL */
	| inputitem input
	;

inputitem: VIEWING viewinfo
	  {
		viewup(up[X], up[Y], up[Z]);
		viewlookat(eye[X], eye[Y], eye[Z], ref[X], ref[Y], ref[Z]);
	  }
	| BACKGROUND expr expr expr
	  {
		background($2, $3, $4);
	  }
	| LIGHT expr expr expr
	  {
		light($2, $3, $4, 0.5, 0.5, 0.5);
	  }
	| MATERIAL expr expr expr expr expr expr expr expr
	  {
			/* following tradition, calculate reflectance... */

		material($2, $3, $4, $5, $6, $7, $9, $8, ((1.0 - $8) < $6) ? 1.0 - $8 : $6);
	  }
	| CONE expr expr expr expr expr expr expr expr
	  {
		cone($2, $3, $4, $5, $6, $7, $8, $9);
	  }
	| SPHERE expr expr expr expr
	  {
		sphere($2, $3, $4, $5);
	  }
	| POLYGON expr vertlist
	  {
		int	i;
		float	*xs, *ys, *zs;
		vnode	*v, *vnxt;

		xs = (float *)smalloc((int)$2 * sizeof(float));
		ys = (float *)smalloc((int)$2 * sizeof(float));
		zs = (float *)smalloc((int)$2 * sizeof(float));

		for (i = 0, v = $3; i != (int)$2; i++, v = vnxt) {
			xs[i] = v->v[X];
			ys[i] = v->v[Y];
			zs[i] = v->v[Z];
			vnxt = v->nxt;
			free(v);
		}

		polygon((int)$2, xs, ys, zs);

		free(xs);
		free(ys);
		free(zs);
	  }
	| POLYGONPATCH expr vertnormlist
	  {
		int	i;
		float	*xs, *ys, *zs;
		float	*nxs, *nys, *nzs;
		vnnode	*v, *vnxt;

		xs = (float *)smalloc((int)$2 * sizeof(float));
		ys = (float *)smalloc((int)$2 * sizeof(float));
		zs = (float *)smalloc((int)$2 * sizeof(float));
		nxs = (float *)smalloc((int)$2 * sizeof(float));
		nys = (float *)smalloc((int)$2 * sizeof(float));
		nzs = (float *)smalloc((int)$2 * sizeof(float));

		for (i = 0, v = $3; i != (int)$2; i++, v = vnxt) {
			xs[i] = v->v[X];
			ys[i] = v->v[Y];
			zs[i] = v->v[Z];
			nxs[i] = v->n[X];
			nys[i] = v->n[Y];
			nzs[i] = v->n[Z];
			vnxt = v->nxt;
			free(v);
		}

		polygonpatch((int)$2, xs, ys, zs, nxs, nys, nzs);

		free(xs);
		free(ys);
		free(zs);
		free(nxs);
		free(nys);
		free(nzs);
	  }
	;

viewinfo: /* NULL */
	| viewitem viewinfo
	;

viewitem: FROM expr expr expr
	  {
		eye[X] = $2;
		eye[Y] = $3;
		eye[Z] = $4;
	  }
	| AT expr expr expr
	  {
		ref[X] = $2;
		ref[Y] = $3;
		ref[Z] = $4;
	  }
	| UP expr expr expr
	  {
		up[X] = $2;
		up[Y] = $3;
		up[Z] = $4;
	  }
	| ANGLE expr
	  {
		viewfov($2);
	  }
	| HITHER expr
	  {
		/* IGNORED - at the momemt!
		printf("hi %f\n", $2);
		*/
	  }
	| RESOLUTION expr expr
	  {
		imagesize((int)$2, (int)$3);
	  }
	;

vertlist: /* NULL */
	  {
		$$ = (vnode *)NULL;
	  }
	| vertlist expr expr expr
	  {
		$$ = (vnode *)smalloc(sizeof(vnode));

		$$->v[X] = $2;
		$$->v[Y] = $3;
		$$->v[Z] = $4;

		$$->nxt = $1;
	  }
	;

vertnormlist: /* NULL */
	  {
		$$ = (vnnode *)NULL;
	  }
	| vertnormlist expr expr expr expr expr expr
	  {
		$$ = (vnnode *)smalloc(sizeof(vnnode));

		$$->v[X] = $2;
		$$->v[Y] = $3;
		$$->v[Z] = $4;

		$$->n[X] = $5;
		$$->n[Y] = $6;
		$$->n[Z] = $7;

		$$->nxt = $1;
	  }
	;

expr	: FLOAT
	  {
		$$ = $1;
	  }
	;
