
typedef union
#ifdef __cplusplus
	YYSTYPE
#endif
 {
	int	y_int;
	float	y_flt;
	vnode	*y_vnd;
	vnnode	*y_vnn;
} YYSTYPE;
extern YYSTYPE yylval;
# define VIEWING 257
# define FROM 258
# define AT 259
# define UP 260
# define ANGLE 261
# define HITHER 262
# define RESOLUTION 263
# define BACKGROUND 264
# define LIGHT 265
# define MATERIAL 266
# define POLYGON 267
# define CONE 268
# define SPHERE 269
# define POLYGONPATCH 270
# define FLOAT 271
