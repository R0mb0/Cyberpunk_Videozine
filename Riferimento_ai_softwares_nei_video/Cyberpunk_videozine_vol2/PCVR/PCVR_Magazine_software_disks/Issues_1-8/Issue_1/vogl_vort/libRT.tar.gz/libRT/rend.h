/*
 * typedef for the vector and vector/normal lists used
 * by the parser.
 */
typedef struct vn {
	vector		v;
	struct vn	*nxt;
} vnode;

typedef struct vnn {
	vector		v, n;
	struct vnn	*nxt;
} vnnode;

