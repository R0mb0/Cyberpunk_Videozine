#include <math.h>
#include <stdio.h>
#include "rt.h"
#include "macro.h"

extern mats	*mstackp;

extern mat4x4	trans;

extern int	maxhitlevel;

extern lightobj	*lights;

/*
 * light
 *
 *	set up a point light source.
 */
light(lx, ly, lz, r, g, b)
	float	lx, ly, lz;
	float	r, g, b;
{
	lightobj	*l;
	int		i;

	l = (lightobj *)smalloc(sizeof(lightobj));

	l->c[RED] = r;
	l->c[GREEN] = g;
	l->c[BLUE] = b;

	l->org[X] = lx;
	l->org[Y] = ly;
	l->org[Z] = lz;

	l->lasthits = (object **)smalloc(sizeof(object *) * (maxhitlevel + 2));
	for (i = 0; i <= maxhitlevel; i++)
		l->lasthits[i] = (object *)NULL;

	/*
	 * add to the list...
	 */
	l->nxt = lights;
	lights = l;
}
