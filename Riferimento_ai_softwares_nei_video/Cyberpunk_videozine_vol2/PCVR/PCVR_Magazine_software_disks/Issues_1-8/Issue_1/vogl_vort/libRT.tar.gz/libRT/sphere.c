#include <math.h>
#include <stdio.h>
#include "rt.h"
#include "macro.h"

extern mats	*mstackp;
extern oentry	*ostackp;
extern float	tolerance;

extern long	objtests[], inttests[], hits[], bboxtests[];

/*
 * spherei
 *
 *	returns a list of intersection points for the ray r and sphere o.
 */
int
spherei(r, o, bboxtest)
	ray	*r;
	object	*o;
	int	bboxtest;
{
	vector	c;
	sphr	*sp;
	float	a, b, d, t;

	if (o == r->orgobj && r->type != TRANSPARENCY_RAY)
		return(RT_FALSE);

	if (bboxtest) {
		bboxtests[o->type]++;
		if (missedbbox(r, &o->bb))
			return(RT_FALSE);
	}

	inttests[o->type]++;

	sp = o->obj.sph;

	vsub(c, r->org, sp->orig);

	b = -dprod(c, r->dir);
	a = (dprod(c, c) - sp->radsqu);

	if ((d = b * b - a) < 0.0 || (b < 0.0 && a > 0.0))
		return(RT_FALSE);

	d = sqrt((double)d);

	t = b - d;

	if (t > tolerance) {
		r->hit.t = t;
		r->hit.obj = o;
		r->hit.vals[X] = r->org[X] + r->dir[X] * t;
		r->hit.vals[Y] = r->org[Y] + r->dir[Y] * t;
		r->hit.vals[Z] = r->org[Z] + r->dir[Z] * t;

		hits[o->type]++;

		return(RT_TRUE);
	} else { 
		t = b + d;
		if (t > tolerance) {
			r->hit.t = t;
			r->hit.obj = o;
			r->hit.vals[X] = r->org[X] + r->dir[X] * t;
			r->hit.vals[Y] = r->org[Y] + r->dir[Y] * t;
			r->hit.vals[Z] = r->org[Z] + r->dir[Z] * t;

			hits[o->type]++;

			return(RT_TRUE);
		}
	}

	return(RT_FALSE);
}

/*
 * spheren
 *
 *	returns the normal to the sphere s
 */
void
spheren(n, l, o)
	vector	n;
	vector	l;
	object	*o;
{
	toobject(o, n, l);
}

/*
 * sphere
 *
 *	initialise the function pointers and fields for a sphere object,
 * returning its pointer.
 */
void
sphere(cx, cy, cz, r)
	float	cx, cy, cz, r;
{
	vector	cent;
	object	*o;

	pushmatrix();

	o = (object *)smalloc(sizeof(object));

	o->type = SPHEREOBJ;

	translate(cx, cy, cz);

	scale(r, r, r);

	setattributes(o);

	makebbox(o, -1.0, -1.0, -1.0, 1.0, 1.0, 1.0);

	o->obj.sph = (sphr *)smalloc(sizeof(sphr));

	cent[X] = cent[Y] = cent[Z] = 0.0;
	vmmult(o->obj.sph->orig, cent, mstackp->obj2ray);

	o->obj.sph->radsqu = r * r;

	/*
	 * add object to stack
	 */
	o->nxt = ostackp->objs;
	ostackp->objs = o;

	popmatrix();
}

/*
 * spheretabinit
 *
 *	set the table of function pointers for the sphere.
 */
spheretabinit(intersects, normals, checkbbox, selfshadowing)
	int	(*intersects[])();
	void	(*normals[])();
	int	checkbbox[];
	int	selfshadowing[];
{
	normals[SPHEREOBJ] = spheren;
	intersects[SPHEREOBJ] = spherei;
	checkbbox[SPHEREOBJ] = RT_FALSE;
	selfshadowing[SPHEREOBJ] = RT_FALSE;
}
