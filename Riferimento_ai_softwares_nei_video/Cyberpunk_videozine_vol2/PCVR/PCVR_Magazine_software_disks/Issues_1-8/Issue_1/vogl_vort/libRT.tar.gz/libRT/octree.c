#include <stdio.h>
#include <math.h>
#include "rt.h"
#include "macro.h"

extern int	shadow_rays;

extern hlist	*(*intersects[])();
extern int	checkbbox[];

extern double	power();

#define	U	0
#define	V	1

extern oentry	*ostackp;
extern object	*oblist, *objlist;
extern hlist	*fhlist;
extern int	maxhitlevel;
extern int	maxoctreedepth;

extern double	power();

extern float	tolerance;


/*
 * splitlist
 *
 *	split list1 along axis for the value val, objects to the left
 * go in list2, objects to the right go in list3.
 */
static
splitlist(axis, val, list1, list2, list3)
	int	axis;
	float	val;
	olist	*list1, **list2, **list3;
{
	int	ax;
	object	*o;
	olist	*objs, *nxtobj, *tmpobj;

	*list2 = *list3 = (olist *)NULL;

	for (objs = list1; objs != (olist *)NULL; objs = nxtobj) {
		nxtobj = objs->nxt;
		o = objs->obj;

		if (o->bb.max[axis] < val) {		/* to the left */
			objs->nxt = *list2;
			*list2 = objs;
		} else if (o->bb.min[axis] > val) {	/* to the right */
			objs->nxt = *list3;
			*list3 = objs;
		} else {				/* in both (sigh) */
			objs->nxt = *list2;
			*list2 = objs;

			tmpobj = (olist *)smalloc(sizeof(olist));
			*tmpobj = *objs;
			tmpobj->nxt = *list3;
			*list3 = tmpobj;
		}
	}
}

/*
 * split
 *
 *	split a leaf into a tree of 8 representing each voxel of
 * the octree.
 */
static void
split(root, bb)
	ocnode	*root;
	bbox	*bb;
{
	int	left[DIMS], right[DIMS], extras[DIMS], tot[DIMS];
	float	vals[DIMS], delta[DIMS];
	ocnode	*quad;
	olist	*ol, *ol2, *nxtol, *nxtol2;
	olist	*leftx, *rightx, *lstol, *lstol2;
	olist	*leftxly, *leftxry, *rightxly, *rightxry;
	object	*o;
	int	count, oldcount, i;

	oldcount = 0;
	for (ol = root->u.leaf.oblist; ol != (olist *)NULL; ol = ol->nxt)
		oldcount++;

	quad = (ocnode *)smalloc(sizeof(ocnode) * 8);

	vals[X] = (bb->max[X] + bb->min[X]) / 2;
	vals[Y] = (bb->max[Y] + bb->min[Y]) / 2;
	vals[Z] = (bb->max[Z] + bb->min[Z]) / 2;

	splitlist(X, vals[X], root->u.leaf.oblist, &leftx, &rightx);

	splitlist(Y, vals[Y], leftx, &leftxly, &leftxry);
	splitlist(Y, vals[Y], rightx, &rightxly, &rightxry);

	splitlist(Z, vals[Z], leftxly, &quad[0].u.leaf.oblist, &quad[1].u.leaf.oblist);
	splitlist(Z, vals[Z], leftxry, &quad[2].u.leaf.oblist, &quad[3].u.leaf.oblist);
	splitlist(Z, vals[Z], rightxly, &quad[4].u.leaf.oblist, &quad[5].u.leaf.oblist);
	splitlist(Z, vals[Z], rightxry, &quad[6].u.leaf.oblist, &quad[7].u.leaf.oblist);

	count = 0;
	for (i = 0; i != 8; i++) {
		for (ol = quad[i].u.leaf.oblist; ol != (olist *)NULL; ol = ol->nxt)
			count++;
	}

	if (count >= 2 * oldcount) {
		/*
		 * reconstruct list and take out duplicates.
		 */
		root->u.leaf.oblist = (olist *)NULL;
		for (i = 0; i != 8; i++) {
			for (ol = quad[i].u.leaf.oblist; ol != (olist *)NULL; ol = nxtol) {
				nxtol = ol->nxt;
				ol->nxt = root->u.leaf.oblist;
				root->u.leaf.oblist = ol;
			}
		}

		for (ol = root->u.leaf.oblist; ol != (olist *)NULL; ol = nxtol) {
			nxtol = ol->nxt;
			lstol2 = ol;
			for (ol2 = nxtol; ol2 != (olist *)NULL; ol2 = nxtol2) {
				nxtol2 = ol2->nxt;
				if (ol2->obj == ol->obj) {
					if (nxtol == ol2)
						ol->nxt = nxtol = ol2->nxt;
					lstol2->nxt = nxtol2 = ol2->nxt;
					free(ol2);
				} else
					lstol2 = ol2;
			}
		}

		root->type = LEAF;
		free(quad);
		return;
	}

	for (i = 0; i != 8; i++) {
		quad[i].u.leaf.depth = root->u.leaf.depth + 1;
		if (quad[i].u.leaf.oblist == (olist *)NULL 
		   || quad[i].u.leaf.depth >= maxoctreedepth)
			quad[i].type = LEAF;
		else {
			count = 0;
			for (ol = quad[i].u.leaf.oblist; ol != (olist *)NULL; ol = ol->nxt)
				count++;
			quad[i].type = (count <= 5) ? LEAF : SPLITABLELEAF;
		}
	}

	root->type = BRANCH;
	root->u.branch = quad;

	treenodes += 8;
}

/*
 * checkleaf
 *
 *	check the objects in a leaf - returning a legal hit if there is
 * one
 */
static int
checkleaf(r, leaf, bb)
	ray	*r;
	ocnode	*leaf;
	bbox	*bb;
{
	olist	*ol;
	object	*o;
	float	val;
	int	bboxcheck;

	if (leaf->u.leaf.oblist == (olist *)NULL)
		return(RT_FALSE);

	bboxcheck = (leaf->u.leaf.oblist->nxt != (olist *)NULL);
	for (ol = leaf->u.leaf.oblist; ol != (olist *)NULL; ol = ol->nxt) {
		o = ol->obj;

		if (o->lastray.raynumber == r->raynumber) {
			if (o->lastray.t != 0.0) {
				r->hit.t = o->lastray.t;
				r->hit.type = o->lastray.type;
				r->hit.obj = o;
			} else
				continue;		/* go to next object */

		} else {

			o->lastray.raynumber = r->raynumber;
			o->lastray.t = 0.0;

			if (!intersects[o->type](r, o, bboxcheck))
				continue;		/* go to next object */

			o->lastray.t = r->hit.t;
			o->lastray.type = r->hit.type;
		}

		if (r->thehit.obj == (object *)NULL)
			r->thehit = r->hit;
		else if (r->thehit.t > r->hit.t)
			r->thehit = r->hit;

		/*
		 * no need to look further...
		 */
		if (r->type == SHADOW_RAY && r->thehit.t <= r->maxt
		    && o->s->T == 0.0) {
			r->done = RT_TRUE;
			return(RT_TRUE);
		}

	}

	if (r->thehit.obj != (object *)NULL) {

		if (r->dir[X] < 0.0) {
			if (r->thehit.vals[X] < bb->min[X])
				return(RT_FALSE);
		} else {
			if (r->thehit.vals[X] > bb->max[X])
				return(RT_FALSE);
		}

		if (r->dir[Y] < 0.0) {
			if (r->thehit.vals[Y] < bb->min[Y])
				return(RT_FALSE);
		} else {
			if (r->thehit.vals[Y] > bb->max[Y])
				return(RT_FALSE);
		}

		if (r->dir[Z] < 0.0) {
			if (r->thehit.vals[Z] < bb->min[Z])
				return(RT_FALSE);
		} else {
			if (r->thehit.vals[Z] > bb->max[Z])
				return(RT_FALSE);
		}
	}

	return(r->thehit.obj != (object *)NULL);
}

/*
 * treetrace
 *
 *	returns the first hit on the octree pointed to by root.
 */
static int
treetrace(r, root, axis, bb)
	ray	*r;
	ocnode	*root;
	int	axis;
	bbox	*bb;
{
	int	hit, p, u, v;
	float	t1, t2, mid, val, org, dir;

	hit = RT_FALSE;

	switch (axis) {
	case X:
		dir = r->dir[X];
		org = r->org[X];
		if (root->type == LEAF)
			return(checkleaf(r, root, bb));
		else if (root->type == SPLITABLELEAF) {
			split(root, bb);
			hit = treetrace(r, root, X, bb);
			return(hit);
		} else {
			mid = (bb->min[X] + bb->max[X]) / 2.0;
			if (org < mid) {
				if (org < bb->min[X] && dir < 0.0)
					return(RT_FALSE);

				val = bb->max[X];
				bb->max[X] = mid;

				hit = treetrace(r, &root->u.branch[0], (axis + 1) % 0x3, bb);

				bb->max[X] = val;

				if (hit) {
					return(hit);
				} else if (dir <= 0.0)
					return(RT_FALSE);

				val = bb->min[X];
				bb->min[X] = mid;

				hit = treetrace(r, &root->u.branch[4], (axis + 1) % 0x3, bb);

				bb->min[X] = val;

				return(hit);
			} else {
				if (org > bb->max[X] && dir > 0.0)
					return(RT_FALSE);

				val = bb->min[X];
				bb->min[X] = mid;

				hit = treetrace(r, &root->u.branch[4], (axis + 1) % 0x3, bb);

				bb->min[X] = val;

				if (hit) {
					return(hit);
				} else if (dir >= 0.0)
					return(RT_FALSE);

				val = bb->max[X];
				bb->max[X] = mid;

				hit = treetrace(r, &root->u.branch[0], (axis + 1) % 0x3, bb);

				bb->max[X] = val;

				return(hit);
			}
		}
		break;
	case Y:
		dir = r->dir[Y];
		org = r->org[Y];
		mid = (bb->min[Y] + bb->max[Y]) / 2.0;
		if (org < mid) {
			if (org < bb->min[Y] && dir < 0.0)
				return(RT_FALSE);

			val = bb->max[Y];
			bb->max[Y] = mid;

			hit = treetrace(r, &root[0], (axis + 1) % 0x3, bb);

			bb->max[Y] = val;

			if (hit) {
				return(hit);
			} else if (dir <= 0.0)
				return(RT_FALSE);

			val = bb->min[Y];
			bb->min[Y] = mid;

			hit = treetrace(r, &root[2], (axis + 1) % 0x3, bb);

			bb->min[Y] = val;

			return(hit);
		} else {
			if (org > bb->max[Y] && dir > 0.0)
				return(RT_FALSE);

			val = bb->min[Y];
			bb->min[Y] = mid;

			hit = treetrace(r, &root[2], (axis + 1) % 0x3, bb);

			bb->min[Y] = val;

			if (hit) {
				return(hit);
			} else if (dir >= 0.0)
				return(RT_FALSE);

			val = bb->max[Y];
			bb->max[Y] = mid;

			hit = treetrace(r, &root[0], (axis + 1) % 0x3, bb);

			bb->max[Y] = val;

			return(hit);
		}
		break;
	case Z:
		dir = r->dir[Z];
		org = r->org[Z];
		mid = (bb->min[Z] + bb->max[Z]) / 2.0;
		if (org < mid) {
			if (org < bb->min[Z] && dir < 0.0)
				return(RT_FALSE);

			val = bb->max[Z];
			bb->max[Z] = mid;

			if (!missedbbox(r, bb))
				hit = treetrace(r, &root[0], (axis + 1) % 0x3, bb);
			else
				hit = RT_FALSE;

			bb->max[Z] = val;

			if (hit) {
				return(hit);
			} else if (dir <= 0.0)
				return(RT_FALSE);

			val = bb->min[Z];
			bb->min[Z] = mid;

			if (!missedbbox(r, bb))
				hit = treetrace(r, &root[1], (axis + 1) % 0x3, bb);
			else
				hit = RT_FALSE;

			bb->min[Z] = val;

			return(hit);
		} else {
			if (org > bb->max[Z] && dir > 0.0)
				return(RT_FALSE);

			val = bb->min[Z];
			bb->min[Z] = mid;

			if (!missedbbox(r, bb))
				hit = treetrace(r, &root[1], (axis + 1) % 0x3, bb);
			else
				hit = RT_FALSE;

			bb->min[Z] = val;

			if (hit) {
				return(hit);
			} else if (dir >= 0.0)
				return(RT_FALSE);

			val = bb->max[Z];
			bb->max[Z] = mid;

			if (!missedbbox(r, bb))
				hit = treetrace(r, &root[0], (axis + 1) % 0x3, bb);
			else
				hit = RT_FALSE;

			bb->max[Z] = val;

			return(hit);
		}
		break;
	default:
		fprintf(stderr, "treetrace: bad axis in switch.\n");
		exit(1);
	}

	return(hit);
}

/*
 * octreei
 *
 *	return the intersections between the ray r and the octree in o.
 */
int
octreei(r, o)
	ray	*r;
	object	*o;
{
	if (treetrace(r, o->obj.oct, X, &o->bb)) {
		r->hit = r->thehit;
		return(RT_TRUE);
	}

	return(RT_FALSE);
}

/*
 * openoctree
 *
 *	start the collecting object for a octree, all we need to
 * do here is push the object stack and start afresh.
 */
void
openoctree()
{
	/*
	 * check we have more room on stack...
	 */
	if (ostackp->nxt == (oentry *)NULL) {
		ostackp->nxt = (oentry *)smalloc(sizeof(oentry));
		ostackp->nxt->lst = ostackp;
	}

	/*
	 * push stack - clearing the object pointer.
	 */
	ostackp = ostackp->nxt;
	ostackp->objs = (object *)NULL;
}

/*
 * closeoctree
 *
 *	grab whatever is sitting on the object stack, pop the stack, and
 * add a octree object containing what we collected since the last openoctree.
 */
void
closeoctree()
{
	object		*obj, *o;
	olist		*ol;
	ocnode		*tree;

	/*
	 * set up the octree object
	 */
	obj = (object *)smalloc(sizeof(object));

	obj->type = OCTREEOBJ;
	obj->obj.oct = tree = (ocnode *)smalloc(sizeof(ocnode));

	tree->type = SPLITABLELEAF;

	treenodes = 1;

	tree->u.leaf.oblist = (olist *)NULL;
	tree->u.leaf.depth = 0;

	obj->bb.min[X] = ostackp->objs->bb.min[X];
	obj->bb.max[X] = ostackp->objs->bb.max[X];

	obj->bb.min[Y] = ostackp->objs->bb.min[Y];
	obj->bb.max[Y] = ostackp->objs->bb.max[Y];

	obj->bb.min[Z] = ostackp->objs->bb.min[Z];
	obj->bb.max[Z] = ostackp->objs->bb.max[Z];

	for (o = ostackp->objs; o != (object *)NULL; o = o->nxt) {
		ol = (olist *)smalloc(sizeof(olist));
		ol->nxt = tree->u.leaf.oblist;
		ol->obj = o;
		adjustbbox(&obj->bb, o);
		tree->u.leaf.oblist = ol;
	}

	/*
	 * pop stack and add octree.
	 */
	ostackp = ostackp->lst;

	obj->nxt = ostackp->objs;
	ostackp->objs = obj;
}

/*
 * octreetabinit
 *
 *	set the table of function pointers for the tree.
 */
octreetabinit(intersects, normals, checkbbox, selfshadowing)
	int	(*intersects[])();
	void	(*normals[])();
	int	checkbbox[];
	int	selfshadowing[];
{
	normals[OCTREEOBJ] = (void (*)())NULL;
	intersects[OCTREEOBJ] = octreei;
	checkbbox[OCTREEOBJ] = RT_TRUE;
	selfshadowing[OCTREEOBJ] = RT_TRUE;
}
