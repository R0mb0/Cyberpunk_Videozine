#include <stdio.h>
#include <math.h>
#include "rt.h"
#include "macro.h"

extern int	maxtreedepth;
extern float	tolerance;
extern float	focallength;
extern float	falloff;

extern int	iwidth, iheight, ibase;
extern int	iwoff, ihoff;

extern vector	up;

extern colour	backcol;

extern int	(*intersects[])();
extern int	checkbbox[];
extern long	bboxtests[];

extern float	*erandp, *randp, randtable[];

extern hlist	*fhlist;

extern oentry	*ostackp;

/*
 * strictly speaking this should be calculated
 * according to the size of the grid, later...
 */
#define SMALL   0.00001
    

/*
 * origin and direction for current ray - used here and in entity.c
 */
float	orgs[DIMS], dirs[DIMS];

extern mat4x4	wtrans;
extern mat4x4	rtrans;

/*
 * default grid size
 */
int	xdiv = 20,
	ydiv = 20,
	zdiv = 20;

/*
 * gridsize
 *
 *	set the size of the grid.
 */
gridsize(xd, yd, zd)
	int	xd, yd, zd;
{
	xdiv = xd;
	ydiv = yd;
	zdiv = zd;
}

/*
 * checkvoxel
 *
 *	check the objects in a object list, returning a hit if the
 * object is intersected by the ray and the hit lies in this voxel.
 */
int
checkvoxel(r, pmin, pmax, voxbb, oblist)
	ray	*r;
	float	**pmin, **pmax;
	bbox	*voxbb;
	olist	*oblist;
{
	olist	*ol;
	object	*o;
	vector	minv, maxv;
	float	val;
	int	bboxcheck;

	minv[X] = *pmin[X];
	minv[Y] = *pmin[Y];
	minv[Z] = *pmin[Z];

	maxv[X] = *pmax[X];
	maxv[Y] = *pmax[Y];
	maxv[Z] = *pmax[Z];
						   
	for (ol = oblist; ol != (olist *)NULL; ol = ol->nxt) {
		o = ol->obj;

		if (o->lastray.raynumber == r->raynumber) {
			if (o->lastray.t != 0.0) {
				r->hit.t = o->lastray.t;
				r->hit.type = o->lastray.type;
				r->hit.obj = o;
			} else
				continue;		/* go to next object */

		} else {

			if (o->bb.max[X] < minv[X] || o->bb.min[X] > maxv[X]
			    || o->bb.max[Y] < minv[Y] || o->bb.min[Y] > maxv[Y]
			    || o->bb.max[Z] < minv[Z] || o->bb.min[Z] > maxv[Z])
				continue;

			o->lastray.raynumber = r->raynumber;
			o->lastray.t = 0.0;

			if (!intersects[o->type](r, o, RT_TRUE))
				continue;		/* go to next object */

			o->lastray.t = r->hit.t;
			o->lastray.type = r->hit.type;
		}

		if (r->thehit.obj == (object *)NULL)
			r->thehit = r->hit;
		else if (r->thehit.t > r->hit.t)
			r->thehit = r->hit;

		if (r->type == SHADOW_RAY && r->hit.t <= r->maxt
		   && o->s->T == 0.0) {
			r->done = RT_TRUE;
			return(RT_TRUE);
		}
	}

	if (r->thehit.obj != (object *)NULL) {

		if (r->dir[X] < 0.0) {
			if (r->thehit.vals[X] < minv[X])
				return(RT_FALSE);
		} else {
			if (r->thehit.vals[X] > maxv[X])
				return(RT_FALSE);
		}

		if (r->dir[Y] < 0.0) {
			if (r->thehit.vals[Y] < minv[Y])
				return(RT_FALSE);
		} else {
			if (r->thehit.vals[Y] > maxv[Y])
				return(RT_FALSE);
		}

		if (r->dir[Z] < 0.0) {
			if (r->thehit.vals[Z] < minv[Z])
				return(RT_FALSE);
		} else {
			if (r->thehit.vals[Z] > maxv[Z])
				return(RT_FALSE);
		}
	}

	return(r->thehit.obj != (object *)NULL);
}

/*
 * gridtrace
 *
 *	intersect a ray with the uniform grid.
 */
int
gridtrace(r, gr)
	ray	*r;
	grid	*gr;
{
	vector	pnt, npnt;
	int	i, j, k;
	int	istep, jstep, kstep;
	int	iend, jend, kend;
	int	hit;
	voxel	*vox;
	bbox	voxbb;
	int	li, lj, lk;
	vector	rmin, rmax, loc;
	vector	xskip, yskip, zskip;
	float	t1, t2, xgap, ygap, zgap, delta;
	float	xdist, ydist, zdist;
	vector	nxpnt, nypnt, nzpnt;
	float	*pmin[3], *pmax[3];

	bboxtests[GRIDOBJ]++;

	if (gr->bb.min[X] <= r->org[X] && gr->bb.max[X] >= r->org[X]
	   && gr->bb.min[Y] <= r->org[Y] && gr->bb.max[Y] >= r->org[Y]
	   && gr->bb.min[Z] <= r->org[Z] && gr->bb.max[Z] >= r->org[Z]) {
		pnt[X] = r->org[X];
		pnt[Y] = r->org[Y];
		pnt[Z] = r->org[Z];
	} else if (inbbox(r, &gr->bb, &t1, &t2)) {
		pnt[X] = r->org[X] + t1 * r->dir[X];
		pnt[Y] = r->org[Y] + t1 * r->dir[Y];
		pnt[Z] = r->org[Z] + t1 * r->dir[Z];
	} else 
		return(RT_FALSE);

	i = (pnt[X] - gr->bb.min[X]) / gr->deltax;
	j = (pnt[Y] - gr->bb.min[Y]) / gr->deltay;
	k = (pnt[Z] - gr->bb.min[Z]) / gr->deltaz;

	/*
	 * check that we aren't on the outside edge...
	 */
	if (i == gr->xdiv)
		i = gr->xdiv - 1;

	if (j == gr->ydiv)
		j = gr->ydiv - 1;

	if (k == gr->zdiv)
		k = gr->zdiv - 1;

	/* 
	 * calculate the increments to get along voxels.
	 */
	voxbb.min[X] = gr->bb.min[X] + i * gr->deltax;
	voxbb.max[X] = voxbb.min[X] + gr->deltax;
	voxbb.min[Y] = gr->bb.min[Y] + j * gr->deltay;
	voxbb.max[Y] = voxbb.min[Y] + gr->deltay;
	voxbb.min[Z] = gr->bb.min[Z] + k * gr->deltaz;
	voxbb.max[Z] = voxbb.min[Z] + gr->deltaz;

	if (r->dir[X] < -SMALL) {
		istep = -1;
		iend = -1;
		xgap = gr->deltax / -r->dir[X];
		xdist = (voxbb.min[X] - pnt[X]) / r->dir[X];
		pmin[X] = &npnt[X];
		pmax[X] = &pnt[X];
	} else if (r->dir[X] > SMALL) {
		istep = 1;
		iend = gr->xdiv;
		xgap = gr->deltax / r->dir[X];
		xdist = (voxbb.max[X] - pnt[X]) / r->dir[X];
		pmin[X] = &pnt[X];
		pmax[X] = &npnt[X];
	} else {
		istep = 0;
		iend = i;
		xgap = HUGE_DIST;
		xdist = HUGE_DIST;
		pmin[X] = &pnt[X];
		pmax[X] = &npnt[X];
	}

	if (r->dir[Y] < -SMALL) {
		jstep = -1;
		jend = -1;
		ygap = gr->deltay / -r->dir[Y];
		ydist = (voxbb.min[Y] - pnt[Y]) / r->dir[Y];
		pmin[Y] = &npnt[Y];
		pmax[Y] = &pnt[Y];
	} else if (r->dir[Y] > SMALL) {
		jstep = 1;
		jend = gr->ydiv;
		ygap = gr->deltay / r->dir[Y];
		ydist = (voxbb.max[Y] - pnt[Y]) / r->dir[Y];
		pmin[Y] = &pnt[Y];
		pmax[Y] = &npnt[Y];
	} else {
		jstep = 0;
		jend = j;
		ygap = HUGE_DIST;
		ydist = HUGE_DIST;
		pmin[Y] = &pnt[Y];
		pmax[Y] = &npnt[Y];
	}

	if (r->dir[Z] < -SMALL) {
		kstep = -1;
		kend = -1;
		zgap = gr->deltaz / -r->dir[Z];
		zdist = (voxbb.min[Z] - pnt[Z]) / r->dir[Z];
		pmin[Z] = &npnt[Z];
		pmax[Z] = &pnt[Z];
	} else if (r->dir[Z] > SMALL) {
		kstep = 1;
		kend = gr->zdiv;
		zgap = gr->deltaz / r->dir[Z];
		zdist = (voxbb.max[Z] - pnt[Z]) / r->dir[Z];
		pmin[Z] = &pnt[Z];
		pmax[Z] = &npnt[Z];
	} else {
		kstep = 0;
		kend = k;
		zgap = HUGE_DIST;
		zdist = HUGE_DIST;
		pmin[Z] = &pnt[Z];
		pmax[Z] = &npnt[Z];
	}

	/*
	 * no point in going past light source
	 */
	if (r->type == SHADOW_RAY) {
		loc[X] = r->org[X] + r->maxt * r->dir[X];
		li = (loc[X] - gr->bb.min[X]) / gr->deltax;
		if (li > 1 && li < gr->xdiv - 1)
			iend = li + istep;

		loc[Y] = r->org[Y] + r->maxt * r->dir[Y];
		lj = (loc[Y] - gr->bb.min[Y]) / gr->deltay;
		if (lj > 1 && lj < gr->ydiv - 1)
			jend = lj + jstep;

		loc[Z] = r->org[Z] + r->maxt * r->dir[Z];
		lk = (loc[Z] - gr->bb.min[Z]) / gr->deltaz;
		if (lk > 1 && lk < gr->zdiv - 1)
			kend = lk + kstep;
	}

	xskip[X] = xgap * r->dir[X];
	xskip[Y] = xgap * r->dir[Y];
	xskip[Z] = xgap * r->dir[Z];

	yskip[X] = ygap * r->dir[X];
	yskip[Y] = ygap * r->dir[Y];
	yskip[Z] = ygap * r->dir[Z];

	zskip[X] = zgap * r->dir[X];
	zskip[Y] = zgap * r->dir[Y];
	zskip[Z] = zgap * r->dir[Z];

	nxpnt[X] = pnt[X] + xdist * r->dir[X];
	nxpnt[Y] = pnt[Y] + xdist * r->dir[Y];
	nxpnt[Z] = pnt[Z] + xdist * r->dir[Z];

	nypnt[X] = pnt[X] + ydist * r->dir[X];
	nypnt[Y] = pnt[Y] + ydist * r->dir[Y];
	nypnt[Z] = pnt[Z] + ydist * r->dir[Z];

	nzpnt[X] = pnt[X] + zdist * r->dir[X];
	nzpnt[Y] = pnt[Y] + zdist * r->dir[Y];
	nzpnt[Z] = pnt[Z] + zdist * r->dir[Z];

	/*
	 * step through the grid until we arrive at an object
	 */
	for (;;) {

		vox = gr->voxs[i][j][k];

		if (xdist < ydist)
			if (xdist < zdist) {
				npnt[X] = nxpnt[X];
				npnt[Y] = nxpnt[Y];
				npnt[Z] = nxpnt[Z];
				if (vox != (voxel *)NULL && (hit = checkvoxel(r, pmin, pmax, &vox->bb, vox->oblist))) {
					return(hit);
				}
				i += istep;
							/* out of grid */
				if (i == iend)
					return(RT_FALSE);

				xdist += xgap;
				pnt[X] = nxpnt[X];
				pnt[Y] = nxpnt[Y];
				pnt[Z] = nxpnt[Z];
				vadd(nxpnt, pnt, xskip);
			} else {
				npnt[X] = nzpnt[X];
				npnt[Y] = nzpnt[Y];
				npnt[Z] = nzpnt[Z];
				if (vox != (voxel *)NULL && (hit = checkvoxel(r, pmin, pmax, &vox->bb, vox->oblist))) {
					return(hit);
				}
				k += kstep;
							/* out of grid */
				if (k == kend)
					return(RT_FALSE);

				zdist += zgap;
				pnt[X] = nzpnt[X];
				pnt[Y] = nzpnt[Y];
				pnt[Z] = nzpnt[Z];
				vadd(nzpnt, pnt, zskip);
			}
		else
			if (ydist < zdist) {
				npnt[X] = nypnt[X];
				npnt[Y] = nypnt[Y];
				npnt[Z] = nypnt[Z];
				if (vox != (voxel *)NULL && (hit = checkvoxel(r, pmin, pmax, &vox->bb, vox->oblist))) {
					return(hit);
				}
				j += jstep;
							/* out of grid */
				if (j == jend)
					return(RT_FALSE);

				ydist += ygap;
				pnt[X] = nypnt[X];
				pnt[Y] = nypnt[Y];
				pnt[Z] = nypnt[Z];
				vadd(nypnt, pnt, yskip);
			} else {
				npnt[X] = nzpnt[X];
				npnt[Y] = nzpnt[Y];
				npnt[Z] = nzpnt[Z];
				if (vox != (voxel *)NULL && (hit = checkvoxel(r, pmin, pmax, &vox->bb, vox->oblist))) {
					return(hit);
				}
				k += kstep;
							/* out of grid */
				if (k == kend)
					return(RT_FALSE);

				zdist += zgap;
				pnt[X] = nzpnt[X];
				pnt[Y] = nzpnt[Y];
				pnt[Z] = nzpnt[Z];
				vadd(nzpnt, pnt, zskip);
			}
	}
}

/*
 * gridi
 * 
 *	intersect a uniform grid.
 *
 */
int
gridi(r, o)
	ray	*r;
	object	*o;
{
	if (gridtrace(r, o->obj.grd)) {
		r->hit = r->thehit;
		return(RT_TRUE);
	}

	return(RT_FALSE);
}

/*
 * opengrid
 *
 *	start the collecting object for a grid, all we need to
 * do here is push the object stack and start afresh.
 */
void
opengrid()
{
	/*
	 * check we have more room on stack...
	 */
	if (ostackp->nxt == (oentry *)NULL) {
		ostackp->nxt = (oentry *)smalloc(sizeof(oentry));
		ostackp->nxt->lst = ostackp;
	}

	/*
	 * push stack - clearing the object pointer.
	 */
	ostackp = ostackp->nxt;
	ostackp->objs = (object *)NULL;
}

/*
 * closegrid
 *
 *	grab whatever is sitting on the object stack, pop the stack, and
 * add a grid object containing what we collected since the last opengrid.
 */
void
closegrid()
{
	object		*obj, *o;
	olist		*ol;
	grid		*gr;
	voxel		*vox;
	int		i, j, k;
	int		mini, maxi, minj, maxj, mink, maxk;

	obj = (object *)smalloc(sizeof(object));

	obj->type = GRIDOBJ;
	obj->obj.grd = gr = (grid *)smalloc(sizeof(grid));

	/*
	 * set the grid's bounding box.
	 */
	obj->bb.min[X] = ostackp->objs->bb.min[X];
	obj->bb.max[X] = ostackp->objs->bb.max[X];

	obj->bb.min[Y] = ostackp->objs->bb.min[Y];
	obj->bb.max[Y] = ostackp->objs->bb.max[Y];

	obj->bb.min[Z] = ostackp->objs->bb.min[Z];
	obj->bb.max[Z] = ostackp->objs->bb.max[Z];

	for (o = ostackp->objs; o != (object *)NULL; o = o->nxt)
		adjustbbox(&obj->bb, o);

	gr->bb = obj->bb;

	gr->deltax = (gr->bb.max[X] - gr->bb.min[X]) / xdiv;
	gr->deltay = (gr->bb.max[Y] - gr->bb.min[Y]) / ydiv;
	gr->deltaz = (gr->bb.max[Z] - gr->bb.min[Z]) / zdiv;

	/*
	 * allocate the space for the grid.
	 */
	gr->voxs = (voxel ****)smalloc(sizeof(voxel ***) * xdiv);
	for (i = 0; i != xdiv; i++) {
		gr->voxs[i] = (voxel ***)smalloc(sizeof(voxel **) * ydiv);
		for (j = 0; j != ydiv; j++) {
			gr->voxs[i][j] = (voxel **)smalloc(sizeof(voxel *) * zdiv);
			for (k = 0; k != zdiv; k++)
				gr->voxs[i][j][k] = (voxel *)NULL;
		}
	}

	gr->xdiv = xdiv;
	gr->ydiv = ydiv;
	gr->zdiv = zdiv;

	/*
	 * insert the objects into the grid.
	 */
	for (o = ostackp->objs; o != (object *)NULL; o = o->nxt) {
		mini = (o->bb.min[X] - gr->bb.min[X]) / gr->deltax;
		maxi = (o->bb.max[X] - gr->bb.min[X]) / gr->deltax;
		if (maxi == gr->xdiv)
			maxi = gr->xdiv - 1;
		minj = (o->bb.min[Y] - gr->bb.min[Y]) / gr->deltay;
		maxj = (o->bb.max[Y] - gr->bb.min[Y]) / gr->deltay;
		if (maxj == gr->ydiv)
			maxj = gr->ydiv - 1;
		mink = (o->bb.min[Z] - gr->bb.min[Z]) / gr->deltaz;
		maxk = (o->bb.max[Z] - gr->bb.min[Z]) / gr->deltaz;
		if (maxk == gr->zdiv)
			maxk = gr->zdiv - 1;
		for (i = mini; i <= maxi; i++)
			for (j = minj; j <= maxj; j++)
				for (k = mink; k <= maxk; k++) {
					if (gr->voxs[i][j][k] == (voxel *)NULL) {
						vox = gr->voxs[i][j][k] = (voxel *)smalloc(sizeof(voxel));
						vox->oblist = (olist *)NULL;
						vox->bb.min[X] = gr->bb.min[X] + i * gr->deltax;
						vox->bb.max[X] = vox->bb.min[X] + gr->deltax;
						vox->bb.min[Y] = gr->bb.min[Y] + j * gr->deltay;
						vox->bb.max[Y] = vox->bb.min[Y] + gr->deltay;
						vox->bb.min[Z] = gr->bb.min[Z] + k * gr->deltaz;
						vox->bb.max[Z] = vox->bb.min[Z] + gr->deltaz;

					}
					ol = (olist *)smalloc(sizeof(olist));
					ol->obj = o;
					ol->nxt = gr->voxs[i][j][k]->oblist;
					gr->voxs[i][j][k]->oblist = ol;
				}

	}

	/*
	 * pop stack and add grid.
	 */
	ostackp = ostackp->lst;

	obj->nxt = ostackp->objs;
	ostackp->objs = obj;
}

/*
 * gridtabinit
 *
 *	set the table of function pointers for a grid.
 */
gridtabinit(intersects, normals, checkbbox, selfshadowing)
	int	(*intersects[])();
	void	(*normals[])();
	int	checkbbox[];
	int	selfshadowing[];
{
	normals[GRIDOBJ] = (void (*)())NULL;
	intersects[GRIDOBJ] = gridi;
	checkbbox[GRIDOBJ] = RT_TRUE;
	selfshadowing[GRIDOBJ] = RT_TRUE;
}
