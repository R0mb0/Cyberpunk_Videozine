/****************************************************************************
    VoglePM - A VOGLE/VOGL driver for OS/2 Presentation Manager
****************************************************************************/

#define VOGLEPM_VERSION         "1.02"
#define VOGLEPM_DATE            __DATE__
#define VOGLEPM_FULLVERSION     VOGLEPM_VERSION " (" VOGLEPM_DATE ")"

#ifdef VOGL
 #define VOGLE_TEXT          "VOGL"
#else
 #define VOGLE_TEXT          "VOGLE"
#endif

// Resource ID's

// To prevent the default icon from being written, define RID_FRAME
// as 100 instead of 1.
#define RID_FRAME       1
#define RID_ABOUTDLG    200

