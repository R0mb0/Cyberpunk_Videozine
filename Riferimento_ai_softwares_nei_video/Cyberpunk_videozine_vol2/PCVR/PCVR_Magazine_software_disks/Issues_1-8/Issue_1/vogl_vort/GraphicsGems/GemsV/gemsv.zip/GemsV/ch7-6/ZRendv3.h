/* Accurate Rendering Algorithm Based on the Z-Buffer Algorithm
   Developed by Raghu Karinthi
                West Virginia University
		Department of Computer Science
		P.O.Box 6330
		Morgantown WV 26506-6330
		raghu@cs.wvu.edu
                Version 3  01/20/95  */

#include <stdio.h>
#include <time.h>
#include <math.h>
#include "matrix/mat3.h"
#ifndef NOLUG 
#include "lug/lug.h"
#include "lug/lugfnts.h"
#define DEFAULTOUT "a.tga"
#else
#define DEFAULTOUT "a.im"
#endif

/* Constants for Fixpoint Arithmetic */
/* Requires: LOBITS to be divisible by 2, HIBITS<=16, and LOBITS <=16. */

#define HIBITS                        15
#define LOBITS                        14

#ifndef TRUE
#define TRUE                          1
#endif

#ifndef FALSE
#define FALSE                         0
#endif

#define LOMASK       (~(0xffffffff << LOBITS))
#define HIMASK       ((~(0xffffffff << HIBITS)) << LOBITS)
#define FIX1         (1 << LOBITS)
#define LOCMASK      (0xffffffff << LOBITS)

typedef int fixpoint;

/* NFF Parser constants */

#define WAITING           0 
#define VIEWING           1
#define TRIDATA           2

#ifndef CLOCKS_PER_SEC
#define CLOCKS_PER_SEC    1000000.0 /* Timing Constant */
#endif

/* Renderer Constants */

#define NUM_TRIANGLES     500
#define X                 0
#define Y                 1
#define Z                 2

#define WINDOW_WIDTH      500
#define WINDOW_HEIGHT     500

#define MAX_INTENSITY     256
#define NUM_LIGHT_SOURCES 4
#define BW_DEPTH          8
#define COLOR_DEPTH       (3*BW_DEPTH)


typedef MAT3vec Point; /* Point Type */

typedef unsigned char color;  /* Framebuffer Color */

typedef fixpoint fcolor;  /* Vertex Color */

typedef struct Color_Vertex_struct {
  Point vertex;
  fcolor red, green, blue;
  MAT3vec normal;
} Color_Vertex;

typedef struct FrameBuffer_Entry_struct {
  color red, green, blue;
  fixpoint z;
} FrameBuffer_Entry;
typedef FrameBuffer_Entry *FrameBuffer_EntryP;
typedef FrameBuffer_Entry FrameBuffer[WINDOW_WIDTH][WINDOW_HEIGHT];

typedef struct _triangle {
  Color_Vertex vertices[3];
  unsigned char accept;
} Triangle;
typedef Triangle *InDataSet;

typedef struct BackgroundColor_struct {
  color red, green, blue;
} BackGroundColor;

typedef struct LightPoint_struct {
  Point location;
  double red, green, blue; 
} LightPoint;
typedef LightPoint *Lights;

typedef struct MtlProperties_struct {
  double red, green, blue, diffuseK, ambientK, c1, c2;
} MtlProp;

typedef union fix_dbl_union {
  unsigned int i[2];
  double d;
} fix_dbl;

