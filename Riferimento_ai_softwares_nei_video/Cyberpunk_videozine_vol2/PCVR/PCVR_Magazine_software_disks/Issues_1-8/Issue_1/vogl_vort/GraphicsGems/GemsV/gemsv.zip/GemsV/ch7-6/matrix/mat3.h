/* Copyright 1991, Brown Computer Graphics Group.  All Rights Reserved. */

#include <math.h>
#include <stdlib.h>
#include <string.h>

#define MAT3_EPSILON	1e-12			/* Close enough to zero   */
#define MAT3_PI 	M_PI			/* Pi			  */

typedef double MAT3mat[4][4];		/* 4x4 matrix			 */
typedef double MAT3vec[3];		/* Vector			 */
typedef double MAT3hvec[4];             /* Vector with homogeneous coord */

#define MAT3_IS_ZERO(N) 	((N) < MAT3_EPSILON && (N) > -MAT3_EPSILON)

/*
 * TITLE   :	Vector operations
 * RETURNS :	void
 */

#define MAT3_SET_VEC(RESULT_V,X,Y,Z)	\
        ((RESULT_V)[0]=(X), (RESULT_V)[1]=(Y), (RESULT_V)[2]=(Z))

#define MAT3_COPY_VEC(TO,FROM)	((TO)[0] = (FROM)[0], \
				 (TO)[1] = (FROM)[1], \
				 (TO)[2] = (FROM)[2])

/*
 * TITLE   :
 * DESCR   :	Basic operations on vector @V@, that modify vector
 *		@RESULT_V@.
 *
 */

#define MAT3_SCALE_VEC(RESULT_V,V,SCALE) \
	MAT3_SET_VEC(RESULT_V, (V)[0]*(SCALE), (V)[1]*(SCALE), (V)[2]*(SCALE))

#define MAT3_ADD_VEC(RESULT_V,V1,V2) \
	MAT3_SET_VEC(RESULT_V, (V1)[0]+(V2)[0], (V1)[1]+(V2)[1], \
			       (V1)[2]+(V2)[2])

#define MAT3_SUB_VEC(RESULT_V,V1,V2) \
	MAT3_SET_VEC(RESULT_V, (V1)[0]-(V2)[0], (V1)[1]-(V2)[1], \
			       (V1)[2]-(V2)[2])

/*
 * TITLE   :
 * DESCR   :	More  complex operations on multiple vectors
 *
 */

/*
 * DESCR   :	Compute dot product of 3-vectors @V1@ and @V2@
 * RETURNS :	double
 */
#define MAT3_DOT_PRODUCT(V1,V2) \
			((V1)[0]*(V2)[0] + (V1)[1]*(V2)[1] + (V1)[2]*(V2)[2])

/*
 * DESCR   :	Normalize the 3-vector @V@, using @TEMP@ as temporary variable.
 * DETAILS :	If the norm of @V@ is too close to zero, no normalization
 * 		takes place, and @TEMP@ is set to zero.
 */
#define MAT3_NORMALIZE_VEC(V,TEMP) \
	if ((TEMP = sqrt(MAT3_DOT_PRODUCT(V,V))) > MAT3_EPSILON) { \
	   TEMP = 1.0 / TEMP; \
	   MAT3_SCALE_VEC(V,V,TEMP); \
	} else TEMP = 0.0

/*
 * DESCR   :	Sets @RESULT_V@ to the linear combination of @V1@ and @V2@,
 * 		scaled by @SCALE1@ and @SCALE2@, respectively 
 */
#define MAT3_LINEAR_COMB(RESULT_V,SCALE1,V1,SCALE2,V2) \
	MAT3_SET_VEC(RESULT_V,	(SCALE1)*(V1)[0] + (SCALE2)*(V2)[0], \
				(SCALE1)*(V1)[1] + (SCALE2)*(V2)[1], \
				(SCALE1)*(V1)[2] + (SCALE2)*(V2)[2])

/*
 * TITLE   :	Homogeneous vector operations
 */

#define MAT3_SET_HVEC(V,X,Y,Z,W) ((V)[0]=(X), (V)[1]=(Y), \
				  (V)[2]=(Z), (V)[3]=(W))

#define MAT3_COPY_HVEC(TO,FROM) ((TO)[0] = (FROM)[0], \
				 (TO)[1] = (FROM)[1], \
				 (TO)[2] = (FROM)[2], \
				 (TO)[3] = (FROM)[3])

/* ------------------------------  Entries  ------------------------------- */

void MAT3scale(
         MAT3mat result_mat,		/* Scale matrix [output] */
         MAT3vec scale 			/* The entries for the diagonal */
);

void MAT3translate(
         MAT3mat result_mat,		/* Translation matrix [output] */
         MAT3vec trans			/* Translation vector [input]  */
);

void MAT3shear(
         register MAT3mat result_mat,	/* Shear matrix [output] */
         register MAT3vec normal,	/* Normal to the shear plane */
         register MAT3vec shear 	/* Shearing vector [perp to normal] */
);

void MAT3identity(
         MAT3mat m 			/* Matrix to be set to identity */
);

void MAT3zero(
         MAT3mat m 			/* Matrix to be set to zero */
);

void MAT3copy(
         MAT3mat t,			/* Target matrix [output] */
         MAT3mat f			/* Source matrix [input] */
);
void MAT3mult(
         MAT3mat result_mat,		/* Computed product [output] */
         MAT3mat mat1,			/* The first factor of the product */
         MAT3mat mat2 			/* The second factor of the product */
);

/* The ordering of "vec" and "mat" parameters in following three functions is
 * probably counterintuitive but is retained for backward compatibility.
 */

int MAT3mult_hvec(
         MAT3hvec          result_vec,	/* Product of vec with mat (output) */
         register MAT3hvec vec,		/* Vector to multiply (input) */
         register MAT3mat  mat,		/* Matrix to multiply (input) */
         int               homogenize	/* Should we homogenize the result? */
);

void MAT3cross_product(
         MAT3vec 	 result_vec,	/* Computed cross-product (output) */
         register MAT3vec vec1,		/* The first factor (input) */
         register MAT3vec vec2 		/* The second factor (input) */
);
