poly3d-r -z
poly3d-r -s 350 350 -a 0.2 -l 1 2 7 -c 5 -2 cube.dat > cube-old.gif
poly3d-r -s 350 350 -a 0.2 -l 1 2 7 -c 5 -2 -S 3 cube.dat > cube.gif
poly3d-r -s 640 400 -g -b -l 1 3 7 -S 3 solid1.dat > solid1.gif
poly3d-r -s 640 400 -g -b -l 1 0 0 -a 0.0 -S 3 solid2.dat > solid2.gif
poly3d-r -s 640 400 -b -M mask3.gif -a 0.1 -S 3 solid3.dat > solid3.gif
poly3d-r -s 640 400 -g -a 0.1 -S 3 -F 2 0.03 saddle.dat > saddle.gif
