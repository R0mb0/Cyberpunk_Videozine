/*****************************************************************************
*   Determines visibility of curves using SGI's Z buffer.		     *
*									     *
* Written by:  Gershon Elber				Ver 0.1, June 1993.  *
*****************************************************************************/

#ifndef ZBUFCRVS_H
#define ZBUFCRVS_H

extern RealType GlblWidthScale;

#endif /* ZBUFCRVS_H */
