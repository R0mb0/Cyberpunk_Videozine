#
# examples makefile 
#
PEXAMPS = ptrivial psimple pshapes ppoly pviews pcirctxt pmoretxt pcurves \
	  pgetstr ppatches pballs pobjvws pworld ploc ptetra pcube \
	  plcube pjtext plstyles

POBJS = ptrivial.o psimple.o pshapes.o ppoly.o pviews.o pcirctxt.o pmoretxt.o \
	pgetstr.o pcurves.o ppatches.o pballs.o pobjvws.o pworld.o ploc.o \
	ptetra.o pcube.o plcube.o pjtext.o plstyles.o

#
# Where to find library
LIB = ../src/libvogle.a
LIBS = -lsuntool -lsunwindow -lpixrect
#
PAS = pc

#
# The -I is so we can include Vogle.h
#
MPFLAGS = -g -f68881 
PFLAGS = $(MPFLAGS) -I../src/sunpas

.p.o:
	$(PAS) -c $(PFLAGS) $*.p

all:	$(PEXAMPS)

$(PEXAMPS): $(POBJS) $(LIB)
	$(PAS) $(PFLAGS) -o $@ $@.o $(LIB) $(LIBS) 

clean:
	rm -f *.o core

clobber:
	rm -f $(PEXAMPS) *.o core
