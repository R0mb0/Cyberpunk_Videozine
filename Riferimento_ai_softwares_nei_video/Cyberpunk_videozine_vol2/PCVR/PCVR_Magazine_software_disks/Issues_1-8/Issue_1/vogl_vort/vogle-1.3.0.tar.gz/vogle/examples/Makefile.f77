#
# examples makefile 
#
FEXAMPS = ftrivial fsimple fshapes fpoly fviews fcirctxt fmoretxt fcurves \
	  fjtext fgetstr fpatches fballs fobjvws fworld floc ftetra fcube \
	  flcube flstyles

FOBJS = ftrivial.o fsimple.o fshapes.o fpoly.o fviews.o fcirctxt.o fmoretxt.o \
	fjtext.o fgetstr.o fcurves.o fpatches.o fballs.o fobjvws.o fworld.o floc.o \
	ftetra.o fcube.o flcube.o flstyles.o

#
# Where to find library
LIB = ../src/libvogle.a
LIBS = -lsuntool -lsunwindow -lpixrect
#
F77 = f77

MFFLAGS = -g -f68881 /usr/lib/f77/f68881/libm.il
FFLAGS = $(MFFLAGS) -C

.f.o:
	$(F77) -c $(FFLAGS) $*.f

all:	$(FEXAMPS)

$(FEXAMPS): $(FOBJS) $(LIB)
	$(F77) $(FFLAGS) -o $@ $@.o $(LIB) $(LIBS) 

clean:
	rm -f *.o core

clobber:
	rm -f $(FEXAMPS) *.o core
