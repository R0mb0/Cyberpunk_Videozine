#include <stdio.h>
#include "vogle.h"

/*
 * This should match the Pascal type 'varying [n] of char'
 */

typedef struct {
	int	n;
	char	s[1];	/* SO compiler doesn't bitch about zero length */
} Vstring;

#define COPYANDTERMINATE(buf, s, l)	strncpy(buf, s, l); buf[l] = '\0';

/*
 * MakeObj
 */
void
MakeObj(n)
	int	n;
{
	makeobj(n);
}

/*
 * CloseObj
 */
void
CloseObj()
{
	closeobj();
}

/*
 * DelObj
 */
void
DelObj(n)
	int	n;
{
	delobj(n);
}

/*
 * GenObj
 */
int
GenObj()
{
	return(genobj());
}

/*
 * GetOpenObj
 */
int
GetOpenObj()
{
	return(getopenobj());
}

/*
 * CallObj
 */
void
CallObj(n)
	int	n;
{
	callobj(n);
}

/*
 * IsObj
 */
int
IsObj(n)
	int	n;
{
	return(isobj(n));
}

/*
 * SaveObj
 */
void
SaveObj(n, s)
	int	n;
	Vstring	s;
{
	char	*p = (char *)s.s;
	char	buf[BUFSIZ];

        COPYANDTERMINATE(buf, p, s.n);

	saveobj(n, buf);
}

/*
 * LoadObj
 */
void
LoadObj(n, s)
	int	n;
	Vstring	s;
{
	char	*p = (char *)s.s;
	char	buf[BUFSIZ];

        COPYANDTERMINATE(buf, p, s.n);

	loadobj(n, buf);
}

