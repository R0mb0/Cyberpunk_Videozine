#include "vogle.h"

/*
 * pushviewport_
 */
void
pushviewport_()
{
	pushviewport();
}

/*
 * popviewport_
 */
void
popviewport_()
{
	popviewport();
}

/*
 * viewport_
 */
void
viewport_(xlow, xhigh, ylow, yhigh)
	float	*xlow, *ylow, *xhigh, *yhigh;
{
	viewport(*xlow, *xhigh, *ylow, *yhigh);
}

/*
 * getviewport_
 */
void
getviewport_(left, right, bottom, top)
	float	*left, *right, *bottom, *top;
{
	getviewport(left, right, bottom, top);
}

