#include "vogle.h"

/*
 * getaspect_
 */
float
getaspect_()
{
	return(getaspect());
}

/*
 * getfactors_
 */
void
getfactors_(xr, yr)
	float	*xr, *yr;
{
	getfactors(xr, yr);
}

/*
 * getdisplaysize_
 */
void
getdisplaysize_(xs, ys)
	float	*xs, *ys;
{
	getdisplaysize(xs, ys);
}

/*
 * expandviewport_
 */
void
expandviewport_()
{
	expandviewport();
}

/*
 * unexpandviewport_
 */
void
unexpandviewport_()
{
	unexpandviewport();
}
