#include <stdio.h>
#include "vogle.h"

typedef struct {
	int     n;
	char    s[1];   /* SO compiler doesn't bitch about zero length */
} Vstring;

#define COPYANDTERMINATE(buf, s, l)	strncpy(buf, s, l); buf[l] = '\0';

/*
 * SetDash
 */
void
SetDash(d)
	float	d;
{
	setdash(d);
}


/*
 * LineStyle
 */
void
LineStyle(l)
        Vstring l;
{
        char    *p = (char *)l.s;
        char    buf[BUFSIZ];

        COPYANDTERMINATE(buf, p, l.n);
        linestyle(buf);
}

/*
 * Draw
 */
void
Draw(x, y, z)
	float	x, y, z;
{
	draw(x, y, z);
}

/*
 * Draw2
 */
void
Draw2(x, y)
	float	x, y;
{
	draw2(x, y);
}

/*
 * Rdraw
 */
void
Rdraw(dx, dy, dz)
	float	dx, dy, dz;
{
	rdraw(dx, dy, dz);
}

/*
 * Rdraw2
 */
void
Rdraw2(dx, dy)
	float	dx, dy;
{
	rdraw2(dx, dy);
}

/*
 * Sdraw2
 */
void
Sdraw2(xs, ys)
	float 	xs, ys;
{
	sdraw2(xs, ys);
}

/*
 * Rsdraw2
 */
void
Rsdraw2(dxs, dys)
	float	dxs, dys;
{
	rsdraw2(dxs, dys);
}
