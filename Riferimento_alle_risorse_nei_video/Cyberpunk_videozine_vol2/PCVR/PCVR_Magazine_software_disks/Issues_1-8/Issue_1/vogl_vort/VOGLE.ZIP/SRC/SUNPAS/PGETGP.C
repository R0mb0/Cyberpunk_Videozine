#include "vogle.h"

/*
 * GetGp
 */
void
GetGp(x, y, z)
	double	*x, *y, *z;
{
	float	a, b, c;
	getgp(&a, &b, &c);

	*x = a;
	*y = b;
	*z = c;
}

/*
 * GetGpT
 */
void
GetGpT(x, y, z, w)
	double	*x, *y, *z, *w;
{
	float	a, b, c, d;
	getgpt(&a, &b, &c, &d);

	*x = a;
	*y = b;
	*z = c;
	*w = d;
}

/*
 * GetGp2
 */
void
GetGp2(x, y)
	double	*x, *y;
{
	float	a, b;
	getgp2(&a, &b);

	*x = a;
	*y = b;
}

/*
 * SgetGp2
 */
void
Sgetgp2(x, y)
	double	*x, *y;
{
	float	a, b;

	sgetgp2(&a, &b);

	*x = a;
	*y = b;
}
