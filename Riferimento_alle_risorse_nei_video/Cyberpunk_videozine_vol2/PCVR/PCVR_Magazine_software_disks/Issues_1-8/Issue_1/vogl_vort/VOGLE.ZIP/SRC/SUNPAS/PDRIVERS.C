#include <stdio.h>
#include "vogle.h"

/*
 * This should match the Pascal type 'varying [n] of char'
 */

typedef struct {
	int	n;
	char	s[1];	/* SO compiler doesn't bitch about zero length */
} Vstring;

#define COPYANDTERMINATE(buf, s, l)	strncpy(buf, s, l); buf[l] = '\0';

/*
 * Voutput
 */
void
Voutput(s)
	Vstring	s;
{
	char	*p = (char *)s.s;
	char	buf[BUFSIZ];

        COPYANDTERMINATE(buf, p, s.n);
	voutput(buf);
}

/*
 * Vinit
 */
void
Vinit(s)
	Vstring	s;
{
	char	*p = (char *)s.s;
	char	buf[BUFSIZ];

        COPYANDTERMINATE(buf, p, s.n);
        vinit(buf);
}

/*
 * VnewDev
 */
void
VnewDev(s)
	Vstring	s;
{
	char	*p = (char *)s.s;
	char	buf[BUFSIZ];

        COPYANDTERMINATE(buf, p, s.n);
	vnewdev(buf);
}

/*
 * VgetDev
 */
void
VgetDev(s)
	Vstring	*s;
{
	char	*p = (char *)s->s;

	(void)vgetdev(p);

	s->n = strlen(p);
}

/*
 * PushDev
 */
void
PushDev(s)
	Vstring	s;
{
	char	*p = (char *)s.s;
	char	buf[BUFSIZ];

        COPYANDTERMINATE(buf, p, s.n);
	pushdev(buf);
}

/*
 * PopDev
 */
void
PopDev()
{
	popdev();
}
	
/*
 * Vexit
 */
void
Vexit()
{
	vexit();
}

/*
 * VsetFlush
 */
void
VsetFlush(i)
	int	i;
{
	vsetflush(i);
}
/*
 * Vflush
 */
void
Vflush()
{
	vflush();
}

/*
 * Clear
 */
void
Clear()
{
	clear();
}

/*
 * Color
 */
void
Color(col)
	int	col;
{
	color(col);
}

/*
 * MapColor
 */
void
MapColor(indx, red, green, blue)
	int	indx, red, green, blue;
{
	mapcolor(indx, red, green, blue);
}

/*
 * GetKey
 */
int
GetKey()
{
	return(getkey());
}

/*
 * CheckKey
 */
int
CheckKey()
{
	return(checkkey());
}

/*
 * GetDepth
 */
int
GetDepth()
{
	return(getdepth());
}

/*
 * Locator
 */
int
Locator(xaddr, yaddr)
	double	*xaddr, *yaddr;
{
	float	x, y;
	int	i;

	i = locator(&x, &y);

	*xaddr = x;
	*yaddr = y;

	return(i);
}

/*
 * Slocator
 */
int
Slocator(xaddr, yaddr)
	double	*xaddr, *yaddr;
{
	float	x, y;
	int	i;

	i = slocator(&x, &y);

	*xaddr = x;
	*yaddr = y;

	return(i);
}
