#include "vogle.h"

/*
 * GetAspect
 */
float
GetAspect()
{
	return(getaspect());
}

/*
 * GetFactors
 */
GetFactors(xr, yr)
	float	*xr, *yr;
{
	getfactors(xr, yr);
}

/*
 * GetDisplaySize
 */
GetDisplaySize(xs, ys)
	float	*xs, *ys;
{
	getdisplaysize(xs, ys);
}

/*
 * ExpandViewport
 */
float
ExpandViewport()
{
	expandviewport();
}

/*
 * UnExpandViewport
 */
float
UnExpandViewport()
{
	unexpandviewport();
}
