/*search.c*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SWISH_EXEC   "/usr/local/swish/swish"

/*---------------------------------------------------------------------------*/
static void seiPrintHeader(void)
{
  printf("<html>\n<head>\n");
  printf("<title>Search Results</title>\n");
printf("<body background=../decr/bldng6.gif color=black link=\"#112288\" vlink=red>\n");

  /*printf("<body bgcolor=\"#000000\" text=\"#ff00ff\" link=\"#00ff80\" vlink=\"#8080ff\" alink=\"#00ff80\">\n");*/
  printf("<h2>Search Results</h2>\n");

} /* seiPrintHeader */

/*---------------------------------------------------------------------------*/
static void seiPrintFooter(char *returnURL)
{
  printf("<p>\n<hr>\n");
  printf("<a href=\"%s\">Search Again</a>\n", returnURL);
  printf("</body>\n");
  printf("</head>\n</html>\n");

} /* seiPrintFooter */

/*---------------------------------------------------------------------------*/
static int seiHexToDecimal(char first, char second)
{
  int value;

  first = tolower(first); 
  second = tolower(second); 

  switch (first) {
    case '0':  value = 16 * 0;  break;
    case '1':  value = 16 * 1;  break;
    case '2':  value = 16 * 2;  break;
    case '3':  value = 16 * 3;  break;
    case '4':  value = 16 * 4;  break;
    case '5':  value = 16 * 5;  break;
    case '6':  value = 16 * 6;  break;
    case '7':  value = 16 * 7;  break;
    case '8':  value = 16 * 8;  break;
    case '9':  value = 16 * 9;  break;
    case 'a':  value = 16 * 10;  break;
    case 'b':  value = 16 * 11;  break;
    case 'c':  value = 16 * 12;  break;
    case 'd':  value = 16 * 13;  break;
    case 'e':  value = 16 * 14;  break;
    case 'f':  value = 16 * 15;  break;
  }
  switch (second) {
    case '0':  value += 0;  break;
    case '1':  value += 1;  break;
    case '2':  value += 2;  break;
    case '3':  value += 3;  break;
    case '4':  value += 4;  break;
    case '5':  value += 5;  break;
    case '6':  value += 6;  break;
    case '7':  value += 7;  break;
    case '8':  value += 8;  break;
    case '9':  value += 9;  break;
    case 'a':  value += 10;  break;
    case 'b':  value += 11;  break;
    case 'c':  value += 12;  break;
    case 'd':  value += 13;  break;
    case 'e':  value += 14;  break;
    case 'f':  value += 15;  break;
  }

  return(value);

} /* seiHexToDecimal */

/*---------------------------------------------------------------------------*/
static void seiReadNameValuePair(char *thestring, char *thevalue)
{
  char *cptr = NULL, *endcptr = NULL;

  cptr = strstr(thestring, "=");
  cptr++;
  endcptr = strstr(thestring, "&");
  if (endcptr) {
    endcptr++;
    endcptr[-1] = '\0';
  }

    /* copy the value of before the original string gets overwritten */
  strcpy(thevalue, cptr);

  if (endcptr)
    strcpy(thestring, endcptr);

} /* seiReadNameValuePair */

/*---------------------------------------------------------------------------*/
static int seiReadString(char *thestring, char *substring)
{
  int len;
  char *cptr = NULL;

  if (thestring[0] == '"') {
    len = strlen(thestring);
    cptr = &thestring[len-1];
    while (cptr[0] != ' ')
      cptr--;
  }
  else {
    cptr = strstr(thestring, " ");
  }
  cptr[0] = '\0';
  cptr++;
  strcpy(substring, thestring);
  strcpy(thestring, cptr);

} /* seiReadString */

/*---------------------------------------------------------------------------*/
void main(void)
{
  char swishindex[256], keywords[512], maxresults[64];
  char returnURL[1000], command[1000], thestring[2000];
  char substring1[2000], substring2[2000], substring3[2000]; 
  char *output = NULL, *cptr = NULL, *ncptr = NULL, *tempcptr;
  int numchar = 10000, character;
  int len, index, nindex, spacecount, done;
  FILE *fp = NULL;
  FILE *spew = NULL;

	returnURL[0] = 0;

	spew = fopen("/tmp/spew", "w");
	fprintf(spew, "begin search\n"); fflush(spew);

    /* print header */
  printf("Content-type: text/html%c%c",10,10);
  fflush(stdout);
  seiPrintHeader();

	fprintf(spew, "header done\n"); fflush(spew);

  sprintf(thestring, "%s", getenv("QUERY_STRING"));
	fprintf(spew, "thestring %s\n", thestring); fflush(spew);
	if (cptr = getenv("PATH_INFO")) {
		  sprintf(returnURL, "%s", cptr);
		fprintf(spew, "returnURL %s\n", returnURL); fflush(spew);
		cptr = NULL;
	}


  nindex = 0;
  len = strlen(thestring);
  for (index = 0; index < len; index++) {
    if (thestring[index] == '+') {
      thestring[nindex++] = ' ';
    }
    else if (thestring[index] == '%') {
        /* convert hex to decimal */
      thestring[nindex++] = (char)seiHexToDecimal(thestring[index+1],
                                                  thestring[index+2]); 
      index+=2;
    }
    else {
      thestring[nindex++] = thestring[index];
    }
  }
  thestring[nindex] = '\0';

       /* the order on the search form must remain constant:
          swishindex, keywords, maxresults */
  seiReadNameValuePair(thestring, swishindex);
  strcpy(keywords, "__NOT_DEFINED__");
  seiReadNameValuePair(thestring, keywords);
  if (strcmp(keywords, "__NOT_DEFINED__")) {
    strcpy(maxresults, "__NOT_DEFINED__");
    seiReadNameValuePair(thestring, maxresults);

      /* build the swish command */
    if (!strcmp(maxresults, "__NOT_DEFINED__"))
      sprintf(command, "%s -f %s -w %s", SWISH_EXEC, swishindex, keywords);
    else
      sprintf(command, "%s -f %s -w %s -m %s", SWISH_EXEC, 
              swishindex, keywords, maxresults);

    index = 0;
    output = (char *)malloc(numchar * sizeof(char)); 

      /* open up a pipe to the swish command */
    fp = popen(command, "r");
    character = fgetc(fp);
    while (character != EOF) {
      output[index++] = (char)character;
      if (index == numchar) {
        numchar *= 2;
        output = (char *)realloc(output, numchar * sizeof(char)); 
      }
      character = fgetc(fp);
    }
    pclose(fp);

      /* parse through the output line by line */
    done = 0;
    cptr = output;
    while (cptr && !done) {
      ncptr = strstr(cptr, "\n"); 
      if (ncptr)
        ncptr[0] = '\0';

        /* results of swish can be-
            line beginning with "#"
            line beginning with "."
            line beginning with "err"
            line beginning with "search words:"
            line beginning with relevance rank */
      if (cptr[0] == '#') {
          /* do something with comments? */
      }
      else if (cptr[0] == '.') {
        done = 1;
      }
      else if (!strncmp(cptr, "err", 3)) {
        printf("<h4>%s</h4>\n", cptr); 
      }
      else if (!strncmp(cptr, "search words:", 13)) {
        printf("<h3>%s</h3>\n", cptr); 
      }
      else {
        strcpy(thestring, cptr);
        seiReadString(thestring, substring1);
        seiReadString(thestring, substring2);
        seiReadString(thestring, substring3);
        fprintf(spew, "%s <a href = \"%s\">%s</a> (%s bytes)<br>\n", 
                substring1, &substring2[1], substring3, thestring); fflush(spew);
        printf("%s <a href = \"%s\">%s</a> (%s bytes)<br>\n", 
                substring1, substring2, substring3, thestring);
      }
      cptr = ncptr;
      if (cptr)
        cptr++;
    }
  }
  else {
      /* no keywords */
    printf("Please specify keywords to perform search.<br>\n");
    printf("__________________________________________<p>\n");
    printf("search example 1: john and doe or jane<br>\n");
    printf("search example 2: john and (doe or jane)<br>\n");
    printf("search example 3: not (john or jane) and doe<br>\n");
    printf("search example 4: j* and doe<br>\n");
  }

	if (returnURL[0])
	  seiPrintFooter(returnURL);

  if (output) {
    free(output);
    output = NULL;
  }

} /* main */

/*---------------------------------------------------------------------------*/
/* eof */

