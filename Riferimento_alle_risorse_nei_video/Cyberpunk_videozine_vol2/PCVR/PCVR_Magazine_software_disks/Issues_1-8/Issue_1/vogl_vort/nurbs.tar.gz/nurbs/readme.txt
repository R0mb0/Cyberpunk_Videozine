A copy of the manual should be built first.
This requires that your system has latex, bibtex and idxtex.

For VMS systems you should type

$ @makefile docs

For UNIX systems you should type

% make docs

NOTE:
----
A postscrpt version of the documentation also exists in the documents
directory, docs and this is called nurbclib.ps
