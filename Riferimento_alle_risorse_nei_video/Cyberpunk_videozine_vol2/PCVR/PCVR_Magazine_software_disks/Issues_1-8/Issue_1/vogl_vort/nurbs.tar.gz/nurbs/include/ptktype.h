#ifndef _PTKTYPE_
#define _PTKTYPE_

typedef unsigned char boolean;

#define FALSE 0
#define TRUE 1

#define MAX(a, b) (((a) > (b)) ? (a) : (b))
#define MIN(a, b) (((a) < (b)) ? (a) : (b))

#endif

/* end of ptktype.h */
