#
# This is the make file for the bool_lib library.
#
#				Gershon Elber, Aug 1990
#

include ../makeflag.sas

OBJS =  adjacncy.o bool-hi.o bool1low.o bool2low.o bool-2d.o

all:	bool.lib

bool.lib: $(OBJS)
	rm -f bool.lib
	oml bool.lib a $(OBJS)

install: bool.lib
	mv -f bool.lib $(LIB_DIR)


# DO NOT DELETE THIS LINE -- make depend depends on it.

adjacncy.o: ../include/irit_sm.h ../include/allocate.h ../include/iritprsr.h
adjacncy.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
adjacncy.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
adjacncy.o: ../include/triv_lib.h bool_loc.h ../include/bool_lib.h
bool-2d.o: ../include/irit_sm.h ../include/allocate.h ../include/iritprsr.h
bool-2d.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
bool-2d.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
bool-2d.o: ../include/triv_lib.h bool_loc.h ../include/bool_lib.h
bool-2d.o: ../include/convex.h ../include/geomat3d.h ../include/intrnrml.h
bool-hi.o: ../include/irit_sm.h ../include/allocate.h ../include/iritprsr.h
bool-hi.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
bool-hi.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
bool-hi.o: ../include/triv_lib.h ../include/attribut.h bool_loc.h
bool-hi.o: ../include/bool_lib.h ../include/convex.h ../include/poly_cln.h
bool-hi.o: ../include/geomat3d.h
bool1low.o: ../include/irit_sm.h ../include/allocate.h ../include/iritprsr.h
bool1low.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
bool1low.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
bool1low.o: ../include/triv_lib.h bool_loc.h ../include/bool_lib.h
bool1low.o: ../include/geomat3d.h
bool2low.o: ../include/irit_sm.h ../include/allocate.h ../include/iritprsr.h
bool2low.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
bool2low.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
bool2low.o: ../include/triv_lib.h bool_loc.h ../include/bool_lib.h
bool2low.o: ../include/convex.h ../include/geomat3d.h ../include/intrnrml.h
