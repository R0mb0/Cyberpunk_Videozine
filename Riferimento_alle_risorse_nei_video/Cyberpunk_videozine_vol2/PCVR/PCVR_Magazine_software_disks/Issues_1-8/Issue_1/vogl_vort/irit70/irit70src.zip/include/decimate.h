/******************************************************************************
* Decimate.c - An implementation of modified Schroeder's decimation algorithm *
*******************************************************************************
* (C) Gershon Elber, Technion, Israel Institute of Technology                 *
*******************************************************************************
* Written by:  Olga Tebeleva                           Ver 1.0, May. 1996     *
******************************************************************************/

#ifndef DECIMATE_H
#define DECIMATE_H

#include "iritprsr.h"
#include "allocate.h"

#if defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif

IPObjectStruct *DecimateObject(IPObjectStruct *);
void DecimateObjSetDistParam(RealType);
void DecimateObjSetPassNumParam(int);
void DecimateObjSetDcmRatioParam(int);
void DecimateObjSetMinAspRatioParam(RealType);

#if defined(__cplusplus) || defined(c_plusplus)
}
#endif

#endif /* DECIMATE_H */
