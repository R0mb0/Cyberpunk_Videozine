* X11 mononcrome support,    petern@bion.kth.se          (Peter Nordlund).
* IRIT2SCN filter,           acc@asterix.inescn.pt       (Antonio Costa).
* Amiga port,		     kyrimis@cti.gr              (Kriton Kyrimis)
* X11/Motif		     				 (Offer Kaufman)
* Animation curves	     				 (Zvika Zilbermann and
							  Haggay Dagan)
* Animation Motif interface  				 (Iris Steinvarts)
* WHILE loop clause	     gever@monk.colossal.com     (Gever Tulley)
* Updated irit.el for emacs  mcg@mcg.math.waikato.ac.nz  (Martin Glanvill)
  dat2sen.c in contrib dir.
* irender		     mplav@cs.technion.ac.il	 (Michael Plavnik
							  Bassarb Dmitri)
