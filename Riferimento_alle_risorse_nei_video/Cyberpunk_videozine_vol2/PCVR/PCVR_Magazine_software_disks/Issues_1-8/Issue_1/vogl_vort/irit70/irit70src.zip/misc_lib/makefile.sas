#
# This is the make file for the misc. lib subdirectory.
#
#				Gershon Elber, Aug 1991
#

include ../makeflag.sas

OBJS =  config.o dist_pts.o genmat.o getarg.o \
	imalloc.o irit_ftl.o irit_wrn.o miscattr.o \
	miscatt2.o miscatt3.o priorque.o xgeneral.o

all:	misc.lib

misc.lib: $(OBJS)
	rm -f misc.lib
	oml misc.lib a $(OBJS)

install: misc.lib
	mv -f misc.lib $(LIB_DIR)

# DO NOT DELETE THIS LINE -- make depend depends on it.

config.o: ../include/irit_sm.h ../include/config.h ../include/imalloc.h
dist_pts.o: ../include/irit_sm.h ../include/imalloc.h ../include/dist_pts.h
genmat.o: ../include/irit_sm.h ../include/genmat.h
getarg.o: ../include/irit_sm.h ../include/getarg.h ../include/imalloc.h
imalloc.o: ../include/irit_sm.h ../include/imalloc.h
irit_ftl.o: ../include/irit_sm.h
irit_wrn.o: ../include/irit_sm.h
miscatt2.o: ../include/irit_sm.h ../include/imalloc.h ../include/miscattr.h
miscatt3.o: ../include/irit_sm.h ../include/imalloc.h ../include/miscattr.h
miscattr.o: ../include/irit_sm.h ../include/imalloc.h ../include/miscattr.h
priorque.o: ../include/irit_sm.h ../include/priorque.h ../include/imalloc.h
xgeneral.o: ../include/irit_sm.h ../include/imalloc.h
