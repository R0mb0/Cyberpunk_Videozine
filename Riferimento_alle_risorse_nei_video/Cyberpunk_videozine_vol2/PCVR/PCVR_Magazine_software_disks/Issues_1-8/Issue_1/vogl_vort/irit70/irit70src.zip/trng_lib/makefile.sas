#
# This is the make file for the trng_lib library.
#
#                               Gershon Elber, Aug 1990
#

include ../makeflag.sas

OBJS =  trng_aux.o trng_dbg.o trng_err.o trng_ftl.o trng_gen.o \
	trngcoer.o trngmesh.o trng_iso.o trng2ply.o trngeval.o \
	trng_der.o

all:	trng.lib

trng.lib: $(OBJS)
	rm -f trng.lib
	oml trng.lib a $(OBJS)

install: trng.lib
	mv -f trng.lib $(LIB_DIR)


# DO NOT DELETE THIS LINE -- make depend depends on it.
