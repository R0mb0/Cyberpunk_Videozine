#
# This is the make file for the prsr. lib subdirectory.
#
#				Gershon Elber, Aug 1991
#

include ../makeflag.sas

OBJS = allocate.o coerce.o iritprs1.o iritprs2.o iritprsb.o \
	attribut.o ip_cnvrt.o ip_fatal.o ip_procs.o soc_clnt.o \
	soc_srvr.o

all:	prsr.lib

RW_OBJS = cagdread.o cagd_wrt.o bsp_read.o bsp_wrt.o \
	bzr_read.o bzr_wrt.o mdl_read.o mdl_wrt.o trivread.o triv_wrt.o \
	trimread.o trim_wrt.o trngread.o trng_wrt.o

prsr.lib: $(OBJS) $(RW_OBJS)
	rm -f prsr.lib
	oml prsr.lib a $(OBJS) $(RW_OBJS)

install: prsr.lib
	mv -f prsr.lib $(LIB_DIR)

soc_srvr: soc_srvr.c
	$(CC) $(CFLAGS) -DDEBUG_SERVER -I. -I$(INC_DIR) -c soc_srvr.c
	$(CC) $(CFLAGS) -o soc_srvr soc_srvr.o $(LIBS) $(MORELIBS) -lm
	rm soc_srvr.o


# DO NOT DELETE THIS LINE -- make depend depends on it.

allocate.o: ../include/irit_sm.h ../include/iritprsr.h ../include/cagd_lib.h
allocate.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
allocate.o: ../include/symb_lib.h ../include/trim_lib.h ../include/triv_lib.h
allocate.o: ../include/allocate.h ../include/attribut.h
attribut.o: ../include/irit_sm.h ../include/iritprsr.h ../include/cagd_lib.h
attribut.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
attribut.o: ../include/symb_lib.h ../include/trim_lib.h ../include/triv_lib.h
attribut.o: ../include/attribut.h ../include/allocate.h
bsp_read.o: prsr_loc.h ../include/irit_sm.h ../include/iritprsr.h
bsp_read.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
bsp_read.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
bsp_read.o: ../include/triv_lib.h
bsp_wrt.o: prsr_loc.h ../include/irit_sm.h ../include/iritprsr.h
bsp_wrt.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
bsp_wrt.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
bsp_wrt.o: ../include/triv_lib.h
bzr_read.o: prsr_loc.h ../include/irit_sm.h ../include/iritprsr.h
bzr_read.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
bzr_read.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
bzr_read.o: ../include/triv_lib.h
bzr_wrt.o: prsr_loc.h ../include/irit_sm.h ../include/iritprsr.h
bzr_wrt.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
bzr_wrt.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
bzr_wrt.o: ../include/triv_lib.h
cagd_wrt.o: prsr_loc.h ../include/irit_sm.h ../include/iritprsr.h
cagd_wrt.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
cagd_wrt.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
cagd_wrt.o: ../include/triv_lib.h ../include/irit_soc.h ../include/allocate.h
cagdread.o: prsr_loc.h ../include/irit_sm.h ../include/iritprsr.h
cagdread.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
cagdread.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
cagdread.o: ../include/triv_lib.h
coerce.o: ../include/irit_sm.h ../include/iritprsr.h ../include/cagd_lib.h
coerce.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
coerce.o: ../include/symb_lib.h ../include/trim_lib.h ../include/triv_lib.h
coerce.o: ../include/allocate.h
ip_cnvrt.o: ../include/irit_sm.h prsr_loc.h ../include/iritprsr.h
ip_cnvrt.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
ip_cnvrt.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
ip_cnvrt.o: ../include/triv_lib.h ../include/allocate.h ../include/ip_cnvrt.h
ip_cnvrt.o: ../include/attribut.h
ip_fatal.o: ../include/irit_sm.h ../include/iritprsr.h ../include/cagd_lib.h
ip_fatal.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
ip_fatal.o: ../include/symb_lib.h ../include/trim_lib.h ../include/triv_lib.h
ip_fatal.o: ../include/allocate.h ../include/attribut.h
ip_procs.o: ../include/irit_sm.h ../include/attribut.h ../include/iritprsr.h
ip_procs.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
ip_procs.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
ip_procs.o: ../include/triv_lib.h
iritprs1.o: ../include/irit_sm.h prsr_loc.h ../include/iritprsr.h
iritprs1.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
iritprs1.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
iritprs1.o: ../include/triv_lib.h ../include/allocate.h ../include/attribut.h
iritprs1.o: ../include/irit_soc.h
iritprs2.o: ../include/irit_sm.h prsr_loc.h ../include/iritprsr.h
iritprs2.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
iritprs2.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
iritprs2.o: ../include/triv_lib.h ../include/allocate.h ../include/attribut.h
iritprs2.o: ../include/irit_soc.h
iritprsb.o: ../include/irit_sm.h prsr_loc.h ../include/iritprsr.h
iritprsb.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
iritprsb.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
iritprsb.o: ../include/triv_lib.h ../include/allocate.h ../include/attribut.h
iritprsb.o: ../include/irit_soc.h
soc_clnt.o: ../include/irit_sm.h prsr_loc.h ../include/iritprsr.h
soc_clnt.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
soc_clnt.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
soc_clnt.o: ../include/triv_lib.h ../include/irit_soc.h ../include/allocate.h
soc_srvr.o: ../include/irit_sm.h prsr_loc.h ../include/iritprsr.h
soc_srvr.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
soc_srvr.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
soc_srvr.o: ../include/triv_lib.h ../include/irit_soc.h ../include/allocate.h
trim_wrt.o: prsr_loc.h ../include/irit_sm.h ../include/iritprsr.h
trim_wrt.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
trim_wrt.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
trim_wrt.o: ../include/triv_lib.h
trimread.o: prsr_loc.h ../include/irit_sm.h ../include/iritprsr.h
trimread.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
trimread.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
trimread.o: ../include/triv_lib.h
triv_wrt.o: prsr_loc.h ../include/irit_sm.h ../include/iritprsr.h
triv_wrt.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
triv_wrt.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
triv_wrt.o: ../include/triv_lib.h
trivread.o: prsr_loc.h ../include/irit_sm.h ../include/iritprsr.h
trivread.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
trivread.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
trivread.o: ../include/triv_lib.h
