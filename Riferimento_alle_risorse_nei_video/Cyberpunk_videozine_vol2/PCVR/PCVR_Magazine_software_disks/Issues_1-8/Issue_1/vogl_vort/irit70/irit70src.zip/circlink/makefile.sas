#
# This is the make file for circlink subdirectory.
#
#				Gershon Elber, Aug 1991
#

include ../makeflag.sas

OBJS =  circlink.o

install: $(OBJS)


# DO NOT DELETE THIS LINE -- make depend depends on it.

circlink.o: ../include/irit_sm.h ../include/symb_lib.h ../include/cagd_lib.h
circlink.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
circlink.o: ../include/geomat3d.h ../include/iritprsr.h ../include/trim_lib.h
circlink.o: ../include/triv_lib.h
