irender -z
irender -b 100 100 100 -s 512 512 -A triangle -i ppm checker.dat checker.mat > checker.ppm
irender -n -v -S -i ppm l3ortho.dat walls.dat walls.mat teapot.dat > teapot.ppm
irender -a 0.0 -b 20 20 20 -M Flat -T -i ppm woodglas.dat > woodglas.ppm
irender -a 0.1 -b 0 0 0 -F 0 40 -i ppm marbglas.dat > marbglas.ppm
irender -b 50 50 50 -i ppm -A sync isoglass.dat > isoglass.ppm
irender -A sync -F 0 40 -P 0.003 0.03 -T -s 700 700 -v -i ppm ../filters/test.dat > filttest.ppm
irender -F 0 40 -v -s 300 300 -i ppm wiggle.dat > wiggle.ppm
irender -F 0 40 -A sync -v -s 500 500 -i ppm teapot2.dat teapot2.mat > teapot2.ppm
irender -F 0 50 -v -i ppm -A sync teapot3.dat teapot2.mat > ! teapot3.ppm