#
# This is the make file for the graphic driver's subdirectory.
#
#				Gershon Elber, June 1993
#

include ../makeflag.sas

GRAPDRVS=nuldrvs amidrvs 

nuldrvs: nuldrvs.o gen_grap.o
	slink from lib:c.o nuldrvs.o gen_grap.o to nuldrvs sc $(SYMS) noicons\
lib $(LIBS) $(MORELIBS) $(GRAPGLLIBS) $(MATHLIB) lib:scnb.lib

AMIDRVS_DRAW = drawln3d.o drawptvc.o drawpoly.o draw_crv.o draw_mdl.o \
               draw_srf.o drawtsrf.o drawtriv.o drawtris.o draw_obj.o
amidrvs: amidrvs.o gen_grap.o $(AMIDRVS_DRAW)
	slink from lib:c.o amidrvs.o gen_grap.o $(AMIDRVS_DRAW) to amidrvs\
sc $(SYMS) noicons lib $(LIBS) $(MORELIBS) $(GRAPGLLIBS) $(MATHLIB)\
lib:scnb.lib

install: $(GRAPDRVS)
	mv -f $(GRAPDRVS) $(BIN_DIR)
	cp *drvs.cfg $(BIN_DIR)


# DO NOT DELETE THIS LINE -- make depend depends on it.

amidrvs.o: ../include/irit_sm.h ../include/genmat.h ../include/iritprsr.h
amidrvs.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
amidrvs.o: ../include/symb_lib.h ../include/trim_lib.h ../include/triv_lib.h
amidrvs.o: ../include/allocate.h ../include/attribut.h ../include/ip_cnvrt.h
amidrvs.o: ../include/iritgrap.h ../include/irit_soc.h
djgdrvs.o: djggraph.h ../include/iritgrap.h ../include/irit_sm.h
djgdrvs.o: ../include/genmat.h ../include/iritprsr.h ../include/cagd_lib.h
djgdrvs.o: ../include/imalloc.h ../include/miscattr.h ../include/symb_lib.h
djgdrvs.o: ../include/trim_lib.h ../include/triv_lib.h
djggraph.o: djggraph.h ../include/iritgrap.h ../include/irit_sm.h
djggraph.o: ../include/genmat.h ../include/iritprsr.h ../include/cagd_lib.h
djggraph.o: ../include/imalloc.h ../include/miscattr.h ../include/symb_lib.h
djggraph.o: ../include/trim_lib.h ../include/triv_lib.h
draw_crv.o: ../include/irit_sm.h ../include/iritprsr.h ../include/cagd_lib.h
draw_crv.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
draw_crv.o: ../include/symb_lib.h ../include/trim_lib.h ../include/triv_lib.h
draw_crv.o: ../include/allocate.h ../include/ip_cnvrt.h ../include/attribut.h
draw_crv.o: ../include/iritgrap.h
draw_obj.o: ../include/irit_sm.h ../include/iritprsr.h ../include/cagd_lib.h
draw_obj.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
draw_obj.o: ../include/symb_lib.h ../include/trim_lib.h ../include/triv_lib.h
draw_obj.o: ../include/iritgrap.h ../include/attribut.h
draw_srf.o: ../include/irit_sm.h ../include/iritprsr.h ../include/cagd_lib.h
draw_srf.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
draw_srf.o: ../include/symb_lib.h ../include/trim_lib.h ../include/triv_lib.h
draw_srf.o: ../include/allocate.h ../include/attribut.h ../include/ip_cnvrt.h
draw_srf.o: ../include/iritgrap.h
drawln3d.o: ../include/irit_sm.h ../include/genmat.h ../include/iritgrap.h
drawln3d.o: ../include/iritprsr.h ../include/cagd_lib.h ../include/imalloc.h
drawln3d.o: ../include/miscattr.h ../include/symb_lib.h ../include/trim_lib.h
drawln3d.o: ../include/triv_lib.h
drawpoly.o: ../include/irit_sm.h ../include/iritprsr.h ../include/cagd_lib.h
drawpoly.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
drawpoly.o: ../include/symb_lib.h ../include/trim_lib.h ../include/triv_lib.h
drawpoly.o: ../include/iritgrap.h
drawptvc.o: ../include/irit_sm.h ../include/iritprsr.h ../include/cagd_lib.h
drawptvc.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
drawptvc.o: ../include/symb_lib.h ../include/trim_lib.h ../include/triv_lib.h
drawptvc.o: ../include/iritgrap.h
drawtriv.o: ../include/irit_sm.h ../include/iritprsr.h ../include/cagd_lib.h
drawtriv.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
drawtriv.o: ../include/symb_lib.h ../include/trim_lib.h ../include/triv_lib.h
drawtriv.o: ../include/allocate.h ../include/attribut.h ../include/ip_cnvrt.h
drawtriv.o: ../include/iritgrap.h
drawtsrf.o: ../include/irit_sm.h ../include/iritprsr.h ../include/cagd_lib.h
drawtsrf.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
drawtsrf.o: ../include/symb_lib.h ../include/trim_lib.h ../include/triv_lib.h
drawtsrf.o: ../include/allocate.h ../include/attribut.h ../include/ip_cnvrt.h
drawtsrf.o: ../include/iritgrap.h
gen_grap.o: ../include/irit_sm.h ../include/genmat.h ../include/getarg.h
gen_grap.o: ../include/config.h ../include/iritprsr.h ../include/cagd_lib.h
gen_grap.o: ../include/imalloc.h ../include/miscattr.h ../include/symb_lib.h
gen_grap.o: ../include/trim_lib.h ../include/triv_lib.h ../include/allocate.h
gen_grap.o: ../include/attribut.h ../include/iritgrap.h ../include/irit_soc.h
nuldrvs.o: ../include/irit_sm.h ../include/iritprsr.h ../include/cagd_lib.h
nuldrvs.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
nuldrvs.o: ../include/symb_lib.h ../include/trim_lib.h ../include/triv_lib.h
nuldrvs.o: ../include/allocate.h ../include/attribut.h ../include/iritgrap.h
nuldrvs.o: ../include/irit_soc.h
os2drvs.o: ../include/irit_sm.h ../include/genmat.h ../include/iritprsr.h
os2drvs.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
os2drvs.o: ../include/symb_lib.h ../include/trim_lib.h ../include/triv_lib.h
os2drvs.o: ../include/allocate.h ../include/attribut.h ../include/ip_cnvrt.h
os2drvs.o: ../include/iritgrap.h os2drvs.h ../include/irit_soc.h
wnt_ogl.o: ../include/irit_sm.h ../include/genmat.h ../include/iritprsr.h
wnt_ogl.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
wnt_ogl.o: ../include/symb_lib.h ../include/trim_lib.h ../include/triv_lib.h
wnt_ogl.o: ../include/allocate.h ../include/attribut.h ../include/iritgrap.h
wnt_ogl.o: ../include/irit_soc.h wntdrvs.h
wnt_win.o: ../include/irit_sm.h ../include/genmat.h ../include/iritprsr.h
wnt_win.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
wnt_win.o: ../include/symb_lib.h ../include/trim_lib.h ../include/triv_lib.h
wnt_win.o: ../include/allocate.h ../include/attribut.h ../include/ip_cnvrt.h
wnt_win.o: ../include/iritgrap.h wntdrvs.h
wntdrvs.o: ../include/irit_sm.h ../include/genmat.h ../include/iritprsr.h
wntdrvs.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
wntdrvs.o: ../include/symb_lib.h ../include/trim_lib.h ../include/triv_lib.h
wntdrvs.o: ../include/allocate.h ../include/attribut.h ../include/ip_cnvrt.h
wntdrvs.o: ../include/iritgrap.h ../include/irit_soc.h wntdrvs.h
x11draw.o: ../include/irit_sm.h ../include/genmat.h ../include/iritprsr.h
x11draw.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
x11draw.o: ../include/symb_lib.h ../include/trim_lib.h ../include/triv_lib.h
x11draw.o: ../include/iritgrap.h ../include/attribut.h x11drvs.h
x11drvs.o: ../include/irit_sm.h ../include/genmat.h ../include/iritprsr.h
x11drvs.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
x11drvs.o: ../include/symb_lib.h ../include/trim_lib.h ../include/triv_lib.h
x11drvs.o: ../include/allocate.h ../include/attribut.h ../include/ip_cnvrt.h
x11drvs.o: ../include/iritgrap.h x11drvs.h ../include/irit_soc.h
xgladap.o: ../include/irit_sm.h ../include/genmat.h ../include/config.h
xgladap.o: ../include/iritprsr.h ../include/cagd_lib.h ../include/imalloc.h
xgladap.o: ../include/miscattr.h ../include/symb_lib.h ../include/trim_lib.h
xgladap.o: ../include/triv_lib.h ../include/allocate.h ../include/attribut.h
xgladap.o: ../include/ip_cnvrt.h ../include/iritgrap.h ../include/irit_soc.h
xgldraw.o: ../include/irit_sm.h ../include/attribut.h ../include/iritprsr.h
xgldraw.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
xgldraw.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
xgldraw.o: ../include/triv_lib.h xgldrvs.h ../include/iritgrap.h
xgldrvs.o: ../include/irit_sm.h ../include/genmat.h ../include/iritprsr.h
xgldrvs.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
xgldrvs.o: ../include/symb_lib.h ../include/trim_lib.h ../include/triv_lib.h
xgldrvs.o: ../include/allocate.h ../include/attribut.h ../include/ip_cnvrt.h
xgldrvs.o: ../include/iritgrap.h xgldrvs.h ../include/irit_soc.h
xmtdrvs.o: ../include/irit_sm.h ../include/genmat.h ../include/iritprsr.h
xmtdrvs.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
xmtdrvs.o: ../include/symb_lib.h ../include/trim_lib.h ../include/triv_lib.h
xmtdrvs.o: ../include/allocate.h ../include/attribut.h ../include/ip_cnvrt.h
xmtdrvs.o: ../include/iritgrap.h x11drvs.h xgldrvs.h ../include/irit_soc.h
xogldraw.o: ../include/irit_sm.h ../include/genmat.h ../include/iritprsr.h
xogldraw.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
xogldraw.o: ../include/symb_lib.h ../include/trim_lib.h ../include/triv_lib.h
xogldraw.o: ../include/allocate.h ../include/attribut.h ../include/iritgrap.h
xogldraw.o: x11drvs.h
xogldrvs.o: ../include/irit_sm.h ../include/genmat.h ../include/iritprsr.h
xogldrvs.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
xogldrvs.o: ../include/symb_lib.h ../include/trim_lib.h ../include/triv_lib.h
xogldrvs.o: ../include/allocate.h ../include/attribut.h ../include/ip_cnvrt.h
xogldrvs.o: ../include/iritgrap.h ../include/irit_soc.h
