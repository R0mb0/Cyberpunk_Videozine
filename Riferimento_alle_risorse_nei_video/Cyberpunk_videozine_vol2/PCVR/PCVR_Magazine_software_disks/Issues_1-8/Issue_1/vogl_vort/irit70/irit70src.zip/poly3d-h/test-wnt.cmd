poly3d-h -z
poly3d-h -b -m cube.dat > cube.hdn
poly3d-h -m -H -q solid1.dat > solid1.hdn
poly3d-h -b -m solid3.dat > solid3.hdn
poly3d-h -b -m -o cone-cyl.hdn cone-cyl.dat
poly3d-h -F 22 0.01 -4 -H saddle.dat > saddle.hdn
poly3d-h -F 0 30 -e 2 -q -4- - < wiggle.dat > wiggle.hdn
poly3d-h -t 0.04 -q- -F 0 20 -W 0.01 ../filters/test.dat > filttest.hdn

wntdrvs cube.hdn
wntdrvs solid1.hdn
wntdrvs solid3.hdn
wntdrvs cone-cyl.hdn
wntdrvs saddle.hdn
wntdrvs wiggle.hdn
wntdrvs filttest.hdn
