#
# This is the make file for the symb_lib library.
#
#				Gershon Elber, Aug 1990
#

include ../makeflag.sas

OBJS =  adap_iso.o arc_len.o bsp_sym.o bzr_sym.o composit.o crv_tans.o \
	crv_skel.o curvatur.o distance.o evalcurv.o \
	ffcnvhul.o ffptdist.o morphing.o multires.o nrmlcone.o \
	offset.o orthotom.o prisa.o symb_err.o symb_ftl.o symbolic.o \
	symbpoly.o symbsply.o symbzero.o

all:	symb.lib

symb.lib: $(OBJS)
	rm -f symb.lib
	oml symb.lib a $(OBJS)

install: symb.lib
	mv -f symb.lib $(LIB_DIR)

# DO NOT DELETE THIS LINE -- make depend depends on it.

adap_iso.o: symb_loc.h ../include/cagd_lib.h ../include/irit_sm.h
adap_iso.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
adap_iso.o: ../include/symb_lib.h
arc_len.o: symb_loc.h ../include/cagd_lib.h ../include/irit_sm.h
arc_len.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
arc_len.o: ../include/symb_lib.h
bsp_sym.o: symb_loc.h ../include/cagd_lib.h ../include/irit_sm.h
bsp_sym.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
bsp_sym.o: ../include/symb_lib.h
bzr_sym.o: symb_loc.h ../include/cagd_lib.h ../include/irit_sm.h
bzr_sym.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
bzr_sym.o: ../include/symb_lib.h
composit.o: symb_loc.h ../include/cagd_lib.h ../include/irit_sm.h
composit.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
composit.o: ../include/symb_lib.h
curvatur.o: symb_loc.h ../include/cagd_lib.h ../include/irit_sm.h
curvatur.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
curvatur.o: ../include/symb_lib.h
distance.o: symb_loc.h ../include/cagd_lib.h ../include/irit_sm.h
distance.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
distance.o: ../include/symb_lib.h
morphing.o: symb_loc.h ../include/cagd_lib.h ../include/irit_sm.h
morphing.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
morphing.o: ../include/symb_lib.h ../include/geomat3d.h ../include/iritprsr.h
morphing.o: ../include/trim_lib.h ../include/triv_lib.h
multires.o: ../include/irit_sm.h ../include/cagd_lib.h ../include/imalloc.h
multires.o: ../include/miscattr.h ../include/genmat.h ../include/symb_lib.h
multires.o: symb_loc.h
offset.o: symb_loc.h ../include/cagd_lib.h ../include/irit_sm.h
offset.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
offset.o: ../include/symb_lib.h ../include/extra_fn.h
prisa.o: symb_loc.h ../include/cagd_lib.h ../include/irit_sm.h
prisa.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
prisa.o: ../include/symb_lib.h
symb_err.o: symb_loc.h ../include/cagd_lib.h ../include/irit_sm.h
symb_err.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
symb_err.o: ../include/symb_lib.h
symb_ftl.o: symb_loc.h ../include/cagd_lib.h ../include/irit_sm.h
symb_ftl.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
symb_ftl.o: ../include/symb_lib.h
symbolic.o: symb_loc.h ../include/cagd_lib.h ../include/irit_sm.h
symbolic.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
symbolic.o: ../include/symb_lib.h
symbpoly.o: symb_loc.h ../include/cagd_lib.h ../include/irit_sm.h
symbpoly.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
symbpoly.o: ../include/symb_lib.h ../include/dist_pts.h
symbsply.o: symb_loc.h ../include/cagd_lib.h ../include/irit_sm.h
symbsply.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
symbsply.o: ../include/symb_lib.h ../include/geomat3d.h ../include/iritprsr.h
symbsply.o: ../include/trim_lib.h ../include/triv_lib.h
symbzero.o: symb_loc.h ../include/cagd_lib.h ../include/irit_sm.h
symbzero.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
symbzero.o: ../include/symb_lib.h
