
irit2dxf -F 0 20 -4 -o test_dxf test.dat

irit2plg -F 0 20 -l test.dat > test_plg.dat

irit2ray -t 0.-3 -F 0 15 -G 10 -l -4 -o test_ray test.dat

irit2pov -t 0.03 -F 0 20 -l -4 -o test_pov test.dat

irit2iv -F 0 20 -l -4 test.dat > test_iv.iv

irit2xfg -f 2 0.01 -s 10.0 -I 2:4:8 -t 1.0 0.5 -o test_1.xfg test.dat
irit2xfg -s 15.0 -F 0 20 -M -i -t 0 0  test.dat > test_2.xfg

irit2hgl -f 0 128 -I 2:4:8 -t 1.0 0.5 -o test_1.hgl test.dat
irit2hgl -a 0.4 -F 0 20 -M -i -t 0 0  test.dat > test_2.hgl

irit2ps -t 0.4 -s 5 -f 2 0.01 -c -p h 0.03 -I 4:4:2 -o test_ps1.ps test.dat
irit2ps -t 0.4 -s 5 -f 1 32 -M -c -C -p h 0.1 -I 4:4:2 -o test_ps2.ps test.dat
irit2ps -s 5 -f 0 128 -F 0 20 -P -G- -W 0.01 -c- -C- -p F 0.02 test.dat > test_ps3.ps

irit2nff -F 0 5 -l -4 -o test_nff test.dat

irit2scn -t 0.4 -F 0 25 -4 -o test_scn test.dat

skeletn1 -4 test.dat test.dat > test_skl.dat

dat2bin test.dat > test_d2b.bdt
dat2bin -t test_d2b.bdt > test_d2b.dat

dat2irit test_d2b.bdt > test_dat.irt
