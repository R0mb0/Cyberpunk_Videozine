/*****************************************************************************
*   "Irit" - the 3d polygonal solid modeller.				     *
*									     *
* Written by:  Gershon Elber				Ver 1.0, Jan. 1992   *
******************************************************************************
* (C) Gershon Elber, Technion, Israel Institute of Technology                *
******************************************************************************
* Global definitions of	x11drvs interface.			             *
*****************************************************************************/

#ifndef	X11DRVS_H	/* Define only once */
#define	X11DRVS_H

#define RESOURCE_NAME		"irit"

#define DEFAULT_VIEW_WIDTH	400
#define DEFAULT_VIEW_HEIGHT	400

extern int
    ViewHasSize,
    ViewHasPos,
    ViewPosX,
    ViewPosY,
    XScreen;
extern unsigned int
    MaxColors,
    ViewBackGroundPixel,
    ViewTextPixel,
    ViewBorderPixel,
    ViewBorderWidth,
    ViewWidth,
    ViewHeight;
extern Display
    *XDisplay;
extern Window
    XRoot,
    ViewWndw;
extern Colormap
    XColorMap;
extern GC
    XViewGraphContext;
extern XColor
    BlackColor,
    *ViewCursorColor,
    XViewColorsHigh[IG_MAX_COLOR + 1],
    XViewColorsLow[IG_MAX_COLOR + 1];

void SetViewWindow(int argc, char **argv);

#endif /* X11DRVS_H */
