/*****************************************************************************
*   A dummy function to force linkage of circularities in libraries.	     *
* This module will be linked as an object file and hence always loaded.      *
******************************************************************************
* (C) Gershon Elber, Technion, Israel Institute of Technology                *
*****************************************************************************/

#include "irit_sm.h"
#include "symb_lib.h"
#include "geomat3d.h"
#include "user_lib.h"

/*****************************************************************************
* Dummy function that is never called. Just force linkage of functions.      *
*****************************************************************************/
void _DummyCircularLinkResolver(void)
{
    PointType Pt;

    BspCrvMult(NULL, NULL);
    BzrCrvMult(NULL, NULL);
    BspSrfMult(NULL, NULL);
    BzrSrfMult(NULL, NULL);

    BspSrfDeriveRational(NULL, CAGD_CONST_U_DIR);
    BzrSrfDeriveRational(NULL, CAGD_CONST_U_DIR);

    SymbSrf2OptPolysCurvatureErrorPrep(NULL);
    SymbComposeSrfCrv(NULL, NULL);

    CGPointFromPointLine(Pt, Pt, Pt, Pt);

    UserPolylines2LinBsplineCrvs(NULL);
}
