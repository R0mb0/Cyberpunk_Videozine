#
# This is the make file for the cagd_lib library.
#
#				Gershon Elber, Aug 1990
#

include ../makeflag.sas

OBJS =  afd_cube.o bsp2poly.o bsp_gen.o bsp_knot.o \
	bspboehm.o bspcoxdb.o bzr2poly.o bzr_gen.o cagd_arc.o \
	cagd_aux.o cagd_cci.o cagd_dbg.o cagd_err.o cagd_ftl.o cagd1gen.o \
	cagd2gen.o cagdbbox.o cagdbsum.o cagdcmpt.o \
	cagdcmrg.o cagdcoer.o cagdcsrf.o cagdedit.o cagdextr.o cagdmesh.o \
	cagdoslo.o cagdprim.o cagdruld.o cagdsmrg.o cagdsrev.o \
	cagdswep.o cbsp_aux.o cbsp_int.o cbspeval.o cbzr_aux.o cbzr_pwr.o \
	cbzreval.o crvmatch.o hermite.o mshplanr.o poly_err.o \
	sbsp_aux.o sbsp_int.o \
	sbspeval.o sbzr_aux.o sbzreval.o

all:	cagd.lib

cagd.lib: $(OBJS)
	rm -f cagd.lib
	oml cagd.lib a $(OBJS)

install: cagd.lib
	mv -f cagd.lib $(LIB_DIR)

# DO NOT DELETE THIS LINE -- make depend depends on it.

afd_cube.o: cagd_loc.h ../include/iritprsr.h ../include/irit_sm.h
afd_cube.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
afd_cube.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
afd_cube.o: ../include/triv_lib.h
bsp2poly.o: cagd_loc.h ../include/iritprsr.h ../include/irit_sm.h
bsp2poly.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
bsp2poly.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
bsp2poly.o: ../include/triv_lib.h
bsp_gen.o: cagd_loc.h ../include/iritprsr.h ../include/irit_sm.h
bsp_gen.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
bsp_gen.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
bsp_gen.o: ../include/triv_lib.h
bsp_knot.o: cagd_loc.h ../include/iritprsr.h ../include/irit_sm.h
bsp_knot.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
bsp_knot.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
bsp_knot.o: ../include/triv_lib.h
bspboehm.o: cagd_loc.h ../include/iritprsr.h ../include/irit_sm.h
bspboehm.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
bspboehm.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
bspboehm.o: ../include/triv_lib.h
bspcoxdb.o: cagd_loc.h ../include/iritprsr.h ../include/irit_sm.h
bspcoxdb.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
bspcoxdb.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
bspcoxdb.o: ../include/triv_lib.h
bzr2poly.o: cagd_loc.h ../include/iritprsr.h ../include/irit_sm.h
bzr2poly.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
bzr2poly.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
bzr2poly.o: ../include/triv_lib.h
bzr_gen.o: cagd_loc.h ../include/iritprsr.h ../include/irit_sm.h
bzr_gen.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
bzr_gen.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
bzr_gen.o: ../include/triv_lib.h
cagd1gen.o: cagd_loc.h ../include/iritprsr.h ../include/irit_sm.h
cagd1gen.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
cagd1gen.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
cagd1gen.o: ../include/triv_lib.h ../include/geomat3d.h
cagd2gen.o: cagd_loc.h ../include/iritprsr.h ../include/irit_sm.h
cagd2gen.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
cagd2gen.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
cagd2gen.o: ../include/triv_lib.h ../include/geomat3d.h
cagd_arc.o: cagd_loc.h ../include/iritprsr.h ../include/irit_sm.h
cagd_arc.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
cagd_arc.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
cagd_arc.o: ../include/triv_lib.h
cagd_aux.o: cagd_loc.h ../include/iritprsr.h ../include/irit_sm.h
cagd_aux.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
cagd_aux.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
cagd_aux.o: ../include/triv_lib.h
cagd_dbg.o: cagd_loc.h ../include/iritprsr.h ../include/irit_sm.h
cagd_dbg.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
cagd_dbg.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
cagd_dbg.o: ../include/triv_lib.h
cagd_err.o: cagd_loc.h ../include/iritprsr.h ../include/irit_sm.h
cagd_err.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
cagd_err.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
cagd_err.o: ../include/triv_lib.h
cagd_ftl.o: cagd_loc.h ../include/iritprsr.h ../include/irit_sm.h
cagd_ftl.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
cagd_ftl.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
cagd_ftl.o: ../include/triv_lib.h
cagdbbox.o: cagd_loc.h ../include/iritprsr.h ../include/irit_sm.h
cagdbbox.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
cagdbbox.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
cagdbbox.o: ../include/triv_lib.h
cagdbsum.o: cagd_loc.h ../include/iritprsr.h ../include/irit_sm.h
cagdbsum.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
cagdbsum.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
cagdbsum.o: ../include/triv_lib.h
cagdcmpt.o: cagd_loc.h ../include/iritprsr.h ../include/irit_sm.h
cagdcmpt.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
cagdcmpt.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
cagdcmpt.o: ../include/triv_lib.h
cagdcmrg.o: cagd_loc.h ../include/iritprsr.h ../include/irit_sm.h
cagdcmrg.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
cagdcmrg.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
cagdcmrg.o: ../include/triv_lib.h
cagdcoer.o: cagd_loc.h ../include/iritprsr.h ../include/irit_sm.h
cagdcoer.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
cagdcoer.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
cagdcoer.o: ../include/triv_lib.h
cagdcsrf.o: cagd_loc.h ../include/iritprsr.h ../include/irit_sm.h
cagdcsrf.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
cagdcsrf.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
cagdcsrf.o: ../include/triv_lib.h
cagdedit.o: cagd_loc.h ../include/iritprsr.h ../include/irit_sm.h
cagdedit.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
cagdedit.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
cagdedit.o: ../include/triv_lib.h
cagdextr.o: cagd_loc.h ../include/iritprsr.h ../include/irit_sm.h
cagdextr.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
cagdextr.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
cagdextr.o: ../include/triv_lib.h
cagdmesh.o: cagd_loc.h ../include/iritprsr.h ../include/irit_sm.h
cagdmesh.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
cagdmesh.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
cagdmesh.o: ../include/triv_lib.h
cagdoslo.o: cagd_loc.h ../include/iritprsr.h ../include/irit_sm.h
cagdoslo.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
cagdoslo.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
cagdoslo.o: ../include/triv_lib.h
cagdruld.o: cagd_loc.h ../include/iritprsr.h ../include/irit_sm.h
cagdruld.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
cagdruld.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
cagdruld.o: ../include/triv_lib.h
cagdsmrg.o: cagd_loc.h ../include/iritprsr.h ../include/irit_sm.h
cagdsmrg.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
cagdsmrg.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
cagdsmrg.o: ../include/triv_lib.h
cagdsrev.o: cagd_loc.h ../include/iritprsr.h ../include/irit_sm.h
cagdsrev.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
cagdsrev.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
cagdsrev.o: ../include/triv_lib.h
cagdswep.o: cagd_loc.h ../include/iritprsr.h ../include/irit_sm.h
cagdswep.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
cagdswep.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
cagdswep.o: ../include/triv_lib.h
cbsp_aux.o: cagd_loc.h ../include/iritprsr.h ../include/irit_sm.h
cbsp_aux.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
cbsp_aux.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
cbsp_aux.o: ../include/triv_lib.h
cbsp_int.o: cagd_loc.h ../include/iritprsr.h ../include/irit_sm.h
cbsp_int.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
cbsp_int.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
cbsp_int.o: ../include/triv_lib.h ../include/extra_fn.h
cbspeval.o: cagd_loc.h ../include/iritprsr.h ../include/irit_sm.h
cbspeval.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
cbspeval.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
cbspeval.o: ../include/triv_lib.h
cbzr_aux.o: cagd_loc.h ../include/iritprsr.h ../include/irit_sm.h
cbzr_aux.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
cbzr_aux.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
cbzr_aux.o: ../include/triv_lib.h
cbzr_pwr.o: cagd_loc.h ../include/iritprsr.h ../include/irit_sm.h
cbzr_pwr.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
cbzr_pwr.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
cbzr_pwr.o: ../include/triv_lib.h
cbzreval.o: cagd_loc.h ../include/iritprsr.h ../include/irit_sm.h
cbzreval.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
cbzreval.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
cbzreval.o: ../include/triv_lib.h
mshplanr.o: cagd_loc.h ../include/iritprsr.h ../include/irit_sm.h
mshplanr.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
mshplanr.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
mshplanr.o: ../include/triv_lib.h
sbsp_aux.o: cagd_loc.h ../include/iritprsr.h ../include/irit_sm.h
sbsp_aux.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
sbsp_aux.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
sbsp_aux.o: ../include/triv_lib.h
sbsp_int.o: cagd_loc.h ../include/iritprsr.h ../include/irit_sm.h
sbsp_int.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
sbsp_int.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
sbsp_int.o: ../include/triv_lib.h ../include/extra_fn.h
sbspeval.o: cagd_loc.h ../include/iritprsr.h ../include/irit_sm.h
sbspeval.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
sbspeval.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
sbspeval.o: ../include/triv_lib.h
sbzr_aux.o: cagd_loc.h ../include/iritprsr.h ../include/irit_sm.h
sbzr_aux.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
sbzr_aux.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
sbzr_aux.o: ../include/triv_lib.h
sbzreval.o: cagd_loc.h ../include/iritprsr.h ../include/irit_sm.h
sbzreval.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
sbzreval.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
sbzreval.o: ../include/triv_lib.h
