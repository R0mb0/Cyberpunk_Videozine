
#
# Makefile for the IRIT solid modeler (unix).
#

include ../makeflag.sas

OBJS = 	bsc_geom.o ctrl-brk.o dosintr.o freefrm1.o freefrm2.o freefrm3.o \
	freefrm4.o freefrm5.o inptevl1.o inptevl2.o inptevl3.o inptprsr.o \
	irit.o objects1.o objects2.o overload.o windows.o

all:	irit

irit:	$(OBJS)
	slink from lib:c.o $(OBJS) to irit sc $(SYMS) lib $(LIBS) $(MORELIBS)\
$(MATHLIB) lib:scnb.lib

install: irit
	mv -f irit $(BIN_DIR)
	cp iritinit.irt $(BIN_DIR)
	cp irit-unx.cfg $(BIN_DIR)/irit.cfg	# sic!


# DO NOT DELETE THIS LINE -- make depend depends on it.

ctrl-brk.o: program.h ../include/irit_sm.h ../include/cagd_lib.h
ctrl-brk.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
ctrl-brk.o: ../include/symb_lib.h ../include/trim_lib.h ../include/triv_lib.h
ctrl-brk.o: ../include/allocate.h ../include/iritprsr.h ../include/attribut.h
ctrl-brk.o: inptprsg.h ctrl-brk.h
dosintr.o: program.h ../include/irit_sm.h ../include/cagd_lib.h
dosintr.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
dosintr.o: ../include/symb_lib.h ../include/trim_lib.h ../include/triv_lib.h
dosintr.o: ../include/allocate.h ../include/iritprsr.h ../include/attribut.h
dosintr.o: dosintr.h ctrl-brk.h
freefrm1.o: program.h ../include/irit_sm.h ../include/cagd_lib.h
freefrm1.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
freefrm1.o: ../include/symb_lib.h ../include/trim_lib.h ../include/triv_lib.h
freefrm1.o: ../include/allocate.h ../include/iritprsr.h ../include/attribut.h
freefrm1.o: objects.h ../include/primitiv.h ../include/ip_cnvrt.h
freefrm1.o: freeform.h
freefrm2.o: program.h ../include/irit_sm.h ../include/cagd_lib.h
freefrm2.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
freefrm2.o: ../include/symb_lib.h ../include/trim_lib.h ../include/triv_lib.h
freefrm2.o: ../include/allocate.h ../include/iritprsr.h ../include/attribut.h
freefrm2.o: objects.h ../include/primitiv.h ../include/ip_cnvrt.h
freefrm2.o: freeform.h
freefrm3.o: program.h ../include/irit_sm.h ../include/cagd_lib.h
freefrm3.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
freefrm3.o: ../include/symb_lib.h ../include/trim_lib.h ../include/triv_lib.h
freefrm3.o: ../include/allocate.h ../include/iritprsr.h ../include/attribut.h
freefrm3.o: objects.h ../include/primitiv.h ../include/ip_cnvrt.h
freefrm3.o: freeform.h
freefrm4.o: program.h ../include/irit_sm.h ../include/cagd_lib.h
freefrm4.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
freefrm4.o: ../include/symb_lib.h ../include/trim_lib.h ../include/triv_lib.h
freefrm4.o: ../include/allocate.h ../include/iritprsr.h ../include/attribut.h
freefrm4.o: objects.h ../include/primitiv.h ../include/ip_cnvrt.h
freefrm4.o: freeform.h
inptevl1.o: program.h ../include/irit_sm.h ../include/cagd_lib.h
inptevl1.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
inptevl1.o: ../include/symb_lib.h ../include/trim_lib.h ../include/triv_lib.h
inptevl1.o: ../include/allocate.h ../include/iritprsr.h ../include/attribut.h
inptevl1.o: ../include/convex.h ctrl-brk.h dosintr.h freeform.h
inptevl1.o: ../include/geomat3d.h ../include/geomvals.h inptprsg.h inptprsl.h
inptevl1.o: objects.h overload.h ../include/primitiv.h
inptevl1.o: ../include/iritgrap.h
inptevl2.o: program.h ../include/irit_sm.h ../include/cagd_lib.h
inptevl2.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
inptevl2.o: ../include/symb_lib.h ../include/trim_lib.h ../include/triv_lib.h
inptevl2.o: ../include/allocate.h ../include/iritprsr.h ../include/attribut.h
inptevl2.o: ../include/convex.h ctrl-brk.h dosintr.h freeform.h
inptevl2.o: ../include/geomat3d.h ../include/geomvals.h inptprsg.h inptprsl.h
inptevl2.o: objects.h overload.h ../include/primitiv.h
inptevl2.o: ../include/iritgrap.h
inptevl3.o: program.h ../include/irit_sm.h ../include/cagd_lib.h
inptevl3.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
inptevl3.o: ../include/symb_lib.h ../include/trim_lib.h ../include/triv_lib.h
inptevl3.o: ../include/allocate.h ../include/iritprsr.h ../include/attribut.h
inptevl3.o: ctrl-brk.h objects.h inptprsg.h inptprsl.h
inptprsr.o: program.h ../include/irit_sm.h ../include/cagd_lib.h
inptprsr.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
inptprsr.o: ../include/symb_lib.h ../include/trim_lib.h ../include/triv_lib.h
inptprsr.o: ../include/allocate.h ../include/iritprsr.h ../include/attribut.h
inptprsr.o: ctrl-brk.h inptprsg.h inptprsl.h objects.h overload.h
irit.o: program.h ../include/irit_sm.h ../include/cagd_lib.h
irit.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
irit.o: ../include/symb_lib.h ../include/trim_lib.h ../include/triv_lib.h
irit.o: ../include/allocate.h ../include/iritprsr.h ../include/attribut.h
irit.o: ../include/config.h ctrl-brk.h dosintr.h inptprsg.h objects.h
irit.o: ../include/iritgrap.h ../include/irit_soc.h
irit.o: ../include/bool_lib.h
objects1.o: program.h ../include/irit_sm.h ../include/cagd_lib.h
objects1.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
objects1.o: ../include/symb_lib.h ../include/trim_lib.h ../include/triv_lib.h
objects1.o: ../include/allocate.h ../include/iritprsr.h ../include/attribut.h
objects1.o: ../include/primitiv.h ../include/geomat3d.h objects.h freeform.h
objects2.o: program.h ../include/irit_sm.h ../include/cagd_lib.h
objects2.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
objects2.o: ../include/symb_lib.h ../include/trim_lib.h ../include/triv_lib.h
objects2.o: ../include/allocate.h ../include/iritprsr.h ../include/attribut.h
objects2.o: ../include/primitiv.h ../include/geomat3d.h objects.h freeform.h
overload.o: program.h ../include/irit_sm.h ../include/cagd_lib.h
overload.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
overload.o: ../include/symb_lib.h ../include/trim_lib.h ../include/triv_lib.h
overload.o: ../include/allocate.h ../include/iritprsr.h ../include/attribut.h
overload.o: ../include/bool_lib.h freeform.h ../include/geomat3d.h inptprsg.h
overload.o: inptprsl.h objects.h overload.h
windows.o: program.h ../include/irit_sm.h ../include/cagd_lib.h
windows.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
windows.o: ../include/symb_lib.h ../include/trim_lib.h ../include/triv_lib.h
windows.o: ../include/allocate.h ../include/iritprsr.h ../include/attribut.h
windows.o: ../include/irit_soc.h
