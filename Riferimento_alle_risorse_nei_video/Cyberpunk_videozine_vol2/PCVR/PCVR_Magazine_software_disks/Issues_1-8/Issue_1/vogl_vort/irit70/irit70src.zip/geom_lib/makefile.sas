#
# This is the make file for the prsr. lib subdirectory.
#
#				Gershon Elber, Aug 1991
#

include ../makeflag.sas

OBJS = animate.o anim_aux.o bbox.o convex.o decimate.o geomat3d.o \
	geomvals.o intrnrml.o ln_sweep.o poly_cln.o poly_pts.o \
	polyofst.o primitiv.o sph_pts.o

all:	geom.lib

geom.lib: $(OBJS)
	rm -f geom.lib
	oml geom.lib a $(OBJS)

install: geom.lib
	mv -f geom.lib $(LIB_DIR)


# DO NOT DELETE THIS LINE -- make depend depends on it.

bbox.o: ../include/irit_sm.h ../include/allocate.h ../include/iritprsr.h
bbox.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
bbox.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
bbox.o: ../include/triv_lib.h ../include/bbox.h
convex.o: ../include/allocate.h ../include/iritprsr.h ../include/irit_sm.h
convex.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
convex.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
convex.o: ../include/triv_lib.h ../include/convex.h ../include/poly_cln.h
convex.o: ../include/geomat3d.h ../include/intrnrml.h ../include/priorque.h
geomat3d.o: ../include/irit_sm.h ../include/iritprsr.h ../include/cagd_lib.h
geomat3d.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
geomat3d.o: ../include/symb_lib.h ../include/trim_lib.h ../include/triv_lib.h
geomat3d.o: ../include/allocate.h ../include/convex.h ../include/geomat3d.h
geomvals.o: ../include/allocate.h ../include/iritprsr.h ../include/irit_sm.h
geomvals.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
geomvals.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
geomvals.o: ../include/triv_lib.h ../include/convex.h ../include/geomat3d.h
geomvals.o: ../include/geomvals.h
intrnrml.o: ../include/irit_sm.h ../include/iritprsr.h ../include/cagd_lib.h
intrnrml.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
intrnrml.o: ../include/symb_lib.h ../include/trim_lib.h ../include/triv_lib.h
intrnrml.o: ../include/geomat3d.h ../include/intrnrml.h
ln_sweep.o: ../include/irit_sm.h ../include/imalloc.h ../include/ln_sweep.h
poly_cln.o: ../include/irit_sm.h ../include/allocate.h ../include/iritprsr.h
poly_cln.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
poly_cln.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
poly_cln.o: ../include/triv_lib.h ../include/poly_cln.h
primitiv.o: ../include/irit_sm.h ../include/geomat3d.h ../include/iritprsr.h
primitiv.o: ../include/cagd_lib.h ../include/imalloc.h ../include/miscattr.h
primitiv.o: ../include/genmat.h ../include/symb_lib.h ../include/trim_lib.h
primitiv.o: ../include/triv_lib.h ../include/allocate.h ../include/attribut.h
primitiv.o: ../include/convex.h ../include/primitiv.h
