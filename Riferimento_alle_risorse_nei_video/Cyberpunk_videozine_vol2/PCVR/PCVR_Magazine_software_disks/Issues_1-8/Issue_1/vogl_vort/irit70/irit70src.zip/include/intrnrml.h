/*****************************************************************************
*   "Irit" - the 3d (not only polygonal) solid modeller.		     *
*									     *
* Written by:  Gershon Elber				Ver 0.2, Aug. 1990   *
******************************************************************************
* (C) Gershon Elber, Technion, Israel Institute of Technology                *
******************************************************************************
* General, visible to others, definitions of normal interpolation module.    *
*****************************************************************************/

#ifndef INTRNRML_H
#define INTRNRML_H

#if defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif

void UpdateVerticesNormals(IPPolygonStruct *PlList,
			   IPPolygonStruct *OriginalPl);
int Colinear3Vertices(IPVertexStruct *V1,
		      IPVertexStruct *V2,
		      IPVertexStruct *V3);
void InterpNrmlBetweenTwo(IPVertexStruct *V,
			  IPVertexStruct *V1,
			  IPVertexStruct *V2);
void InterpNrmlBetweenTwo2(PointType Pt,
			   VectorType Normal,
			   IPVertexStruct *V1,
			   IPVertexStruct *V2);

#if defined(__cplusplus) || defined(c_plusplus)
}
#endif

#endif /* INTRNRML_H */
