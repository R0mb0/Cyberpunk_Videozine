#
# This is the make file for the user_lib library.
#
#				Gershon Elber, Aug 1990
#

include ../makeflag.sas

OBJS =  srfray.o srf_cntr.o user_ftl.o user_err.o usrcnvrt.o visible.o

all:	user.lib

user.lib: $(OBJS)
	rm -f user.lib
	oml user.lib a $(OBJS)

install: user.lib
	mv -f user.lib $(LIB_DIR)

# DO NOT DELETE THIS LINE -- make depend depends on it.
