/******************************************************************************
* GeomVals.h - Area, Volume, and counts on polygonal objects.		      *
*******************************************************************************
* (C) Gershon Elber, Technion, Israel Institute of Technology                 *
*******************************************************************************
* Written by Gershon Elber, March 1990.					      *
******************************************************************************/

#ifndef GEOM_VAL_GH
#define GEOM_VAL_GH

#if defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif

double PolyObjectArea(IPObjectStruct *PObj);
double PolyOnePolyArea(IPPolygonStruct *Pl);
double PolyObjectVolume(IPObjectStruct *PObj);
double PolyCountPolys(IPObjectStruct *PObj);

#if defined(__cplusplus) || defined(c_plusplus)
}
#endif

#endif /* GEOM_VAL_GH */
