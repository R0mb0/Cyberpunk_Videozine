#
# This is the make file for the trim_lib library.
#
#				Gershon Elber, Aug 1990
#

include ../makeflag.sas

OBJS =  trim_aux.o trim_dbg.o trim_err.o trim_ftl.o trim_gen.o \
	trim_iso.o trim_sub.o trim2ply.o trimcntr.o

all:	trim.lib

trim.lib: $(OBJS)
	rm -f trim.lib
	oml trim.lib a $(OBJS)

install: trim.lib
	mv -f trim.lib $(LIB_DIR)

testeval:	testeval.o triv.lib
	slink from lib:c.o testeval.o to testeval sc $(SYMS) noicons\
lib libtrim.a $(LIBS) $(MORELIBS) $(MATHLIB) lib:scnb.lib

# DO NOT DELETE THIS LINE -- make depend depends on it.

iso_crvs.o: trim_loc.h ../include/irit_sm.h ../include/cagd_lib.h
iso_crvs.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
iso_crvs.o: ../include/symb_lib.h ../include/trim_lib.h
trim_aux.o: trim_loc.h ../include/irit_sm.h ../include/cagd_lib.h
trim_aux.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
trim_aux.o: ../include/symb_lib.h ../include/trim_lib.h
trim_dbg.o: trim_loc.h ../include/irit_sm.h ../include/cagd_lib.h
trim_dbg.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
trim_dbg.o: ../include/symb_lib.h ../include/trim_lib.h ../include/iritprsr.h
trim_dbg.o: ../include/triv_lib.h
trim_err.o: trim_loc.h ../include/irit_sm.h ../include/cagd_lib.h
trim_err.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
trim_err.o: ../include/symb_lib.h ../include/trim_lib.h
trim_ftl.o: trim_loc.h ../include/irit_sm.h ../include/cagd_lib.h
trim_ftl.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
trim_ftl.o: ../include/symb_lib.h ../include/trim_lib.h
trim_gen.o: trim_loc.h ../include/irit_sm.h ../include/cagd_lib.h
trim_gen.o: ../include/imalloc.h ../include/miscattr.h ../include/genmat.h
trim_gen.o: ../include/symb_lib.h ../include/trim_lib.h
