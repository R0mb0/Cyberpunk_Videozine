rem
rem Now that gnu emacs is available for dos, here is a batch file to create
rem a tags file for all this set of sources. You will need gnu etags.
rem

del c:\demacs\tags

etags -a -t -f c:\demacs\tags c:\c\irit\cagd_lib\*.h
etags -a -t -f c:\demacs\tags c:\c\irit\cagd_lib\*.c
etags -a -t -f c:\demacs\tags c:\c\irit\misc_lib\*.h
etags -a -t -f c:\demacs\tags c:\c\irit\misc_lib\*.c
etags -a -t -f c:\demacs\tags c:\c\irit\irit\*.h
etags -a -t -f c:\demacs\tags c:\c\irit\irit\*.c
etags -a -t -f c:\demacs\tags c:\c\irit\filters\*.h
etags -a -t -f c:\demacs\tags c:\c\irit\filters\*.c
etags -a -t -f c:\demacs\tags c:\c\irit\poly3d\*.h
etags -a -t -f c:\demacs\tags c:\c\irit\poly3d\*.c
etags -a -t -f c:\demacs\tags c:\c\irit\poly3d-r\*.h
etags -a -t -f c:\demacs\tags c:\c\irit\poly3d-r\*.c
etags -a -t -f c:\demacs\tags c:\c\irit\poly3d-h\*.h
etags -a -t -f c:\demacs\tags c:\c\irit\poly3d-h\*.c

