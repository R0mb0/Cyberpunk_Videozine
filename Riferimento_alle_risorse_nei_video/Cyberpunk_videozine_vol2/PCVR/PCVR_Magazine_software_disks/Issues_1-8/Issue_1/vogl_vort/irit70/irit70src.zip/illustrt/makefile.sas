#
# Makefile for the ILLUSTRT program.
#
#					Gershon Elber, June 1993
#

include ../makeflag.sas

OBJECTS	= illustrt.o intersct.o spltsort.o

all:	illustrt

illustrt:	$(OBJECTS)
	slink from lib:c.o $(OBJECTS) to illustrt $(SYMS) lib $(LIBS)\
$(MORELIBS) $(MATHLIB) lib:scnb.lib

install: illustrt
	mv -f illustrt $(BIN_DIR)
	cp illustrt.cfg $(BIN_DIR)


# DO NOT DELETE THIS LINE -- make depend depends on it.

illustrt.o: program.h ../include/irit_sm.h ../include/genmat.h
illustrt.o: ../include/iritprsr.h ../include/cagd_lib.h ../include/imalloc.h
illustrt.o: ../include/miscattr.h ../include/symb_lib.h ../include/trim_lib.h
illustrt.o: ../include/triv_lib.h ../include/attribut.h ../include/allocate.h
illustrt.o: ../include/config.h ../include/iritgrap.h ../include/poly_cln.h
illustrt.o: ../include/geomat3d.h ../include/getarg.h ../include/ip_cnvrt.h
intersct.o: program.h ../include/irit_sm.h ../include/genmat.h
intersct.o: ../include/iritprsr.h ../include/cagd_lib.h ../include/imalloc.h
intersct.o: ../include/miscattr.h ../include/symb_lib.h ../include/trim_lib.h
intersct.o: ../include/triv_lib.h ../include/attribut.h ../include/allocate.h
intersct.o: ../include/ln_sweep.h
spltsort.o: program.h ../include/irit_sm.h ../include/genmat.h
spltsort.o: ../include/iritprsr.h ../include/cagd_lib.h ../include/imalloc.h
spltsort.o: ../include/miscattr.h ../include/symb_lib.h ../include/trim_lib.h
spltsort.o: ../include/triv_lib.h ../include/attribut.h ../include/allocate.h
