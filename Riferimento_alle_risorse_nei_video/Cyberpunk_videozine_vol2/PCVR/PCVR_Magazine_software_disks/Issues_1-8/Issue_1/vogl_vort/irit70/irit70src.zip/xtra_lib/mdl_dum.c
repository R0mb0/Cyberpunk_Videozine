/*****************************************************************************
*   Dummy function all to link in the Mdl missing functions.		     *
******************************************************************************
* (C) Gershon Elber, Technion, Israel Institute of Technology                *
******************************************************************************
* Written by:  Gershon Elber			       Ver 1.0, Dec. 1996    *
*****************************************************************************/

#include "irit_sm.h"
#include "mdl_lib.h"

void MdlTrimSegFree(MdlTrimSegStruct *MTSeg)
{
    fprintf(stderr, "MdlTrimSegFree Not supported\n");
}

void MdlTrimSegFreeList(MdlTrimSegStruct *MTSegList)
{
    fprintf(stderr, "MdlTrimSegFreeList Not supported\n");
}

void MdlTrimSegRefFree(MdlTrimSegRefStruct *MTSegRef)
{
    fprintf(stderr, "MdlTrimSegRefFree Not supported\n");
}

void MdlLoopFree(MdlLoopStruct *MdlLoop)
{
    fprintf(stderr, "MdlLoopFree Not supported\n");
}

void MdlTrimSrfFree(MdlTrimSrfStruct *TrimSrf)
{
    fprintf(stderr, "MdlTrimSrfFree Not supported\n");
}

void MdlTrimSrfFreeList(MdlTrimSrfStruct *MdlTrimSrfList)
{
    fprintf(stderr, "MdlTrimSrfFreeList Not supported\n");
}

void MdlModelFree(MdlModelStruct *Model)
{
    fprintf(stderr, "MdlModelFree Not supported\n");
}

void MdlModelFreeList(MdlModelStruct *Model)
{
    fprintf(stderr, "MdlModelFreeList Not supported\n");
}

MdlTrimSegStruct *MdlTrimSegCopy(MdlTrimSegStruct *MdlTrimSeg,
				 MdlTrimSrfStruct *TrimSrfList)
{
    fprintf(stderr, "MdlTrimSegCopy Not supported\n");

    return NULL;
}

MdlTrimSegStruct *MdlTrimSegCopyList(MdlTrimSegStruct *MdlTrimSegList,
				     MdlTrimSrfStruct *TrimSrfList)
{
    fprintf(stderr, "MdlTrimSegCopyList Not supported\n");

    return NULL;
}

MdlTrimSegRefStruct *MdlTrimSegRefCopy(MdlTrimSegRefStruct *MTSegRefList,
				       MdlTrimSegStruct *TrimSegList)
{
    fprintf(stderr, "MdlTrimSegRefCopy Not supported\n");

    return NULL;
}

MdlTrimSegRefStruct *MdlTrimSegRefCopyList(MdlTrimSegRefStruct *SegRefList,
					   MdlTrimSegStruct *TrimSegList)
{
    fprintf(stderr, "MdlTrimSegRefCopyList Not supported\n");

    return NULL;
}

MdlLoopStruct *MdlLoopCopy(MdlLoopStruct *MdlLoop, 
			   MdlTrimSegStruct *TrimSegList)
{
    fprintf(stderr, "MdlLoopCopy Not supported\n");

    return NULL;
}

MdlLoopStruct *MdlLoopCopyList(MdlLoopStruct *MdlLoopList, 
			       MdlTrimSegStruct *TrimSegList)
{
    fprintf(stderr, "MdlLoopCopyList Not supported\n");

    return NULL;
}

MdlTrimSrfStruct *MdlTrimSrfCopy(MdlTrimSrfStruct *MdlTrimSrf, 
				 MdlTrimSegStruct *TrimSegList)
{
    fprintf(stderr, "MdlTrimSrfCopy Not supported\n");

    return NULL;
}

MdlTrimSrfStruct *MdlTrimSrfCopyList(MdlTrimSrfStruct *MdlTrimSrfList, 
				     MdlTrimSegStruct *TrimSegList)
{
    fprintf(stderr, "MdlTrimSrfCopyList Not supported\n");

    return NULL;
}

MdlModelStruct *MdlModelCopy(MdlModelStruct *Model)
{
    fprintf(stderr, "MdlModelCopy Not supported\n");

    return NULL;
}

MdlModelStruct *MdlModelCopyList(MdlModelStruct *ModelList)
{
    fprintf(stderr, "MdlModelCopyList Not supported\n");

    return NULL;
}

MdlTrimSegStruct *MdlTrimSegNew(CagdCrvStruct *UVCrv1,
				CagdCrvStruct *UVCrv2,
                                CagdCrvStruct *EucCrv1,
                                MdlTrimSrfStruct *SrfFirst,
                                MdlTrimSrfStruct *SrfSecond)
{
    fprintf(stderr, "MdlTrimSegNew Not supported\n");

    return NULL;
}

MdlTrimSegRefStruct *MdlTrimSegRefNew(MdlTrimSegStruct *MdlTrimSeg)
{
    fprintf(stderr, "MdlTrimSegRefNew Not supported\n");

    return NULL;
}

MdlLoopStruct *MdlLoopNew(MdlTrimSegRefStruct *MdlTrimSegRefList)
{
    fprintf(stderr, "MdlLoopNew Not supported\n");

    return NULL;
}

MdlTrimSrfStruct *MdlTrimSrfNew(CagdSrfStruct *Srf,
				MdlLoopStruct *LoopList, 
				CagdBType HasTopLvlTrim)
{
    fprintf(stderr, "MdlTrimSrfNew Not supported\n");

    return NULL;
}

MdlTrimSrfStruct *MdlTrimSrfNew2(CagdSrfStruct *Srf,
	 		         CagdCrvStruct *LoopList, 
			         CagdBType HasTopLvlTrim)
{
    fprintf(stderr, "MdlTrimSrfNew2 Not supported\n");

    return NULL;
}

MdlModelStruct *MdlModelNew(CagdSrfStruct *Srf,
		            CagdCrvStruct *LoopList,
		            CagdBType HasTopLvlTrim)
{
    fprintf(stderr, "MdlModelNew Not supported\n");

    return NULL;
}

MdlModelStruct *MdlModelNew2(MdlTrimSrfStruct *TrimSrfs,
			     MdlTrimSegStruct *TrimSegs)
{
    fprintf(stderr, "MdlModelNew2 Not supported\n");

    return NULL;
}

void MdlPatchTrimmingSegPointers(MdlModelStruct *Model)
{
    fprintf(stderr, "MdlPatchTrimmingSegPointers Not supported\n");
}

int MdlGetLoopSegIndex(MdlTrimSegRefStruct *TrimSeg,
		       MdlTrimSegStruct *TrimSegList)
{
    fprintf(stderr, "MdlGetLoopSegIndex Not supported\n");

    return 0;
}

int MdlGetSrfIndex(MdlTrimSrfStruct *Srf, MdlTrimSrfStruct *TrimSrfList)
{
    fprintf(stderr, "MdlGetSrfIndex Not supported\n");

    return 0;
}

void MdlModelTransform(MdlModelStruct *Model,
		       CagdRType *Translate,
		       CagdRType Scale)
{
    fprintf(stderr, "MdlModelTransform Not supported\n");
}

void MdlModelMatTransform(MdlModelStruct *Model, CagdMType Mat)
{
    fprintf(stderr, "MdlModelMatTransform Not supported\n");
}

/******************************************************************************
* Bounding boxes routines.						      *
******************************************************************************/

void MdlModelBBox(MdlModelStruct *Mdl, CagdBBoxStruct *BBox)
{
    fprintf(stderr, "MdlModelBBox Not supported\n");
}

void MdlModelListBBox(MdlModelStruct *Mdls, CagdBBoxStruct *BBox)
{
    fprintf(stderr, "MdlModelListBBox Not supported\n");
}

/******************************************************************************
* Boolean operations.							      *
******************************************************************************/

CagdCrvStruct *MdlExtractUVCrv(MdlTrimSrfStruct *Srf, MdlTrimSegStruct *Seg)
{
    fprintf(stderr, "MdlExtractUVCrv Not supported\n");
 
    return NULL;
}

CagdCrvStruct *MdlExtructReversUVCrv(MdlTrimSrfStruct *MdlSrf, 
				     MdlTrimSegStruct *MdlSeg)
{
    fprintf(stderr, "MdlExtructReversUVCrv Not supported\n");
 
    return NULL;
}

MdlModelStruct *MdlBooleanOperator(MdlModelStruct *Model1, 
				   MdlModelStruct *Model2,
				   MdlBoolType BoolOperator)
{
    fprintf(stderr, "MdlBooleanOperator Not supported\n");
 
    return NULL;
}

MdlModelStruct *MdlBooleanUnion(MdlModelStruct *Model1, 
				MdlModelStruct *Model2)
{
    fprintf(stderr, "MdlBooleanUnion Not supported\n");
 
    return NULL;
}

MdlModelStruct *MdlBooleanIntersection(MdlModelStruct *Model1, 
				       MdlModelStruct *Model2)
{
    fprintf(stderr, "MdlBooleanIntersection Not supported\n");
 
    return NULL;
}

MdlModelStruct *MdlBooleanSubtraction(MdlModelStruct *Model1, 
				      MdlModelStruct *Model2)
{
    fprintf(stderr, "MdlBooleanSubtraction Not supported\n");
 
    return NULL;
}

TrimSrfStruct *MdlTrimConvert(MdlModelStruct *Model)
{
    fprintf(stderr, "MdlTrimConvert Not supported\n");

    return NULL;
}



/******************************************************************************
* Error handling.							      *
******************************************************************************/

void MdlFatalError(MdlFatalErrorType ErrID)
{
    fprintf(stderr, "MdlFatalError Not supported\n");
}

char *MdlDescribeError(MdlFatalErrorType ErrID)
{
    fprintf(stderr, "MdlDescribeError Not supported\n");

    return NULL;
}
