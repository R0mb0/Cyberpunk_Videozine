#
# This is the make file for the xtra lib subdirectory.
#
#				Gershon Elber, Aug 1991
#

include ../makeflag.sas

OBJS = bzrintrp.o cnvxhull.o filt.o mdl_dum.o nure_svd.o

xtra.lib: $(OBJS)
	rm -f xtra.lib
	oml xtra.lib a *.o

install: xtra.lib
	mv -f xtra.lib $(LIB_DIR)

# DO NOT DELETE THIS LINE -- make depend depends on it.

bzrintrp.o: ../include/irit_sm.h ../include/extra_fn.h
nure_svd.o: ../include/irit_sm.h ../include/imalloc.h
