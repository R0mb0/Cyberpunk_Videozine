/*****************************************************************************
*  Animation module - call back functions used by display devices - supplied *
* here dummies for use in batch programs.				     *
******************************************************************************
* (C) Gershon Elber, Technion, Israel Institute of Technology                *
******************************************************************************
*							Ver 0.1, Feb. 1995.  *
*****************************************************************************/

#include "irit_sm.h"
#include "iritgrap.h"
#include "animate.h"

int IGGlblViewMode;

void IGRedrawViewWindow(void)
{
}

int AnimCheckInterrupt(AnimationStruct *Anim)
{
    return Anim != NULL;
}
