#
# Makefile for the IRENDER scan converter.
#

include ../makeflag.sas

#
# This might be defined in the URT's rle_config.h.
# If so, you may comment it out.
#
MORE_FLAGS = DEFINE=USE_PROTOTYPES=1 DEFINE=USE_STDLIB_H=1 # For the rle include.

OBJS	= main.o config.o parser.o map.o polyline.o \
	  lights.o rle.o ppm.o image.o bucket.o shader.o \
	  alias.o color.o interpol.o texture.o shadow.o 

all:	irender


irender:	$(OBJS)
	slink from lib:c.o $(OBJS) to irender sc $(SYMS) lib $(LIBS)\
$(MORELIBS) $(MATHLIB) lib:scnb.lib

install: irender
	mv -f irender $(BIN_DIR)
	cp irender.cfg $(BIN_DIR)


# DO NOT DELETE THIS LINE -- make depend depends on it.
