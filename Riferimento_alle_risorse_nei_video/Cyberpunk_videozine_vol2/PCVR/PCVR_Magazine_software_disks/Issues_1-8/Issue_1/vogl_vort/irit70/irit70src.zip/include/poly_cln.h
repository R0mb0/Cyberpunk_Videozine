/******************************************************************************
* Poly_cln.c - Clean polygonal data.					      *
*******************************************************************************
* (C) Gershon Elber, Technion, Israel Institute of Technology                 *
*******************************************************************************
* Written by Gershon Elber, June 1993.					      *
******************************************************************************/

#ifndef POLY_CLN_H
#define POLY_CLN_H

#if defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif

void CleanUpPolygonList(IPPolygonStruct **PPolygons);
void CleanUpPolylineList(IPPolygonStruct **PPolylines);

#if defined(__cplusplus) || defined(c_plusplus)
}
#endif

#endif /* POLY_CLN_H */
