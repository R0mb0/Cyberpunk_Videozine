zip %1 %2 %3 %4 %5 %6 %7 %8 -r irit-sm * -x *.exe -x *.o -x *.a -x *.obj -x *.lib -x *.pdb -x *.res -x *.dll -x *.def -x *.exp

