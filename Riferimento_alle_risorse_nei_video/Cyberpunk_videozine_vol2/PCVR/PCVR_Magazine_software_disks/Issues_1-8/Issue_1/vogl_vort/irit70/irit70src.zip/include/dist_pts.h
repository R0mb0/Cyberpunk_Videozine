/******************************************************************************
* Distribute N points in a one/two dimensional domain, so as to minimize      *
* their energy according to a given energy function.			      *
*******************************************************************************
* (C) Gershon Elber, Technion, Israel Institute of Technology                 *
*******************************************************************************
*				      Written by Gershon Elber, February 1994 *
******************************************************************************/

#ifndef DIST_PTS_H
#define DIST_PTS_H

typedef RealType (* DistEnergy1DFuncType)(RealType);

#if defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif

RealType *DistPoint1DWithEnergy(int N,
				RealType XMin,
				RealType XMax,
				int Resolution,
				DistEnergy1DFuncType EnergyFunc);

#if defined(__cplusplus) || defined(c_plusplus)
}
#endif

#endif /* DIST_PTS_H */
