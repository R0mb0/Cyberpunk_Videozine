/*****************************************************************************
*   "Irit" - the 3d polygonal solid modeller.				     *
*									     *
* Written by:  Gershon Elber				Ver 1.0, Feb. 1995   *
******************************************************************************
* (C) Gershon Elber, Technion, Israel Institute of Technology                *
******************************************************************************
* Global definitions of	xmtdrvs interface.			             *
*****************************************************************************/

#ifndef	XMTDRVS_H	/* Define only once */
#define	XMTDRVS_H

#define XTP			XtPointer
#define XTC			XtCallbackProc

#include "x11drvs.h"

extern Widget IGTopLevel, MainTransForm;

/* xmtdrvs.c */
Widget CreateSubForm(Widget Parent, int Pos);
Widget AddButton(Widget Parent,
		 char *Label,
		 int Pos,
		 XTC FuncPtr,
		 XTP FuncEvent);
Widget AddLabel(Widget Parent, char *Label, int Pos);
Widget AddSlide(Widget Parent,
		int Pos,
		int Range,
		XTC FuncPtr,
		XTP FuncEvent);
void SetLabel(Widget  w, char *NewLabel);

/* anim_xmt.c */
void CreateAnimation(Widget w);
void AnimationCB(void);
void ReplaceLabel(Widget  w, char *NewLabel);

#endif /* XMTDRVS_H */
