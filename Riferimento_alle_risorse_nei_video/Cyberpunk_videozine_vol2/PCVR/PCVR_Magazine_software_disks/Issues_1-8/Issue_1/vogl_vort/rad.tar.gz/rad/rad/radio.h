/**************************************************************************
  Copyright (C) 1992 Guy Moreillon
  All rights reserved.

  This software may be freely copied, modified, and redistributed
  provided that this copyright notice is preserved on all copies.

  You may not distribute this software, in whole or in part, as part of
  any commercial product without the express consent of the authors.

  There is no warranty or other guarantee of fitness of this software
  for any purpose.  It is provided solely "as is".
**************************************************************************/
/**************************************************************************

				RAD
		       (Interactive Radiosity)
		    	    Version 1.0
			       1992		    	    
		    	    
		  
		    	  Guy Moreillon
		    	  
**************************************************************************/

/**************************************************************************
  Fichier	: radio.h
  Description	: Declarations des fonctions de calcul de la radiosite
		  proprement dite
**************************************************************************/

#ifndef radio_h
#define radio_h

extern	BOOLEAN	comp_rad(SCENE_OP scene, int time_quota);

extern	void	find_subdiv(TRIANGLEP  tri,
			    SAMPLEP    sample);

extern	float	comp_newE(TRIANGLEP   tri);

#endif
