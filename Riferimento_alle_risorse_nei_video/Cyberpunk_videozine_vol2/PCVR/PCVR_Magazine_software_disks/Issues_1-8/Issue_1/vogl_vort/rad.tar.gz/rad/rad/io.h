/**************************************************************************
  Copyright (C) 1992 Guy Moreillon
  All rights reserved.

  This software may be freely copied, modified, and redistributed
  provided that this copyright notice is preserved on all copies.

  You may not distribute this software, in whole or in part, as part of
  any commercial product without the express consent of the authors.

  There is no warranty or other guarantee of fitness of this software
  for any purpose.  It is provided solely "as is".
**************************************************************************/
/**************************************************************************

				RAD
		       (Interactive Radiosity)
		    	    Version 1.0
			       1992		    	    
		    	    
		  
		    	  Guy Moreillon
		    	  
**************************************************************************/

/**************************************************************************
  Fichier	: io.h
  Description	: Declarations des fonctions utilisees pendant la lecture
		  ou l'ecriture de donnees sur fichier
**************************************************************************/

#ifndef io_h
#define io_h

#define START_POLY	256
#define END_POLY	257
#define START_SUBDIV	258
#define END_SUBDIV	259
#define FILL_FACT	1.5

#endif
