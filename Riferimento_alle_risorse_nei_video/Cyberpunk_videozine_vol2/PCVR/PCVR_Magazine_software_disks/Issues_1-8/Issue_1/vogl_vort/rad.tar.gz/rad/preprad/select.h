/**************************************************************************
  Copyright (C) 1992 Guy Moreillon
  All rights reserved.

  This software may be freely copied, modified, and redistributed
  provided that this copyright notice is preserved on all copies.

  You may not distribute this software, in whole or in part, as part of
  any commercial product without the express consent of the authors.

  There is no warranty or other guarantee of fitness of this software
  for any purpose.  It is provided solely "as is".
**************************************************************************/
/**************************************************************************

			     PREPRAD
		     (Scene preparation program)
		    	    Version 1.0
			       1992		    	    
		    	    
		  
		    	  Guy Moreillon
		    	  
**************************************************************************/

/**************************************************************************
  Fichier	: select.h
  Description	: Declaration des routines de management de l'interface
**************************************************************************/

#ifndef select_h
#define select_h

extern	void select_obj(SCENE_OP scene,
			SELECTIONP select,
			VECTOR point,
			BOOLEAN	poly);

OBJECT_OP select_box_obj(float x, float y,
			 BOX_OBJP tab, int nb_obj);

#endif
