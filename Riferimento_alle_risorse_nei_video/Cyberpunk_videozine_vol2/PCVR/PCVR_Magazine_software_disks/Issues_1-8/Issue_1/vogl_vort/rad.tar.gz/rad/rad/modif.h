/**************************************************************************
  Copyright (C) 1992 Guy Moreillon
  All rights reserved.

  This software may be freely copied, modified, and redistributed
  provided that this copyright notice is preserved on all copies.

  You may not distribute this software, in whole or in part, as part of
  any commercial product without the express consent of the authors.

  There is no warranty or other guarantee of fitness of this software
  for any purpose.  It is provided solely "as is".
**************************************************************************/
/**************************************************************************

				RAD
		       (Interactive Radiosity)
		    	    Version 1.0
			       1992		    	    
		    	    
		  
		    	  Guy Moreillon
		    	  
**************************************************************************/

/**************************************************************************
  Fichier	: modif.h
  Description	: Declaration des routines de gestion de queue de
		  modification d'objet
**************************************************************************/

#ifndef modif_h
#define modif_h

extern	void enq_modif(MODIFP modif);

extern	void remove_modif();

extern	void next_modif(MODIFP modif);

extern	BOOLEAN modif_q_not_empty();

extern	void empty_modif_queue();

#endif
