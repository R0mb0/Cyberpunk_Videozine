/**************************************************************************
  Copyright (C) 1992 Guy Moreillon
  All rights reserved.

  This software may be freely copied, modified, and redistributed
  provided that this copyright notice is preserved on all copies.

  You may not distribute this software, in whole or in part, as part of
  any commercial product without the express consent of the authors.

  There is no warranty or other guarantee of fitness of this software
  for any purpose.  It is provided solely "as is".
**************************************************************************/
/**************************************************************************

				RAD
		       (Interactive Radiosity)
		    	    Version 1.0
			       1992		    	    
		    	    
		  
		    	  Guy Moreillon
		    	  
**************************************************************************/

/**************************************************************************
  Fichier	: rad.h
  Description	: Exportation des variables globales
**************************************************************************/

#ifndef rad_h
#define rad_h

#define MAX_TEX		50

extern	SCENE_O	    the_scene;
extern	BOOLEAN	    min_size_set;
extern	BOOLEAN	    tex_yes;
extern	int	    tot_pol;
extern	int	    linecount;
extern	TEXTURE	    textures[MAX_TEX];
extern	char	    *scene_path, *off_path, *tex_path;

extern	long int    nb_rays;
extern	long int    nb_tests;
extern	long int    nb_hits;
extern	long int    nb_bbox_hits;
extern	long int    nb_bbox_trials;
extern	long int    nb_nif_tests;
extern	long int    nb_int_cuts;
extern	long int    nb_shad_test_av;
extern	long int    nb_patch;
extern	long int    nb_tri;

extern	void	    init_glob_var();

#endif

