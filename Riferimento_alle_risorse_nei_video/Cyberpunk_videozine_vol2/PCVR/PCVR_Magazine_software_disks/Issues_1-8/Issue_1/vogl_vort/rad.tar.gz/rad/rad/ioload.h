/**************************************************************************
  Copyright (C) 1992 Guy Moreillon
  All rights reserved.

  This software may be freely copied, modified, and redistributed
  provided that this copyright notice is preserved on all copies.

  You may not distribute this software, in whole or in part, as part of
  any commercial product without the express consent of the authors.

  There is no warranty or other guarantee of fitness of this software
  for any purpose.  It is provided solely "as is".
**************************************************************************/
/**************************************************************************

				RAD
		       (Interactive Radiosity)
		    	    Version 1.0
			       1992		    	    
		    	    
		  
		    	  Guy Moreillon
		    	  
**************************************************************************/

/**************************************************************************
  Fichier	: io.h
  Description	: Declarations des fonctions utilisees pour la lecture
		  de donnees sur fichier
**************************************************************************/

#ifndef ioload_h
#define ioload_h

extern	BOOLEAN	load_new_state(FILE	    *file,
			       File_type    type,
			       SCENE_OP	    scene);

#endif
