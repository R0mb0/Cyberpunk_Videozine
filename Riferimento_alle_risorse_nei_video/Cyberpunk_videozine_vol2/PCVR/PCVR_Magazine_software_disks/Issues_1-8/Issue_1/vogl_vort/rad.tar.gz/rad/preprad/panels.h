/**************************************************************************
  Copyright (C) 1992 Guy Moreillon
  All rights reserved.

  This software may be freely copied, modified, and redistributed
  provided that this copyright notice is preserved on all copies.

  You may not distribute this software, in whole or in part, as part of
  any commercial product without the express consent of the authors.

  There is no warranty or other guarantee of fitness of this software
  for any purpose.  It is provided solely "as is".
**************************************************************************/
/* Header file generated with fdesign. */

/**** Callback routines ****/






/**** Forms and Objects ****/

extern FL_FORM *Control_Panel;

extern FL_OBJECT
        *Create_Object_Button,
        *Modify_Object_Button,
        *Join_Object_Button,
        *Split_Object_Button,
        *Aperture_Slider,
        *Display_Normals_Button,
        *Display_B_boxes_Button,
        *Load_Button,
        *Write_Button,
        *Quit_Button,
        *Destroy_Object_Button;

extern FL_FORM *Edit_Panel;

extern FL_OBJECT
        *Red_Slider,
        *Green_Slider,
        *Blue_Slider,
        *Color_Box,
        *Edit_Reflectivity_Input,
        *Edit_Emissivity_Input,
        *Edit_Ok_Button,
        *Edit_Cancel_Button,
        *Edit_Object_Name_Input,
        *Edit_Shadows_Button,
        *Add_Texture_Button;

extern FL_FORM *Texture_Panel;

extern FL_OBJECT
        *Texture_Name_Browser,
        *Scale_Input,
        *Tex_Reflectivity_Input,
        *Tex_Emissivity_Input,
        *Texture_Box,
	*Texture_Pict,
        *Tex_Object_Name_Input,
        *Tex_Shadows_Button,
        *Tex_Ok_Button,
        *Tex_Cancel_Button,
        *No_Texture_Button;



/**** Creation Routine ****/

extern void create_the_forms();
