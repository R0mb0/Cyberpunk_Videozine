/**************************************************************************
  Copyright (C) 1992 Guy Moreillon
  All rights reserved.

  This software may be freely copied, modified, and redistributed
  provided that this copyright notice is preserved on all copies.

  You may not distribute this software, in whole or in part, as part of
  any commercial product without the express consent of the authors.

  There is no warranty or other guarantee of fitness of this software
  for any purpose.  It is provided solely "as is".
**************************************************************************/
/**************************************************************************

			     PREPRAD
		     (Scene preparation program)
		    	    Version 1.0
			       1992		    	    
		    	    
		  
		    	  Guy Moreillon
		    	  
**************************************************************************/

/**************************************************************************
  Fichier	: ray.h
  Description	: Declarations des fonctions de calcul des ombres
		  portees (raytracing)
**************************************************************************/

#ifndef ray_h
#define ray_h

extern	BOOLEAN object_in_sight(SELECTIONP  select,
				RAYP	    ray,
				SCENE_OP    scene,
				float	    dis,
				BOOLEAN	    poly);

extern	void	init_grids(OBJECT_OP   object);

#endif

