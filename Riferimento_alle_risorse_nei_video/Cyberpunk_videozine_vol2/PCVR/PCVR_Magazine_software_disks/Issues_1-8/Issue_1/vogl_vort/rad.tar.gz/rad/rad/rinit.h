/**************************************************************************
  Copyright (C) 1992 Guy Moreillon
  All rights reserved.

  This software may be freely copied, modified, and redistributed
  provided that this copyright notice is preserved on all copies.

  You may not distribute this software, in whole or in part, as part of
  any commercial product without the express consent of the authors.

  There is no warranty or other guarantee of fitness of this software
  for any purpose.  It is provided solely "as is".
**************************************************************************/
/**************************************************************************

				RAD
		       (Interactive Radiosity)
		    	    Version 1.0
			       1992		    	    
		    	    
		  
		    	  Guy Moreillon
		    	  
**************************************************************************/

/**************************************************************************
  Fichier	: rinit.h
  Description	: Declarations des fonctions d'initialisation des donnees
**************************************************************************/

#ifndef rinit_h
#define rinit_h

extern	void prep_object(OBJECT_OP  object,
			 OBJECT_OP  dad,
			 VECTOR	    bbox0,
			 VECTOR	    bbox1);

extern	void init_samples(TRIANGLE *tri);

extern	void init_tev();

extern	void init_scene(SCENE_OP scene);

#endif
