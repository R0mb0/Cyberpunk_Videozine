/**************************************************************************
  Copyright (C) 1992 Guy Moreillon
  All rights reserved.

  This software may be freely copied, modified, and redistributed
  provided that this copyright notice is preserved on all copies.

  You may not distribute this software, in whole or in part, as part of
  any commercial product without the express consent of the authors.

  There is no warranty or other guarantee of fitness of this software
  for any purpose.  It is provided solely "as is".
**************************************************************************/
/**************************************************************************

				RAD
		       (Interactive Radiosity)
		    	    Version 1.0
			       1992		    	    
		    	    
		  
		    	  Guy Moreillon
		    	  
**************************************************************************/

/**************************************************************************
  Fichier	: constants.h
  Description	: Fichier de definition des constantes (include)
**************************************************************************/

#ifndef constants_h
#define constants_h

#ifndef TRUE
#define	TRUE		1
#endif

#ifndef FALSE
#define FALSE		0
#endif

#define NAME_SIZE	64
#define STRING_SIZE	128
#define GRID_SIZE	20
#define TRI_BLOCK_SIZE	250
#define VERT_BLOCK_SIZE	10

#define MAX_DEPTH	20
#define NB_SAMPLES	3

#endif
