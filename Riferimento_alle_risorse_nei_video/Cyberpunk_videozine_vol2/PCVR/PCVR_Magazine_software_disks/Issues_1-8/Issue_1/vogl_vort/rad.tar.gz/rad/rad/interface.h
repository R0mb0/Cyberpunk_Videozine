/**************************************************************************
  Copyright (C) 1992 Guy Moreillon
  All rights reserved.

  This software may be freely copied, modified, and redistributed
  provided that this copyright notice is preserved on all copies.

  You may not distribute this software, in whole or in part, as part of
  any commercial product without the express consent of the authors.

  There is no warranty or other guarantee of fitness of this software
  for any purpose.  It is provided solely "as is".
**************************************************************************/
/**************************************************************************

				RAD
		       (Interactive Radiosity)
		    	    Version 1.0
			       1992		    	    
		    	    
		  
		    	  Guy Moreillon
		    	  
**************************************************************************/

/**************************************************************************
  Fichier	: interface.h
  Description	: Declaration des routines de gestion de l'interface
**************************************************************************/

#ifndef interface_h
#define interface_h

#define	NOPATTERN	0
#define PATTERN		1

extern	float	min_disp2_size;

extern	float	center_x, center_y;
extern	float	ratio_alpha, ratio_beta;
extern	Matrix	rot_x_m, rot_y_m, trans_m, modif_m;

extern	void	run_display(SCENE_OP scene);

#endif
