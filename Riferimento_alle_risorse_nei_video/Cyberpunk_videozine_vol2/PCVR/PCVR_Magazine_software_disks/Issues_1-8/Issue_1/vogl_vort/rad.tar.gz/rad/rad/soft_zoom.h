/**************************************************************************
  Copyright (C) 1992 Guy Moreillon
  All rights reserved.

  This software may be freely copied, modified, and redistributed
  provided that this copyright notice is preserved on all copies.

  You may not distribute this software, in whole or in part, as part of
  any commercial product without the express consent of the authors.

  There is no warranty or other guarantee of fitness of this software
  for any purpose.  It is provided solely "as is".
**************************************************************************/
/**************************************************************************

				RAD
		       (Interactive Radiosity)
		    	    Version 1.0
			       1992		    	    
		    	    
		  
		    	  Guy Moreillon
		    	  
**************************************************************************/

/**************************************************************************
  Fichier	: soft_zoom.h
  Description	: Declaration des routines de zoom d'une image
**************************************************************************/

#ifndef soft_zoom_h
#define soft_zoom_h


#define IMPULSE		1
#define BOX		2
#define TRIANGLE	3
#define QUADRATIC	4
#define MITCHELL	5
#define IRIS            6


extern void soft_zoom(unsigned long *in_image, 
                      unsigned long *out_image,
                      int in_size_x,  int in_size_y, int in_size_z,
                      int out_size_x, int out_size_y);

#endif
