/**************************************************************************
  Copyright (C) 1992 Guy Moreillon
  All rights reserved.

  This software may be freely copied, modified, and redistributed
  provided that this copyright notice is preserved on all copies.

  You may not distribute this software, in whole or in part, as part of
  any commercial product without the express consent of the authors.

  There is no warranty or other guarantee of fitness of this software
  for any purpose.  It is provided solely "as is".
**************************************************************************/
/* Header file generated with fdesign. */

/**** Callback routines ****/







/**** Forms and Objects ****/

extern FL_FORM *Control_Panel;

extern FL_OBJECT
        *Translation_Slider,
        *Rotation_Slider,
        *Aperture_Slider,
        *Update_Rate_Slider,
        *Load_Button,
        *Save_Button,
        *Hold_Button,
        *Quit_Button,
        *Activity_Dial;

extern FL_FORM *Edit_Panel;

extern FL_OBJECT
        *Red_Slider,
        *Green_Slider,
        *Blue_Slider,
        *Color_Box,
        *Edit_Reflectivity_Input,
        *Edit_Emissivity_Input,
        *Ok_to_modify_object_Button,
        *Add_Texture_Button;

extern FL_FORM *Texture_Panel;

extern FL_OBJECT
        *Texture_Name_Browser,
        *Scale_Input,
        *Tex_Reflectivity_Input,
        *Tex_Emissivity_Input,
        *Bind_and_Modify_Button,
        *No_Texture_Button,
        *Texture_Box,
	*Texture_Pict;

extern FL_FORM *Radiosity_Panel;

extern FL_OBJECT
        *Rad_Red_Text,
        *Rad_Green_Text,
        *Rad_Blue_Text;



/**** Creation Routine ****/

extern void create_the_forms();
