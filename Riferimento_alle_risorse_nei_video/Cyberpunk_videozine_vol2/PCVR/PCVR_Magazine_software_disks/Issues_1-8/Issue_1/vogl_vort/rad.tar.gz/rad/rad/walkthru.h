/**************************************************************************
  Copyright (C) 1992 Guy Moreillon
  All rights reserved.

  This software may be freely copied, modified, and redistributed
  provided that this copyright notice is preserved on all copies.

  You may not distribute this software, in whole or in part, as part of
  any commercial product without the express consent of the authors.

  There is no warranty or other guarantee of fitness of this software
  for any purpose.  It is provided solely "as is".
**************************************************************************/
/**************************************************************************

				RAD
		       (Interactive Radiosity)
		    	    Version 1.0
			       1992		    	    
		    	    
		  
		    	  Guy Moreillon
		    	  
**************************************************************************/

/**************************************************************************
  Fichier	: walkthru.h
  Description	: Declaration des routines de management du walkthrough
**************************************************************************/

#ifndef walkthru_h
#define walkthru_h

extern	void build_rotation_x(float db, Matrix matrix);

extern	void build_rotation_y(float da, Matrix matrix);

extern	void build_translation(float step, Matrix matrix);

#endif
