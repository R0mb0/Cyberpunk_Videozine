/**************************************************************************
  Copyright (C) 1992 Guy Moreillon
  All rights reserved.

  This software may be freely copied, modified, and redistributed
  provided that this copyright notice is preserved on all copies.

  You may not distribute this software, in whole or in part, as part of
  any commercial product without the express consent of the authors.

  There is no warranty or other guarantee of fitness of this software
  for any purpose.  It is provided solely "as is".
**************************************************************************/
/**************************************************************************

			     PREPRAD
		     (Scene preparation program)
		    	    Version 1.0
			       1992		    	    
		    	    
		  
		    	  Guy Moreillon
		    	  
**************************************************************************/

/**************************************************************************
  Fichier	: preprad.h
  Description	: Declarations de macros generales et de variables globales
**************************************************************************/

#ifndef preprad_h
#define preprad_h

#define NOPATTERN	0
#define	PATTERN		1

#define BOX_SIZE	10.0
#define DBL_BOX		(BOX_SIZE*2.0)
#define HALF_BOX	(BOX_SIZE/2.0)
#define MAX_TEX		50

#define Mark(OBJ) OBJ->name[strlen(OBJ->name)+1] |= '\1'
#define Markswitch(OBJ) OBJ->name[strlen(OBJ->name)+1] ^= '\1'
#define unMark(OBJ) OBJ->name[strlen(OBJ->name)+1] &= '\0'
#define Marked(OBJ) (OBJ->name[strlen(OBJ->name)+1] & '\1')

#define Hide(OBJ) OBJ->name[strlen(OBJ->name)+1] |= '\2'
#define Hideswitch(OBJ) OBJ->name[strlen(OBJ->name)+1] ^= '\2'
#define unHide(OBJ) OBJ->name[strlen(OBJ->name)+1] &= '\1'
#define Hidden(OBJ) (OBJ->name[strlen(OBJ->name)+1] & '\2')

extern	char	*scene_path, *off_path, *tex_path;

#endif
