/**************************************************************************
  Copyright (C) 1992 Guy Moreillon
  All rights reserved.

  This software may be freely copied, modified, and redistributed
  provided that this copyright notice is preserved on all copies.

  You may not distribute this software, in whole or in part, as part of
  any commercial product without the express consent of the authors.

  There is no warranty or other guarantee of fitness of this software
  for any purpose.  It is provided solely "as is".
**************************************************************************/
/**************************************************************************

			     PREPRAD
		     (Scene preparation program)
		    	    Version 1.0
			       1992		    	    
		    	    
		  
		    	  Guy Moreillon
		    	  
**************************************************************************/

/**************************************************************************
  Fichier	: object.h
  Description	: Declarations des fonctions de manipulation d'objet
**************************************************************************/

#ifndef object_h
#define object_h

OBJECT_OP create_object(SCENE_OP    scene,
			int	    nb_pol,
			OBJECT_OP   *tab_dad,
			int	    nb_dad);

#endif
