/**************************************************************************
  Copyright (C) 1992 Guy Moreillon
  All rights reserved.

  This software may be freely copied, modified, and redistributed
  provided that this copyright notice is preserved on all copies.

  You may not distribute this software, in whole or in part, as part of
  any commercial product without the express consent of the authors.

  There is no warranty or other guarantee of fitness of this software
  for any purpose.  It is provided solely "as is".
**************************************************************************/
/**************************************************************************

			     PREPRAD
		     (Scene preparation program)
		    	    Version 1.0
			       1992		    	    
		    	    
		  
		    	  Guy Moreillon
		    	  
**************************************************************************/

/**************************************************************************
  Fichier	: prtype.h
  Description	: Types propes a Preprad
**************************************************************************/

#ifndef prtype_h
#define prtype_h

typedef struct {
	OBJECT_OP   obj;
	float	    x;
	float	    y;
	} BOX_OBJ, *BOX_OBJP;

typedef struct {
	TEXMAP	    map;
	TEXTURE	    texture;
	} TEX, *TEXP;

typedef struct {
	OBJECT_OP   object;
	float	    ro, E;
	BOOLEAN	    shadows;
	VECTOR	    color;
	TEX	    tex;
	NAME	    name;
	} MAT, *MATP;

typedef void (*Proc)();

#endif
