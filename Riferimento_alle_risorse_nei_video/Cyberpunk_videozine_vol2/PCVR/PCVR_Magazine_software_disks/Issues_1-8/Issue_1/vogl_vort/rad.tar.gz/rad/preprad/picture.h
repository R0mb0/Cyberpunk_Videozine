/**************************************************************************
  Copyright (C) 1992 Guy Moreillon
  All rights reserved.

  This software may be freely copied, modified, and redistributed
  provided that this copyright notice is preserved on all copies.

  You may not distribute this software, in whole or in part, as part of
  any commercial product without the express consent of the authors.

  There is no warranty or other guarantee of fitness of this software
  for any purpose.  It is provided solely "as is".
**************************************************************************/
/**************************************************************************

				RAD
		       (Interactive Radiosity)
		    	    Version 1.0
			       1992		    	    
		    	    
		  
		    	  Guy Moreillon
		    	  
**************************************************************************/

/**************************************************************************
  Fichier	: picture.h
  Description	: Declaration des routines de gestion de l'objet libre
		  Picture
**************************************************************************/

#ifndef picture_h
#define picture_h

extern	void set_picture(unsigned long *image, int width, int height);

extern	int picture_handle(FL_OBJECT *obj,
			   int event,
			   float mx, float my,
			   char key);

#endif
