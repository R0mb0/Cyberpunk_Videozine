/**************************************************************************
  Copyright (C) 1992 Guy Moreillon
  All rights reserved.

  This software may be freely copied, modified, and redistributed
  provided that this copyright notice is preserved on all copies.

  You may not distribute this software, in whole or in part, as part of
  any commercial product without the express consent of the authors.

  There is no warranty or other guarantee of fitness of this software
  for any purpose.  It is provided solely "as is".
**************************************************************************/
/**************************************************************************

			     PREPRAD
		     (Scene preparation program)
		    	    Version 1.0
			       1992		    	    
		    	    
		  
		    	  Guy Moreillon
		    	  
**************************************************************************/

/**************************************************************************
  Fichier	: popup.h
  Description	: Declaration des routines de fenetre popup
**************************************************************************/

#ifndef popup_h
#define popup_h

extern	STR	tex_brow_path;

extern	BOOLEAN popup_caract(MATP val, SCENE_OP scene);

extern	void apply_modif(SCENE_OP scene);

#endif
