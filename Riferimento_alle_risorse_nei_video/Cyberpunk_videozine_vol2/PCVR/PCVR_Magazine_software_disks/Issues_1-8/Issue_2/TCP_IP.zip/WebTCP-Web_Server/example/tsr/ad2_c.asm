
        .model  small
	.code

        public _adconvert

_adconvert       proc

	push	bp
	mov	bp,sp
	mov     ax,[bp+4]

;	Convert the number in AX to board, side, channel

	push	ax			; save a copy

	mov	ah,0

	shl	ax,1
	shl	ax,1
	shl	ax,1
	shl	ax,1
	shl	ax,1
	mov	bh,ah			; got the board number
	and	bh,7			; clean it up

	shl	ax,1
	mov	bl,ah			; got the side number
	and	bl,1			; clean it up

	pop	ax			; got the channel number
	and	ax,3			; clean it up

	call	ad_convert

	pop	bp

		ret

;-------------------------------------------------------------------------
;
;	AD_convert - Do one A/D conversion
;
;	Enter with:
;	AL = Channel number
;	BH = Board number
;	BL = Side number
;
;	On return:
;	AX = Right justified 12 bit results
;
ad_convert:
	push	si
	push	dx
	push	cx
	push	bx

	mov	bl,18			; calculate pointer to channel data
	mul	bl
	mov	ah,0
		mov     si,offset rd_0
	add	si,ax

	pop	bx
	push	bx

	mov	dx,0F864h		; configure all Port F pins for
	mov	al,0			; output
	out	dx,al

	mov	al,0			; set CS0/ for write
	call	select

	mov	dx,0F862h		; point to output port
cmd_loop:
	mov	al,cs:[si]		; get a byte
	cmp	al,0			; done?
	je	cmd_done		; yes, leave
	out	dx,al			; no, send it
	inc	si			; bump pointer
	jmp	cmd_loop		; and loop

cmd_done:
	mov	dx,0F864h		; configure data line for read
	mov	al,10h
	out	dx,al

	mov	cx,16			; 16 bits to get
	mov	bx,0			; result goes here
	mov	ah,0
in_loop:
	mov	dx,0F860h
	in	al,dx			; data is in bit 4

	rcl	al,1			; rotate it into carry
	rcl	al,1
	rcl	al,1
	rcl	al,1
	rcl	bx,1			; rotate it from carry to bx

	mov	dx,0F862h		; point to output port
	mov	al,70h			; set the clock high
	out	dx,al

	mov	al,50h
	out	dx,al

	loop	in_loop	

	shr	bx,1			; last 3 bits are zeros, shift
	shr	bx,1			; 12 bit value over
	shr	bx,1
	and	bx,0FFFh

	mov	dx,0F862h		; idle the bus
	mov	al,40h
	out	dx,al
	mov	ax,bx

	call	bus_reset

	pop	bx
	pop	cx
	pop	dx
	pop	si

	retn

delay:
	push	ax
	mov	ax,10
delay_loop:
	dec	ax
	jnz	delay_loop
	pop	ax
	retn



;	Read A/D channel #0 single-ended

rd_0:
	db	50h,70h			; 1 Start
	db	40h,60h			; 0 A2
	db	40h,60h			; 0 A1
	db	50h,70h			; 1 A0
	db	40h,60h			; 0 Mode
	db	50h,70h			; 1 Single - Diff/
	db	50h,70h			; 1 PD1
	db	50h,70h			; 1 PD0

	db	50h			; idle the bus, data is high 
	db	0			; null terminator

;	Read A/D channel #1 single-ended

rd_1:   db      50h,70h                 ; 1 Start
	db	50h,70h			; 1 A2
	db	40h,60h			; 0 A1
	db	50h,70h			; 1 A0
	db	40h,60h			; 0 Mode
	db	50h,70h			; 1 Single - Diff/
	db	50h,70h			; 1 PD1
	db	50h,70h			; 1 PD0

	db	50h			; idle the bus, data is high 
	db	0			; null terminator

;	Read A/D channel #2 single-ended

rd_2:   db      50h,70h                 ; 1 Start
	db	40h,60h			; 0 A2
	db	50h,70h			; 1 A1
	db	40h,60h			; 0 A0
	db	40h,60h			; 0 Mode
	db	50h,70h			; 1 Single - Diff/
	db	50h,70h			; 1 PD1
	db	50h,70h			; 1 PD0

	db	50h			; idle the bus, data is high 
	db	0			; null terminator

;	Read A/D channel #3 single-ended

rd_3:   db      50h,70h                 ; 1 Start
	db	50h,70h			; 1 A2
	db	50h,70h			; 1 A1
	db	40h,60h			; 0 A0
	db	40h,60h			; 0 Mode
	db	50h,70h			; 1 Single - Diff/
	db	50h,70h			; 1 PD1
	db	50h,70h			; 1 PD0

	db	50h			; idle the bus, data is high 
	db	0			; null terminator

;-------------------------------------------------------------------------
;
;	Select - Activates the chip select for the proper device
;		 BH = Board to select, 0 - 8
;		 BL = Side to select, 0 - 1
;		 AL = Chip Select, 0 - 5
;
select:
	call	bus_reset		; reset the bus to start
	push	ax			; save the chip select
	mov	cl,bh			; get board in cl
board_select_loop:
	cmp	cl,0			; any to do
	je	side_select		; no, do the side
	mov	al,7			; select next board
	call	bus_channel		; do it
	dec	cl			; decrement board count
	jmp	board_select_loop	; and loop
side_select:
	cmp	bl,0			; if zero, don't do anything
	je	chip_select
	mov	al,6			; select side 1
	call	bus_channel
chip_select:
	pop	ax			; get the chip select
	call	bus_channel		; and do it
	retn

;-------------------------------------------------------------------------
;
;	Reset - send a reset pulse to all of the decoders on the bus
;
bus_reset:
	push	ax
	push	dx

	mov	dx,0F862h		; put a zero in the output ports
	mov	al,0
	out	dx,al

	mov	dx,0F864h		; select all outputs
	out	dx,al

	mov	dx,0F862h
	mov	al,40h			; lift reset
	out	dx,al

	pop	dx
	pop	ax

	retn

;-------------------------------------------------------------------------
;
;	Select selects the channel passed in AL
;
;
bus_channel:
	push	bx
	push	si			; going to need some registers
	push	dx
	push	ax

	mov	bl,al			; channel needs to go into bl

	mov	bh,0
	shl	bl,1			; multiply bl times 8 for proper
	shl	bl,1			; table offset
	shl	bl,1

	mov	si,offset select_table	; point to first entry
	add	si,bx			; add in offset

	mov	bx,8			; loop counter now
	mov	dx,0F862h		; point to port

send_loop:
	mov	al,cs:[si]		; get the byte
	out	dx,al			; send it
	inc	si			; bump pointer
	dec	bx			; unbump counter
	jnz	send_loop		; done?

	mov	al,050h			; idle the bus
	out	dx,al

	pop	ax
	pop	dx
	pop	si
	pop	bx

	retn

select_table:

s0      db      70h,50h,60h,40h,60h,40h,60h,40h
s1      db      70h,50h,60h,40h,60h,40h,70h,50h
s2      db      70h,50h,60h,40h,70h,50h,60h,40h
s3      db      70h,50h,60h,40h,70h,50h,70h,50h
s4      db      70h,50h,70h,50h,60h,40h,60h,40h
s5      db      70h,50h,70h,50h,60h,40h,70h,50h
s6      db      70h,50h,70h,50h,70h,50h,60h,40h
s7      db      70h,50h,70h,50h,70h,50h,70h,50h


_adconvert       endp
	end
