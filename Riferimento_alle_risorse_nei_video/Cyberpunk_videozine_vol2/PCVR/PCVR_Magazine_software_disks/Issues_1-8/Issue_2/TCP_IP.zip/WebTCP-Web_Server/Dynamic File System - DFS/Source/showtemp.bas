Start:
	  ' Ascii constants

	null$=chr$(0)
	ack$=chr$(6)

        OPTION BASE 0

        DIM temp1min$(12, 4)
        DIM temp1mintime$(12)

        DIM temp1hr$(12, 4)
        DIM temp1hrtime$(12)

	DIM temp1day$(24, 4)
	DIM temp1daytime$(24)

	' Set server link baudrate to 9600

	lcr%=inp(&h3fb)
	out &h3fb,&h80
	out &h3f8,12
	out &h3fb,lcr%


	  ' Open console communications

	open "cons:" for output as #2

	print #2,"Temperature to web page formatter"

	  ' Load the first half of the web page

	home1$=""
	open "home1.htm" for input as #3	
	while eof(3)=0
		line input #3,a$
		home1$=home1$+a$
	wend
	close 3

	  ' Load the second half of the web page

	home2$=""
	open "home2.htm" for input as #3
	while eof(3)=0
		line input #3,a$
		home2$=home2$+a$
	wend
	close 3

	' Wait for server to boot up

	print #2, "Waiting for server to boot... ";
	t$=time$
	for i = 2 to 1 step -1
		while t$=time$
		wend
		t$=time$
		print #2,i;
	next i	
	print #2,""

	' Send null log files

	filename$="hourlog.htm"
	tempfile$ = ""
	tempfile$ = tempfile$ + "<font size=+2>Sorry, not enough data yet, "
	tempfile$ = tempfile$ + "click to return "
	tempfile$ = tempfile$ + "<A HREF="+chr$(34)+"homepage.htm"+chr$(34)+">"
	tempfile$ = tempfile$ + "home</A>"
	tempfile$ = tempfile$ + "</FONT><p>"

	filedata$ = tempfile$
	gosub sendpacket

	filename$="minlog.htm"
	gosub sendpacket

	filename$="hourlog.htm"
	gosub sendpacket

	filename$="daylog.htm"
	gosub sendpacket

	RXready = 0

	t$ = TIME$

        ptr = 0
	minptr = 0
	dayptr = 0

	time2$=time$
      	hr = VAL(LEFT$(time2$, 2))
       	min = VAL(MID$(time2$, 4, 2))
	sec = VAL(RIGHT$(time2$, 2))


	' Main program loop

	while RXready = 0
		lineStatus=inp(&h2FD)
		RXready=lineStatus AND 1

		sec = VAL(RIGHT$(time$, 2))
		while int((sec) / 5) <> ((sec) / 5)
			t$=time$
       			min = VAL(MID$(t$, 4, 2))
			sec = VAL(RIGHT$(t$, 2))
		wend

		gosub gettemp
		gosub secondupdate
		gosub homeupdate
		if int((min) / 5) = ((min) / 5) and sec = 0 then gosub minuteupdate
		if min = 0 and sec = 0 then gosub hourupdate

	wend			
	end	
	




SendPacket:
	  ' Tell the user that the packet is being sent
	print #2,time$;" Sending File "+filename$

	  ' Convert the length of the file to 2 ascii chars
	FileLenHi=int(len(filedata$)/256)
	FileLenLo=len(filedata$)-(FileLenHi*256)
	FileLen$=chr$(FileLenLo)+chr$(FileLenHi)

	  ' Form the packet then calculate and append the checksum
	packet$=ack$+filename$+null$+fileLen$+filedata$

	  ' Send the packet

	checksum&=0
	for I& = 1 to len(packet$)
		txStatus%=inp(&h3FD) AND &h20
		while txStatus% = 0
			txStatus%=inp(&h3FD) AND &h20
		wend

		Ichar%=asc(mid$(packet$,I&,1%))
		checksum&=checksum&+Ichar%

		' Checksum is modulo 10000h

		if checksum& => 65536 then checksum& = checksum& - 65536
		out &h3f8,Ichar%
	next
	
 	  ' Convert checksum to 2's complement
	checksum& = 65536 - checksum&

	  ' Convert checksum to a 2 char string
	ChecksumHi%=int(checksum&/256)
	ChecksumLo%=checksum&-(ChecksumHi%*256)
	
	txStatus%=inp(&h3FD) AND &h20
	while txStatus% = 0
		txStatus%=inp(&h3FD) AND &h20
	wend
	out &h3f8,ChecksumLo%

	txStatus%=inp(&h3FD) AND &h20
	while txStatus% = 0
		txStatus%=inp(&h3FD) AND &h20
	wend
	out &h3f8,ChecksumHi%


'	print #1,packet$;

	  ' Tell the user that the packet was sent
	print #2,time$;" Done"
	return



GetTemp:
	 ' Get the 4 A/D readings and calibrate them to degrees F	
	t$=time$
	chan% = 0
	gosub getaverage
	chan = (chan% * .176) - 459.67
	t1 = int(chan * 10) / 10
	t1$=str$(t1)
	if len(t1$) = 3 then t1$ = " " + t1$ + ".0"
	if len(t1$) = 4 then t1$ = t1$ + ".0"
	if len(t1$) = 5 then t1$ = " " + t1$

	chan%=1
	gosub getaverage
	chan = (chan% * .176) - 461.5
	t2 = int(chan * 10) / 10	
	t2$=str$(t2)
	if len(t2$) = 3 then t2$ = " " + t2$ + ".0"
	if len(t2$) = 4 then t2$ = t2$ + ".0"
	if len(t2$) = 5 then t2$ = " " + t2$

	chan%=2
	gosub getaverage
	chan = (chan% * .176) - 458.7
	t3 = int(chan * 10) / 10	
	t3$=str$(t3)
	if len(t3$) = 3 then t3$ = " " + t3$ + ".0"
	if len(t3$) = 4 then t3$ = t3$ + ".0"
	if len(t3$) = 5 then t3$ = " " + t3$

	chan%=3
	gosub getaverage
	chan = (chan% * .176) - 460.1
	t4 = int(chan * 10) / 10	
	t4$=str$(t4)
	if len(t4$) = 3 then t4$ = " " + t4$ + ".0"
	if len(t4$) = 4 then t4$ = t4$ + ".0"
	if len(t4$) = 5 then t4$ = " " + t4$
	
	return


getaverage:

	 ' Get 100 readings and average them
	sum=0
	for average%=1 to 100
		temp%=chan%
		call adconvert(chan%)
		sum=sum+chan%
		chan%=temp%
	next average%
	chan%=sum/100
	return
       
       
secondupdate:      
	tempfile$=""
        temp1min$(ptr, 1) = t1$
        temp1min$(ptr, 2) = t2$
        temp1min$(ptr, 3) = t3$
        temp1min$(ptr, 4) = t4$
        temp1mintime$(ptr) = t$

	tempfile$ = tempfile$ + "<font size=+2>Click to see the "
	tempfile$ = tempfile$ + "<A HREF="+chr$(34)+"hourlog.htm"+chr$(34)+">"
	tempfile$ = tempfile$ + "last hour's</A> data, the "
	tempfile$ = tempfile$ + "<A HREF="+chr$(34)+"daylog.htm"+chr$(34)+">"
	tempfile$ = tempfile$ + "last 24 hour's</A> data "
	tempfile$ = tempfile$ + "or return "
	tempfile$ = tempfile$ + "<A HREF="+chr$(34)+"homepage.htm"+chr$(34)+">"
	tempfile$ = tempfile$ + "home</A>"
	tempfile$ = tempfile$ + "</FONT><p>"
	tempfile$ = tempfile$ + "<tt><pre><em>"

        tempfile$ = tempfile$ + " Time        T1      T2      T3      T4<p>"
        tempfile$ = tempfile$ + "--------   -----   -----   -----   -----<p>"
	tempfile$ = tempfile$ + "</em>"
	FOR i = 0 TO 11
                      if ptr - i < 0 then fileptr = ptr - i + 12 else fileptr = ptr - i
                      tempfile$ = tempfile$ + temp1mintime$(fileptr) + "  " + temp1min$(fileptr, 1) + "  " + temp1min$(fileptr, 2) + "  " + temp1min$(fileptr, 3) + "  " + temp1min$(fileptr, 4) + "<p>"
        NEXT i
        IF ptr = 11 THEN ptr = 0 ELSE ptr = ptr + 1

        tempfile$ = tempfile$ + "</pre></tt>"

	filename$="minlog.htm"
	filedata$=tempfile$
	gosub sendpacket

        RETURN
       
    
       
minuteupdate:      
	tempfile$=""
        temp1hr$(ptr, 1) = t1$
        temp1hr$(ptr, 2) = t2$
        temp1hr$(ptr, 3) = t3$
        temp1hr$(ptr, 4) = t4$
        temp1hrtime$(ptr) = t$

	tempfile$ = tempfile$ + "<font size=+2>Click to see the "
	tempfile$ = tempfile$ + "<A HREF="+chr$(34)+"minlog.htm"+chr$(34)+">"
	tempfile$ = tempfile$ + "last minute's</A> data, the "
	tempfile$ = tempfile$ + "<A HREF="+chr$(34)+"daylog.htm"+chr$(34)+">"
	tempfile$ = tempfile$ + "last 24 hour's</A> data "
	tempfile$ = tempfile$ + "or return "
	tempfile$ = tempfile$ + "<A HREF="+chr$(34)+"homepage.htm"+chr$(34)+">"
	tempfile$ = tempfile$ + "home</A>"
	tempfile$ = tempfile$ + "</FONT><p>"
	tempfile$ = tempfile$ + "<tt><pre><em>"

        tempfile$ = tempfile$ + " Time        T1      T2      T3      T4<p>"
        tempfile$ = tempfile$ + "--------   -----   -----   -----   -----<p>"
	tempfile$ = tempfile$ + "</em>"
	FOR i = 0 TO 11
                      if ptr - i < 0 then fileptr = ptr - i + 12 else fileptr = ptr - i
                      tempfile$ = tempfile$ + temp1hrtime$(fileptr) + "  " + temp1hr$(fileptr, 1) + "  " + temp1hr$(fileptr, 2) + "  " + temp1hr$(fileptr, 3) + "  " + temp1hr$(fileptr, 4) + "<p>"
        NEXT i
        IF ptr = 11 THEN ptr = 0 ELSE ptr = ptr + 1

        tempfile$ = tempfile$ + "</pre></tt>"

	filename$="hourlog.htm"
	filedata$=tempfile$
	gosub sendpacket

        RETURN


hourupdate:      
	tempfile$=""
        temp1day$(dayptr, 1) = t1$
        temp1day$(dayptr, 2) = t2$
        temp1day$(dayptr, 3) = t3$
        temp1day$(dayptr, 4) = t4$
        temp1daytime$(dayptr) = t$

	tempfile$ = tempfile$ + "<font size=+2>Click to see the "
	tempfile$ = tempfile$ + "<A HREF="+chr$(34)+"minlog.htm"+chr$(34)+">"
	tempfile$ = tempfile$ + "last minute's</A> data, the "
	tempfile$ = tempfile$ + "<A HREF="+chr$(34)+"hourlog.htm"+chr$(34)+">"
	tempfile$ = tempfile$ + "last hour's</A> data "
	tempfile$ = tempfile$ + "or return "
	tempfile$ = tempfile$ + "<A HREF="+chr$(34)+"homepage.htm"+chr$(34)+">"
	tempfile$ = tempfile$ + "home</A>"
	tempfile$ = tempfile$ + "</FONT><p>"
	tempfile$ = tempfile$ + "<tt><pre><em>"

        tempfile$ = tempfile$ + " Time        T1      T2      T3      T4<p>"
        tempfile$ = tempfile$ + "--------   -----   -----   -----   -----<p>"
	tempfile$ = tempfile$ + "</em>"

	FOR i = 0 TO 23
                      if dayptr - i < 0 then fileptr = dayptr - i +24 else fileptr = dayptr - i
                      tempfile$ = tempfile$ + temp1daytime$(fileptr) + "  " + temp1day$(fileptr, 1) + "  " + temp1day$(fileptr, 2) + "  " + temp1day$(fileptr, 3) + "  " + temp1day$(fileptr, 4) + "<p>"
        NEXT i
        IF dayptr = 23 THEN dayptr = 0 ELSE dayptr = dayptr + 1
        tempfile$ = tempfile$ + "</pre></tt>"
	filename$="daylog.htm"
	filedata$=tempfile$
	gosub sendpacket
	return
        

homeupdate:
	filename$="homepage.htm"

	tempstr1$="Sensor T1 reads"+t1$+" Deg. F.<p>"
	tempstr2$="Sensor T2 reads"+t2$+" Deg. F.<p>"
	tempstr3$="Sensor T3 reads"+t3$+" Deg. F.<p>"
	tempstr4$="Sensor T4 reads"+t4$+" Deg. F."

	temp$=tempstr1$+tempstr2$+tempstr3$+tempstr4$

	filedata$=home1$+"<p><pre>The local time is "+t$+" PST<p> <p>"+temp$+"</pre>"+home2$
 
	gosub SendPacket
	return
