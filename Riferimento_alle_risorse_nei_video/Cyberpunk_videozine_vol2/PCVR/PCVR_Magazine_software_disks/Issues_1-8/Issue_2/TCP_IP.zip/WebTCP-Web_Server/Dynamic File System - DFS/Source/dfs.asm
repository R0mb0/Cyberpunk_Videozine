	page	60,132

Code_seg	Segment
	assume	cs:code_seg,ds:code_seg,ss:code_seg

	title	DFS.ASM - Web Server Dynamic File System

;************************************************************************;
;*								       	*;
;*	Copyright JK microsystems 1998	-  All Rights Reserved	  	*;
;*									*;
;*	This software is NOT shareware, freeware, or public domain.	*;
;*	It is the property of JK microsystems.				*;
;*									*;
;*	Customers of JK microsystems may modify the source code		*; 
;*	and/or distribute the binary image of this software without 	*;
;*	additional costs provided it is run only on hardware 		*;
;*	manufactured by JK microsystems.  All other use is expressly 	*;
;*	prohibited.							*;
;*									*;
;*	Update Log							*;
;*									*;
;*	Vers	Date	 Comments			Progammer	*;
;*	----	-------	 ------------------------------	----------	*;
;*	1.0	7-31-98	 Initial release		jds		*;
;*	1.1	9-03-98	 Moved data area to 108h	jds		*;
;*                       Removed check for DFS				*;
;*			 already loaded					*;
;*									*;
;************************************************************************;


	org	100h

;-----------------------------------------------------------------------------
;
;	The first thing we do is initalize then terminate and stay resident.
;	The initialization code is put at the end so that it can be discarded
;	when we terminate.
;
start:					
	jmp	init			; jump to initialization code

	org	105h

		dw	55AAh		; signature
		db	version		; and version

filename1:	db	12 dup (0FFh)	; null-terminated filename
		db	0
file1_len:	dw	0		; file length, zeroed if no file
file1_off:	dw	offset file1	; file start

filename2:	db	12 dup (0FFh)
		db	0
file2_len:	dw	0
file2_off:	dw	offset file2

filename3:	db	12 dup (0FFh)
		db	0
file3_len:	dw	0
file3_off:	dw	offset file3

filename4:	db	12 dup (0FFh)
		db	0
file4_len:	dw	0
file4_off:	dw	offset file4


;-----------------------------------------------------------------------------
;
;	This is invoked with each Int30h interrupt
;
intp:
	cmp	ah,3			; are we selected?
	jne	int_done		; no, leave
	
	cmp	al,0			; get ID and poll RS-232 connection
	je	ID

	cmp	al,1			; Get File
	je	get_file
	
int_done:
 	db	0EAh			; this is a hard-coded far jump
int_off dw	0			; to the previous int 30h vector
int_seg dw	0			


;-------------------------------------------------------------------------
;
;	Get_file	Get_File returns a pointer to the segment and 
;			offset of a dynamic file matching the filename
;			passed to it by the client.
;
;	Enter with	ES:BX = start of null-terminated filename
;
;	Returns		ES:BX = start of file
;			CX    = byte count of file if present 
;			CX    = 0 if file not found
;
Get_file:
	push	ax			; save the registers we need
	push	ds

	mov	ax,cs
	mov	ds,ax

	mov	si,offset filename1	; ds:bx points to local filename
	call	file_check		; check it
	cmp	cx,0			; do we have a match?
	jne	file_done		; yes, don't check any others

	mov	si,offset filename2	; no, test the next filename
	call	file_check		
	cmp	cx,0
	jne	file_done

	mov	si,offset filename3	
	call	file_check		
	cmp	cx,0
	jne	file_done

	mov	si,offset filename4	
	call	file_check		

file_done:
	pop	ds			; restore registers
	pop	ax

	iret				; and return


;-------------------------------------------------------------------------
;
;	ID  -	Get the driver ID and signature
;
;	Returns	BH = 03h, Shared int 30 function
;		BL = binary version no., starts at 10h
;		CX = 55AAh
;
ID:
	mov	bh,03h
	mov	bl,byte ptr cs:[version]
	mov	cx,55AAh		; CX = 55AA
	mov	al,byte ptr cs:[state]

	iret


;-----------------------------------------------------------------------------
;
;	Serial interrupt service routine
;
Serial_isr:
	call	com_mask		; mask off this port's interrupts
	sti				; and reenable all the others
	push 	ax			; save the registers we're most
	push	bx			; likely to use
	push	cx
	push	dx
	push	di
	push	si
	push	ds
	push	es

	mov	ax,cs			; set DS and ES 
	mov	ds,ax
	mov	es,ax

	mov	dx,word ptr [com_port_base] ; get the char that caused the
	in	al,dx			; interrupt
	mov	dl,al			; keep in dl since we need al

	mov	ah,0		       	; update the running checksum
	add	ax,word ptr [in_file_sum]
	mov	word ptr [in_file_sum],ax

	lea	bx,jump_table		; bx points to jump table
	mov	al,byte ptr [state]	; get the state
	shl	al,1			; multiply x2 because jumps are 2 bytes
	mov	ah,0			; zero hi byte of word
	add	bx,ax			; add it to the jump table offset
	mov	al,dl			; get the char back in al
	jmp	[bx]			; jump to current state

state_return:
	mov	al,20h			; set the interrrupt controller
	out	20h,al			; for more interrrupts

	pop	es
	pop	ds			; restore our registers
	pop	si
	pop	di
	pop	dx
	pop	cx
	pop	bx
	pop	ax

	call	com_unmask
	iret


;-------------------------------------------------------------------------
;
;	State 0  Wait for ACK
;
;	If char is ACK, set state 1 and initialize pointers
;	If not, set state 0
;
State0:
	cmp	al,6			; did we get an ACK?
	je	got_ACK			; yes
	mov	word ptr [in_file_sum],0 ; no, rezero checksum
	jmp	state_return		; return with state=0

got_ACK:				; yes, initialize some pointers
	mov	byte ptr [in_file_sum],6  ; add in the ACK's sum
	mov	word ptr [in_file_ptr],offset in_filename ; where the filename goes
	mov	word ptr [in_file_len],0 ; initialize length


	mov	byte ptr [state],1	; and return with state 1 set
	jmp	state_return


;-------------------------------------------------------------------------
;
;	State 1  Get Filename
;
;	If char=0 and len>0, filename is done - set state 2
;	If char=0 and len=0, filename is bad - set state 0
;	If char>0 and len<13, filename is still loading - set state 1
;	If len>12, filename is bad - set state 0
;
State1:
	call	get_ptr			; get pointer and count
	cmp	cx,12			; is the filename too long?	
	ja	filename_bad		; yes, abort

	cmp	al,0			; did we get the null terminator?
	je	filename_done		; no, continue getting filename

	call	store_char_filename	; store the char and leave with	
	mov	byte ptr [state],1	; state 2 set
	jmp	state_return

filename_done:
	cmp	cx,0			; zero length filename?
	je	filename_bad		; yes, unacceptable
	call	store_char_filename	; no, store the null terminator
	mov	word ptr [in_file_ptr],offset in_file ; init the file pointer
	mov	byte ptr [state],2	; go to next state
	jmp	state_return

filename_bad:
	mov	byte ptr [state],0	; bad filename, go back to
	jmp	state_return		; waiting for ACK
	

;-------------------------------------------------------------------------
;
;	State 2 - Get first length byte
;
State2:
	mov	byte ptr [in_file_len],al
	mov	byte ptr [state],3
	jmp	state_return


;-------------------------------------------------------------------------
;
;	State 3 - Get Second length byte
;
State3:
	mov	byte ptr [in_file_len+1],al		; get lo len byte
	mov	ax,word ptr [in_file_len]		; get len
	mov	word ptr [in_file_len2],ax		; store in len2
	cmp	ax,offset in_file_end - offset in_file	; is file too long?
	jg	file_too_long				; yes, reject packet
	mov	word ptr [in_file_ptr],offset in_file	; point to start
	mov	byte ptr [state],4
	jmp	state_return

file_too_long:
	mov	byte ptr [state],0			; reset state machine
	jmp	state_return				; and leave
	

;-------------------------------------------------------------------------
;
;	State 4 - Get file
;
State4:
	call	get_ptr
	cmp	cx,0
	je	get_file_done
	cmp	cx,offset in_file_end - offset in_file
	jng	file_size_ok
	mov	byte ptr [state],0
	jmp	state_return

file_size_ok:
	call	store_char
	jmp	state_return

get_file_done:
	mov	bl,al				; save a copy of the char
	mov	ah,0			       	; adjust the checksum
	sub	word ptr [in_file_sum],ax
	mov	ax,word ptr [in_file_sum]
	mov	word ptr [in_file_sum2],ax	
	mov	byte ptr [in_file_sum3],bl	
	mov	byte ptr [state],5
	
	jmp	state_return


;-------------------------------------------------------------------------
;
;	State 5 - get second checksum byte and move the finished file
;		  into one of the 4 slots
;
State5:
	mov	byte ptr [in_file_sum3+1],al	; store the hi byte sent
	mov	ax,word ptr [in_file_sum2]	; get the running checksum
	add	ax,word ptr [in_file_sum3]	; add the sent and running
	mov	word ptr [in_file_sum],ax	; store the sum
	cmp	ax,0				; is it zero?
	je	good_file_in

	mov	byte ptr [state],0		; bad checksum, start over
	jmp	state_return

good_file_in:
	push	ds
	push	es

	mov	ax,cs
	mov	ds,ax
	mov	es,ax

check_file1:
	cld
	lea	bx,in_filename		; check for a match
	lea	si,filename1
	call	file_check
	jnc	check_file2

	lea	bx,filename1		; update the file length
find_end1:
	mov	al,[bx]			; search for null terminator
	inc	bx
	cmp	al,0
	jnz	find_end1
	mov	cx,word ptr [in_file_len2] ; get the length
	mov	[bx],cx			; install it

	lea	si,in_file		; move the file
	lea	di,file1
	mov	word ptr [file1_off],di
	rep 	movsb
	mov	byte ptr [state],0
	jmp	check_done
		
check_file2:
	lea	bx,in_filename		; check for a match
	lea	si,filename2
	call	file_check
	jnc	check_file3

	lea	si,filename2		; go to the end of the filename and
file2_term:				; put in length
	mov	al,byte ptr [si]	; at terminator?
	inc	si
	cmp	al,0
	jne	file2_term
	mov	cx,word ptr [in_file_len2]
	mov	word ptr [si],cx

	lea	si,in_file		; move the file
	lea	di,file2
	mov	word ptr [file2_off],di
	rep 	movsb
	mov	byte ptr [state],0
	jmp	check_done

check_file3:
	lea	bx,in_filename		; check for a match
	lea	si,filename3
	call	file_check
	jnc	check_file4

	lea	si,filename3		; go to the end of the filename and
file3_term:				; put in length
	mov	al,byte ptr [si]	; at terminator?
	inc	si
	cmp	al,0
	jne	file3_term
	mov	cx,word ptr [in_file_len2]
	mov	word ptr [si],cx

	lea	si,in_file		; move the file
	lea	di,file3
	mov	word ptr [file3_off],di
	rep 	movsb
	mov	byte ptr [state],0
	jmp	check_done

check_file4:
	lea	bx,in_filename		; check for a match
	lea	si,filename4
	call	file_check
	jnc	check_empty_file

	lea	si,filename4		; go to the end of the filename and
file4_term:				; put in length
	mov	al,byte ptr [si]	; at terminator?
	inc	si
	cmp	al,0
	jne	file4_term
	mov	cx,word ptr [in_file_len2]
	mov	word ptr [si],cx

	lea	si,in_file		; move the file
	lea	di,file4
	mov	word ptr [file4_off],di
	rep 	movsb
	mov	byte ptr [state],0
	jmp	check_done

; 	We've checked all four files for matching filenames and found
;	none.  Now we'll check for an empty file

check_empty_file:
	lea	si,filename1		; go to the end of the filename
file1f_term:				; to check file length
	mov	al,byte ptr [si]	; get char
	inc	si			; bump pointer
	cmp	al,0			; char = 0?
	jne	file1f_term		; no, keep stepping through name
	cmp	[si],word ptr 0		; file length = 0?
	jne	empty2			; no, check next

	lea	si,in_filename		; move the filename
	lea	di,filename1
move1:
	mov	al,[si]
	mov	[di],al
	inc	si
	inc	di
	cmp	al,0
	jne	move1

	mov	cx,word ptr [in_file_len2] ; move the file length
	mov	word ptr [di],cx

	lea	si,in_file		; move the file
	lea	di,file1
	mov	word ptr [file1_off],di ; set offset = start
	rep 	movsb			; still using old cx value
	mov	byte ptr [state],0
	jmp	check_done

empty2:
	lea	si,filename2		; go to the end of the filename
file2f_term:				; to check file length
	mov	al,byte ptr [si]	; get char
	inc	si			; bump pointer
	cmp	al,0			; char = 0?
	jne	file2f_term		; no, keep stepping through name
	cmp	[si],word ptr 0		; file length = 0?
	jne	empty3			; no, check next file entry

	lea	si,in_filename		; move the filename
	lea	di,filename2
move2:
	mov	al,[si]
	mov	[di],al
	inc	si
	inc	di
	cmp	al,0
	jne	move2

	mov	cx,word ptr [in_file_len2] ; move the file length
	mov	word ptr [di],cx

	lea	si,in_file		; move the file
	lea	di,file2
	mov	word ptr [file2_off],di ; set offset = start
	rep 	movsb			; still using old cx value

	mov	byte ptr [state],0
	jmp	check_done

empty3:
	lea	si,filename3		; go to the end of the filename
file3f_term:				; to check file length
	mov	al,byte ptr [si]	; get char
	inc	si			; bump pointer
	cmp	al,0			; char = 0?
	jne	file3f_term		; no, keep stepping through name
	cmp	[si],word ptr 0		; file length = 0?
	jne	empty4			; no, check next file entry

	lea	si,in_filename		; move the filename
	lea	di,filename3
move3:
	mov	al,[si]
	mov	[di],al
	inc	si
	inc	di
	cmp	al,0
	jne	move3

	mov	cx,word ptr [in_file_len2] ; move the file length
	mov	word ptr [di],cx

	lea	si,in_file		; move the file
	lea	di,file3
	mov	word ptr [file3_off],di ; set offset = start
	rep 	movsb			; still using old cx value

	mov	byte ptr [state],0
	jmp	check_done

empty4:
	lea	si,filename4		; go to the end of the filename
file4f_term:				; to check file length
	mov	al,byte ptr [si]	; get char
	inc	si			; bump pointer
	cmp	al,0			; char = 0?
	jne	file4f_term		; no, keep stepping through name
	cmp	[si],word ptr 0		; file length = 0?
	jne	check_done		; no, check next file entry

	lea	si,in_filename		; move the filename
	lea	di,filename4
move4:
	mov	al,[si]
	mov	[di],al
	inc	si
	inc	di
	cmp	al,0
	jne	move4

	mov	cx,word ptr [in_file_len2] ; move the file length
	mov	word ptr [di],cx

	lea	si,in_file		; move the file
	lea	di,file4
	mov	word ptr [file4_off],di ; set offset = start
	rep 	movsb			; still using old cx value


check_done:
	mov	byte ptr cs:[state],0
	pop	es
	pop	ds
	jmp	state_return


;-------------------------------------------------------------------------
;
;	Compares 2 filename strings for match.
;
;	ES:BX is null-terminated submitted filename
;	DS:SI is null-terminated local filename
;
;	If we reach null terminator of submitted file, we have a match
;	and return the word following the terminator as the file length
;	in CX and the next word in BX as the starting location, and we
;	set the carry flag.
;
;	If we get a char mismatch or reach the local filename terminator,
;	we return with CX=0 to indicate no match and clear the carry flag.
;
file_check:
	push	si
	mov	di,bx			; es:di is submitted filename
filename_test_loop:
	mov	al,es:[di]		; get char from submitted filename
	cmp	al,0			; is it null terminator?
	je	good_file		; yes, send pointer
	and	al,0DFh			; force it to upper case
	mov	ah,[si]			; get char from our filename
	cmp	ah,0			; are we at end?
	je	no_match		; yes, no match
	and	ah,0DFh			; force it to upper case
	inc	si			; bump pointers
	inc	di
	cmp	al,ah			; do chars match?
	je	filename_test_loop	; yes, test next char

no_match:
	pop	si
	mov	cx,0			; no, return with zero in cx
	clc				; clear carry
	ret

good_file:
	mov	al,[si]			; go to end of file
	inc	si
	cmp	al,0			; null terminator?
	jne	good_file		; no, keep going
	mov	cx,[si]			; yes, get count
	pop	si
	add	si,15
	mov	bx,[si]			; get offset
	stc				; set carry

	push	cs			; pass our segment
	pop	es
	ret


;-------------------------------------------------------------------------
;
;	Store char for filename
;	
store_char_filename:
	mov	[di],al
	inc	di
	inc	cx
	mov	word ptr [in_file_ptr],di
	mov	word ptr [in_file_len],cx
	ret


;-------------------------------------------------------------------------
;
;	Store char for file
;	
store_char:
	mov	[di],al
	inc	di
	dec	cx
	mov	word ptr [in_file_ptr],di
	mov	word ptr [in_file_len],cx
	ret


;-------------------------------------------------------------------------
;
;	Get pointers
;
get_ptr:
	mov	di,word ptr [in_file_ptr]	; get pointer	
	mov	cx,word ptr [in_file_len]	; get length
	ret	


;-------------------------------------------------------------------------
;
;	Com mask 	Mask serial interrupts on the active com port
;
com_mask:
	push	ax
	in	al,21h			; get the interrupt mask reg
	or	al,irq4_mask		; set the bit
	out	21h,al			; and output it
	pop	ax
	ret


;-------------------------------------------------------------------------
;
;	Com unmask	Unmask serial interrupts on the active com port
;
Com_unmask:
	push	ax
	in	al,21h			; get the interrupt mask reg
	and	al,irq4_unmask		; clear the bit
	out	21h,al			; and output it
	pop	ax
	ret
	
;-------------------------------------------------------------------------
;
;		Data area and equates
;
buffer_size	equ	1000h		; 4096 byte buffers now, 12k is about
					; maximum, all must fit in 64k

version		equ	11h		; change version in welcome message too

		
in_file:	db	buffer_size dup (?) ; incoming data is buffered here
in_file_end:	db	?		; until it becomes a file
in_file_ptr	dw	?		; pointer to next free location
in_filename:	db	13 dup (?)	; incoming filename
in_file_len:	dw	?		; incoming file length
in_file_len2:	dw	?
in_file_sum:	dw	?		; incoming file running checksum
in_file_sum2:	dw	?		; final running checksum
in_file_sum3:	dw	?		; computed checksum, should be zero
in_file_stop:	db	?


file1:		db	buffer_size dup (?) ; storage for 4 files
file1_end:	db	?
	
file2:		db	buffer_size dup (?)
file2_end:	db	?
	
file3:		db	buffer_size dup (?)
file3_end:	db	?
	
file4:		db	buffer_size dup (?)
file4_end:	db	?

state:		db	0		; state machine state
timestamp:	dw	0		; time stamp of last ENQ

com_port_base:	dw	0		; base address of the current com port
com_int:	dw	0		; current com port interrupt vector

jump_table:	dw	offset state0	; get ACK
		dw	offset state1	; get filename
		dw	offset state2	; get 1st byte of length
		dw	offset state3	; get 2nd byte of length
		dw	offset state4	; get file
		dw	offset state5	; get checksum

com1_base	equ	3F8h		; base addresses for the com ports
com2_base	equ	2F8h
com3_base	equ	3E8h
com4_base	equ	2E8h

irq3		equ	2Ch		; these are the offsets of the irqs
irq4		equ	30h		; segment zero is assumed
irq5		equ	34h
irq6		equ	38h

irq3_mask	equ	08h		; to mask an interrupt, input the
irq4_mask	equ	10h		; value from port 21h, OR this byte
irq5_mask	equ	20h		; in, and write it back to port 21h
irq6_mask	equ	40h

irq3_unmask	equ	0F7h		; to unmask an interrupt, input the
irq4_unmask	equ	0EFh		; value from port 21h, AND this byte
irq5_unmask	equ	0DFh		; in, and write it back to port 21h
irq6_unmask	equ	0FFh

;-----------------------------------------------------------------------------
;
;	This is our initialization code
;
init:					; all code past this point abandoned
	mov	ax,cs			; restore ds
	mov	ds,ax

load_tsr:				
	mov	ah,9			; tell user we loaded ok
	mov	dx,offset load_string
	int	21h

	mov	ax,irq4			; and irq4
	mov	word ptr [com_int],ax

	mov	ax,com1_base		; use com1 for now
	mov	word ptr [com_port_base],ax	

	mov	dx,ax			; set 9600 baud
	push	dx
	add	dx,3
	mov	al,83h			; set bit to change baud rate reg
	out	dx,al			
	sub	dx,3			; low byte of divisor		
	mov	al,12			; divisor for 9600 baud
	out	dx,al			; send it
	add	dx,3			; restore line control reg
	mov	al,3
	out	dx,al

	pop	dx			; enable dtr,rts,out2
	add 	dx,4			
	mov	ax,0Bh			
	out	dx,al

	push	ds
	mov	ax,0			; point to interrupt vector table
	mov 	ds,ax

	cli				; no ints while changing vectors
	mov	ax,[30h * 4]		; get int 30h offset
	mov	cs:[int_off],ax		; save it and replace
	mov	ds:[30h * 4],offset intp

	mov	ax,[30h * 4 + 2]	; get int 30h segment
	mov	cs:[int_seg],ax		; save it
	mov	ax,cs			; get our segment
	mov	ds:[30h * 4 + 2],ax	; and install it

	mov	si,word ptr cs:[com_int] ; get the comm int vector loc in si
	mov	[si],offset serial_isr 	; and put our routine's address there
	add	si,2			; point to vector segment
	mov	ax,cs			; use our code seg
	mov	[si],ax			; and install it

	call	com_unmask		; unmask the com interrupt

	mov	dx,word ptr cs:[com_port_base] ; point to serial port
	inc	dx			; point to interrupt enab reg
	mov	al,1			; enable data avail interrupt
	out	dx,al			; do it

	sti				; ints back on

	pop	ds	
	mov	ax,3100h		; TSR function code
	mov 	dx,offset init	 	; get last address used
	mov 	cl,4			; convert to paragraphs
	shr     dx,cl			; by dividing by 16
	inc	dx			; and rounding up by one

	int	21h			; tell dos to do it

abort_tsr:				; tell user we couldn't load
	mov	ah,9
	mov	dx,offset abort_string
	int	21h

	mov	ax,4C00h		; exit to dos
	int	21h

;-----------------------------------------------------------------------------
;
;	Initialization data area - discarded after use
;
load_string:
	db	0Ah,0Dh
	db	'Dynamic File System 1.1 Installed',0Ah,0Dh
	db	'Copyright JK microsystems, 1998',0Ah,0Dh
	db	' Using COM1, IRQ4, 9600 baud',0Ah,0Dh
	db	' 4 file buffers, 4 kbytes each',0Ah,0Dh
	db	0Ah,0Dh,'$'

abort_string:
	db	'Dynamic File System already installed',07h,0Ah,0Dh,'$'

code_seg 	ends
	end	start

