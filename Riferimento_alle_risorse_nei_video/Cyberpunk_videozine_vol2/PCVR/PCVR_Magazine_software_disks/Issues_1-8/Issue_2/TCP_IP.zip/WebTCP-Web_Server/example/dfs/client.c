#include <stdio.h>
#include <dos.h>
#include <conio.h>
#include <string.h>
#include <time.h>
#include <values.h>

#define ACK 0x06						// ascii acknowledge (ACK) character
#define FILENAME "dfshome.htm"			// file to send
#define FILENAME2 "dfhome.htm"			// file to send

#define DATA1	base           			// serial port registers
#define IER1	base+1
#define IIR1		base+2
#define LCR1		base+3
#define MCR1		base+4
#define LSR1		base+5
#define MSR1		base+6

#define DATA3	0x3E8           			// serial port registers
#define IER3		0x3E8+1
#define IIR3		0x3E8+2
#define LCR3		0x3E8+3
#define MCR3		0x3E8+4
#define LSR3		0x3E8+5
#define MSR3		0x3E8+6

static int base=0x3F8;					// com 1 port address

main(int argc, char *argv[])
{
	unsigned int packet_no=0;					// packet number
	int headerlen=0;							// length of ACK+filename+length
	int filelen=0;								// complete file length
	unsigned char filelen_hi=0, filelen_lo=0;	// file length parts
	unsigned int chksum=0;						// complete checksum
	unsigned char chksum_hi=0, chksum_lo=0;		// checksum parts
	char file1[4096], file2[4096]; 				// big buffers for files
	char outfile[16384];
	char *bufp;									// pointer for parsing
	char tmp[128];								// temp for string processing
	FILE *fp;                       		    // disk file pointer
	time_t sec_now;			   					// stuff to work w/ time/date
	char c;
	int i;

	if (argc>1 && *argv[1]=='2') {				// if COM2 not specified
		base=0x2F8;
		printf("COM2: %x\n",base);
	}
	else {                                      // default to COM1
		base=0x3F8;
		printf("COM1 %x\n",base);
	}

	printf("File: %s\n", FILENAME );
										// set up serial port 9600,8,n,1
	outportb(LCR1,0x80);					// divisor latch access
	outportb(DATA1,0x0C);				// baud rate divisor low
	outportb(IER1,0x00);					// baud rate divisor hi
	outportb(LCR1,0x03);					// 8,1,n

	outportb(LCR3,0x80);					// divisor latch access
	outportb(DATA3,0x0C);				// baud rate divisor low
	outportb(IER3,0x00);					// baud rate divisor hi
	outportb(LCR3,0x03);					// 8,1,n

	bufp = file1;						// read first file
	fp=fopen("home1.htm","rt");
	while ( (c=getc(fp)) != EOF ) {
		*bufp++ = c;
	}
	*bufp = '\0';						// null terminate frist piece
	fclose(fp);

	bufp = file2;						// read second file
	fp=fopen("home2.htm","rt");
	while ( (c=getc(fp)) != EOF ) {
		*bufp++ = c;
	}
	*bufp = '\0';						// null terminate frist piece
	fclose(fp);

	while ( !kbhit() || (kbhit() && ((c=getch()) != ' ')) ){
		if (c=='b') {
			printf("Forced bad checksum \n");
			chksum +=10;
            c=0;
		}
		chksum=0;
		filelen=0;
		headerlen=0;
		packet_no++;					// increment packet number

		// build output file
		// use ACKs as place holders for NULL and file length
		sprintf( outfile, "%c%s%c%c%c", ACK,FILENAME,ACK,ACK,ACK );
		headerlen=strlen(outfile);		// header length

		strcat(outfile, file1);			// append header file

		time(&sec_now);					// create ascii time/date stamp
		sprintf(tmp,"<P>The time is %.24s<p>This is packet #%u<P>",ctime(&sec_now), packet_no );
		strcat( outfile, tmp);

		strcat( outfile, file2);	  	// append footer file

		filelen=strlen(outfile);          	// get length of file
		filelen_hi=(unsigned char)((filelen-headerlen)>>8);		// make file length in 2 ascii chars
		filelen_lo=(unsigned char)((filelen-headerlen)&0xFF);

		bufp=strchr(outfile+1,ACK);	 	// have packet length, fill in place holders

		*bufp = NULL;					// put NULL into packet header
		*(bufp+1)=filelen_lo;			// plug file length into packet
		*(bufp+2)=filelen_hi;

		for (i=0; i < filelen; i++) {				// send file to COM port
			chksum+=(unsigned char)outfile[i];      // add data to checksum
			outportb(DATA1,outfile[i]);              // write it to the UART
			outportb(DATA3,outfile[i]);              // write it to the UART
			while ( !(inportb(LSR1) & 0x20)  ) {;}	// wait for char to transmit
			while ( !(inportb(LSR3) & 0x20)  ) {;}	// wait for char to transmit
		}

		chksum = (unsigned int)(0x10000L - (long)chksum); 	// convert chksum to 2's complemnet

		chksum_lo=(unsigned char)(chksum&0xFF);		// send low byte of chksum
		outportb(DATA1,chksum_lo);
		outportb(DATA3,chksum_lo);
		while ( !(inportb(LSR1) & 0x20)  ) {;}		// wait for char to transmit
		while ( !(inportb(LSR3) & 0x20)  ) {;}		// wait for char to transmit

		chksum_hi=(unsigned char)(chksum>>8);		// send hi byte of chksum
		outportb(DATA1,chksum_hi);
		outportb(DATA3,chksum_hi);
		while ( !(inportb(LSR1) & 0x20)  ) {;}		// wait for char to transmit
		while ( !(inportb(LSR3) & 0x20)  ) {;}		// wait for char to transmit

		printf("Sent packet %.12s: #%5u, length: %0.2x%0.2x checksum: %0.2x%0.2x\n", FILENAME, packet_no,
					(int)filelen_hi, (int)filelen_lo, (int)chksum_hi, (int)chksum_lo );

		chksum=0;
		filelen=0;
		headerlen=0;

		// build output file
		// use ACKs as place holders for NULL and file length
		sprintf( outfile, "%c%s%c%c%c", ACK,FILENAME2,ACK,ACK,ACK );
		headerlen=strlen(outfile);		// header length

		strcat(outfile, "<body>");		// start HTML

		time(&sec_now);					// create ascii time/date stamp
		sprintf(tmp,"<P>The time is %.24s<p>This is packet #%u<P>",ctime(&sec_now), packet_no );
		strcat( outfile, tmp);

		strcat( outfile, "</body>");	  	// end HTML

		filelen=strlen(outfile);          	// get length of file
		filelen_hi=(unsigned char)((filelen-headerlen)>>8);		// make file length in 2 ascii chars
		filelen_lo=(unsigned char)((filelen-headerlen)&0xFF);

		bufp=strchr(outfile+1,ACK);	 	// have packet length, fill in place holders

		*bufp = NULL;					// put NULL into packet header
		*(bufp+1)=filelen_lo;			// plug file length into packet
		*(bufp+2)=filelen_hi;

		for (i=0; i < filelen; i++) {				// send file to COM port
			chksum+=(unsigned char)outfile[i];      // add data to checksum
			outportb(DATA1,outfile[i]);
			outportb(DATA3,outfile[i]);
			while ( !(inportb(LSR1) & 0x20)  ) {;}	// wait for char to transmit
			while ( !(inportb(LSR3) & 0x20)  ) {;}	// wait for char to transmit
		}
		chksum = (unsigned int)(0x10000L - (long)chksum); 	// convert chksum to 2's complemnet

		chksum_lo=(unsigned char)(chksum&0xFF);		// send low byte of chksum
		outportb(DATA1,chksum_lo);
		outportb(DATA3,chksum_lo);
		while ( !(inportb(LSR1) & 0x20)  ) {;}		// wait for char to transmit
		while ( !(inportb(LSR3) & 0x20)  ) {;}		// wait for char to transmit

		chksum_hi=(unsigned char)(chksum>>8);		// send hi byte of chksum
		outportb(DATA1,chksum_hi);
		outportb(DATA3,chksum_hi);
		while ( !(inportb(LSR1) & 0x20)  ) {;}		// wait for char to transmit
		while ( !(inportb(LSR3) & 0x20)  ) {;}		// wait for char to transmit

		printf("Sent packet %.12s: #%5u, length: %0.2x%0.2x checksum: %0.2x%0.2x\n", FILENAME2, packet_no,
					(int)filelen_hi, (int)filelen_lo, (int)chksum_hi, (int)chksum_lo );
	}
return(0);
}


