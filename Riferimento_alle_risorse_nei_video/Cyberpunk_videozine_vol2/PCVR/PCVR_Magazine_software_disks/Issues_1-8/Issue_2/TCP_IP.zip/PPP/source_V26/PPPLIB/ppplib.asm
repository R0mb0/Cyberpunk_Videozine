	.286p
	ifndef	??version
?debug	macro
	endm
publicdll macro	name
	public	name
	endm
$comm	macro	name,dist,size,count
	comm	dist name:BYTE:count*size
	endm
	else
$comm	macro	name,dist,size,count
	comm	dist name[size]:BYTE:count
	endm
	endif
	?debug	V 301h
	?debug	S "PPPLIB.C"
	?debug	C E9FC02742C085050504C49422E43
	?debug	C E980261D1F15433A5C424334355C494E434C5544455C444F532E48
	?debug	C E980261D1F17433A5C424334355C494E434C5544455C5F44454653+
	?debug	C 2E48
	?debug	C E980261D1F17433A5C424334355C494E434C5544455C535444494F+
	?debug	C 2E48
	?debug	C E980261D1F18433A5C424334355C494E434C5544455C5F4E46494C+
	?debug	C 452E48
	?debug	C E980261D1F17433A5C424334355C494E434C5544455C5F4E554C4C+
	?debug	C 2E48
	?debug	C E980261D1F17433A5C424334355C494E434C5544455C414C4C4F43+
	?debug	C 2E48
	?debug	C E90403742C085050504C49422E48
_TEXT	segment byte public 'CODE'
_TEXT	ends
DGROUP	group	_DATA,_BSS
	assume	cs:_TEXT,ds:DGROUP
_DATA	segment word public 'DATA'
d@	label	byte
d@w	label	word
_DATA	ends
_BSS	segment word public 'BSS'
b@	label	byte
b@w	label	word
_BSS	ends
_DATA	segment word public 'DATA'
_PPPInterrupt	label	word
	db	0
	db	0
_PPPSignature	label	byte
	db	80
	db	80
	db	80
	db	32
	db	68
	db	82
	db	86
	db	82
	db	0
	db	0
_DATA	ends
_TEXT	segment byte public 'CODE'
	?debug	C E801085050504C49422E43FC02742C
   ;	
   ;	unsigned int PPPInit(unsigned int Interrupt)
   ;	
	?debug	L 51
	assume	cs:_TEXT,ds:DGROUP
_PPPInit	proc	near
	?debug	B
	enter	4,0
	push	si
	push	di
	?debug	C E609496E746572727570740A0A0400000137012E+
	?debug	C 0000
	mov	di,word ptr [bp+4]
	?debug	B
   ;	
   ;	{
   ;		unsigned int Seg, Off, i, j, sig = 0;
   ;	
	?debug	L 53
	xor	dx,dx
   ;	
   ;		// Read the segment and the offset of the ISR
   ;		Off = *(unsigned int far*)(MK_FP(0,Interrupt * 4));
   ;	
	?debug	L 55
	mov	bx,di
	shl	bx,2
	xor	ax,ax
	mov	es,ax
	mov	ax,word ptr es:[bx]
	mov	word ptr [bp-4],ax
   ;	
   ;		Seg = *(unsigned int far*)(MK_FP(0,(Interrupt * 4) + 2));
   ;	
	?debug	L 56
	mov	bx,di
	shl	bx,2
	xor	ax,ax
	mov	es,ax
	mov	ax,word ptr es:[bx+2]
	mov	word ptr [bp-2],ax
   ;	
   ;	
   ;	#ifdef _DEBUG
   ;		printf("PPPLIB: PPPInit() -- Initializing PPP Interrupt Vector 0x%X (Address %04X:%04X)\n",
   ;			Interrupt, Seg, Off);
   ;	#endif
   ;	
   ;		i = 0;
   ;	
	?debug	L 63
	xor	cx,cx
	jmp	short @1@254
@1@58:
   ;	
   ;		// While we haven't found the signature and we still have bytes left to try
   ;		// Note: i is used to denote the start of the signature.  We search for it
   ;		// so that it can start in any of the first five bytes of the ISR.
   ;		while ((sig == 0) && (i < 5))
   ;		{
   ;			j = 0;
   ;	
	?debug	L 69
	xor	si,si
   ;	
   ;			// Assume we will find the signature at this starting location (i)
   ;			sig = 1;
   ;	
	?debug	L 71
	mov	dx,1
	jmp	short @1@170
@1@86:
   ;	
   ;			// While we still think we have found the signature and we still haven't
   ;			// checked the whole signature
   ;			while ((sig == 1) && (j < 9))
   ;			{
   ;				// If this byte doesn't match then we know we didn't find it at this i
   ;				// Setting sig=0; will break out of the inner while and cause the outer
   ;				// one to loop again
   ;				if (((char far*)(MK_FP(Seg, (Off + i))))[j] != PPPSignature[j])
   ;	
	?debug	L 79
	mov	bx,word ptr [bp-4]
	add	bx,cx
	mov	es,word ptr [bp-2]
	mov	al,byte ptr es:[bx+si]
	cmp	al,byte ptr DGROUP:_PPPSignature[si]
	je	short @1@142
   ;	
   ;					sig = 0;
   ;	
	?debug	L 80
	xor	dx,dx
@1@142:
   ;	
   ;				// Increment j so that we can check the next character of the signature
   ;				j++;
   ;	
	?debug	L 82
	inc	si
@1@170:
	?debug	L 74
	cmp	dx,1
	jne	short @1@226
	cmp	si,9
	jb	short @1@86
@1@226:
   ;	
   ;			}
   ;	
   ;			// Increment i so that we can check the next possible start location of
   ;			// the signature
   ;			i++;
   ;	
	?debug	L 87
	inc	cx
@1@254:
	?debug	L 67
	or	dx,dx
	jne	short @1@310
	cmp	cx,5
	jb	short @1@58
@1@310:
   ;	
   ;		}
   ;	
   ;		// Once we get here either we ran out of chars in the signature (j) without
   ;		// finding one that didn't match (so sig==1).  Or we ran out of starting
   ;		// locations for the signature without finding it (sig==0)
   ;	
   ;		// If we found the signature
   ;		if (sig)
   ;	
	?debug	L 95
	or	dx,dx
	je	short @1@394
   ;	
   ;		{
   ;	#ifdef _DEBUG
   ;			printf("PPPLIB: PPPInit() -- Initialized PPP Interrupt Vector 0x%X\n", Interrupt);
   ;	#endif
   ;	
   ;			// Save the interrupt
   ;			PPPInterrupt = Interrupt;
   ;	
	?debug	L 102
	mov	word ptr DGROUP:_PPPInterrupt,di
   ;	
   ;	
   ;			// If we're in debug mode then retrieve the PPP response level
   ;	#ifdef _DEBUG
   ;			ResponseLevel = PPPGetRespLevel();
   ;			printf("PPPLIB: PPPInit() -- Matching PPP debug response level %d\n", ResponseLevel);
   ;	#endif
   ;	
   ;			// Return success
   ;			return 0;
   ;	
	?debug	L 111
	xor	ax,ax
	jmp	short @1@422
@1@394:
   ;	
   ;		}
   ;	
   ;	#ifdef _DEBUG
   ;		printf("PPPLIB: PPPInit() -- Initialization of PPP Interrupt Vector 0x%X failed\n", Interrupt);
   ;		printf("PPPLIB: PPPInit() -- PPP Not loaded or Signature (\"PPP DRVR\") not found\n");
   ;	#endif
   ;	
   ;		// Return failure
   ;		return 1;
   ;	
	?debug	L 120
	mov	ax,1
	jmp	short @1@422
@1@422:
   ;	
   ;	}
   ;	
	?debug	L 121
	pop	di
	pop	si
	leave	
	ret	
	?debug	C E6037369670A040201350001430403060F000001+
	?debug	C 6A0A04060135000145050503000001690A040101+
	?debug	C 3500013F040C080000034F66660A02FCFF013500+
	?debug	C 0137180000035365670A02FEFF01350001381700+
	?debug	C 0009496E746572727570740A0C070000
	?debug	E
	?debug	E
_PPPInit	endp
   ;	
   ;	char* PPPLoadScript(char* FileName)
   ;	
	?debug	L 129
	assume	cs:_TEXT,ds:DGROUP
@PPPLoadScript$qpc	proc	near
	?debug	B
	enter	22,0
	push	si
	push	di
	?debug	C E318000200150204
	?debug	C E60846696C654E616D65180A04000001FEB50000+
	?debug	C 00
	?debug	B
   ;	
   ;	{
   ;		struct REGPACK Regs;
   ;		FILE *File;
   ;		char *Script, *rp;
   ;	
   ;	#ifdef _DEBUG
   ;		if (ResponseLevel >= 2)
   ;		{
   ;			printf("PPPLIB: PPPLoadScript() -- Attempting to load script \'%s\'\n",
   ;				FileName);
   ;		}
   ;	#endif
   ;	
   ;		// Make sure someone called PPPInit first with a valid interrupt
   ;		if (PPPInterrupt == 0)
   ;	
	?debug	L 144
	cmp	word ptr DGROUP:_PPPInterrupt,0
	jne	short @2@86
   ;	
   ;		{
   ;	#ifdef _DEBUG
   ;			if (ResponseLevel >= 1)
   ;				printf("PPPLIB: PPPLoadScript() -- PPPLIB was not initialized\n");
   ;	#endif
   ;			return 0;
   ;	
	?debug	L 150
	jmp	short @2@198
@2@86:
   ;	
   ;		}
   ;	
   ;		// We need to determine the maximum script size PPP will accept
   ;		// so that we can allocate memory approriately
   ;		Regs.r_ax = 4;
   ;	
	?debug	L 155
	mov	word ptr [bp-22],4
   ;	
   ;		intr(PPPInterrupt, &Regs);
   ;	
	?debug	L 156
	lea	ax,word ptr [bp-22]
	push	ax
	push	word ptr DGROUP:_PPPInterrupt
	call	near ptr _intr
	add	sp,4
   ;	
   ;	
   ;	#ifdef _DEBUG
   ;		if (ResponseLevel >= 3)
   ;			printf("PPPLIB: PPPLoadScript() -- Maximum script size: %d\n", Regs.r_ax);
   ;	#endif
   ;	
   ;		// Allocate memory according to the language we are compiling under
   ;	#ifdef _cplusplus
   ;		rp = Script = new char[Regs.r_ax];
   ;	#else
   ;		rp = Script = (char *)malloc(Regs.r_ax);
   ;	
	?debug	L 167
	push	word ptr [bp-22]
	call	near ptr _malloc
	pop	cx
	mov	word ptr [bp-2],ax
	mov	si,ax
   ;	
   ;	#endif
   ;	
   ;		// Make sure that our memory allocation succeeded
   ;		if (Script == NULL)
   ;	
	?debug	L 171
	cmp	word ptr [bp-2],0
	jne	short @2@142
	jmp	short @2@198
@2@142:
   ;	
   ;		{
   ;	#ifdef _DEBUG
   ;			if (ResponseLevel >= 1)
   ;				printf("PPPLIB: PPPLoadScript() -- Memory allocation failed\n");
   ;	#endif
   ;			return NULL;
   ;		}
   ;	
   ;		// Open the requested script file
   ;		if ((File = fopen(FileName, "rt")) == NULL)
   ;	
	?debug	L 181
	push	offset DGROUP:s@
	push	word ptr [bp+4]
	call	near ptr _fopen
	add	sp,4
	mov	di,ax
	or	ax,ax
	jne	short @2@226
   ;	
   ;		{
   ;	#ifdef _DEBUG
   ;			if (ResponseLevel >= 1)
   ;				printf("PPPLIB: PPPLoadScript() -- Failed to open the script file\n");
   ;	#endif
   ;	
   ;			// The call the fopen() failed so we need to free the allocated memory
   ;			PPPFreeScript(Script);
   ;	
	?debug	L 189
	push	word ptr [bp-2]
	call	near ptr @PPPFreeScript$qpc
	pop	cx
@2@198:
   ;	
   ;			// and return failure
   ;			return NULL;
   ;	
	?debug	L 191
	xor	ax,ax
	jmp	short @2@394
@2@226:
	jmp	short @2@282
@2@254:
   ;	
   ;		}
   ;	
   ;	#ifdef _DEBUG
   ;		if (ResponseLevel >= 4)
   ;		{
   ;			printf("PPPLIB: PPPLoadScript() -- Loading script from file:\n");
   ;			printf("-------------------------------------\n");
   ;	
   ;	   	// Simple loop to read the contents of the file into the allocated memory
   ;			while ((!feof(File)) && ((rp - Script) < (Regs.r_ax - 1)))
   ;			{
   ;				// Dump the script to the screen while reading it
   ;				putchar((*(rp++)) = fgetc(File));
   ;			}
   ;	
   ;			printf("-------------------------------------\n");
   ;		}
   ;		else
   ;		{
   ;	#endif
   ;			// Simple loop to read the contents of the file into the allocated memory
   ;			while ((!feof(File)) && ((rp - Script) < (Regs.r_ax - 1)))
   ;				(*(rp++)) = fgetc(File);
   ;	
	?debug	L 214
	push	di
	call	near ptr _fgetc
	pop	cx
	mov	byte ptr [si],al
	inc	si
@2@282:
	?debug	L 213
	test	byte ptr [di+2],32
	jne	short @2@338
	mov	ax,si
	sub	ax,word ptr [bp-2]
	mov	dx,word ptr [bp-22]
	dec	dx
	cmp	ax,dx
	jb	short @2@254
@2@338:
   ;	
   ;	#ifdef _DEBUG
   ;		}
   ;	#endif
   ;	
   ;		// Terminate the memory buffer will a null character
   ;		(*rp) = 0;
   ;	
	?debug	L 220
	mov	byte ptr [si],0
   ;	
   ;	
   ;		// Close the file, since we are done with it
   ;		fclose(File);
   ;	
	?debug	L 223
	push	di
	call	near ptr _fclose
	pop	cx
   ;	
   ;	
   ;		// Return the allocated block of memory with the script loaded into it
   ;		return Script;
   ;	
	?debug	L 226
	mov	ax,word ptr [bp-2]
	jmp	short @2@394
@2@394:
   ;	
   ;	}
   ;	
	?debug	L 227
	pop	di
	pop	si
	leave	
	ret	
	?debug	C E31A0446494C4510001E01
	?debug	C E31B000200150804
	?debug	C E319000200151A04
	?debug	C E31C075245475041434B14001E0B
	?debug	C E602727018040601850001FEA7002E0106000006+
	?debug	C 5363726970741802FEFF01850001FEA700041218+
	?debug	C 0D00000446696C6519040701840001FEB5002001+
	?debug	C 09000004526567731C02EAFF01830001FE9B0001+
	?debug	C 0B2E00000846696C654E616D65180A04000000
	?debug	E
	?debug	E
@PPPLoadScript$qpc	endp
   ;	
   ;	void PPPFreeScript(char* Script)
   ;	
	?debug	L 234
	assume	cs:_TEXT,ds:DGROUP
@PPPFreeScript$qpc	proc	near
	?debug	B
	push	bp
	mov	bp,sp
	?debug	C E606536372697074180A04000001FEF1000000
	?debug	B
   ;	
   ;	{
   ;		// All we have to do is free the memory, but we need to use the right method
   ;		// to correspond to how it was allocated
   ;	#ifdef _cplusplus
   ;		delete Script;
   ;	#else
   ;		free(Script);
   ;	
	?debug	L 241
	push	word ptr [bp+4]
	call	near ptr _free
	pop	cx
   ;	
   ;	#endif
   ;	}
   ;	
	?debug	L 243
	pop	bp
	ret	
	?debug	C E606536372697074180A04000000
	?debug	E
	?debug	E
@PPPFreeScript$qpc	endp
   ;	
   ;	unsigned int PPPOpen(char* OpenScript, char* CloseScript, int WaitForConnect)
   ;	
	?debug	L 250
	assume	cs:_TEXT,ds:DGROUP
_PPPOpen	proc	near
	?debug	B
	enter	24,0
	push	si
	push	di
	?debug	C E60E57616974466F72436F6E6E656374040A0800+
	?debug	C 0001FE610100000B436C6F736553637269707418+
	?debug	C 0A06000001FE210108022002010E00000A4F7065+
	?debug	C 6E536372697074180A04000001FE0A0108021E0D+
	?debug	C 02011B0000
	mov	si,word ptr [bp+4]
	mov	di,word ptr [bp+6]
	?debug	B
   ;	
   ;	{
   ;		struct REGPACK Regs;
   ;		int LOpen = 0, LClose = 0;
   ;	
	?debug	L 253
	mov	word ptr [bp-2],0
	mov	word ptr [bp-4],0
   ;	
   ;	
   ;		// Make sure someone called PPPInit first with a valid interrupt
   ;		if (PPPInterrupt == 0)
   ;	
	?debug	L 256
	cmp	word ptr DGROUP:_PPPInterrupt,0
	jne	short @4@86
	jmp	@4@870
@4@86:
   ;	
   ;		{
   ;	#ifdef _DEBUG
   ;			if (ResponseLevel >= 1)
   ;				printf("PPPLIB: PPPOpen() -- PPPLIB was not initialized\n");
   ;	#endif
   ;			return 0x8FFD;
   ;		}
   ;	
   ;		// If we were passed a string that did not begin with @ then it's a file name
   ;		if (OpenScript && (OpenScript[0] != '@'))
   ;	
	?debug	L 266
	or	si,si
	je	short @4@226
	mov	al,byte ptr [si]
	cbw	
	cmp	ax,64
	je	short @4@226
   ;	
   ;		{
   ;	#ifdef _DEBUG
   ;			if (ResponseLevel >= 2)
   ;				printf("PPPLIB: PPPOpen() -- OpenScript[0] != \'@\' Assuming script file name\n");
   ;	#endif
   ;	
   ;			// Load the open script using the file name we were given
   ;			OpenScript = PPPLoadScript(OpenScript);
   ;	
	?debug	L 274
	push	si
	call	near ptr @PPPLoadScript$qpc
	pop	cx
	mov	si,ax
   ;	
   ;			// If we failed to load the script then return an error
   ;			if (!OpenScript)
   ;	
	?debug	L 276
	or	si,si
	jne	short @4@198
   ;	
   ;			{
   ;	#ifdef _DEBUG
   ;				if (ResponseLevel >= 1)
   ;				printf("PPPLIB: PPPOpen() -- Failed to load OpenScript from disk\n");
   ;	#endif
   ;				return 0x8FFF;
   ;	
	?debug	L 282
	mov	ax,-28673
	jmp	@4@926
@4@198:
   ;	
   ;			}
   ;			// Flag the fact that we loaded a script (to free the memory later)
   ;			LOpen = 1;
   ;	
	?debug	L 285
	mov	word ptr [bp-2],1
@4@226:
   ;	
   ;		}
   ;	
   ;		// If we were passed a string that did not begin with @ then it's a file name
   ;		if (CloseScript && (CloseScript[0] != '@'))
   ;	
	?debug	L 289
	or	di,di
	je	short @4@422
	mov	al,byte ptr [di]
	cbw	
	cmp	ax,64
	je	short @4@422
   ;	
   ;		{
   ;	#ifdef _DEBUG
   ;			if (ResponseLevel >= 2)
   ;				printf("PPPLIB: PPPOpen() -- CloseScript[0] != \'@\' Assuming script file name\n");
   ;	#endif
   ;	
   ;			// Load the close script using the file name we were given
   ;			CloseScript = PPPLoadScript(CloseScript);
   ;	
	?debug	L 297
	push	di
	call	near ptr @PPPLoadScript$qpc
	pop	cx
	mov	di,ax
   ;	
   ;	      // If we failed to load the script then return an error
   ;			if (!CloseScript)
   ;	
	?debug	L 299
	or	di,di
	jne	short @4@394
   ;	
   ;			{
   ;	#ifdef _DEBUG
   ;				if (ResponseLevel >= 1)
   ;				printf("PPPLIB: PPPOpen() -- Failed to load CloseScript from disk\n");
   ;	#endif
   ;				// Free the open script if we loaded it
   ;				if (LOpen) PPPFreeScript(OpenScript);
   ;	
	?debug	L 306
	cmp	word ptr [bp-2],0
	je	short @4@366
	push	si
	call	near ptr @PPPFreeScript$qpc
	pop	cx
@4@366:
   ;	
   ;				return 0x8FFE;
   ;	
	?debug	L 307
	mov	ax,-28674
	jmp	@4@926
@4@394:
   ;	
   ;			}
   ;			// Flag the fact that we loaded a script (to free the memory later)
   ;			LClose = 1;
   ;	
	?debug	L 310
	mov	word ptr [bp-4],1
@4@422:
   ;	
   ;		}
   ;	
   ;		// AX contains the function code
   ;		// The function code for 'open' is 1
   ;		Regs.r_ax = 1;
   ;	
	?debug	L 315
	mov	word ptr [bp-24],1
   ;	
   ;	
   ;		// Convert the pointers to the scripts to far pointers and load them into the
   ;		// appropriate registers for the ISR
   ;		if (OpenScript != 0)
   ;	
	?debug	L 319
	or	si,si
	je	short @4@478
   ;	
   ;		{
   ;			Regs.r_ds = FP_SEG((char far*)OpenScript);
   ;	
	?debug	L 321
	mov	word ptr [bp-10],ds
   ;	
   ;			Regs.r_si = FP_OFF((char far*)OpenScript);
   ;	
	?debug	L 322
	mov	word ptr [bp-14],si
   ;	
   ;	
   ;	#ifdef _DEBUG
   ;		if (ResponseLevel >= 3)
   ;			printf("PPPLIB: PPPOpen() -- OpenScript = Address %04X:%04X\n",
   ;				Regs.r_ds, Regs.r_si);
   ;	#endif
   ;		}
   ;	
	?debug	L 329
	jmp	short @4@506
@4@478:
   ;	
   ;		else Regs.r_ds = Regs.r_si = 0;
   ;	
	?debug	L 330
	xor	ax,ax
	mov	word ptr [bp-14],ax
	mov	word ptr [bp-10],ax
@4@506:
   ;	
   ;		if (CloseScript != 0)
   ;	
	?debug	L 331
	or	di,di
	je	short @4@562
   ;	
   ;		{
   ;			Regs.r_es = FP_SEG((char far*)CloseScript);
   ;	
	?debug	L 333
	mov	word ptr [bp-8],ds
   ;	
   ;			Regs.r_di = FP_OFF((char far*)CloseScript);
   ;	
	?debug	L 334
	mov	word ptr [bp-12],di
   ;	
   ;	
   ;	#ifdef _DEBUG
   ;		if (ResponseLevel >= 3)
   ;			printf("PPPLIB: PPPOpen() -- CloseScript = Address %04X:%04X\n",
   ;				Regs.r_ds, Regs.r_si);
   ;	#endif
   ;		}
   ;	
	?debug	L 341
	jmp	short @4@590
@4@562:
   ;	
   ;		else Regs.r_es = Regs.r_di = 0;
   ;	
	?debug	L 342
	xor	ax,ax
	mov	word ptr [bp-12],ax
	mov	word ptr [bp-8],ax
@4@590:
   ;	
   ;	
   ;		// Call the ISR with the register structure set up above
   ;		intr(PPPInterrupt, &Regs);
   ;	
	?debug	L 345
	lea	ax,word ptr [bp-24]
	push	ax
	push	word ptr DGROUP:_PPPInterrupt
	call	near ptr _intr
	add	sp,4
   ;	
   ;	
   ;		// Free the scripts that we loaded from disk (to prevent memory leaks)
   ;		if (LClose) PPPFreeScript(CloseScript);
   ;	
	?debug	L 348
	cmp	word ptr [bp-4],0
	je	short @4@646
	push	di
	call	near ptr @PPPFreeScript$qpc
	pop	cx
@4@646:
   ;	
   ;		if (LOpen) PPPFreeScript(OpenScript);
   ;	
	?debug	L 349
	cmp	word ptr [bp-2],0
	je	short @4@702
	push	si
	call	near ptr @PPPFreeScript$qpc
	pop	cx
@4@702:
   ;	
   ;	
   ;		// If the call was successful and we are supposed to wait for a complete
   ;		// connection
   ;		if ((Regs.r_ax == 0) && WaitForConnect)
   ;	
	?debug	L 353
	cmp	word ptr [bp-24],0
	jne	short @4@898
	cmp	word ptr [bp+8],0
	je	short @4@898
	jmp	short @4@786
@4@786:
   ;	
   ;		{
   ;	#ifdef _DEBUG
   ;			if (ResponseLevel >= 2)
   ;				printf("PPPLIB: PPPOpen() -- Waiting for connection success or failure\n");
   ;	#endif
   ;			// While PPP is neither fully open nor closed, just loop
   ;			while(!PPPISOPEN(PPPStatus()) && !PPPISCLOSED(PPPStatus())) { }
   ;	
	?debug	L 360
	call	near ptr _PPPStatus
	shr	ax,10
	and	ax,31
	cmp	ax,3
	je	short @4@842
	call	near ptr _PPPStatus
	shr	ax,10
	and	ax,31
	cmp	ax,6
	jne	short @4@786
@4@842:
   ;	
   ;			// If the connection failed after some time then return an error
   ;			if (PPPISCLOSED(PPPStatus()))
   ;	
	?debug	L 362
	call	near ptr _PPPStatus
	shr	ax,10
	and	ax,31
	cmp	ax,6
	jne	short @4@898
@4@870:
   ;	
   ;			{
   ;	#ifdef _DEBUG
   ;				if (ResponseLevel >= 1)
   ;					printf("PPPLIB: PPPOpen() -- Connection failed while waiting\n");
   ;	#endif
   ;				return 0x8FFD;
   ;	
	?debug	L 368
	mov	ax,-28675
	jmp	short @4@926
@4@898:
   ;	
   ;			}
   ;		}
   ;	
   ;	#ifdef _DEBUG
   ;		if ((ResponseLevel >= 1) && (Regs.r_ax != 0))
   ;			printf("PPPLIB: PPPOpen() -- Connection failed immediately\n");
   ;	#endif
   ;	
   ;		// The ISR returns a status code in AX
   ;		// 0 means success, anything else means failure
   ;		return Regs.r_ax;
   ;	
	?debug	L 379
	mov	ax,word ptr [bp-24]
	jmp	short @4@926
@4@926:
   ;	
   ;	}
   ;	
	?debug	L 380
	pop	di
	pop	si
	leave	
	ret	
	?debug	C E6064C436C6F73650402FCFF01FD0001FE360126+
	?debug	C 0000054C4F70656E0402FEFF01FD0001FE1D0115+
	?debug	C 2B000004526567731C02E8FF01FC0001FE3B0106+
	?debug	C 010803010803081A00000A4F70656E5363726970+
	?debug	C 74180C0600000B436C6F7365536372697074180C+
	?debug	C 0700000E57616974466F72436F6E6E656374040A+
	?debug	C 08000000
	?debug	E
	?debug	E
_PPPOpen	endp
   ;	
   ;	unsigned int PPPClose(void)
   ;	
	?debug	L 387
	assume	cs:_TEXT,ds:DGROUP
_PPPClose	proc	near
	?debug	B
	enter	20,0
	?debug	B
   ;	
   ;	{
   ;		struct REGPACK Regs;
   ;	
   ;		// Make sure someone called PPPInit first with a valid interrupt
   ;		if (PPPInterrupt == 0)
   ;	
	?debug	L 392
	cmp	word ptr DGROUP:_PPPInterrupt,0
	jne	short @5@86
   ;	
   ;		{
   ;	#ifdef _DEBUG
   ;			if (ResponseLevel >= 1)
   ;				printf("PPPLIB: PPPClose() -- PPPLIB was not initialized\n");
   ;	#endif
   ;			return 0xFF;
   ;	
	?debug	L 398
	mov	ax,255
	leave	
	ret	
@5@86:
   ;	
   ;		}
   ;	
   ;		// AX contains the function code
   ;		// The function code for 'close' is 2
   ;		Regs.r_ax = 2;
   ;	
	?debug	L 403
	mov	word ptr [bp-20],2
   ;	
   ;		intr(PPPInterrupt, &Regs);
   ;	
	?debug	L 404
	lea	ax,word ptr [bp-20]
	push	ax
	push	word ptr DGROUP:_PPPInterrupt
	call	near ptr _intr
	add	sp,4
   ;	
   ;	
   ;	#ifdef _DEBUG
   ;		if ((ResponseLevel >= 1) && (Regs.r_ax != 0))
   ;			printf("PPPLIB: PPPClose() -- Connection could not be closed (PPP is reset)\n");
   ;	#endif
   ;	
   ;		// The ISR returns a status code in AX
   ;		// 0 means success, anything else means failure
   ;		return Regs.r_ax;
   ;	
	?debug	L 413
	mov	ax,word ptr [bp-20]
	leave	
	ret	
   ;	
   ;	}
   ;	
	?debug	L 414
	leave	
	ret	
	?debug	C E604526567731C02ECFF01850101FE9301010900+
	?debug	C 00
	?debug	E
	?debug	E
_PPPClose	endp
   ;	
   ;	unsigned int PPPStatus(void)
   ;	
	?debug	L 424
	assume	cs:_TEXT,ds:DGROUP
_PPPStatus	proc	near
	?debug	B
	enter	20,0
	?debug	B
   ;	
   ;	{
   ;		struct REGPACK Regs;
   ;	
   ;		// Make sure someone called PPPInit first with a valid interrupt
   ;		if (PPPInterrupt == 0)
   ;	
	?debug	L 429
	cmp	word ptr DGROUP:_PPPInterrupt,0
	jne	short @6@86
   ;	
   ;		{
   ;	#ifdef _DEBUG
   ;			if (ResponseLevel >= 1)
   ;				printf("PPPLIB: PPPStatus() -- PPPLIB was not initialized\n");
   ;	#endif
   ;			return 0xFF;
   ;	
	?debug	L 435
	mov	ax,255
	leave	
	ret	
@6@86:
   ;	
   ;		}
   ;	
   ;		// AX contains the function code
   ;		// The function code for 'status' is 3
   ;	
   ;		Regs.r_ax = 3;
   ;	
	?debug	L 441
	mov	word ptr [bp-20],3
   ;	
   ;		intr(PPPInterrupt, &Regs);
   ;	
	?debug	L 442
	lea	ax,word ptr [bp-20]
	push	ax
	push	word ptr DGROUP:_PPPInterrupt
	call	near ptr _intr
	add	sp,4
   ;	
   ;	
   ;		return Regs.r_ax;
   ;	
	?debug	L 444
	mov	ax,word ptr [bp-20]
	leave	
	ret	
   ;	
   ;	}
   ;	
	?debug	L 445
	leave	
	ret	
	?debug	C E604526567731C02ECFF01AA0101FEB901010200+
	?debug	C 00
	?debug	E
	?debug	E
_PPPStatus	endp
   ;	
   ;	unsigned long PPPLocalIP(void)
   ;	
	?debug	L 452
	assume	cs:_TEXT,ds:DGROUP
_PPPLocalIP	proc	near
	?debug	B
	enter	20,0
	?debug	B
   ;	
   ;	{
   ;		struct REGPACK Regs;
   ;	
   ;		// Make sure someone called PPPInit first with a valid interrupt
   ;		if (PPPInterrupt == 0)
   ;	
	?debug	L 457
	cmp	word ptr DGROUP:_PPPInterrupt,0
	jne	short @7@86
   ;	
   ;		{
   ;	#ifdef _DEBUG
   ;			if (ResponseLevel >= 1)
   ;				printf("PPPLIB: PPPLocalIP() -- PPPLIB was not initialized\n");
   ;	#endif
   ;			return 0xFFFFFFFFl;
   ;	
	?debug	L 463
	mov	dx,-1
	mov	ax,-1
	leave	
	ret	
@7@86:
   ;	
   ;		}
   ;	
   ;		// AX contains the function code
   ;		// The function code for 'LocalIP' is 6
   ;		Regs.r_ax = 6;
   ;	
	?debug	L 468
	mov	word ptr [bp-20],6
   ;	
   ;	
   ;		// Call the ISR with the register structure set up above
   ;		intr(PPPInterrupt, &Regs);
   ;	
	?debug	L 471
	lea	ax,word ptr [bp-20]
	push	ax
	push	word ptr DGROUP:_PPPInterrupt
	call	near ptr _intr
	add	sp,4
   ;	
   ;	
   ;		// The ISR returns the localIP in AX:BX
   ;		return ((unsigned long)(Regs.r_ax) << 16) | (unsigned long)(Regs.r_bx);
   ;	
	?debug	L 474
	mov	dx,word ptr [bp-20]
	xor	ax,ax
	or	ax,word ptr [bp-18]
	leave	
	ret	
   ;	
   ;	}
   ;	
	?debug	L 475
	leave	
	ret	
	?debug	C E604526567731C02ECFF01C60101FED401030300+
	?debug	C 00
	?debug	E
	?debug	E
_PPPLocalIP	endp
   ;	
   ;	unsigned long PPPRemoteIP(void)
   ;	
	?debug	L 482
	assume	cs:_TEXT,ds:DGROUP
_PPPRemoteIP	proc	near
	?debug	B
	enter	20,0
	?debug	B
   ;	
   ;	{
   ;		struct REGPACK Regs;
   ;	
   ;		// Make sure someone called PPPInit first with a valid interrupt
   ;		if (PPPInterrupt == 0)
   ;	
	?debug	L 487
	cmp	word ptr DGROUP:_PPPInterrupt,0
	jne	short @8@86
   ;	
   ;		{
   ;	#ifdef _DEBUG
   ;			if (ResponseLevel >= 1)
   ;				printf("PPPLIB: PPPLocalIP() -- PPPLIB was not initialized\n");
   ;	#endif
   ;			return 0xFFFFFFFFl;
   ;	
	?debug	L 493
	mov	dx,-1
	mov	ax,-1
	leave	
	ret	
@8@86:
   ;	
   ;		}
   ;	
   ;		// AX contains the function code
   ;		// The function code for 'RemoteIP' is 7
   ;		Regs.r_ax = 7;
   ;	
	?debug	L 498
	mov	word ptr [bp-20],7
   ;	
   ;	
   ;		// Call the ISR with the register structure set up above
   ;		intr(PPPInterrupt, &Regs);
   ;	
	?debug	L 501
	lea	ax,word ptr [bp-20]
	push	ax
	push	word ptr DGROUP:_PPPInterrupt
	call	near ptr _intr
	add	sp,4
   ;	
   ;	
   ;		// The ISR returns the RemoteIP in AX:BX
   ;		return ((unsigned long)(Regs.r_ax) << 16) | (unsigned long)(Regs.r_bx);
   ;	
	?debug	L 504
	mov	dx,word ptr [bp-20]
	xor	ax,ax
	or	ax,word ptr [bp-18]
	leave	
	ret	
   ;	
   ;	}
   ;	
	?debug	L 505
	leave	
	ret	
	?debug	C E604526567731C02ECFF01E40101FEF201030300+
	?debug	C 00
	?debug	E
	?debug	E
_PPPRemoteIP	endp
	?debug	C E9
	?debug	C FA00000000
_TEXT	ends
_DATA	segment word public 'DATA'
s@	label	byte
	db	'rt'
	db	0
_DATA	ends
_TEXT	segment byte public 'CODE'
_TEXT	ends
_s@	equ	s@
_peek	equ	peek
_peekb	equ	peekb
_poke	equ	poke
_pokeb	equ	pokeb
	extrn	_intr:near
	extrn	_fclose:near
	extrn	_fgetc:near
	extrn	_fopen:near
	extrn	_free:near
	extrn	_malloc:near
	public	_PPPInit
	public	_PPPOpen
	public	_PPPClose
	public	_PPPStatus
	public	_PPPLocalIP
	public	_PPPRemoteIP
	public	_PPPInterrupt
	public	_PPPSignature
	public	@PPPLoadScript$qpc
	public	@PPPFreeScript$qpc
	?debug	C EA0509
	?debug	C E31D05646672656508001E16
	?debug	C E31E0A6469736B667265655F7408001E1B
	?debug	C E31F0474696D6504001E20
	?debug	C E32009646F7374696D655F7404001E25
	?debug	C E321046461746504001E2A
	?debug	C E32209646F73646174655F7405001E2E
	?debug	C E323056666626C6B2B001E33
	?debug	C E3240015001A02
	?debug	C E325000D001A02
	?debug	C E3260666696E645F742B001E3A
	?debug	C E3270015001A02
	?debug	C E328000D001A02
	?debug	C E3290366636225001E41
	?debug	C E32A0008001A02
	?debug	C E32B0003001A02
	?debug	C E32C000A001A02
	?debug	C E32D04786663622C001E4C
	?debug	C E32E0005001A02
	?debug	C E32F08444F534552524F5205001E51
	?debug	C E33007666174696E666F06001E56
	?debug	C E33108574F52445245475310001E5B
	?debug	C E33208425954455245475308001E64
	?debug	C E333045245475310001F6D
	?debug	C E33405535245475308001E71
	?debug	C E33500000023040000
	?debug	C E33600000023020000
	?debug	C E33700000023010000
	?debug	C E33800000023010000
	?debug	C E33900000023010000
	?debug	C EB055F696E7472390001FE9C00FE59013B261D1E+
	?debug	C 0000
	?debug	C E33A07434F554E54525922001E76
	?debug	C E33B0005001A02
	?debug	C E33C0002001A02
	?debug	C E33D0002001A02
	?debug	C E33E0002001A02
	?debug	C E33F0002001A02
	?debug	C E3400002001A02
	?debug	C E341000A001A02
	?debug	C E3420664657668647212001E8083
	?debug	C E3430008001A02
	?debug	C E34400000023040000
	?debug	C EB075F66636C6F7365440001FEDF000000
	?debug	C E34500000023040000
	?debug	C EB065F6667657463450001FED6000000
	?debug	C E34600000023190000
	?debug	C EB065F666F70656E460001FEB5000000
	?debug	C E3470B66617268656170696E666F0A001E8089
	?debug	C E348000400160101
	?debug	C E3490868656170696E666F06001E808D
	?debug	C E34A000200150104
	?debug	C E34B00000023010000
	?debug	C EB055F667265654B0001FEF1000000
	?debug	C E34C000000234A0000
	?debug	C EB075F6D616C6C6F634C0001FEA7000000
	?debug	C E34D000000230A0000
	?debug	C EC085F505050496E69744D1801330000
	?debug	C E34E000000230A0000
	?debug	C EC085F5050504F70656E4E1801FA0000
	?debug	C E34F000000230A0000
	?debug	C EC095F505050436C6F73654F1801830100
	?debug	C E350000000230A0000
	?debug	C EC0A5F505050537461747573501801A80101FE68+
	?debug	C 01020000
	?debug	C E351000000230C0000
	?debug	C EC0B5F5050504C6F63616C4950511801C40100
	?debug	C E352000000230C0000
	?debug	C EC0C5F50505052656D6F74654950521801E20100
	?debug	C EC0D5F505050496E746572727570740A00011D00+
	?debug	C 01662A0C64592F0C190D0F0E100E0000
	?debug	C E353000A001A02
	?debug	C EC0D5F5050505369676E61747572655300012500+
	?debug	C 014F0000
	?debug	C E35400000023180000
	?debug	C EC12405050504C6F616453637269707424717063+
	?debug	C 541801810001FE1201170000
	?debug	C E35500000023010000
	?debug	C EC12405050504672656553637269707424717063+
	?debug	C 551801EA0001FEBD00FE32012A010000
	?debug	C E60673697A655F740A06032C0003FEAA00080CFF+
	?debug	C 045B00020100000666706F735F74060603310003+
	?debug	C FEA4000C00000446494C451A0603730003FE8400+
	?debug	C 1C01010101010101010102010101010101020702+
	?debug	C 010602010209050101030402010701FF01840000+
	?debug	C 0009707472646966665F74040604360000056466+
	?debug	C 7265651D0702420002FEC50000000A6469736B66+
	?debug	C 7265655F741E07024A0002FEB10000000474696D+
	?debug	C 651F0702520002FEC100060202000009646F7374+
	?debug	C 696D655F742007025A0002FEB700080000046461+
	?debug	C 7465210702620002FEC100020502000009646F73+
	?debug	C 646174655F74220702690002FEAF000B00000566+
	?debug	C 66626C6B2307028D00000666696E645F74260702+
	?debug	C 980002FEAD0001000003666362290702E40002FE+
	?debug	C F700FE7401FE450201000004786663622D0702F2+
	?debug	C 000008444F534552524F522F0702030102FE6D01+
	?debug	C 000007666174696E666F3007020C0102FE700101+
	?debug	C 000008574F5244524547533107022D0102FE4A01+
	?debug	C 020000084259544552454753320702390102FE4D+
	?debug	C 0100000452454753330702450102FE8601010101+
	?debug	C 020101010000055352454753340702500102FE79+
	?debug	C 0111050000075245475041434B1C07025E0102FE+
	?debug	C 9001FF018300FEFC00FE8501251C1E000007434F+
	?debug	C 554E5452593A0702B50102FEC501010000066465+
	?debug	C 76686472420702D601000B66617268656170696E+
	?debug	C 666F470704420004FE8E0000000868656170696E+
	?debug	C 666F4907044B0004FE84000000
	?debug	F peek 53 24 2 633	0
	?debug	F peekb 54 24 2 638	0
	?debug	F poke 55 24 2 643	0
	?debug	F pokeb 56 24 2 648	0
	?debug	C E200056C6576656C040005666C6167730A000266+
	?debug	C 64020004686F6C640800056273697A6504000662+
	?debug	C 75666665721B0004637572701B0006697374656D+
	?debug	C 700A0005746F6B656E04C010000000
	?debug	C E20004725F61780A0004725F62780A0004725F63+
	?debug	C 780A0004725F64780A0004725F62700A0004725F+
	?debug	C 73690A0004725F64690A0004725F64730A000472+
	?debug	C 5F65730A0007725F666C6167730AC014000000
	?debug	C E2000864665F617661696C0A000864665F746F74+
	?debug	C 616C0A000764665F627365630A000864665F7363+
	?debug	C 6C75730AC008000000
	?debug	C E2000E746F74616C5F636C7573746572730A000E+
	?debug	C 617661696C5F636C7573746572730A0013736563+
	?debug	C 746F72735F7065725F636C75737465720A001062+
	?debug	C 797465735F7065725F736563746F720AC0080000+
	?debug	C 00
	?debug	C E2000674695F6D696E08000774695F686F757208+
	?debug	C 000774695F68756E6408000674695F73656308C0+
	?debug	C 04000000
	?debug	C E20004686F75720800066D696E75746508000673+
	?debug	C 65636F6E64080007687365636F6E6408C0040000+
	?debug	C 00
	?debug	C E2000764615F7965617204000664615F64617902+
	?debug	C 000664615F6D6F6E02C004000000
	?debug	C E200036461790800056D6F6E7468080004796561+
	?debug	C 720A00096461796F667765656B08C005000000
	?debug	C E2000B66665F726573657276656424000966665F+
	?debug	C 61747472696202000866665F6674696D650A0008+
	?debug	C 66665F66646174650A000866665F6673697A6506+
	?debug	C 000766665F6E616D6525C02B000000
	?debug	C E200087265736572766564270006617474726962+
	?debug	C 02000777725F74696D650A000777725F64617465+
	?debug	C 0A000473697A650600046E616D6528C02B000000
	?debug	C E200096663625F64726976650200086663625F6E+
	?debug	C 616D652A00076663625F6578742B000A6663625F+
	?debug	C 637572626C6B04000B6663625F72656373697A65+
	?debug	C 04000B6663625F66696C73697A65060008666362+
	?debug	C 5F646174650400086663625F726573762C000A66+
	?debug	C 63625F63757272656302000A6663625F72616E64+
	?debug	C 6F6D06C025000000
	?debug	C E20009786663625F666C6167020009786663625F+
	?debug	C 726573762E0009786663625F6174747202000878+
	?debug	C 6663625F66636229C02C000000
	?debug	C E2000B64655F6578746572726F7204000864655F+
	?debug	C 636C61737302000964655F616374696F6E020008+
	?debug	C 64655F6C6F63757302C005000000
	?debug	C E2000866695F73636C757302000866695F666174+
	?debug	C 696402000866695F6E636C75730A000866695F62+
	?debug	C 7973656304C006000000
	?debug	C E2000261780A000262780A000263780A00026478+
	?debug	C 0A000273690A000264690A000563666C61670A00+
	?debug	C 05666C6167730AC010000000
	?debug	C E20002616C0800026168080002626C0800026268+
	?debug	C 080002636C0800026368080002646C0800026468+
	?debug	C 08C008000000
	?debug	C E2000178310001773100016832C010000000
	?debug	C E2000265730A000263730A000273730A00026473+
	?debug	C 0AC008000000
	?debug	C E20007636F5F64617465040007636F5F63757272+
	?debug	C 3B0008636F5F74687365703C0008636F5F646573+
	?debug	C 65703D0008636F5F64747365703E0008636F5F74+
	?debug	C 6D7365703F000C636F5F637572727374796C6502+
	?debug	C 0009636F5F646967697473020007636F5F74696D+
	?debug	C 65020007636F5F63617365060008636F5F646173+
	?debug	C 6570400007636F5F66696C6C41C022000000
	?debug	C E2000764685F6E65787406000764685F61747472+
	?debug	C 04000864685F73747261740A000864685F696E74+
	?debug	C 65720A000764685F6E616D6543C012000000
	?debug	C E2000370747248000473697A650C0006696E5F75+
	?debug	C 736504C00A000000
	?debug	C E200037074724A000473697A650A0006696E5F75+
	?debug	C 736504C006000000
	end
