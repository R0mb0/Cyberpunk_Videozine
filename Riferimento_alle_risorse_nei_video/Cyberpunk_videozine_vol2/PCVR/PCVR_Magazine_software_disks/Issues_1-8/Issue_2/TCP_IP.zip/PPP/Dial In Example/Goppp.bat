ppp 0x60 0x61 0x3F8 4 57600 8 1 0 0 3 256
pppopen /i:0x61 /o:open.ppp /c:close.ppp