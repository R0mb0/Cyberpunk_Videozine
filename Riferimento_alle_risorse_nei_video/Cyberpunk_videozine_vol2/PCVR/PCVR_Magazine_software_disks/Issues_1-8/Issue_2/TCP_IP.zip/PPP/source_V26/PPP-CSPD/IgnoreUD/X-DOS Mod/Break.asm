;
;	-----------------------------------------------------------------
;	!          HANDLING OF THE INTERRUPT 23 FOR BREAK BY CTRL 'C'   !
;	!          HANDLING OF THE DIVIDE ERROR HANDLER                 !
;	!                                                               !
;	!  THIS FUNCTIONS CHECKS IF CONTROL 'C' HAS BEEN PRESSED AND    !
;	!  IF SO, ISSUE A INT 23H CALL TO THE CURRENT HANDLER.          !
;	!  ON RETURN, FROM THE HANDLER, X-DOS TESTS IF THE STACK HAS    !
;	!  CHANGED, IF SO, THE CARRY FLAG TELLS IF APPLICATION MUST BE  !
;	!  TERMINATED, OR CONTINUED.                                    !
;	!                                                               !
;	!  Written by Thierry, December 1989                            !
;	-----------------------------------------------------------------
code	segment word public 'CODE'
	assume cs:code,ds:code,es:code,ss:code
;
;	-------------------------------------------------------------
;	!             EXTERNAL AND PUBLIC DECLARATIONS              !
;	-------------------------------------------------------------
extrn	entry_count		: byte
extrn	int_24_flag		: byte
extrn   task_ax			: word
extrn   task_al			: byte
extrn   task_bx			: word
extrn   task_cx			: word
extrn   task_dx			: word
extrn   task_si			: word
extrn   task_di			: word
extrn   task_bp			: word
extrn   task_sp			: word
extrn   task_ds			: word
extrn   task_es			: word
extrn   task_ss			: word
extrn   task_cs			: word
extrn   task_ip			: word
extrn	task_flag		: word
extrn	int_23_sp		: word
extrn	buf_break		: byte
extrn	mark_it_23		: byte
extrn	con_driver		: dword

extrn	it_dos			: near
extrn	save_task_reg		: near
extrn	restore_task_reg  	: near
extrn	driver_call		: near
extrn	do_aff_string_0		: near
extrn	bin_to_hex		: near
extrn	do_output_char_echo_0	: near
extrn	disp_cr_lf		: near

public 	div_err_handler
public	bad_opcode_handler
public	generate_int_23
public	test_break
;
;	-----------------------------------------------------------------
;	!              DATA USED BY THE BREAK HANDLE ROUTINE            !
;	-----------------------------------------------------------------
;
rh		db	30 dup (0)	       	; Local Request header
divide_error	db	0dh,0ah,7,'Divide overflow at address : ','$'
bad_opcode_error db	0dh,0ah,7,'Illegal instruction at address : ','$'
;
;	-----------------------------------------------------------------
;	!      INCLUDE EXTERNAL FILES FOR  INT 23 HANDLER OPERATION     !
;	-----------------------------------------------------------------
;
include	error.equ				; Common errors and fatal flags
include	inter.equ				; Interrupt used in X-dos
include	ddb.equ					; Dos block description
include	reqhdr.equ				; Header for driver stuff
;
;	---------------------------------------------------------------
;	!       TEST DU BREAK IF THIS IS THE FIRST ENTRY CALL ONLY    !
;	---------------------------------------------------------------
test_break	proc near
	call	save_task_reg			; Save the registers of the task
	mov	ax,cs				; Get the current stack
	mov	ds,ax				; Get in right segments
	mov	es,ax
	cmp	entry_count,1			; Is it first entry in DOS ?
	jnz	test_break_end			; No, so ignore treatment
	mov	rh_len,rh5_len			; Length of the header	
	mov	rh_unit,0			; Reset unit
	mov	rh_cmd,cmd_input_nowait		; Command : Non destructive input
	mov	rh_status,0			; Clear the status
	mov	rh5_char,0			; Clear the character
	mov	rh4_bufoff,offset buf_break	; Adress of buffer for break
	mov	rh4_bufseg,cs			; Segment for break
	mov	bx,offset rh			; Adress of local request header
	lds	si,con_driver			; Adress of driver
	call	driver_call			; Call the driver
	push	cs				; Normal segment
	pop	ds				; Configuration
	test	rh_status,da_otilbsy		; Is it busy ?
	jnz	test_break_end			; Yes, so ignore 	
	cmp	rh5_char,3			; Test if control 'C' preseed
	jnz	test_break_end			; No, Ignore
	mov	rh_len,rh6_len			; Length of the header	
	mov	rh_unit,0			; Reset unit
	mov	rh_cmd,cmd_input_nowait		; Command : Non destructive input
	mov	rh_cmd,cmd_input		; Command : Input
	mov	rh_status,0			; Clear the status
	mov	rh4_count,1			; 1 character to input only
	mov	rh4_bufoff,offset buf_break	; Adress of buffer for break
	mov	rh4_bufseg,cs			; Segment for break
	mov	bx,offset rh			; Adress of local request header
	lds	si,con_driver			; Adress of driver
	call	driver_call			; Call the driver
	call	restore_task_reg		; Restore the saved registers
	jmp	generate_int_23			; Generate an INT 23h
test_break_end:
	call	restore_task_reg		; Restore the saved registers
	ret					; And return
test_break	endp

;
;	--------------------------------------------------------------
;	!   THIS FUNCTION GENERATES THE INT 23H THAT INDICATE BREAK  !
;	--------------------------------------------------------------
generate_int_23	proc near
	mov	cs:entry_count,0		; Clear entry count
	mov	cs:int_24_flag,0		; And flag INT 24 pending
	cli					; Mask the interrupts
	mov	ax,cs:task_ax			
	mov	bx,cs:task_bx
	mov	cx,cs:task_cx
	mov	dx,cs:task_dx
	mov	si,cs:task_si			; Get the registers back
	mov	di,cs:task_di
	mov	bp,cs:task_bp
	mov	ds,cs:task_ds
	mov	es,cs:task_es
	mov	sp,cs:task_sp			; Restore the Stack Pointer
	mov	ss,cs:task_ss			; And the associated segment
	push	cs:task_flag			; Put flags in stack	
	push	cs:task_cs			; Put the code segment of caller
	push	cs:task_ip			; And the current IP
	mov	cs:int_23_sp,sp			; Save the stack for later inspection	
	sti					; Release the interrupt
	clc					; Clear the carry
	int	int_abort			; Abort the task processus
	cli					; Mask them again
	mov	cs:task_ax,ax			; Save the values of AX, maybe change by application
	pushf
	pop	ax				; Save the state of the carry
	cmp	sp,cs:int_23_sp			; See if stack changed ?	
generate_int_23_0:
	mov	bx,cs:task_bx
	mov	cx,cs:task_cx
	mov	dx,cs:task_dx
	mov	si,cs:task_si			; Get the registers again
	mov	di,cs:task_di
	mov	bp,cs:task_bp
	mov	ds,cs:task_ds
	mov	es,cs:task_es
	je	generate_int_23_1		; No
	push	ax
	popf					; Get the state of carry back
	jnc	generate_int_23_1		; No carry, so restart normally
	mov	ax,4c01h			; Declare abort by user
	jmp	short generate_int_23_2		; And perform a restart of dos request
generate_int_23_1:
	mov	ax,cs:task_ax		
generate_int_23_2:
	mov	sp,cs:int_23_sp			; Reload stack adress from before
	jmp	it_dos				; Start again folks !
generate_int_23	endp
;
;	--------------------------------------------------------------
;	!        THIS IS THE DIVIDE ERROR INTERRUPTION HANDLER       !
;	--------------------------------------------------------------
;
div_err_handler	proc near
	mov	si,offset divide_error		; Adress of String 'DIVIDE ERROR ...'
div_err_handler_0:
	push	cs				; Swap to local segments
	pop	ds
	call	do_aff_string_0			; Ask driver to display message
	pop	cx				; Get the IP
	pop	ax				; And the CS
	call	bin_to_hex			; Display the Hexa number of CS
	mov	al,':'				; Delimiter
	push	cx
	call	do_output_char_echo_0		; Display the delimiter
	pop	ax				; Get the IP back
	call	bin_to_hex			; Display the IP
	call	disp_cr_lf			; Display a CR LF
	or	al,1				; Make it NZ
	stc					; Carry set
	jmp	short generate_int_23_0		; Reload and break task
div_err_handler	endp

;
;	--------------------------------------------------------------
;	!        THIS IS THE EXECUTION ERROR FOR UNDEFINED OPCODE    !
;	--------------------------------------------------------------
;
bad_opcode_handler	proc near
	push	ds
	push	si
	push	ax

	mov	si,sp
	add	si,6
	mov	ax,ss:[si]
	add	si,2
	mov	si,ss:[si]
	mov	ds,si
	mov	si,ax
	mov	al,ds:[si-1]
	cmp	al,66h
	je	ignore

	pop	ax
	pop	si
	pop	ds
	
	mov	si,offset bad_opcode_error	; Adress of String Error
	jmp	short div_err_handler_0

ignore:
	pop	ax
	pop	si
	pop	ds
	iret
bad_opcode_handler	endp

code	ends
	end
