del %1.lib
tlib %1.lib +auth.obj +fchain.obj +frame.obj +int.obj +ipcp.obj +lcp.obj +modem.obj +pdrv.obj +ppplinkd.obj +script.obj +timer.obj