	.386p
	ifndef	??version
?debug	macro
	endm
publicdll macro	name
	public	name
	endm
$comm	macro	name,dist,size,count
	comm	dist name:BYTE:count*size
	endm
	else
$comm	macro	name,dist,size,count
	comm	dist name[size]:BYTE:count
	endm
	endif
	?debug	V 301h
	?debug	S "PPPLINKD.CPP"
	?debug	C E9CD742F2D0C5050504C494E4B442E435050
	?debug	C E9802E1D1F15433A5C424334355C494E434C5544455C444F532E48
	?debug	C E9802E1D1F17433A5C424334355C494E434C5544455C5F44454653+
	?debug	C 2E48
	?debug	C E9802E1D1F16433A5C424334355C494E434C5544455C42494F532E+
	?debug	C 48
	?debug	C E9802E1D1F17433A5C424334355C494E434C5544455C535444494F+
	?debug	C 2E48
	?debug	C E9802E1D1F18433A5C424334355C494E434C5544455C5F4E46494C+
	?debug	C 452E48
	?debug	C E9802E1D1F17433A5C424334355C494E434C5544455C5F4E554C4C+
	?debug	C 2E48
	?debug	C E9802E1D1F18433A5C424334355C494E434C5544455C5354444C49+
	?debug	C 422E48
	?debug	C E9802E1D1F17433A5C424334355C494E434C5544455C434F4E494F+
	?debug	C 2E48
	?debug	C E9735D652C055050502E48
	?debug	C E91C56C32C0754595045532E48
	?debug	C E9705D652C074652414D452E48
	?debug	C E91C56C32C0754595045532E48
	?debug	C E99D7BC32C074D4F44454D2E48
	?debug	C E9705D652C074652414D452E48
	?debug	C E96F5D652C0846434841494E2E48
	?debug	C E91C56C32C0754595045532E48
	?debug	C E9705D652C074652414D452E48
	?debug	C E949798E2C085343524950542E48
	?debug	C E91C56C32C0754595045532E48
	?debug	C E99D7BC32C074D4F44454D2E48
	?debug	C E90473BF2C054C43502E48
	?debug	C E9705D652C074652414D452E48
	?debug	C E96F5D652C0846434841494E2E48
	?debug	C E99D7BC32C074D4F44454D2E48
	?debug	C E96E5D652C06415554482E48
	?debug	C E949798E2C085343524950542E48
	?debug	C E90473BF2C054C43502E48
	?debug	C E90D7F8E2C06495043502E48
	?debug	C E9705D652C074652414D452E48
	?debug	C E96F5D652C0846434841494E2E48
	?debug	C E90473BF2C054C43502E48
	?debug	C E9725D652C06504452562E48
	?debug	C E90D7F8E2C06495043502E48
	?debug	C E9745D652C0754494D45522E48
	?debug	C E9705D652C05494E542E48
	?debug	C E900582F2D0A5050504C494E4B442E48
PPPLINKD_TEXT	segment byte public use16 'CODE'
PPPLINKD_TEXT	ends
DGROUP	group	_DATA,_BSS
	assume	cs:PPPLINKD_TEXT,ds:DGROUP
_DATA	segment word public use16 'DATA'
d@	label	byte
d@w	label	word
_DATA	ends
_BSS	segment word public use16 'BSS'
b@	label	byte
b@w	label	word
_BSS	ends
_DATA	segment word public use16 'DATA'
_PPPInterrupt	label	word
	db	0
	db	0
_PPPLoaded	label	word
	db	0
	db	0
_PPPSignature	label	byte
	db	80
	db	80
	db	80
	db	32
	db	68
	db	82
	db	86
	db	82
	db	0
	db	0
_DATA	ends
_BSS	segment word public use16 'BSS'
_pOpenScript	label	dword
	db	4 dup (?)
_pCloseScript	label	dword
	db	4 dup (?)
_BSS	ends
_DATA	segment word public use16 'DATA'
_ResponseLevel	label	word
	db	0
	db	0
_DATA	ends
PPPLINKD_TEXT	segment byte public use16 'CODE'
_$A	label	byte
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	58
	db	32
	db	80
	db	80
	db	80
	db	76
	db	111
	db	97
	db	100
	db	40
	db	41
	db	32
	db	45
	db	45
	db	32
	db	73
	db	110
	db	105
	db	116
	db	105
	db	97
	db	108
	db	105
	db	122
	db	105
	db	110
	db	103
	db	32
	db	80
	db	80
	db	80
	db	32
	db	73
	db	110
	db	116
	db	101
	db	114
	db	114
	db	117
	db	112
	db	116
	db	32
	db	86
	db	101
	db	99
	db	116
	db	111
	db	114
	db	32
	db	48
	db	120
	db	37
	db	88
	db	32
	db	40
	db	65
	db	100
	db	100
	db	114
	db	101
	db	115
	db	115
	db	32
	db	37
	db	48
	db	52
	db	88
	db	58
	db	37
	db	48
	db	52
	db	88
	db	41
	db	10
	db	0
PPPLINKD_TEXT	ends
_DATA	segment word public use16 'DATA'
_DATA	ends
PPPLINKD_TEXT	segment byte public use16 'CODE'
_$B	label	byte
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	58
	db	32
	db	80
	db	80
	db	80
	db	76
	db	111
	db	97
	db	100
	db	40
	db	41
	db	32
	db	45
	db	45
	db	32
	db	73
	db	110
	db	105
	db	116
	db	105
	db	97
	db	108
	db	105
	db	122
	db	101
	db	100
	db	32
	db	80
	db	80
	db	80
	db	32
	db	73
	db	110
	db	116
	db	101
	db	114
	db	114
	db	117
	db	112
	db	116
	db	32
	db	86
	db	101
	db	99
	db	116
	db	111
	db	114
	db	32
	db	48
	db	120
	db	37
	db	88
	db	10
	db	0
PPPLINKD_TEXT	ends
_DATA	segment word public use16 'DATA'
_DATA	ends
PPPLINKD_TEXT	segment byte public use16 'CODE'
_$C	label	byte
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	58
	db	32
	db	80
	db	80
	db	80
	db	76
	db	111
	db	97
	db	100
	db	40
	db	41
	db	32
	db	45
	db	45
	db	32
	db	77
	db	97
	db	116
	db	99
	db	104
	db	105
	db	110
	db	103
	db	32
	db	80
	db	80
	db	80
	db	32
	db	100
	db	101
	db	98
	db	117
	db	103
	db	32
	db	114
	db	101
	db	115
	db	112
	db	111
	db	110
	db	115
	db	101
	db	32
	db	108
	db	101
	db	118
	db	101
	db	108
	db	32
	db	37
	db	100
	db	10
	db	0
PPPLINKD_TEXT	ends
_DATA	segment word public use16 'DATA'
_DATA	ends
PPPLINKD_TEXT	segment byte public use16 'CODE'
_$D	label	byte
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	58
	db	32
	db	80
	db	80
	db	80
	db	76
	db	111
	db	97
	db	100
	db	40
	db	41
	db	32
	db	45
	db	45
	db	32
	db	78
	db	111
	db	32
	db	80
	db	80
	db	80
	db	32
	db	84
	db	83
	db	82
	db	32
	db	102
	db	111
	db	117
	db	110
	db	100
	db	44
	db	32
	db	108
	db	111
	db	97
	db	100
	db	105
	db	110
	db	103
	db	32
	db	105
	db	110
	db	116
	db	101
	db	114
	db	110
	db	97
	db	108
	db	32
	db	80
	db	80
	db	80
	db	46
	db	46
	db	46
	db	10
	db	0
PPPLINKD_TEXT	ends
_DATA	segment word public use16 'DATA'
_DATA	ends
PPPLINKD_TEXT	segment byte public use16 'CODE'
_$E	label	byte
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	58
	db	32
	db	80
	db	80
	db	80
	db	76
	db	111
	db	97
	db	100
	db	40
	db	41
	db	32
	db	45
	db	45
	db	32
	db	83
	db	101
	db	116
	db	32
	db	114
	db	101
	db	115
	db	112
	db	111
	db	110
	db	115
	db	101
	db	32
	db	108
	db	101
	db	118
	db	101
	db	108
	db	32
	db	37
	db	117
	db	10
	db	0
PPPLINKD_TEXT	ends
_DATA	segment word public use16 'DATA'
_DATA	ends
PPPLINKD_TEXT	segment byte public use16 'CODE'
_$F	label	byte
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	58
	db	32
	db	80
	db	80
	db	80
	db	76
	db	111
	db	97
	db	100
	db	40
	db	41
	db	32
	db	45
	db	45
	db	32
	db	83
	db	101
	db	116
	db	32
	db	116
	db	105
	db	109
	db	101
	db	111
	db	117
	db	116
	db	32
	db	37
	db	117
	db	10
	db	0
PPPLINKD_TEXT	ends
_DATA	segment word public use16 'DATA'
_DATA	ends
PPPLINKD_TEXT	segment byte public use16 'CODE'
_$G	label	byte
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	58
	db	32
	db	80
	db	80
	db	80
	db	76
	db	111
	db	97
	db	100
	db	40
	db	41
	db	32
	db	45
	db	45
	db	32
	db	78
	db	111
	db	116
	db	32
	db	97
	db	32
	db	118
	db	97
	db	108
	db	105
	db	100
	db	32
	db	112
	db	97
	db	99
	db	107
	db	101
	db	116
	db	32
	db	100
	db	114
	db	105
	db	118
	db	101
	db	114
	db	32
	db	105
	db	110
	db	116
	db	101
	db	114
	db	114
	db	117
	db	112
	db	116
	db	33
	db	10
	db	0
PPPLINKD_TEXT	ends
_DATA	segment word public use16 'DATA'
_DATA	ends
PPPLINKD_TEXT	segment byte public use16 'CODE'
_$H	label	byte
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	58
	db	32
	db	80
	db	80
	db	80
	db	76
	db	111
	db	97
	db	100
	db	40
	db	41
	db	32
	db	45
	db	45
	db	32
	db	73
	db	110
	db	118
	db	97
	db	108
	db	105
	db	100
	db	32
	db	104
	db	111
	db	111
	db	107
	db	32
	db	105
	db	110
	db	116
	db	101
	db	114
	db	114
	db	117
	db	112
	db	116
	db	33
	db	10
	db	0
PPPLINKD_TEXT	ends
_DATA	segment word public use16 'DATA'
_DATA	ends
PPPLINKD_TEXT	segment byte public use16 'CODE'
   ;	
   ;	unsigned int				PPPLoad(unsigned int Interrupt, unsigned char _PacketInterrupt, unsigned char _HookInterrupt, unsigned int _COMB
   ;	
	assume	cs:PPPLINKD_TEXT,ds:DGROUP
_PPPLoad	proc	far
	enter	10,0
	push	si
	push	di
   ;	
   ;	{
   ;		unsigned int Seg, Off, i, j, sig = 0;
   ;	
	mov	word ptr [bp-6],0
   ;	
   ;		Off = *(unsigned int far*)(MK_FP(0,Interrupt * 4));
   ;	
	mov	bx,word ptr [bp+6]
	shl	bx,2
	xor	ax,ax
	mov	es,ax
	mov	ax,word ptr es:[bx]
	mov	word ptr [bp-4],ax
   ;	
   ;		Seg = *(unsigned int far*)(MK_FP(0,(Interrupt * 4) + 2));
   ;	
	mov	bx,word ptr [bp+6]
	shl	bx,2
	xor	ax,ax
	mov	es,ax
	mov	ax,word ptr es:[bx+2]
	mov	word ptr [bp-2],ax
   ;	
   ;	
   ;		RESPONSE2(printf("PPPLIB: PPPLoad() -- Initializing PPP Interrupt Vector 0x%X (Address %04X:%04X)\n", Interrupt, Seg, Off));
   ;	
	cmp	word ptr DGROUP:_ResponseLevel,2
	jb	short @1@86
	push	word ptr [bp-4]
	push	ax
	push	word ptr [bp+6]
	push	cs
	push	offset _$A
	call	far ptr _printf
	add	sp,10
@1@86:
   ;	
   ;	
   ;		i = 0;
   ;	
	xor	cx,cx
	mov	ax,word ptr [bp-4]
	mov	word ptr [bp-10],ax
	jmp	short @1@422
@1@142:
   ;	
   ;		while ((sig == 0) && (i < 5))
   ;		{
   ;			j = 0;
   ;	
	xor	dx,dx
   ;	
   ;			sig = 1;
   ;	
	mov	word ptr [bp-6],1
	mov	ax,word ptr [bp-10]
	mov	word ptr [bp-8],ax
	jmp	short @1@310
@1@198:
   ;	
   ;			while ((sig == 1) && (j < 9))
   ;			{
   ;				if (((char far*)(MK_FP(Seg, (Off + i))))[j] != PPPSignature[j]) sig = 0;
   ;	
	mov	es,word ptr [bp-2]
	mov	bx,word ptr [bp-8]
	mov	al,byte ptr es:[bx]
	mov	bx,dx
	cmp	al,byte ptr DGROUP:_PPPSignature[bx]
	je	short @1@254
	mov	word ptr [bp-6],0
@1@254:
   ;	
   ;				j++;
   ;	
	inc	word ptr [bp-8]
	inc	dx
@1@310:
	cmp	word ptr [bp-6],1
	jne	short @1@366
	cmp	dx,9
	jb	short @1@198
@1@366:
   ;	
   ;			}
   ;			i++;
   ;	
	inc	word ptr [bp-10]
	inc	cx
@1@422:
	cmp	word ptr [bp-6],0
	jne	short @1@478
	cmp	cx,5
	jb	short @1@142
@1@478:
   ;	
   ;		}
   ;	
   ;		if (sig)
   ;	
	cmp	word ptr [bp-6],0
	je	short @1@534
   ;	
   ;		{
   ;	#ifdef RESP_LEVS
   ;			printf("PPPLIB: PPPLoad() -- Initialized PPP Interrupt Vector 0x%X\n", Interrupt);
   ;	
	push	word ptr [bp+6]
	push	cs
	push	offset _$B
	call	far ptr _printf
	add	sp,6
   ;	
   ;	#endif
   ;	
   ;			// Save the interrupt
   ;			PPPInterrupt = Interrupt;
   ;	
	mov	ax,word ptr [bp+6]
	mov	word ptr DGROUP:_PPPInterrupt,ax
   ;	
   ;	
   ;	#ifdef RESP_LEVS
   ;			ResponseLevel = PPPGetRespLevel();
   ;	
	call	far ptr _PPPGetRespLevel
	mov	word ptr DGROUP:_ResponseLevel,ax
   ;	
   ;			printf("PPPLIB: PPPLoad() -- Matching PPP debug response level %d\n", ResponseLevel);
   ;	
	push	ax
	push	cs
	push	offset _$C
	call	far ptr _printf
	add	sp,6
	jmp	@1@1206
@1@534:
   ;	
   ;	#endif
   ;	
   ;			// Return success
   ;			return 0;
   ;		}
   ;	
   ;		RESPONSE2(printf("PPPLIB: PPPLoad() -- No PPP TSR found, loading internal PPP...\n"));
   ;	
	cmp	word ptr DGROUP:_ResponseLevel,2
	jb	short @1@590
	push	cs
	push	offset _$D
	call	far ptr _printf
	add	sp,4
@1@590:
   ;	
   ;		PPPInterrupt = 0;
   ;	
	mov	word ptr DGROUP:_PPPInterrupt,0
   ;	
   ;	
   ;	#ifdef RESP_LEVS
   ;		ResponseLevel = _RespLev;
   ;	
	mov	ax,word ptr [bp+34]
	mov	word ptr DGROUP:_ResponseLevel,ax
   ;	
   ;		printf("PPPLIB: PPPLoad() -- Set response level %u\n", ResponseLevel);
   ;	
	push	ax
	push	cs
	push	offset _$E
	call	far ptr _printf
	add	sp,6
   ;	
   ;	#endif
   ;	
   ;		Timeout = _Timeout;
   ;	
	movzx	eax,word ptr [bp+32]
	mov	dword ptr DGROUP:_Timeout,eax
   ;	
   ;		RESPONSE2(printf("PPPLIB: PPPLoad() -- Set timeout %u\n", Timeout));
   ;	
	cmp	word ptr DGROUP:_ResponseLevel,2
	jb	short @1@646
	push	eax
	push	cs
	push	offset _$F
	call	far ptr _printf
	add	sp,8
@1@646:
   ;	
   ;	
   ;		if ((_PacketInterrupt > 0x80) || (_PacketInterrupt < 0x60))
   ;	
	cmp	byte ptr [bp+8],128
	ja	short @1@702
	cmp	byte ptr [bp+8],96
	jae	short @1@786
@1@702:
   ;	
   ;		{
   ;			RESPONSE2(printf("PPPLIB: PPPLoad() -- Not a valid packet driver interrupt!\n"));
   ;	
	cmp	word ptr DGROUP:_ResponseLevel,2
	jb	short @1@758
	push	cs
	push	offset _$G
	call	far ptr _printf
	add	sp,4
@1@758:
   ;	
   ;			return 2;
   ;	
	mov	ax,2
	jmp	@1@1234
@1@786:
   ;	
   ;		}
   ;		if (_HookInterrupt < 0x20)
   ;	
	cmp	byte ptr [bp+10],32
	jae	short @1@898
   ;	
   ;		{
   ;			RESPONSE2(printf("PPPLIB: PPPLoad() -- Invalid hook interrupt!\n"));
   ;	
	cmp	word ptr DGROUP:_ResponseLevel,2
	jb	short @1@870
	push	cs
	push	offset _$H
	call	far ptr _printf
	add	sp,4
@1@870:
   ;	
   ;			return 3;
   ;	
	mov	ax,3
	jmp	@1@1234
@1@898:
   ;	
   ;		}
   ;	
   ;		if (Script::Create(ScriptSize = _ScriptSize, NULLPOINTER, &pOpenScript) != 0)  return 4;
   ;	
	push	ds
	push	offset DGROUP:_pOpenScript
	push	large 0
	mov	ax,word ptr [bp+30]
	mov	word ptr DGROUP:_ScriptSize,ax
	push	ax
	call	far ptr @Script@Create$quinxcnn6Script
	add	sp,10
	or	ax,ax
	je	short @1@954
	mov	ax,4
	jmp	@1@1234
@1@954:
   ;	
   ;		if (Script::Create(ScriptSize, NULLPOINTER, &pCloseScript) != 0)
   ;	
	push	ds
	push	offset DGROUP:_pCloseScript
	push	large 0
	push	word ptr DGROUP:_ScriptSize
	call	far ptr @Script@Create$quinxcnn6Script
	add	sp,10
	or	ax,ax
	je	short @1@1010
   ;	
   ;		{
   ;			pOpenScript->Destroy();
   ;	
	push	dword ptr DGROUP:_pOpenScript
	call	far ptr @Script@Destroy$qv
	add	sp,4
   ;	
   ;			return 5;
   ;	
	mov	ax,5
	jmp	@1@1234
@1@1010:
   ;	
   ;		}
   ;	
   ;		// PacketInterrupt, HookInterrupt, COMBase, COMInt, Baud, WordSize, StopBits, Parity, FIFO, NumBuffers, ScriptSize, Timeout, Re
   ;		if (Modem_Create(_COMBase, _COMInt, _Baud, _WordSize, _StopBits, _Parity, _FIFO, 1, _NumBuffers) != 0)
   ;	
	push	word ptr [bp+28]
	push	1
	push	word ptr [bp+26]
	push	word ptr [bp+24]
	push	word ptr [bp+22]
	push	word ptr [bp+20]
	push	dword ptr [bp+16]
	push	word ptr [bp+14]
	push	word ptr [bp+12]
	call	far ptr @Modem_Create$quiuculucucucucucui
	add	sp,20
	or	ax,ax
	je	short @1@1066
   ;	
   ;		{
   ;			pCloseScript->Destroy();
   ;	
	push	dword ptr DGROUP:_pCloseScript
	call	far ptr @Script@Destroy$qv
	add	sp,4
   ;	
   ;			pOpenScript->Destroy();
   ;	
	push	dword ptr DGROUP:_pOpenScript
	call	far ptr @Script@Destroy$qv
	add	sp,4
   ;	
   ;			return 6;
   ;	
	mov	ax,6
	jmp	@1@1234
@1@1066:
   ;	
   ;		}
   ;		SetMRU(2000);
   ;	
	push	2000
	call	far ptr @SetMRU$qui
	pop	cx
   ;	
   ;	
   ;	   if (LCP_Create() != 0)
   ;	
	call	far ptr @LCP_Create$qv
	or	ax,ax
	je	short @1@1122
   ;	
   ;		{
   ;			Modem_Destroy();
   ;	
	call	far ptr @Modem_Destroy$qv
   ;	
   ;			pCloseScript->Destroy();
   ;	
	push	dword ptr DGROUP:_pCloseScript
	call	far ptr @Script@Destroy$qv
	add	sp,4
   ;	
   ;			pOpenScript->Destroy();
   ;	
	push	dword ptr DGROUP:_pOpenScript
	call	far ptr @Script@Destroy$qv
	add	sp,4
   ;	
   ;			return 7;
   ;	
	mov	ax,7
	jmp	short @1@1234
@1@1122:
   ;	
   ;		}
   ;	
   ;		if (IPCP_Create() != 0)
   ;	
	call	far ptr @IPCP_Create$qv
	or	ax,ax
	je	short @1@1178
   ;	
   ;		{
   ;			LCP_Destroy();
   ;	
	call	far ptr @LCP_Destroy$qv
   ;	
   ;			Modem_Destroy();
   ;	
	call	far ptr @Modem_Destroy$qv
   ;	
   ;			pCloseScript->Destroy();
   ;	
	push	dword ptr DGROUP:_pCloseScript
	call	far ptr @Script@Destroy$qv
	add	sp,4
   ;	
   ;			pOpenScript->Destroy();
   ;	
	push	dword ptr DGROUP:_pOpenScript
	call	far ptr @Script@Destroy$qv
	add	sp,4
   ;	
   ;			return 8;
   ;	
	mov	ax,8
	jmp	short @1@1234
@1@1178:
   ;	
   ;		}
   ;	
   ;		InstallPPPISR(PPPLoaded = _HookInterrupt);
   ;	
	mov	al,byte ptr [bp+10]
	mov	ah,0
	mov	word ptr DGROUP:_PPPLoaded,ax
	push	ax
	call	far ptr @InstallPPPISR$quc
	pop	cx
   ;	
   ;		InstallPacketISR(_PacketInterrupt);
   ;	
	push	word ptr [bp+8]
	call	far ptr @InstallPacketISR$quc
	pop	cx
@1@1206:
   ;	
   ;	
   ;		return 0;
   ;	
	xor	ax,ax
@1@1234:
   ;	
   ;	}
   ;	
	pop	di
	pop	si
	leave	
	ret	
_PPPLoad	endp
_$I	label	byte
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	58
	db	32
	db	80
	db	80
	db	80
	db	76
	db	111
	db	97
	db	100
	db	83
	db	99
	db	114
	db	105
	db	112
	db	116
	db	40
	db	41
	db	32
	db	45
	db	45
	db	32
	db	65
	db	116
	db	116
	db	101
	db	109
	db	112
	db	116
	db	105
	db	110
	db	103
	db	32
	db	116
	db	111
	db	32
	db	108
	db	111
	db	97
	db	100
	db	32
	db	115
	db	99
	db	114
	db	105
	db	112
	db	116
	db	32
	db	39
	db	37
	db	115
	db	39
	db	10
	db	0
_$J	label	byte
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	58
	db	32
	db	80
	db	80
	db	80
	db	76
	db	111
	db	97
	db	100
	db	83
	db	99
	db	114
	db	105
	db	112
	db	116
	db	40
	db	41
	db	32
	db	45
	db	45
	db	32
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	32
	db	119
	db	97
	db	115
	db	32
	db	110
	db	111
	db	116
	db	32
	db	105
	db	110
	db	105
	db	116
	db	105
	db	97
	db	108
	db	105
	db	122
	db	101
	db	100
	db	10
	db	0
_$K	label	byte
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	58
	db	32
	db	80
	db	80
	db	80
	db	76
	db	111
	db	97
	db	100
	db	83
	db	99
	db	114
	db	105
	db	112
	db	116
	db	40
	db	41
	db	32
	db	45
	db	45
	db	32
	db	77
	db	97
	db	120
	db	105
	db	109
	db	117
	db	109
	db	32
	db	115
	db	99
	db	114
	db	105
	db	112
	db	116
	db	32
	db	115
	db	105
	db	122
	db	101
	db	58
	db	32
	db	37
	db	100
	db	10
	db	0
_$L	label	byte
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	58
	db	32
	db	80
	db	80
	db	80
	db	76
	db	111
	db	97
	db	100
	db	83
	db	99
	db	114
	db	105
	db	112
	db	116
	db	40
	db	41
	db	32
	db	45
	db	45
	db	32
	db	77
	db	101
	db	109
	db	111
	db	114
	db	121
	db	32
	db	97
	db	108
	db	108
	db	111
	db	99
	db	97
	db	116
	db	105
	db	111
	db	110
	db	32
	db	102
	db	97
	db	105
	db	108
	db	101
	db	100
	db	10
	db	0
_$M	label	byte
	db	114
	db	116
	db	0
_$N	label	byte
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	58
	db	32
	db	80
	db	80
	db	80
	db	76
	db	111
	db	97
	db	100
	db	83
	db	99
	db	114
	db	105
	db	112
	db	116
	db	40
	db	41
	db	32
	db	45
	db	45
	db	32
	db	70
	db	97
	db	105
	db	108
	db	101
	db	100
	db	32
	db	116
	db	111
	db	32
	db	111
	db	112
	db	101
	db	110
	db	32
	db	116
	db	104
	db	101
	db	32
	db	115
	db	99
	db	114
	db	105
	db	112
	db	116
	db	32
	db	102
	db	105
	db	108
	db	101
	db	10
	db	0
_$O	label	byte
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	58
	db	32
	db	80
	db	80
	db	80
	db	76
	db	111
	db	97
	db	100
	db	83
	db	99
	db	114
	db	105
	db	112
	db	116
	db	40
	db	41
	db	32
	db	45
	db	45
	db	32
	db	76
	db	111
	db	97
	db	100
	db	105
	db	110
	db	103
	db	32
	db	115
	db	99
	db	114
	db	105
	db	112
	db	116
	db	32
	db	102
	db	114
	db	111
	db	109
	db	32
	db	102
	db	105
	db	108
	db	101
	db	58
	db	10
	db	0
_$P	label	byte
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	10
	db	0
_$Q	label	byte
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	45
	db	10
	db	0
   ;	
   ;	char* PPPLoadScript(char* FileName)
   ;	
	assume	cs:PPPLINKD_TEXT,ds:DGROUP
@PPPLoadScript$qnc	proc	far
	enter	32,0
	push	si
	push	di
   ;	
   ;	{
   ;		struct REGPACK Regs;
   ;		FILE *File;
   ;		char *Script, *rp;
   ;	
   ;		RESPONSE2(printf("PPPLIB: PPPLoadScript() -- Attempting to load script \'%s\'\n", FileName));
   ;	
	cmp	word ptr DGROUP:_ResponseLevel,2
	jb	short @2@86
	push	dword ptr [bp+6]
	push	cs
	push	offset _$I
	call	far ptr _printf
	add	sp,8
@2@86:
   ;	
   ;	
   ;		// Make sure someone called PPPInit first with a valid interrupt
   ;		if ((PPPInterrupt == 0) && (PPPLoaded == 0))
   ;	
	cmp	word ptr DGROUP:_PPPInterrupt,0
	jne	short @2@198
	cmp	word ptr DGROUP:_PPPLoaded,0
	jne	short @2@198
   ;	
   ;		{
   ;			RESPONSE1(printf("PPPLIB: PPPLoadScript() -- PPPLIB was not initialized\n"));
   ;	
	cmp	word ptr DGROUP:_ResponseLevel,1
	jb	@2@534
	push	cs
	push	offset _$J
	call	far ptr _printf
	add	sp,4
	jmp	@2@534
@2@198:
   ;	
   ;			return NULL;
   ;		}
   ;	
   ;		// We need to determine the maximum script size PPP will accept
   ;		// so that we can allocate memory approriately
   ;		if (PPPInterrupt != 0)
   ;	
	cmp	word ptr DGROUP:_PPPInterrupt,0
	je	short @2@254
   ;	
   ;		{
   ;			Regs.r_ax = 4;
   ;	
	mov	word ptr [bp-32],4
   ;	
   ;			intr(PPPInterrupt, &Regs);
   ;	
	push	ss
	lea	ax,word ptr [bp-32]
	push	ax
	push	word ptr DGROUP:_PPPInterrupt
	call	far ptr _intr
	add	sp,6
   ;	
   ;		}
   ;	
	jmp	short @2@282
@2@254:
   ;	
   ;		else Regs.r_ax = ScriptSize;
   ;	
	mov	ax,word ptr DGROUP:_ScriptSize
	mov	word ptr [bp-32],ax
@2@282:
   ;	
   ;	
   ;		RESPONSE3(printf("PPPLIB: PPPLoadScript() -- Maximum script size: %d\n", Regs.r_ax));
   ;	
	cmp	word ptr DGROUP:_ResponseLevel,3
	jb	short @2@338
	push	word ptr [bp-32]
	push	cs
	push	offset _$K
	call	far ptr _printf
	add	sp,6
@2@338:
   ;	
   ;		rp = Script = new char[Regs.r_ax];
   ;	
	push	word ptr [bp-32]
	call	far ptr @$bnwa$qui
	pop	cx
	mov	word ptr [bp-6],dx
	mov	word ptr [bp-8],ax
	mov	word ptr [bp-10],dx
	mov	word ptr [bp-12],ax
   ;	
   ;	
   ;		if (Script == NULL)
   ;	
	cmp	dword ptr [bp-8],large 0
	jne	short @2@422
   ;	
   ;		{
   ;			RESPONSE1(printf("PPPLIB: PPPLoadScript() -- Memory allocation failed\n"));
   ;	
	cmp	word ptr DGROUP:_ResponseLevel,1
	jb	short @2@534
	push	cs
	push	offset _$L
	call	far ptr _printf
	add	sp,4
	jmp	short @2@534
@2@422:
   ;	
   ;			return NULL;
   ;		}
   ;	
   ;		// Open the requested script file
   ;		if ((File = fopen(FileName, "rt")) == NULL)
   ;	
	push	cs
	push	offset _$M
	push	dword ptr [bp+6]
	call	far ptr _fopen
	add	sp,8
	mov	word ptr [bp-2],dx
	mov	word ptr [bp-4],ax
	or	ax,dx
	jne	short @2@562
   ;	
   ;		{
   ;			RESPONSE1(printf("PPPLIB: PPPLoadScript() -- Failed to open the script file\n"));
   ;	
	cmp	word ptr DGROUP:_ResponseLevel,1
	jb	short @2@506
	push	cs
	push	offset _$N
	call	far ptr _printf
	add	sp,4
@2@506:
   ;	
   ;	
   ;			// The call the fopen() failed so we need to free the allocated memory
   ;			PPPFreeScript(Script);
   ;	
	push	dword ptr [bp-8]
	call	far ptr @PPPFreeScript$qnc
	add	sp,4
   ;	
   ;			// and return failure
   ;			return NULL;
   ;	
@2@534:
	xor	dx,dx
	xor	ax,ax
	jmp	@2@898
@2@562:
   ;	
   ;		}
   ;	
   ;	#ifdef RESP_LEVS
   ;		if (ResponseLevel >= 4)
   ;	
	cmp	word ptr DGROUP:_ResponseLevel,4
	jb	@2@814
   ;	
   ;		{
   ;			printf("PPPLIB: PPPLoadScript() -- Loading script from file:\n");
   ;	
	push	cs
	push	offset _$O
	call	far ptr _printf
	add	sp,4
   ;	
   ;			printf("-------------------------------------\n");
   ;	
	push	cs
	push	offset _$P
	call	far ptr _printf
	add	sp,4
	jmp	short @2@702
@2@618:
   ;	
   ;	
   ;	   	// Simple loop to read the contents of the file into the allocated memory
   ;			while ((!feof(File)) && ((rp - Script) < (Regs.r_ax - 1)))
   ;			{
   ;				// Dump the script to the screen while reading it
   ;				putchar((*(rp++)) = fgetc(File));
   ;	
	inc	word ptr DGROUP:__streams+20
	jge	short @2@674
	push	dword ptr [bp-4]
	call	far ptr _fgetc
	add	sp,4
	les	bx,dword ptr [bp-12]
	inc	word ptr [bp-12]
	mov	byte ptr es:[bx],al
	les	bx,dword ptr DGROUP:__streams+32
	inc	word ptr DGROUP:__streams+32
	mov	byte ptr es:[bx],al
	mov	ah,0
	jmp	short @2@702
@2@674:
	push	ds
	push	offset DGROUP:__streams+20
	push	dword ptr [bp-4]
	call	far ptr _fgetc
	add	sp,4
	les	bx,dword ptr [bp-12]
	inc	word ptr [bp-12]
	mov	byte ptr es:[bx],al
	push	ax
	call	far ptr __fputc
	add	sp,6
@2@702:
	les	bx,dword ptr [bp-4]
	test	byte ptr es:[bx+2],32
	jne	short @2@758
	mov	ax,word ptr [bp-32]
	dec	ax
	movzx	eax,ax
	mov	dx,word ptr [bp-12]
	xor	bx,bx
	sub	dx,word ptr [bp-8]
	sbb	bx,0
	push	bx
	push	dx
	pop	edx
	cmp	eax,edx
	jg	short @2@618
@2@758:
   ;	
   ;			}
   ;	
   ;			printf("-------------------------------------\n");
   ;	
	push	cs
	push	offset _$Q
	call	far ptr _printf
	add	sp,4
   ;	
   ;		}
   ;	
	jmp	short @2@870
@2@786:
   ;	
   ;		else
   ;		{
   ;	#endif
   ;			// Simple loop to read the contents of the file into the allocated memory
   ;			while ((!feof(File)) && ((rp - Script) < (Regs.r_ax - 1)))
   ;				(*(rp++)) = fgetc(File);
   ;	
	push	dword ptr [bp-4]
	call	far ptr _fgetc
	add	sp,4
	les	bx,dword ptr [bp-12]
	mov	byte ptr es:[bx],al
	inc	word ptr [bp-12]
@2@814:
	les	bx,dword ptr [bp-4]
	test	byte ptr es:[bx+2],32
	jne	short @2@870
	mov	ax,word ptr [bp-32]
	dec	ax
	movzx	eax,ax
	mov	dx,word ptr [bp-12]
	xor	bx,bx
	sub	dx,word ptr [bp-8]
	sbb	bx,0
	push	bx
	push	dx
	pop	edx
	cmp	eax,edx
	jg	short @2@786
@2@870:
   ;	
   ;	#ifdef RESP_LEVS
   ;		}
   ;	#endif
   ;	
   ;		// Terminate the memory buffer will a null character
   ;		(*rp) = 0;
   ;	
	les	bx,dword ptr [bp-12]
	mov	byte ptr es:[bx],0
   ;	
   ;	
   ;		// Close the file, since we are done with it
   ;		fclose(File);
   ;	
	push	dword ptr [bp-4]
	call	far ptr _fclose
	add	sp,4
   ;	
   ;	
   ;		// Return the allocated block of memory with the script loaded into it
   ;		return Script;
   ;	
	mov	dx,word ptr [bp-6]
	mov	ax,word ptr [bp-8]
@2@898:
   ;	
   ;	}
   ;	
	pop	di
	pop	si
	leave	
	ret	
@PPPLoadScript$qnc	endp
   ;	
   ;	void PPPFreeScript(char* Script)
   ;	
	assume	cs:PPPLINKD_TEXT,ds:DGROUP
@PPPFreeScript$qnc	proc	far
	push	bp
	mov	bp,sp
	push	si
	push	di
   ;	
   ;	{
   ;		// All we have to do is free the memory, but we need to use the right method
   ;		// to correspond to how it was allocated
   ;		delete Script;
   ;	
	push	dword ptr [bp+6]
	call	far ptr @$bdele$qnv
	add	sp,4
   ;	
   ;	}
   ;	
	pop	di
	pop	si
	pop	bp
	ret	
@PPPFreeScript$qnc	endp
_$R	label	byte
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	58
	db	32
	db	80
	db	80
	db	80
	db	79
	db	112
	db	101
	db	110
	db	40
	db	41
	db	32
	db	45
	db	45
	db	32
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	32
	db	119
	db	97
	db	115
	db	32
	db	110
	db	111
	db	116
	db	32
	db	105
	db	110
	db	105
	db	116
	db	105
	db	97
	db	108
	db	105
	db	122
	db	101
	db	100
	db	10
	db	0
_$S	label	byte
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	58
	db	32
	db	80
	db	80
	db	80
	db	79
	db	112
	db	101
	db	110
	db	40
	db	41
	db	32
	db	45
	db	45
	db	32
	db	79
	db	112
	db	101
	db	110
	db	83
	db	99
	db	114
	db	105
	db	112
	db	116
	db	91
	db	48
	db	93
	db	32
	db	33
	db	61
	db	32
	db	39
	db	64
	db	39
	db	32
	db	65
	db	115
	db	115
	db	117
	db	109
	db	105
	db	110
	db	103
	db	32
	db	115
	db	99
	db	114
	db	105
	db	112
	db	116
	db	32
	db	102
	db	105
	db	108
	db	101
	db	32
	db	110
	db	97
	db	109
	db	101
	db	10
	db	0
_$T	label	byte
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	58
	db	32
	db	80
	db	80
	db	80
	db	79
	db	112
	db	101
	db	110
	db	40
	db	41
	db	32
	db	45
	db	45
	db	32
	db	70
	db	97
	db	105
	db	108
	db	101
	db	100
	db	32
	db	116
	db	111
	db	32
	db	108
	db	111
	db	97
	db	100
	db	32
	db	79
	db	112
	db	101
	db	110
	db	83
	db	99
	db	114
	db	105
	db	112
	db	116
	db	32
	db	102
	db	114
	db	111
	db	109
	db	32
	db	100
	db	105
	db	115
	db	107
	db	10
	db	0
_$U	label	byte
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	58
	db	32
	db	80
	db	80
	db	80
	db	79
	db	112
	db	101
	db	110
	db	40
	db	41
	db	32
	db	45
	db	45
	db	32
	db	67
	db	108
	db	111
	db	115
	db	101
	db	83
	db	99
	db	114
	db	105
	db	112
	db	116
	db	91
	db	48
	db	93
	db	32
	db	33
	db	61
	db	32
	db	39
	db	64
	db	39
	db	32
	db	65
	db	115
	db	115
	db	117
	db	109
	db	105
	db	110
	db	103
	db	32
	db	115
	db	99
	db	114
	db	105
	db	112
	db	116
	db	32
	db	102
	db	105
	db	108
	db	101
	db	32
	db	110
	db	97
	db	109
	db	101
	db	10
	db	0
_$V	label	byte
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	58
	db	32
	db	80
	db	80
	db	80
	db	79
	db	112
	db	101
	db	110
	db	40
	db	41
	db	32
	db	45
	db	45
	db	32
	db	70
	db	97
	db	105
	db	108
	db	101
	db	100
	db	32
	db	116
	db	111
	db	32
	db	108
	db	111
	db	97
	db	100
	db	32
	db	67
	db	108
	db	111
	db	115
	db	101
	db	83
	db	99
	db	114
	db	105
	db	112
	db	116
	db	32
	db	102
	db	114
	db	111
	db	109
	db	32
	db	100
	db	105
	db	115
	db	107
	db	10
	db	0
_$W	label	byte
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	58
	db	32
	db	80
	db	80
	db	80
	db	79
	db	112
	db	101
	db	110
	db	40
	db	41
	db	32
	db	45
	db	45
	db	32
	db	79
	db	112
	db	101
	db	110
	db	83
	db	99
	db	114
	db	105
	db	112
	db	116
	db	32
	db	61
	db	32
	db	65
	db	100
	db	100
	db	114
	db	101
	db	115
	db	115
	db	32
	db	37
	db	48
	db	52
	db	88
	db	58
	db	37
	db	48
	db	52
	db	88
	db	10
	db	0
_$X	label	byte
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	58
	db	32
	db	80
	db	80
	db	80
	db	79
	db	112
	db	101
	db	110
	db	40
	db	41
	db	32
	db	45
	db	45
	db	32
	db	67
	db	108
	db	111
	db	115
	db	101
	db	83
	db	99
	db	114
	db	105
	db	112
	db	116
	db	32
	db	61
	db	32
	db	65
	db	100
	db	100
	db	114
	db	101
	db	115
	db	115
	db	32
	db	37
	db	48
	db	52
	db	88
	db	58
	db	37
	db	48
	db	52
	db	88
	db	10
	db	0
_$Y	label	byte
	db	72
	db	101
	db	108
	db	108
	db	111
	db	46
	db	46
	db	46
	db	32
	db	37
	db	117
	db	32
	db	48
	db	120
	db	37
	db	48
	db	56
	db	108
	db	88
	db	10
	db	0
_$Z	label	byte
	db	87
	db	111
	db	114
	db	108
	db	100
	db	46
	db	46
	db	46
	db	10
	db	0
_$AB	label	byte
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	58
	db	32
	db	80
	db	80
	db	80
	db	79
	db	112
	db	101
	db	110
	db	40
	db	41
	db	32
	db	45
	db	45
	db	32
	db	87
	db	97
	db	105
	db	116
	db	105
	db	110
	db	103
	db	32
	db	102
	db	111
	db	114
	db	32
	db	99
	db	111
	db	110
	db	110
	db	101
	db	99
	db	116
	db	105
	db	111
	db	110
	db	32
	db	115
	db	117
	db	99
	db	99
	db	101
	db	115
	db	115
	db	32
	db	111
	db	114
	db	32
	db	102
	db	97
	db	105
	db	108
	db	117
	db	114
	db	101
	db	10
	db	0
_$BB	label	byte
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	58
	db	32
	db	80
	db	80
	db	80
	db	79
	db	112
	db	101
	db	110
	db	40
	db	41
	db	32
	db	45
	db	45
	db	32
	db	67
	db	111
	db	110
	db	110
	db	101
	db	99
	db	116
	db	105
	db	111
	db	110
	db	32
	db	102
	db	97
	db	105
	db	108
	db	101
	db	100
	db	32
	db	119
	db	104
	db	105
	db	108
	db	101
	db	32
	db	119
	db	97
	db	105
	db	116
	db	105
	db	110
	db	103
	db	10
	db	0
_$CB	label	byte
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	58
	db	32
	db	80
	db	80
	db	80
	db	79
	db	112
	db	101
	db	110
	db	40
	db	41
	db	32
	db	45
	db	45
	db	32
	db	67
	db	111
	db	110
	db	110
	db	101
	db	99
	db	116
	db	105
	db	111
	db	110
	db	32
	db	102
	db	97
	db	105
	db	108
	db	101
	db	100
	db	32
	db	105
	db	109
	db	109
	db	101
	db	100
	db	105
	db	97
	db	116
	db	101
	db	108
	db	121
	db	10
	db	0
   ;	
   ;	unsigned int /*_loadds*/ PPPOpen(char* OpenScript, char* CloseScript, int WaitForConnect)
   ;	
	assume	cs:PPPLINKD_TEXT,ds:DGROUP
_PPPOpen	proc	far
	enter	24,0
	push	si
	push	di
   ;	
   ;	{
   ;		struct REGPACK Regs;
   ;		int LOpen = 0, LClose = 0;
   ;	
	mov	word ptr [bp-2],0
	mov	word ptr [bp-4],0
   ;	
   ;	
   ;		// Make sure someone called PPPInit first with a valid interrupt
   ;		if ((PPPInterrupt == 0) && (PPPLoaded == 0))
   ;	
	cmp	word ptr DGROUP:_PPPInterrupt,0
	jne	short @4@170
	cmp	word ptr DGROUP:_PPPLoaded,0
	jne	short @4@170
   ;	
   ;		{
   ;			RESPONSE1(printf("PPPLIB: PPPOpen() -- PPPLIB was not initialized\n"));
   ;	
	cmp	word ptr DGROUP:_ResponseLevel,1
	jb	short @4@142
	push	cs
	push	offset _$R
	call	far ptr _printf
	add	sp,4
@4@142:
   ;	
   ;			return 0x8FFD;
   ;	
	mov	ax,08FFDh
	jmp	@4@1710
@4@170:
   ;	
   ;		}
   ;	
   ;		// If we were passed a string that did not begin with @ then it's a file name
   ;		if (OpenScript && (OpenScript[0] != '@'))
   ;	
	cmp	dword ptr [bp+6],large 0
	je	short @4@422
	les	bx,dword ptr [bp+6]
	mov	al,byte ptr es:[bx]
	cbw	
	cmp	ax,64
	je	short @4@422
   ;	
   ;		{
   ;			RESPONSE2(printf("PPPLIB: PPPOpen() -- OpenScript[0] != \'@\' Assuming script file name\n"));
   ;	
	cmp	word ptr DGROUP:_ResponseLevel,2
	jb	short @4@282
	push	cs
	push	offset _$S
	call	far ptr _printf
	add	sp,4
@4@282:
   ;	
   ;	
   ;			// Load the open script using the file name we were given
   ;			OpenScript = PPPLoadScript(OpenScript);
   ;	
	push	dword ptr [bp+6]
	push	cs
	call	near ptr @PPPLoadScript$qnc
	add	sp,4
	mov	word ptr [bp+8],dx
	mov	word ptr [bp+6],ax
   ;	
   ;			// If we failed to load the script then return an error
   ;			if (!OpenScript)
   ;	
	cmp	dword ptr [bp+6],large 0
	jne	short @4@394
   ;	
   ;			{
   ;				RESPONSE1(printf("PPPLIB: PPPOpen() -- Failed to load OpenScript from disk\n"));
   ;	
	cmp	word ptr DGROUP:_ResponseLevel,1
	jb	short @4@366
	push	cs
	push	offset _$T
	call	far ptr _printf
	add	sp,4
@4@366:
   ;	
   ;				return 0x8FFF;
   ;	
	mov	ax,08FFFh
	jmp	@4@1710
@4@394:
   ;	
   ;			}
   ;			// Flag the fact that we loaded a script (to free the memory later)
   ;			LOpen = 1;
   ;	
	mov	word ptr [bp-2],1
@4@422:
   ;	
   ;		}
   ;	
   ;		// If we were passed a string that did not begin with @ then it's a file name
   ;		if (CloseScript && (CloseScript[0] != '@'))
   ;	
	cmp	dword ptr [bp+10],large 0
	je	short @4@730
	les	bx,dword ptr [bp+10]
	mov	al,byte ptr es:[bx]
	cbw	
	cmp	ax,64
	je	short @4@730
   ;	
   ;		{
   ;			RESPONSE2(printf("PPPLIB: PPPOpen() -- CloseScript[0] != \'@\' Assuming script file name\n"));
   ;	
	cmp	word ptr DGROUP:_ResponseLevel,2
	jb	short @4@534
	push	cs
	push	offset _$U
	call	far ptr _printf
	add	sp,4
@4@534:
   ;	
   ;	
   ;			// Load the close script using the file name we were given
   ;			CloseScript = PPPLoadScript(CloseScript);
   ;	
	push	dword ptr [bp+10]
	push	cs
	call	near ptr @PPPLoadScript$qnc
	add	sp,4
	mov	word ptr [bp+12],dx
	mov	word ptr [bp+10],ax
   ;	
   ;	      // If we failed to load the script then return an error
   ;			if (!CloseScript)
   ;	
	cmp	dword ptr [bp+10],large 0
	jne	short @4@702
   ;	
   ;			{
   ;				RESPONSE1(printf("PPPLIB: PPPOpen() -- Failed to load CloseScript from disk\n"));
   ;	
	cmp	word ptr DGROUP:_ResponseLevel,1
	jb	short @4@618
	push	cs
	push	offset _$V
	call	far ptr _printf
	add	sp,4
@4@618:
   ;	
   ;				// Free the open script if we loaded it
   ;				if (LOpen) PPPFreeScript(OpenScript);
   ;	
	cmp	word ptr [bp-2],0
	je	short @4@674
	push	dword ptr [bp+6]
	push	cs
	call	near ptr @PPPFreeScript$qnc
	add	sp,4
@4@674:
   ;	
   ;				return 0x8FFE;
   ;	
	mov	ax,08FFEh
	jmp	@4@1710
@4@702:
   ;	
   ;			}
   ;			// Flag the fact that we loaded a script (to free the memory later)
   ;			LClose = 1;
   ;	
	mov	word ptr [bp-4],1
@4@730:
   ;	
   ;		}
   ;	
   ;		// AX contains the function code
   ;		// The function code for 'open' is 1
   ;		Regs.r_ax = 1;
   ;	
	mov	word ptr [bp-24],1
   ;	
   ;	
   ;		// Convert the pointers to the scripts to far pointers and load them into the
   ;		// appropriate registers for the ISR
   ;		if (OpenScript != 0)
   ;	
	cmp	dword ptr [bp+6],large 0
	je	short @4@814
   ;	
   ;		{
   ;			Regs.r_ds = FP_SEG((char far*)OpenScript);
   ;	
	mov	ax,word ptr [bp+8]
	mov	word ptr [bp-10],ax
   ;	
   ;			Regs.r_si = FP_OFF((char far*)OpenScript);
   ;	
	mov	ax,word ptr [bp+6]
	mov	word ptr [bp-14],ax
   ;	
   ;	
   ;			RESPONSE3(printf("PPPLIB: PPPOpen() -- OpenScript = Address %04X:%04X\n", Regs.r_ds, Regs.r_si));
   ;	
	cmp	word ptr DGROUP:_ResponseLevel,3
	jb	short @4@842
	push	ax
	push	word ptr [bp+8]
	push	cs
	push	offset _$W
	call	far ptr _printf
	add	sp,8
	jmp	short @4@842
@4@814:
   ;	
   ;		}
   ;		else Regs.r_ds = Regs.r_si = 0;
   ;	
	xor	ax,ax
	mov	word ptr [bp-14],ax
	mov	word ptr [bp-10],ax
@4@842:
   ;	
   ;		if (CloseScript != 0)
   ;	
	cmp	dword ptr [bp+10],large 0
	je	short @4@926
   ;	
   ;		{
   ;			Regs.r_es = FP_SEG((char far*)CloseScript);
   ;	
	mov	ax,word ptr [bp+12]
	mov	word ptr [bp-8],ax
   ;	
   ;			Regs.r_di = FP_OFF((char far*)CloseScript);
   ;	
	mov	ax,word ptr [bp+10]
	mov	word ptr [bp-12],ax
   ;	
   ;	
   ;			RESPONSE3(printf("PPPLIB: PPPOpen() -- CloseScript = Address %04X:%04X\n", Regs.r_es, Regs.r_di));
   ;	
	cmp	word ptr DGROUP:_ResponseLevel,3
	jb	short @4@954
	push	ax
	push	word ptr [bp+12]
	push	cs
	push	offset _$X
	call	far ptr _printf
	add	sp,8
	jmp	short @4@954
@4@926:
   ;	
   ;		}
   ;		else Regs.r_es = Regs.r_di = 0;
   ;	
	xor	ax,ax
	mov	word ptr [bp-12],ax
	mov	word ptr [bp-8],ax
@4@954:
   ;	
   ;	
   ;		printf("Hello... %u 0x%08lX\n", (WORD)(PPPInterrupt ? PPPInterrupt : PPPLoaded), (void far*)&RetRegs2);
   ;	
	push	ds
	push	offset DGROUP:_RetRegs2
	cmp	word ptr DGROUP:_PPPInterrupt,0
	je	short @4@1010
	mov	ax,word ptr DGROUP:_PPPInterrupt
	jmp	short @4@1038
@4@1010:
	mov	ax,word ptr DGROUP:_PPPLoaded
@4@1038:
	push	ax
	push	cs
	push	offset _$Y
	call	far ptr _printf
	add	sp,10
@4@1066:
   ;	
   ;	
   ;		while (1)
   ;		{
   ;			if (kbhit()) if (getch() == 'Q') break;
   ;	
	call	far ptr _kbhit
	or	ax,ax
	je	short @4@1066
	call	far ptr _getch
	cmp	ax,81
	jne	short @4@1066
   ;	
   ;		}
   ;	
   ;		// Call the ISR with the register structure set up above
   ;		intr((PPPInterrupt ? PPPInterrupt : PPPLoaded), &Regs);
   ;	
	push	ss
	lea	ax,word ptr [bp-24]
	push	ax
	cmp	word ptr DGROUP:_PPPInterrupt,0
	je	short @4@1178
	mov	ax,word ptr DGROUP:_PPPInterrupt
	jmp	short @4@1206
@4@1178:
	mov	ax,word ptr DGROUP:_PPPLoaded
@4@1206:
	push	ax
	call	far ptr _intr
	add	sp,6
   ;	
   ;	
   ;		printf("World...\n");
   ;	
	push	cs
	push	offset _$Z
	call	far ptr _printf
	add	sp,4
   ;	
   ;	
   ;		// Free the scripts that we loaded from disk (to prevent memory leaks)
   ;		if (LClose) PPPFreeScript(CloseScript);
   ;	
	cmp	word ptr [bp-4],0
	je	short @4@1262
	push	dword ptr [bp+10]
	push	cs
	call	near ptr @PPPFreeScript$qnc
	add	sp,4
@4@1262:
   ;	
   ;		if (LOpen) PPPFreeScript(OpenScript);
   ;	
	cmp	word ptr [bp-2],0
	je	short @4@1318
	push	dword ptr [bp+6]
	push	cs
	call	near ptr @PPPFreeScript$qnc
	add	sp,4
@4@1318:
   ;	
   ;	
   ;		// If the call was successful and we are supposed to wait for a complete
   ;		// connection
   ;		if ((Regs.r_ax == 0) && WaitForConnect)
   ;	
	cmp	word ptr [bp-24],0
	jne	short @4@1598
	cmp	word ptr [bp+14],0
	je	short @4@1598
   ;	
   ;		{
   ;			RESPONSE2(printf("PPPLIB: PPPOpen() -- Waiting for connection success or failure\n"));
   ;	
	cmp	word ptr DGROUP:_ResponseLevel,2
	jb	short @4@1430
	push	cs
	push	offset _$AB
	call	far ptr _printf
	add	sp,4
@4@1430:
   ;	
   ;			// While PPP is neither fully open nor closed, just loop
   ;			while(!PPPISOPEN(PPPStatus()) && !PPPISCLOSED(PPPStatus())) { }
   ;	
	call	far ptr _PPPStatus
	shr	ax,10
	and	ax,31
	cmp	ax,3
	je	short @4@1486
	call	far ptr _PPPStatus
	shr	ax,10
	and	ax,31
	cmp	ax,6
	jne	short @4@1430
@4@1486:
   ;	
   ;			// If the connection failed after some time then return an error
   ;			if (PPPISCLOSED(PPPStatus()))
   ;	
	call	far ptr _PPPStatus
	shr	ax,10
	and	ax,31
	cmp	ax,6
	jne	short @4@1598
   ;	
   ;			{
   ;				RESPONSE1(printf("PPPLIB: PPPOpen() -- Connection failed while waiting\n"));
   ;	
	cmp	word ptr DGROUP:_ResponseLevel,1
	jb	short @4@1570
	push	cs
	push	offset _$BB
	call	far ptr _printf
	add	sp,4
@4@1570:
   ;	
   ;				return 0x8FFC;
   ;	
	mov	ax,08FFCh
	jmp	short @4@1710
@4@1598:
   ;	
   ;			}
   ;		}
   ;	
   ;	#ifdef RESP_LEVS
   ;		if ((ResponseLevel >= 1) && (Regs.r_ax != 0))
   ;	
	cmp	word ptr DGROUP:_ResponseLevel,1
	jb	short @4@1682
	cmp	word ptr [bp-24],0
	je	short @4@1682
   ;	
   ;			printf("PPPLIB: PPPOpen() -- Connection failed immediately\n");
   ;	
	push	cs
	push	offset _$CB
	call	far ptr _printf
	add	sp,4
@4@1682:
   ;	
   ;	#endif
   ;	
   ;		// The ISR returns a status code in AX
   ;		// 0 means success, anything else means failure
   ;		return Regs.r_ax;
   ;	
	mov	ax,word ptr [bp-24]
@4@1710:
   ;	
   ;	}
   ;	
	pop	di
	pop	si
	leave	
	ret	
_PPPOpen	endp
_$DB	label	byte
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	58
	db	32
	db	80
	db	80
	db	80
	db	67
	db	108
	db	111
	db	115
	db	101
	db	40
	db	41
	db	32
	db	45
	db	45
	db	32
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	32
	db	119
	db	97
	db	115
	db	32
	db	110
	db	111
	db	116
	db	32
	db	105
	db	110
	db	105
	db	116
	db	105
	db	97
	db	108
	db	105
	db	122
	db	101
	db	100
	db	10
	db	0
_$EB	label	byte
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	58
	db	32
	db	80
	db	80
	db	80
	db	67
	db	108
	db	111
	db	115
	db	101
	db	40
	db	41
	db	32
	db	45
	db	45
	db	32
	db	67
	db	111
	db	110
	db	110
	db	101
	db	99
	db	116
	db	105
	db	111
	db	110
	db	32
	db	99
	db	111
	db	117
	db	108
	db	100
	db	32
	db	110
	db	111
	db	116
	db	32
	db	98
	db	101
	db	32
	db	99
	db	108
	db	111
	db	115
	db	101
	db	100
	db	32
	db	40
	db	80
	db	80
	db	80
	db	32
	db	105
	db	115
	db	32
	db	114
	db	101
	db	115
	db	101
	db	116
	db	41
	db	10
	db	0
   ;	
   ;	unsigned int PPPClose(void)
   ;	
	assume	cs:PPPLINKD_TEXT,ds:DGROUP
_PPPClose	proc	far
	enter	20,0
	push	si
	push	di
   ;	
   ;	{
   ;		struct REGPACK Regs;
   ;	
   ;		// Make sure someone called PPPInit first with a valid interrupt
   ;		if ((PPPInterrupt == 0) && (PPPLoaded == 0))
   ;	
	cmp	word ptr DGROUP:_PPPInterrupt,0
	jne	short @5@170
	cmp	word ptr DGROUP:_PPPLoaded,0
	jne	short @5@170
   ;	
   ;		{
   ;			RESPONSE1(printf("PPPLIB: PPPClose() -- PPPLIB was not initialized\n"));
   ;	
	cmp	word ptr DGROUP:_ResponseLevel,1
	jb	short @5@142
	push	cs
	push	offset _$DB
	call	far ptr _printf
	add	sp,4
@5@142:
   ;	
   ;			return 0x8FFD;
   ;	
	mov	ax,08FFDh
	jmp	short @5@366
@5@170:
   ;	
   ;		}
   ;	
   ;		// AX contains the function code
   ;		// The function code for 'close' is 2
   ;		Regs.r_ax = 2;
   ;	
	mov	word ptr [bp-20],2
   ;	
   ;		intr((PPPInterrupt ? PPPInterrupt : PPPLoaded), &Regs);
   ;	
	push	ss
	lea	ax,word ptr [bp-20]
	push	ax
	cmp	word ptr DGROUP:_PPPInterrupt,0
	je	short @5@226
	mov	ax,word ptr DGROUP:_PPPInterrupt
	jmp	short @5@254
@5@226:
	mov	ax,word ptr DGROUP:_PPPLoaded
@5@254:
	push	ax
	call	far ptr _intr
	add	sp,6
   ;	
   ;	
   ;	#ifdef RESP_LEVS
   ;		if ((ResponseLevel >= 1) && (Regs.r_ax != 0))
   ;	
	cmp	word ptr DGROUP:_ResponseLevel,1
	jb	short @5@338
	cmp	word ptr [bp-20],0
	je	short @5@338
   ;	
   ;			printf("PPPLIB: PPPClose() -- Connection could not be closed (PPP is reset)\n");
   ;	
	push	cs
	push	offset _$EB
	call	far ptr _printf
	add	sp,4
@5@338:
   ;	
   ;	#endif
   ;	
   ;		// The ISR returns a status code in AX
   ;		// 0 means success, anything else means failure
   ;		return Regs.r_ax;
   ;	
	mov	ax,word ptr [bp-20]
@5@366:
   ;	
   ;	}
   ;	
	pop	di
	pop	si
	leave	
	ret	
_PPPClose	endp
_$FB	label	byte
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	58
	db	32
	db	80
	db	80
	db	80
	db	83
	db	116
	db	97
	db	116
	db	117
	db	115
	db	40
	db	41
	db	32
	db	45
	db	45
	db	32
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	32
	db	119
	db	97
	db	115
	db	32
	db	110
	db	111
	db	116
	db	32
	db	105
	db	110
	db	105
	db	116
	db	105
	db	97
	db	108
	db	105
	db	122
	db	101
	db	100
	db	10
	db	0
   ;	
   ;	unsigned int PPPStatus(void)
   ;	
	assume	cs:PPPLINKD_TEXT,ds:DGROUP
_PPPStatus	proc	far
	enter	20,0
	push	si
	push	di
   ;	
   ;	{
   ;		struct REGPACK Regs;
   ;	
   ;		// Make sure someone called PPPInit first with a valid interrupt
   ;		if ((PPPInterrupt == 0) && (PPPLoaded == 0))
   ;	
	cmp	word ptr DGROUP:_PPPInterrupt,0
	jne	short @6@170
	cmp	word ptr DGROUP:_PPPLoaded,0
	jne	short @6@170
   ;	
   ;		{
   ;			RESPONSE1(printf("PPPLIB: PPPStatus() -- PPPLIB was not initialized\n"));
   ;	
	cmp	word ptr DGROUP:_ResponseLevel,1
	jb	short @6@142
	push	cs
	push	offset _$FB
	call	far ptr _printf
	add	sp,4
@6@142:
   ;	
   ;			return 0xFF;
   ;	
	mov	ax,255
	jmp	short @6@282
@6@170:
   ;	
   ;		}
   ;	
   ;		// AX contains the function code
   ;		// The function code for 'status' is 3
   ;	
   ;		Regs.r_ax = 3;
   ;	
	mov	word ptr [bp-20],3
   ;	
   ;		intr((PPPInterrupt ? PPPInterrupt : PPPLoaded), &Regs);
   ;	
	push	ss
	lea	ax,word ptr [bp-20]
	push	ax
	cmp	word ptr DGROUP:_PPPInterrupt,0
	je	short @6@226
	mov	ax,word ptr DGROUP:_PPPInterrupt
	jmp	short @6@254
@6@226:
	mov	ax,word ptr DGROUP:_PPPLoaded
@6@254:
	push	ax
	call	far ptr _intr
	add	sp,6
   ;	
   ;	
   ;		return Regs.r_ax;
   ;	
	mov	ax,word ptr [bp-20]
@6@282:
   ;	
   ;	}
   ;	
	pop	di
	pop	si
	leave	
	ret	
_PPPStatus	endp
_$GB	label	byte
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	58
	db	32
	db	80
	db	80
	db	80
	db	76
	db	111
	db	99
	db	97
	db	108
	db	73
	db	80
	db	40
	db	41
	db	32
	db	45
	db	45
	db	32
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	32
	db	119
	db	97
	db	115
	db	32
	db	110
	db	111
	db	116
	db	32
	db	105
	db	110
	db	105
	db	116
	db	105
	db	97
	db	108
	db	105
	db	122
	db	101
	db	100
	db	10
	db	0
   ;	
   ;	unsigned long PPPLocalIP(void)
   ;	
	assume	cs:PPPLINKD_TEXT,ds:DGROUP
_PPPLocalIP	proc	far
	enter	20,0
	push	si
	push	di
   ;	
   ;	{
   ;		struct REGPACK Regs;
   ;	
   ;		// Make sure someone called PPPInit first with a valid interrupt
   ;		if ((PPPInterrupt == 0) && (PPPLoaded == 0))
   ;	
	cmp	word ptr DGROUP:_PPPInterrupt,0
	jne	short @7@170
	cmp	word ptr DGROUP:_PPPLoaded,0
	jne	short @7@170
   ;	
   ;		{
   ;			RESPONSE1(printf("PPPLIB: PPPLocalIP() -- PPPLIB was not initialized\n"));
   ;	
	cmp	word ptr DGROUP:_ResponseLevel,1
	jb	short @7@142
	push	cs
	push	offset _$GB
	call	far ptr _printf
	add	sp,4
@7@142:
   ;	
   ;			return 0xFFFFFFFFl;
   ;	
	mov	dx,-1
	mov	ax,0FFFFh
	jmp	short @7@282
@7@170:
   ;	
   ;		}
   ;	
   ;		// AX contains the function code
   ;		// The function code for 'LocalIP' is 6
   ;		Regs.r_ax = 6;
   ;	
	mov	word ptr [bp-20],6
   ;	
   ;	
   ;		// Call the ISR with the register structure set up above
   ;		intr((PPPInterrupt ? PPPInterrupt : PPPLoaded), &Regs);
   ;	
	push	ss
	lea	ax,word ptr [bp-20]
	push	ax
	cmp	word ptr DGROUP:_PPPInterrupt,0
	je	short @7@226
	mov	ax,word ptr DGROUP:_PPPInterrupt
	jmp	short @7@254
@7@226:
	mov	ax,word ptr DGROUP:_PPPLoaded
@7@254:
	push	ax
	call	far ptr _intr
	add	sp,6
   ;	
   ;	
   ;		// The ISR returns the localIP in AX:BX
   ;		return ((unsigned long)(Regs.r_ax) << 16) | (unsigned long)(Regs.r_bx);
   ;	
	mov	ax,word ptr [bp-18]
	mov	dx,word ptr [bp-20]
@7@282:
   ;	
   ;	}
   ;	
	pop	di
	pop	si
	leave	
	ret	
_PPPLocalIP	endp
_$HB	label	byte
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	58
	db	32
	db	80
	db	80
	db	80
	db	82
	db	101
	db	109
	db	111
	db	116
	db	101
	db	73
	db	80
	db	40
	db	41
	db	32
	db	45
	db	45
	db	32
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	32
	db	119
	db	97
	db	115
	db	32
	db	110
	db	111
	db	116
	db	32
	db	105
	db	110
	db	105
	db	116
	db	105
	db	97
	db	108
	db	105
	db	122
	db	101
	db	100
	db	10
	db	0
   ;	
   ;	unsigned long PPPRemoteIP(void)
   ;	
	assume	cs:PPPLINKD_TEXT,ds:DGROUP
_PPPRemoteIP	proc	far
	enter	20,0
	push	si
	push	di
   ;	
   ;	{
   ;		struct REGPACK Regs;
   ;	
   ;		// Make sure someone called PPPInit first with a valid interrupt
   ;		if ((PPPInterrupt == 0) && (PPPLoaded == 0))
   ;	
	cmp	word ptr DGROUP:_PPPInterrupt,0
	jne	short @8@170
	cmp	word ptr DGROUP:_PPPLoaded,0
	jne	short @8@170
   ;	
   ;		{
   ;			RESPONSE1(printf("PPPLIB: PPPRemoteIP() -- PPPLIB was not initialized\n"));
   ;	
	cmp	word ptr DGROUP:_ResponseLevel,1
	jb	short @8@142
	push	cs
	push	offset _$HB
	call	far ptr _printf
	add	sp,4
@8@142:
   ;	
   ;			return 0xFFFFFFFFl;
   ;	
	mov	dx,-1
	mov	ax,0FFFFh
	jmp	short @8@282
@8@170:
   ;	
   ;		}
   ;	
   ;		// AX contains the function code
   ;		// The function code for 'RemoteIP' is 7
   ;		Regs.r_ax = 7;
   ;	
	mov	word ptr [bp-20],7
   ;	
   ;	
   ;		// Call the ISR with the register structure set up above
   ;		intr((PPPInterrupt ? PPPInterrupt : PPPLoaded), &Regs);
   ;	
	push	ss
	lea	ax,word ptr [bp-20]
	push	ax
	cmp	word ptr DGROUP:_PPPInterrupt,0
	je	short @8@226
	mov	ax,word ptr DGROUP:_PPPInterrupt
	jmp	short @8@254
@8@226:
	mov	ax,word ptr DGROUP:_PPPLoaded
@8@254:
	push	ax
	call	far ptr _intr
	add	sp,6
   ;	
   ;	
   ;		// The ISR returns the RemoteIP in AX:BX
   ;		return ((unsigned long)(Regs.r_ax) << 16) | (unsigned long)(Regs.r_bx);
   ;	
	mov	ax,word ptr [bp-18]
	mov	dx,word ptr [bp-20]
@8@282:
   ;	
   ;	}
   ;	
	pop	di
	pop	si
	leave	
	ret	
_PPPRemoteIP	endp
_$IB	label	byte
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	58
	db	32
	db	80
	db	80
	db	80
	db	82
	db	101
	db	109
	db	111
	db	116
	db	101
	db	80
	db	68
	db	78
	db	83
	db	40
	db	41
	db	32
	db	45
	db	45
	db	32
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	32
	db	119
	db	97
	db	115
	db	32
	db	110
	db	111
	db	116
	db	32
	db	105
	db	110
	db	105
	db	116
	db	105
	db	97
	db	108
	db	105
	db	122
	db	101
	db	100
	db	10
	db	0
   ;	
   ;	unsigned long PPPRemotePDNS(void)
   ;	
	assume	cs:PPPLINKD_TEXT,ds:DGROUP
_PPPRemotePDNS	proc	far
	enter	20,0
	push	si
	push	di
   ;	
   ;	{
   ;		struct REGPACK Regs;
   ;	
   ;		// Make sure someone called PPPInit first with a valid interrupt
   ;		if ((PPPInterrupt == 0) && (PPPLoaded == 0))
   ;	
	cmp	word ptr DGROUP:_PPPInterrupt,0
	jne	short @9@170
	cmp	word ptr DGROUP:_PPPLoaded,0
	jne	short @9@170
   ;	
   ;		{
   ;			RESPONSE1(printf("PPPLIB: PPPRemotePDNS() -- PPPLIB was not initialized\n"));
   ;	
	cmp	word ptr DGROUP:_ResponseLevel,1
	jb	short @9@142
	push	cs
	push	offset _$IB
	call	far ptr _printf
	add	sp,4
@9@142:
   ;	
   ;			return 0xFFFFFFFFl;
   ;	
	mov	dx,-1
	mov	ax,0FFFFh
	jmp	short @9@282
@9@170:
   ;	
   ;		}
   ;	
   ;		// AX contains the function code
   ;		// The function code for 'RemotePDNS' is 9
   ;		Regs.r_ax = 9;
   ;	
	mov	word ptr [bp-20],9
   ;	
   ;	
   ;		// Call the ISR with the register structure set up above
   ;		intr((PPPInterrupt ? PPPInterrupt : PPPLoaded), &Regs);
   ;	
	push	ss
	lea	ax,word ptr [bp-20]
	push	ax
	cmp	word ptr DGROUP:_PPPInterrupt,0
	je	short @9@226
	mov	ax,word ptr DGROUP:_PPPInterrupt
	jmp	short @9@254
@9@226:
	mov	ax,word ptr DGROUP:_PPPLoaded
@9@254:
	push	ax
	call	far ptr _intr
	add	sp,6
   ;	
   ;	
   ;		// The ISR returns the RemotePDNS in AX:BX
   ;		return ((unsigned long)(Regs.r_ax) << 16) | (unsigned long)(Regs.r_bx);
   ;	
	mov	ax,word ptr [bp-18]
	mov	dx,word ptr [bp-20]
@9@282:
   ;	
   ;	}
   ;	
	pop	di
	pop	si
	leave	
	ret	
_PPPRemotePDNS	endp
_$JB	label	byte
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	58
	db	32
	db	80
	db	80
	db	80
	db	82
	db	101
	db	109
	db	111
	db	116
	db	101
	db	83
	db	68
	db	78
	db	83
	db	40
	db	41
	db	32
	db	45
	db	45
	db	32
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	32
	db	119
	db	97
	db	115
	db	32
	db	110
	db	111
	db	116
	db	32
	db	105
	db	110
	db	105
	db	116
	db	105
	db	97
	db	108
	db	105
	db	122
	db	101
	db	100
	db	10
	db	0
   ;	
   ;	unsigned long PPPRemoteSDNS(void)
   ;	
	assume	cs:PPPLINKD_TEXT,ds:DGROUP
_PPPRemoteSDNS	proc	far
	enter	20,0
	push	si
	push	di
   ;	
   ;	{
   ;		struct REGPACK Regs;
   ;	
   ;		// Make sure someone called PPPInit first with a valid interrupt
   ;		if ((PPPInterrupt == 0) && (PPPLoaded == 0))
   ;	
	cmp	word ptr DGROUP:_PPPInterrupt,0
	jne	short @10@170
	cmp	word ptr DGROUP:_PPPLoaded,0
	jne	short @10@170
   ;	
   ;		{
   ;			RESPONSE1(printf("PPPLIB: PPPRemoteSDNS() -- PPPLIB was not initialized\n"));
   ;	
	cmp	word ptr DGROUP:_ResponseLevel,1
	jb	short @10@142
	push	cs
	push	offset _$JB
	call	far ptr _printf
	add	sp,4
@10@142:
   ;	
   ;			return 0xFFFFFFFFl;
   ;	
	mov	dx,-1
	mov	ax,0FFFFh
	jmp	short @10@282
@10@170:
   ;	
   ;		}
   ;	
   ;		// AX contains the function code
   ;		// The function code for 'RemoteSDNS' is 10
   ;		Regs.r_ax = 10;
   ;	
	mov	word ptr [bp-20],10
   ;	
   ;	
   ;		// Call the ISR with the register structure set up above
   ;		intr((PPPInterrupt ? PPPInterrupt : PPPLoaded), &Regs);
   ;	
	push	ss
	lea	ax,word ptr [bp-20]
	push	ax
	cmp	word ptr DGROUP:_PPPInterrupt,0
	je	short @10@226
	mov	ax,word ptr DGROUP:_PPPInterrupt
	jmp	short @10@254
@10@226:
	mov	ax,word ptr DGROUP:_PPPLoaded
@10@254:
	push	ax
	call	far ptr _intr
	add	sp,6
   ;	
   ;	
   ;		// The ISR returns the RemoteSDNS in AX:BX
   ;		return ((unsigned long)(Regs.r_ax) << 16) | (unsigned long)(Regs.r_bx);
   ;	
	mov	ax,word ptr [bp-18]
	mov	dx,word ptr [bp-20]
@10@282:
   ;	
   ;	}
   ;	
	pop	di
	pop	si
	leave	
	ret	
_PPPRemoteSDNS	endp
_$KB	label	byte
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	58
	db	32
	db	80
	db	80
	db	80
	db	84
	db	105
	db	109
	db	101
	db	111
	db	117
	db	116
	db	84
	db	105
	db	99
	db	107
	db	115
	db	40
	db	41
	db	32
	db	45
	db	45
	db	32
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	32
	db	119
	db	97
	db	115
	db	32
	db	110
	db	111
	db	116
	db	32
	db	105
	db	110
	db	105
	db	116
	db	105
	db	97
	db	108
	db	105
	db	122
	db	101
	db	100
	db	10
	db	0
   ;	
   ;	unsigned long PPPTimeoutTicks(void)
   ;	
	assume	cs:PPPLINKD_TEXT,ds:DGROUP
_PPPTimeoutTicks	proc	far
	enter	28,0
	push	si
	push	di
   ;	
   ;	{
   ;		struct REGPACK Regs;
   ;		unsigned long RetVal;
   ;	
   ;		// Make sure someone called PPPInit first with a valid interrupt
   ;		if ((PPPInterrupt == 0) && (PPPLoaded == 0))
   ;	
	cmp	word ptr DGROUP:_PPPInterrupt,0
	jne	short @11@170
	cmp	word ptr DGROUP:_PPPLoaded,0
	jne	short @11@170
   ;	
   ;		{
   ;			RESPONSE1(printf("PPPLIB: PPPTimeoutTicks() -- PPPLIB was not initialized\n"));
   ;	
	cmp	word ptr DGROUP:_ResponseLevel,1
	jb	short @11@142
	push	cs
	push	offset _$KB
	call	far ptr _printf
	add	sp,4
@11@142:
   ;	
   ;			return 0;
   ;	
	xor	dx,dx
	xor	ax,ax
	jmp	short @11@282
@11@170:
   ;	
   ;		}
   ;	
   ;		// AX contains the function code
   ;		// The function code for 'Timeout' is 13
   ;		Regs.r_ax = 13;
   ;	
	mov	word ptr [bp-28],13
   ;	
   ;	
   ;		// Call the ISR with the register structure set up above
   ;		intr((PPPInterrupt ? PPPInterrupt : PPPLoaded), &Regs);
   ;	
	push	ss
	lea	ax,word ptr [bp-28]
	push	ax
	cmp	word ptr DGROUP:_PPPInterrupt,0
	je	short @11@226
	mov	ax,word ptr DGROUP:_PPPInterrupt
	jmp	short @11@254
@11@226:
	mov	ax,word ptr DGROUP:_PPPLoaded
@11@254:
	push	ax
	call	far ptr _intr
	add	sp,6
   ;	
   ;	
   ;		RetVal = ((unsigned long)(Regs.r_bx) << 16) | (unsigned long)(Regs.r_ax);
   ;	
	movzx	eax,word ptr [bp-26]
	shl	eax,16
	movzx	edx,word ptr [bp-28]
	mov	dword ptr [bp-8],edx
	or	eax,edx
	mov	dword ptr [bp-4],eax
   ;	
   ;		RetVal -= ((unsigned long)(Regs.r_dx) << 16) | (unsigned long)(Regs.r_ax);
   ;	
	movzx	eax,word ptr [bp-22]
	shl	eax,16
	or	eax,dword ptr [bp-8]
	sub	dword ptr [bp-4],eax
   ;	
   ;	
   ;		return RetVal;
   ;	
	mov	dx,word ptr [bp-2]
	mov	ax,word ptr [bp-4]
@11@282:
   ;	
   ;	}
   ;	
	pop	di
	pop	si
	leave	
	ret	
_PPPTimeoutTicks	endp
_$LB	label	byte
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	58
	db	32
	db	80
	db	80
	db	80
	db	84
	db	105
	db	109
	db	101
	db	111
	db	117
	db	116
	db	84
	db	105
	db	99
	db	107
	db	115
	db	40
	db	41
	db	32
	db	45
	db	45
	db	32
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	32
	db	119
	db	97
	db	115
	db	32
	db	110
	db	111
	db	116
	db	32
	db	105
	db	110
	db	105
	db	116
	db	105
	db	97
	db	108
	db	105
	db	122
	db	101
	db	100
	db	10
	db	0
   ;	
   ;	unsigned long PPPTimeout(void)
   ;	
	assume	cs:PPPLINKD_TEXT,ds:DGROUP
_PPPTimeout	proc	far
	enter	28,0
	push	si
	push	di
   ;	
   ;	{
   ;		struct REGPACK Regs;
   ;		unsigned long RetVal;
   ;	
   ;		// Make sure someone called PPPInit first with a valid interrupt
   ;		if ((PPPInterrupt == 0) && (PPPLoaded == 0))
   ;	
	cmp	word ptr DGROUP:_PPPInterrupt,0
	jne	short @12@170
	cmp	word ptr DGROUP:_PPPLoaded,0
	jne	short @12@170
   ;	
   ;		{
   ;			RESPONSE1(printf("PPPLIB: PPPTimeoutTicks() -- PPPLIB was not initialized\n"));
   ;	
	cmp	word ptr DGROUP:_ResponseLevel,1
	jb	short @12@142
	push	cs
	push	offset _$LB
	call	far ptr _printf
	add	sp,4
@12@142:
   ;	
   ;			return 0;
   ;	
	xor	dx,dx
	xor	ax,ax
	jmp	short @12@282
@12@170:
   ;	
   ;		}
   ;	
   ;		// AX contains the function code
   ;		// The function code for 'Timeout' is 13
   ;		Regs.r_ax = 13;
   ;	
	mov	word ptr [bp-28],13
   ;	
   ;	
   ;		// Call the ISR with the register structure set up above
   ;		intr((PPPInterrupt ? PPPInterrupt : PPPLoaded), &Regs);
   ;	
	push	ss
	lea	ax,word ptr [bp-28]
	push	ax
	cmp	word ptr DGROUP:_PPPInterrupt,0
	je	short @12@226
	mov	ax,word ptr DGROUP:_PPPInterrupt
	jmp	short @12@254
@12@226:
	mov	ax,word ptr DGROUP:_PPPLoaded
@12@254:
	push	ax
	call	far ptr _intr
	add	sp,6
   ;	
   ;	
   ;		RetVal = ((unsigned long)(Regs.r_bx) << 16) | (unsigned long)(Regs.r_ax);
   ;	
	movzx	eax,word ptr [bp-26]
	shl	eax,16
	movzx	edx,word ptr [bp-28]
	mov	dword ptr [bp-8],edx
	or	eax,edx
	mov	dword ptr [bp-4],eax
   ;	
   ;		RetVal -= ((unsigned long)(Regs.r_dx) << 16) | (unsigned long)(Regs.r_ax);
   ;	
	movzx	eax,word ptr [bp-22]
	shl	eax,16
	or	eax,dword ptr [bp-8]
	sub	dword ptr [bp-4],eax
   ;	
   ;	
   ;		return (RetVal * 10) / 182;
   ;	
	mov	eax,dword ptr [bp-4]
	imul	eax,large 10
	mov	ebx,large 182
	xor	edx,edx
	div	ebx
	shld	edx,eax,16
@12@282:
   ;	
   ;	}
   ;	
	pop	di
	pop	si
	leave	
	ret	
_PPPTimeout	endp
_$MB	label	byte
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	58
	db	32
	db	80
	db	80
	db	80
	db	71
	db	101
	db	116
	db	82
	db	101
	db	115
	db	112
	db	76
	db	101
	db	118
	db	101
	db	108
	db	40
	db	41
	db	32
	db	45
	db	45
	db	32
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	32
	db	119
	db	97
	db	115
	db	32
	db	110
	db	111
	db	116
	db	32
	db	105
	db	110
	db	105
	db	116
	db	105
	db	97
	db	108
	db	105
	db	122
	db	101
	db	100
	db	10
	db	0
_$NB	label	byte
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	58
	db	32
	db	80
	db	80
	db	80
	db	71
	db	101
	db	116
	db	82
	db	101
	db	115
	db	112
	db	76
	db	101
	db	118
	db	101
	db	108
	db	40
	db	41
	db	32
	db	45
	db	45
	db	32
	db	71
	db	101
	db	116
	db	116
	db	105
	db	110
	db	103
	db	32
	db	97
	db	110
	db	100
	db	32
	db	109
	db	97
	db	116
	db	99
	db	104
	db	105
	db	110
	db	103
	db	32
	db	80
	db	80
	db	80
	db	32
	db	114
	db	101
	db	115
	db	112
	db	111
	db	110
	db	115
	db	101
	db	32
	db	108
	db	101
	db	118
	db	101
	db	108
	db	32
	db	37
	db	100
	db	10
	db	0
_$OB	label	byte
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	58
	db	32
	db	80
	db	80
	db	80
	db	71
	db	101
	db	116
	db	82
	db	101
	db	115
	db	112
	db	76
	db	101
	db	118
	db	101
	db	108
	db	40
	db	41
	db	32
	db	45
	db	45
	db	32
	db	77
	db	97
	db	116
	db	99
	db	104
	db	105
	db	110
	db	103
	db	32
	db	80
	db	80
	db	80
	db	32
	db	114
	db	101
	db	115
	db	112
	db	111
	db	110
	db	115
	db	101
	db	32
	db	108
	db	101
	db	118
	db	101
	db	108
	db	32
	db	48
	db	10
	db	0
   ;	
   ;	unsigned int PPPGetRespLevel(void)
   ;	
	assume	cs:PPPLINKD_TEXT,ds:DGROUP
_PPPGetRespLevel	proc	far
	enter	20,0
	push	si
	push	di
   ;	
   ;	{
   ;		struct REGPACK Regs;
   ;	
   ;		if ((PPPInterrupt == 0) && (PPPLoaded == 0))
   ;	
	cmp	word ptr DGROUP:_PPPInterrupt,0
	jne	short @13@170
	cmp	word ptr DGROUP:_PPPLoaded,0
	jne	short @13@170
   ;	
   ;		{
   ;			RESPONSE1(printf("PPPLIB: PPPGetRespLevel() -- PPPLIB was not initialized\n"));
   ;	
	cmp	word ptr DGROUP:_ResponseLevel,1
	jb	short @13@142
	push	cs
	push	offset _$MB
	call	far ptr _printf
	add	sp,4
@13@142:
   ;	
   ;			return 0xFFFF;
   ;	
	mov	ax,0FFFFh
	jmp	short @13@310
@13@170:
   ;	
   ;		}
   ;	
   ;		if (PPPInterrupt != 0)
   ;	
	cmp	word ptr DGROUP:_PPPInterrupt,0
	je	short @13@282
   ;	
   ;		{
   ;			// AX contains the function code
   ;			// The function code for 'SetRespLev' is 5
   ;			Regs.r_ax = 8;
   ;	
	mov	word ptr [bp-20],8
   ;	
   ;	
   ;			// Call the ISR with the register structure set up above
   ;			intr(PPPInterrupt, &Regs);
   ;	
	push	ss
	lea	ax,word ptr [bp-20]
	push	ax
	push	word ptr DGROUP:_PPPInterrupt
	call	far ptr _intr
	add	sp,6
   ;	
   ;	
   ;			if (Regs.r_ax == 0)
   ;	
	cmp	word ptr [bp-20],0
	jne	short @13@254
   ;	
   ;			{
   ;				ResponseLevel = Regs.r_bx;
   ;	
	mov	ax,word ptr [bp-18]
	mov	word ptr DGROUP:_ResponseLevel,ax
   ;	
   ;				printf("PPPLIB: PPPGetRespLevel() -- Getting and matching PPP response level %d\n", ResponseLevel);
   ;	
	push	ax
	push	cs
	push	offset _$NB
	call	far ptr _printf
	add	sp,6
	jmp	short @13@282
@13@254:
   ;	
   ;	
   ;				// The ISR returns the 0 on success, error when PPP is the non-debug version
   ;				return ResponseLevel;
   ;			}
   ;	
   ;			printf("PPPLIB: PPPGetRespLevel() -- Matching PPP response level 0\n");
   ;	
	push	cs
	push	offset _$OB
	call	far ptr _printf
	add	sp,4
   ;	
   ;	
   ;			return (ResponseLevel = 0);
   ;	
	xor	ax,ax
	mov	word ptr DGROUP:_ResponseLevel,ax
	jmp	short @13@310
@13@282:
   ;	
   ;		}
   ;	
   ;		return ResponseLevel;;
   ;	
	mov	ax,word ptr DGROUP:_ResponseLevel
@13@310:
   ;	
   ;	}
   ;	
	pop	di
	pop	si
	leave	
	ret	
_PPPGetRespLevel	endp
_$PB	label	byte
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	58
	db	32
	db	80
	db	80
	db	80
	db	83
	db	101
	db	116
	db	82
	db	101
	db	115
	db	112
	db	76
	db	101
	db	118
	db	101
	db	108
	db	40
	db	41
	db	32
	db	45
	db	45
	db	32
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	32
	db	119
	db	97
	db	115
	db	32
	db	110
	db	111
	db	116
	db	32
	db	105
	db	110
	db	105
	db	116
	db	105
	db	97
	db	108
	db	105
	db	122
	db	101
	db	100
	db	10
	db	0
_$QB	label	byte
	db	80
	db	80
	db	80
	db	76
	db	73
	db	66
	db	58
	db	32
	db	80
	db	80
	db	80
	db	83
	db	101
	db	116
	db	82
	db	101
	db	115
	db	112
	db	76
	db	101
	db	118
	db	101
	db	108
	db	40
	db	41
	db	32
	db	45
	db	45
	db	32
	db	83
	db	101
	db	116
	db	116
	db	105
	db	110
	db	103
	db	32
	db	97
	db	110
	db	100
	db	32
	db	109
	db	97
	db	116
	db	99
	db	104
	db	105
	db	110
	db	103
	db	32
	db	80
	db	80
	db	80
	db	32
	db	114
	db	101
	db	115
	db	112
	db	111
	db	110
	db	115
	db	101
	db	32
	db	108
	db	101
	db	118
	db	101
	db	108
	db	32
	db	37
	db	100
	db	10
	db	0
   ;	
   ;	unsigned int PPPSetRespLevel(unsigned int ResponseLevel)
   ;	
	assume	cs:PPPLINKD_TEXT,ds:DGROUP
_PPPSetRespLevel	proc	far
	enter	20,0
	push	si
	push	di
   ;	
   ;	{
   ;		struct REGPACK Regs;
   ;	
   ;		// Make sure someone called PPPInit first with a valid interrupt
   ;		if ((PPPInterrupt == 0) && (PPPLoaded == 0))
   ;	
	cmp	word ptr DGROUP:_PPPInterrupt,0
	jne	short @14@170
	cmp	word ptr DGROUP:_PPPLoaded,0
	jne	short @14@170
   ;	
   ;		{
   ;			RESPONSE1(printf("PPPLIB: PPPSetRespLevel() -- PPPLIB was not initialized\n"));
   ;	
	cmp	word ptr [bp+6],1
	jb	short @14@142
	push	cs
	push	offset _$PB
	call	far ptr _printf
	add	sp,4
@14@142:
   ;	
   ;			return 0x8FFD;
   ;	
	mov	ax,08FFDh
	jmp	short @14@254
@14@170:
   ;	
   ;		}
   ;	
   ;		if (PPPInterrupt != 0)
   ;	
	cmp	word ptr DGROUP:_PPPInterrupt,0
	je	short @14@226
   ;	
   ;		{
   ;			// AX contains the function code
   ;			// The function code for 'SetRespLev' is 5
   ;			Regs.r_ax = 5;
   ;	
	mov	word ptr [bp-20],5
   ;	
   ;	
   ;			// BX contains the desired response level
   ;			Regs.r_bx = ResponseLevel;
   ;	
	mov	ax,word ptr [bp+6]
	mov	word ptr [bp-18],ax
   ;	
   ;	
   ;			// Call the ISR with the register structure set up above
   ;			intr(PPPInterrupt, &Regs);
   ;	
	push	ss
	lea	ax,word ptr [bp-20]
	push	ax
	push	word ptr DGROUP:_PPPInterrupt
	call	far ptr _intr
	add	sp,6
   ;	
   ;	
   ;			::ResponseLevel = ResponseLevel;
   ;	
	mov	ax,word ptr [bp+6]
	mov	word ptr DGROUP:_ResponseLevel,ax
   ;	
   ;	
   ;			printf("PPPLIB: PPPSetRespLevel() -- Setting and matching PPP response level %d\n", ResponseLevel);
   ;	
	push	ax
	push	cs
	push	offset _$QB
	call	far ptr _printf
	add	sp,6
   ;	
   ;	
   ;			// The ISR returns the 0 on success, error when PPP is the non-debug version
   ;			return Regs.r_ax;
   ;	
	mov	ax,word ptr [bp-20]
	jmp	short @14@254
@14@226:
   ;	
   ;		}
   ;	
   ;		::ResponseLevel = ResponseLevel;
   ;	
	mov	ax,word ptr [bp+6]
	mov	word ptr DGROUP:_ResponseLevel,ax
   ;	
   ;		return 0;
   ;	
	xor	ax,ax
@14@254:
   ;	
   ;	}
   ;	
	pop	di
	pop	si
	leave	
	ret	
_PPPSetRespLevel	endp
	?debug	C E9
	?debug	C FA15020000
PPPLINKD_TEXT	ends
_DATA	segment word public use16 'DATA'
s@	label	byte
_DATA	ends
PPPLINKD_TEXT	segment byte public use16 'CODE'
PPPLINKD_TEXT	ends
_s@	equ	s@
	extrn	@$bnwa$qui:far
	extrn	@$bdele$qnv:far
_peek	equ	peek
_peekb	equ	peekb
_poke	equ	poke
_pokeb	equ	pokeb
	extrn	_intr:far
	extrn	__streams:word
	extrn	_fclose:far
	extrn	_fgetc:far
	extrn	_fopen:far
	extrn	_printf:far
	extrn	__fputc:far
_abs	equ	abs
_atoi	equ	atoi
	extrn	_getch:far
	extrn	_kbhit:far
	public	_pOpenScript
	public	_pCloseScript
	public	_ResponseLevel
	extrn	_ScriptSize:word
	extrn	@Modem_Create$quiuculucucucucucui:far
	extrn	@Modem_Destroy$qv:far
	extrn	@SetMRU$qui:far
	extrn	@Script@Create$quinxcnn6Script:far
	extrn	@Script@Destroy$qv:far
	extrn	@LCP_Create$qv:far
	extrn	@LCP_Destroy$qv:far
	extrn	@IPCP_Create$qv:far
	extrn	@InstallPacketISR$quc:far
	extrn	@InstallPPPISR$quc:far
	public	_PPPLoad
	public	_PPPOpen
	public	_PPPClose
	public	_PPPStatus
	public	_PPPLocalIP
	public	_PPPRemoteIP
	public	_PPPRemotePDNS
	public	_PPPRemoteSDNS
	public	_PPPTimeoutTicks
	public	_PPPTimeout
	public	_PPPGetRespLevel
	public	_PPPSetRespLevel
	extrn	_RetRegs2:word
	public	_PPPInterrupt
	public	_PPPLoaded
	public	_PPPSignature
	extrn	_Timeout:word
	public	@PPPLoadScript$qnc
	public	@PPPFreeScript$qnc
	end
