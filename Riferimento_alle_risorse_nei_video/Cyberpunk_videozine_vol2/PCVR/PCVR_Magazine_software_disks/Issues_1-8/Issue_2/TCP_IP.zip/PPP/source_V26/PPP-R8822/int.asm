	ifndef	??version
?debug	macro
	endm
publicdll macro	name
	public	name
	endm
$comm	macro	name,dist,size,count
	comm	dist name:BYTE:count*size
	endm
	else
$comm	macro	name,dist,size,count
	comm	dist name[size]:BYTE:count
	endm
	endif
	?debug	V 301h
	?debug	S "INT.CPP"
	?debug	C E93147C32C07494E542E435050
	?debug	C E980261D1F15433A5C424334355C494E434C5544455C444F532E48
	?debug	C E980261D1F17433A5C424334355C494E434C5544455C5F44454653+
	?debug	C 2E48
	?debug	C E980261D1F16433A5C424334355C494E434C5544455C42494F532E+
	?debug	C 48
	?debug	C E980261D1F17433A5C424334355C494E434C5544455C535444494F+
	?debug	C 2E48
	?debug	C E980261D1F18433A5C424334355C494E434C5544455C5F4E46494C+
	?debug	C 452E48
	?debug	C E980261D1F17433A5C424334355C494E434C5544455C5F4E554C4C+
	?debug	C 2E48
	?debug	C E92D56632E055050502E48
	?debug	C E90F60662E0754595045532E48
	?debug	C E949718E2C085343524950542E48
	?debug	C E90F60662E0754595045532E48
	?debug	C E92544BF2C074D4F44454D2E48
	?debug	C E97055652C074652414D452E48
	?debug	C E90F60662E0754595045532E48
	?debug	C E96F55652C0846434841494E2E48
	?debug	C E90F60662E0754595045532E48
	?debug	C E97055652C074652414D452E48
	?debug	C E90D778E2C06495043502E48
	?debug	C E97055652C074652414D452E48
	?debug	C E96F55652C0846434841494E2E48
	?debug	C E9046BBF2C054C43502E48
	?debug	C E97055652C074652414D452E48
	?debug	C E96F55652C0846434841494E2E48
	?debug	C E92544BF2C074D4F44454D2E48
	?debug	C E96E55652C06415554482E48
	?debug	C E949718E2C085343524950542E48
	?debug	C E9046BBF2C054C43502E48
	?debug	C E9046BBF2C054C43502E48
	?debug	C E92544BF2C074D4F44454D2E48
	?debug	C E97255652C06504452562E48
	?debug	C E90D778E2C06495043502E48
	?debug	C E9D25E662E0754494D45522E48
INT_TEXT	segment byte public 'CODE'
INT_TEXT	ends
DGROUP	group	_DATA,_BSS
	assume	cs:INT_TEXT,ds:DGROUP
_DATA	segment word public 'DATA'
d@	label	byte
d@w	label	word
_DATA	ends
_BSS	segment word public 'BSS'
b@	label	byte
b@w	label	word
_RetRegs2	label	word
	db	18 dup (?)
_OldPPPISR	label	dword
	db	4 dup (?)
_PPPISRNum	label	byte
	db	1 dup (?)
	db	1 dup (?)
_ScriptSize	label	word
	db	2 dup (?)
_BSS	ends
INT_TEXT	segment byte public 'CODE'
_$A	label	byte
	db	80
	db	80
	db	80
	db	80
	db	68
	db	32
	db	45
	db	32
	db	83
	db	101
	db	116
	db	116
	db	105
	db	110
	db	103
	db	32
	db	100
	db	101
	db	98
	db	117
	db	103
	db	32
	db	114
	db	101
	db	115
	db	112
	db	111
	db	110
	db	115
	db	101
	db	32
	db	116
	db	111
	db	32
	db	108
	db	101
	db	118
	db	101
	db	108
	db	32
	db	37
	db	100
	db	10
	db	0
INT_TEXT	ends
_BSS	segment word public 'BSS'
_BSS	ends
INT_TEXT	segment byte public 'CODE'
   ;	
   ;	void interrupt PPPISR(...)
   ;	
	assume	cs:INT_TEXT,ds:DGROUP
@PPPISR$qve	proc	far
	jmp	OverText2
	db	'PPP DRVR',00h
OverText2:
	push	ds

	push	bp
	mov	bp,DGROUP
	mov	ds,bp
	mov	bp,sp
	sub	sp,4
   ;	
   ;	{
   ;		//   jmp	OverText2
   ;		//   db	'PPP DRVR',00h
   ;		//OverText2:
   ;		//   push	ds
   ;	
   ;		RetRegs2.AX = _AX;
   ;	
	mov	word ptr DGROUP:_RetRegs2,ax
   ;	
   ;		RetRegs2.BX = _BX;
   ;	
	mov	word ptr DGROUP:_RetRegs2+2,bx
   ;	
   ;		RetRegs2.CX = _CX;
   ;	
	mov	word ptr DGROUP:_RetRegs2+4,cx
   ;	
   ;		RetRegs2.DX = _DX;
   ;	
	mov	word ptr DGROUP:_RetRegs2+6,dx
   ;	
   ;		RetRegs2.SI = _SI;
   ;	
	mov	word ptr DGROUP:_RetRegs2+8,si
   ;	
   ;		RetRegs2.DI = _DI;
   ;	
	mov	word ptr DGROUP:_RetRegs2+10,di
   ;	
   ;		RetRegs2.FLAGS = _FLAGS;
   ;	
	pushf	
	pop	ax
	mov	word ptr DGROUP:_RetRegs2+12,ax
   ;	
	;		//mov	ax,[bp-2]
	;		RetRegs2.DS = _AX;
	;
	mov	ax,[bp-2]
	mov	word ptr DGROUP:_RetRegs2+14,ax
   ;	
   ;		RetRegs2.ES = _ES;
   ;	
	mov	word ptr DGROUP:_RetRegs2+16,es
	jmp	short @1@198
@1@58:
   ;	
   ;	
   ;		disable();
   ;		while (Semaphore != 0)
   ;		{
   ;			enable();
   ;	
	db	251
   ;	
   ;			DELAY(SHORT_TICKDELAY);
   ;	
	xor	ax,ax
	push	ax
	push	ax
	push	ax
	call	far ptr _biostime
	add	sp,6
	mov	word ptr [bp-2],dx
	mov	word ptr [bp-4],ax
@1@114:
	xor	ax,ax
	push	ax
	push	ax
	push	ax
	call	far ptr _biostime
	add	sp,6
	mov	bx,word ptr [bp-2]
	mov	cx,word ptr [bp-4]
	add	cx,5
	adc	bx,0
	cmp	dx,bx
	jl	short @1@114
	jne	short @1@198
	cmp	ax,cx
	jb	short @1@114
@1@198:
   ;	
   ;			disable();
   ;	
	db	250
	cmp	byte ptr DGROUP:_Semaphore,0
	jne	short @1@58
   ;	
   ;		}
   ;		  _asm
   ;		{
   ;			mov	ah,51h
   ;	
	mov		ah,51h
   ;	
   ;			int	21h
   ;	
	int		21h
   ;	
   ;		}
   ;		OldPSP = _BX;
   ;	
	mov	word ptr DGROUP:_OldPSP,bx
   ;	
   ;		_BX = PSPSeg;
   ;	
	mov	bx,word ptr DGROUP:_PSPSeg
   ;	
   ;		_asm
   ;		{
   ;			mov	ah,50h
   ;	
	mov		ah,50h
   ;	
   ;			int	21h
   ;	
	int		21h
   ;	
   ;		}
   ;		Semaphore = 1;
   ;	
	mov	byte ptr DGROUP:_Semaphore,1
   ;	
   ;		OldSS = _SS;
   ;	
	mov	word ptr DGROUP:_OldSS,ss
   ;	
   ;		OldSP = _SP;
   ;	
	mov	word ptr DGROUP:_OldSP,sp
   ;	
   ;		OldBP = _BP;
   ;	
	mov	word ptr DGROUP:_OldBP,bp
   ;	
   ;		_BX = _BP - _SP;
   ;	
	mov	bx,bp
	sub	bx,sp
   ;	
   ;		_SS = FP_SEG((char far*)&LocalStack);
   ;	
	mov	ax,ds
	mov	ss,ax
   ;	
   ;		_BP = FP_OFF((char far*)&(LocalStack[sizeof(LocalStack) - 4]));
   ;	
	mov	bp,offset DGROUP:_LocalStack+2044
   ;	
   ;		_SP = _BP - _BX;
   ;	
	mov	ax,bp
	sub	ax,bx
	mov	sp,ax
   ;	
   ;		enable();
   ;	
	db	251
   ;	
   ;	
   ;		switch(RetRegs2.AX)
   ;	
	mov	bx,word ptr DGROUP:_RetRegs2
	dec	bx
	cmp	bx,12
	jbe	@@3
	jmp	@1@1402
@@3:
	add	bx,bx
	jmp	word ptr cs:@1@C1298[bx]
@1@506:
   ;	
   ;		{
   ;			case 1:
   ;				if ((IPCP_State != IPCP_INITIAL) && (IPCP_State != IPCP_CLOSED))
   ;	
	cmp	word ptr DGROUP:_IPCP_State,0
	je	short @1@590
	cmp	word ptr DGROUP:_IPCP_State,5
	je	short @1@590
   ;	
   ;				{
   ;					RetRegs2.AX = 0x8001;
   ;	
	mov	word ptr DGROUP:_RetRegs2,-32767
   ;	
   ;					break;
   ;	
	jmp	@1@1402
@1@590:
   ;	
   ;				}
   ;	
   ;				if ((pOpenScript->LoadScript((char far*)MK_FP(RetRegs2.DS, RetRegs2.SI))) ||
   ;	
   ;	
   ;						(pCloseScript->LoadScript((char far*)MK_FP(RetRegs2.ES, RetRegs2.DI))))
   ;	
	push	word ptr DGROUP:_RetRegs2+14
	push	word ptr DGROUP:_RetRegs2+8
	push	word ptr DGROUP:_pOpenScript+2
	push	word ptr DGROUP:_pOpenScript
	call	far ptr @Script@LoadScript$qnc
	add	sp,8
	or	ax,ax
	jne	short @1@646
	push	word ptr DGROUP:_RetRegs2+16
	push	word ptr DGROUP:_RetRegs2+10
	push	word ptr DGROUP:_pCloseScript+2
	push	word ptr DGROUP:_pCloseScript
	call	far ptr @Script@LoadScript$qnc
	add	sp,8
	or	ax,ax
	je	short @1@674
@1@646:
   ;	
   ;				{
   ;					RetRegs2.AX = 0x8003;
   ;	
	mov	word ptr DGROUP:_RetRegs2,-32765
   ;	
   ;				}
   ;	
	jmp	@1@1402
@1@674:
   ;	
   ;				else
   ;				{
   ;					IPCP_ReLoadScript();
   ;	
	call	far ptr @IPCP_ReLoadScript$qv
   ;	
   ;	
   ;					if (IPCP_Open() == 0)
   ;	
	call	far ptr @IPCP_Open$qv
	or	ax,ax
	jne	short @1@730
   ;	
   ;					{
   ;						EnableTimerISR();
   ;	
	call	far ptr @EnableTimerISR$qv
	jmp	@1@1346
@1@730:
   ;	
   ;						RetRegs2.AX = 0;
   ;					}
   ;					else RetRegs2.AX = 0x8002;
   ;	
	mov	word ptr DGROUP:_RetRegs2,-32766
	jmp	@1@1402
@1@758:
   ;	
   ;				}
   ;				break;
   ;			case 2:
   ;				if ((IPCP_State == IPCP_INITIAL) || (IPCP_State == IPCP_CLOSED))
   ;	
	cmp	word ptr DGROUP:_IPCP_State,0
	je	short @1@814
	cmp	word ptr DGROUP:_IPCP_State,5
	jne	short @1@842
@1@814:
   ;	
   ;				{
   ;					RetRegs2.AX = 0x8001;
   ;	
	mov	word ptr DGROUP:_RetRegs2,-32767
   ;	
   ;					break;
   ;	
	jmp	@1@1402
@1@842:
   ;	
   ;				}
   ;	
   ;				DisableTimerISR();
   ;	
	call	far ptr @DisableTimerISR$qv
   ;	
   ;	
   ;				RetRegs2.AX = IPCP_Close(1);
   ;	
	mov	al,1
	push	ax
	call	far ptr @IPCP_Close$quc
	pop	cx
	mov	word ptr DGROUP:_RetRegs2,ax
   ;	
   ;				if (RetRegs2.AX) RetRegs2.AX &= 0x8000;
   ;	
	cmp	word ptr DGROUP:_RetRegs2,0
	jne	@@4
	jmp	@1@1402
@@4:
	and	word ptr DGROUP:_RetRegs2,-32768
	jmp	@1@1402
@1@898:
   ;	
   ;				break;
   ;			case 3:
   ;				RetRegs2.AX = ((IPCP_State & 0x1F) << 10) | ((LCP_State & 0x1F) << 5) | (Modem_State & 0x1F);
   ;	
	mov	ax,word ptr DGROUP:_IPCP_State
	and	ax,31
	mov	cl,10
	shl	ax,cl
	mov	dx,word ptr DGROUP:_LCP_State
	and	dx,31
	mov	cl,5
	shl	dx,cl
	or	ax,dx
	mov	dx,word ptr DGROUP:_Modem_State
	and	dx,31
	or	ax,dx
@1@926:
	mov	word ptr DGROUP:_RetRegs2,ax
   ;	
   ;				break;
   ;	
	jmp	@1@1402
@1@954:
   ;	
   ;			case 4:
   ;				RetRegs2.AX = ScriptSize;
   ;	
	mov	ax,word ptr DGROUP:_ScriptSize
	jmp	short @1@926
@1@982:
   ;	
   ;				break;
   ;			case 5:
   ;	#ifdef RESP_LEVS
   ;				ResponseLevel = RetRegs2.BX;
   ;	
	mov	ax,word ptr DGROUP:_RetRegs2+2
	mov	word ptr DGROUP:_ResponseLevel,ax
   ;	
   ;				RetRegs2.AX = 0;
   ;	
	mov	word ptr DGROUP:_RetRegs2,0
   ;	
   ;				printf("PPPPD - Setting debug response to level %d\n", ResponseLevel);
   ;	
	push	word ptr DGROUP:_RetRegs2+2
	push	cs
	mov	ax,offset _$A
	push	ax
	call	far ptr _printf
	add	sp,6
   ;	
   ;	#else
   ;				RetRegs2.AX = 0x8001;
   ;	#endif
   ;				break;
   ;	
	jmp	@1@1402
@1@1010:
   ;	
   ;			case 6: // LocalIP
   ;			case 7: // RemoteIP
   ;			case 9: // RemotePDNS
   ;			case 10:// RemoteSDNS
   ;			//case 11:
   ;			//case 12:
   ;				if (IPCP_State != IPCP_OPENED)
   ;	
	cmp	word ptr DGROUP:_IPCP_State,3
	je	short @1@1066
   ;	
   ;				{
   ;					RetRegs2.AX = 0;
   ;	
	mov	word ptr DGROUP:_RetRegs2,0
   ;	
   ;					RetRegs2.BX = 0;
   ;	
	mov	word ptr DGROUP:_RetRegs2+2,0
   ;	
   ;				}
   ;	
	jmp	@1@1402
@1@1066:
   ;	
   ;				else
   ;				{
   ;					switch (RetRegs2.AX)
   ;	
	mov	bx,word ptr DGROUP:_RetRegs2
	sub	bx,6
	cmp	bx,4
	ja	short @1@1402
	add	bx,bx
	jmp	word ptr cs:@1@C1266[bx]
@1@1150:
   ;	
   ;					{
   ;						case 6:
   ;							RetRegs2.AX = (WORD)(IPCP_LocalIP >> 16);
   ;	
	mov	dx,word ptr DGROUP:_IPCP_LocalIP+2
	mov	word ptr DGROUP:_RetRegs2,dx
   ;	
   ;							RetRegs2.BX = (WORD)(IPCP_LocalIP & 0xFFFF);
   ;	
	mov	ax,word ptr DGROUP:_IPCP_LocalIP
	jmp	short @1@1262
@1@1178:
   ;	
   ;							break;
   ;						case 7:
   ;							RetRegs2.AX = (WORD)(IPCP_RemoteIP >> 16);
   ;	
	mov	dx,word ptr DGROUP:_IPCP_RemoteIP+2
	mov	word ptr DGROUP:_RetRegs2,dx
   ;	
   ;							RetRegs2.BX = (WORD)(IPCP_RemoteIP & 0xFFFF);
   ;	
	mov	ax,word ptr DGROUP:_IPCP_RemoteIP
	jmp	short @1@1262
@1@1206:
   ;	
   ;							break;
   ;						case 9:
   ;							RetRegs2.AX = (WORD)(IPCP_RemotePDNS >> 16);
   ;	
	mov	dx,word ptr DGROUP:_IPCP_RemotePDNS+2
	mov	word ptr DGROUP:_RetRegs2,dx
   ;	
   ;							RetRegs2.BX = (WORD)(IPCP_RemotePDNS & 0xFFFF);
   ;	
	mov	ax,word ptr DGROUP:_IPCP_RemotePDNS
	jmp	short @1@1262
@1@1234:
   ;	
   ;							break;
   ;						case 10:
   ;							RetRegs2.AX = (WORD)(IPCP_RemoteSDNS >> 16);
   ;	
	mov	dx,word ptr DGROUP:_IPCP_RemoteSDNS+2
	mov	word ptr DGROUP:_RetRegs2,dx
   ;	
   ;							RetRegs2.BX = (WORD)(IPCP_RemoteSDNS & 0xFFFF);
   ;	
	mov	ax,word ptr DGROUP:_IPCP_RemoteSDNS
@1@1262:
	mov	word ptr DGROUP:_RetRegs2+2,ax
   ;	
   ;							break;
   ;	
	jmp	short @1@1402
@1@1290:
   ;	
   ;					}
   ;				}
   ;				break;
   ;	
	jmp	short @1@1402
@1@1318:
   ;	
   ;			case 8:
   ;	#ifdef RESP_LEVS
   ;				RetRegs2.BX = ResponseLevel;
   ;	
	mov	ax,word ptr DGROUP:_ResponseLevel
	mov	word ptr DGROUP:_RetRegs2+2,ax
@1@1346:
   ;	
   ;				RetRegs2.AX = 0;
   ;	
	mov	word ptr DGROUP:_RetRegs2,0
   ;	
   ;	#else
   ;				RetRegs2.AX = 0x8001;
   ;	#endif
   ;				break;
   ;	
	jmp	short @1@1402
@1@1374:
   ;	
   ;			case 13:
   ;				RetRegs2.AX = (WORD)(Timeout & 0xFFFF);
   ;	
	mov	ax,word ptr DGROUP:_Timeout
	mov	word ptr DGROUP:_RetRegs2,ax
   ;	
   ;				RetRegs2.BX = (WORD)((Timeout & 0xFFFF0000l) >> 16);
   ;	
	and	ax,0
	mov	dx,word ptr DGROUP:_Timeout+2
	mov	word ptr DGROUP:_RetRegs2+2,dx
   ;	
   ;				RetRegs2.CX = (WORD)(TimeoutCount & 0xFFFF);
   ;	
	mov	ax,word ptr DGROUP:_TimeoutCount
	mov	word ptr DGROUP:_RetRegs2+4,ax
   ;	
   ;				RetRegs2.DX = (WORD)((TimeoutCount & 0xFFFF0000l) >> 16);
   ;	
	and	ax,0
	mov	dx,word ptr DGROUP:_TimeoutCount+2
	mov	word ptr DGROUP:_RetRegs2+6,dx
   ;	
   ;				break;
   ;	
@1@1402:
   ;	
   ;		}
   ;	
   ;		disable();
   ;	
	db	250
   ;	
   ;		_SS = OldSS;
   ;	
   ;	
   ;		_SP = OldSP;
   ;	
	mov	ss,word ptr DGROUP:_OldSS
	mov	sp,word ptr DGROUP:_OldSP
   ;	
   ;		_BP = OldBP;
   ;	
	mov	bp,word ptr DGROUP:_OldBP
   ;	
   ;		Semaphore = 0;
   ;	
	mov	byte ptr DGROUP:_Semaphore,0
   ;	
   ;		_BX = OldPSP;
   ;	
	mov	bx,word ptr DGROUP:_OldPSP
   ;	
   ;		_asm
   ;		{
   ;			mov	ah,50h
   ;	
	mov		ah,50h
   ;	
   ;			int	21h
   ;	
	int		21h
   ;	
   ;		}
   ;		enable();
   ;	
	db	251
   ;	
   ;	
   ;		_AX = RetRegs2.AX;
   ;	
	mov	ax,word ptr DGROUP:_RetRegs2
   ;	
   ;		_BX = RetRegs2.BX;
   ;	
	mov	bx,word ptr DGROUP:_RetRegs2+2
   ;	
   ;		_CX = RetRegs2.CX;
   ;	
	mov	cx,word ptr DGROUP:_RetRegs2+4
   ;	
   ;		_DX = RetRegs2.DX;
   ;	
	mov	dx,word ptr DGROUP:_RetRegs2+6
   ;	
   ;		_SI = RetRegs2.SI;
   ;	
	mov	si,word ptr DGROUP:_RetRegs2+8
   ;	
   ;		_DI = RetRegs2.DI;
   ;	
	mov	di,word ptr DGROUP:_RetRegs2+10
   ;	
   ;		_FLAGS = RetRegs2.FLAGS;
   ;	
	push	word ptr DGROUP:_RetRegs2+12
	popf	
   ;	
   ;		_ES = RetRegs2.ES;
   ;	
   ;	
   ;		_DS = RetRegs2.DS;
   ;	
	mov	es,word ptr DGROUP:_RetRegs2+16
	mov	ds,word ptr DGROUP:_RetRegs2+14
   ;	
   ;	
	;	   //	add	sp,2
   ;	}
   ;	
	mov	sp,bp
	pop	bp
	add	sp,2
	iret	
@PPPISR$qve	endp
@1@C1266	label	word
	dw	@1@1150
	dw	@1@1178
	dw	@1@1290
	dw	@1@1206
	dw	@1@1234
@1@C1298	label	word
	dw	@1@506
	dw	@1@758
	dw	@1@898
	dw	@1@954
	dw	@1@982
	dw	@1@1010
	dw	@1@1010
	dw	@1@1318
	dw	@1@1010
	dw	@1@1010
	dw	@1@1402
	dw	@1@1402
	dw	@1@1374
   ;	
   ;	WORD InstallPPPISR(BYTE _PPPISRNum)
   ;	
	assume	cs:INT_TEXT,ds:DGROUP
@InstallPPPISR$quc	proc	far
	push	bp
	mov	bp,sp
	push	si
	push	di
   ;	
   ;	{
   ;		disable();
   ;	
	db	250
   ;	
   ;		if (getvect(PPPISRNum = _PPPISRNum) == PPPISR)
   ;	
	mov	al,byte ptr [bp+6]
	mov	byte ptr DGROUP:_PPPISRNum,al
	mov	ah,0
	push	ax
	call	far ptr _getvect
	pop	cx
	cmp	dx,seg @PPPISR$qve
	jne	short @2@114
	cmp	ax,offset @PPPISR$qve
	jne	short @2@114
   ;	
   ;		{
   ;			enable();
   ;	
	db	251
   ;	
   ;			return 1;
   ;	
	mov	ax,1
	jmp	short @2@142
@2@114:
   ;	
   ;		}
   ;	
   ;		OldPPPISR = getvect(PPPISRNum);
   ;	
	mov	al,byte ptr DGROUP:_PPPISRNum
	mov	ah,0
	push	ax
	call	far ptr _getvect
	pop	cx
	mov	word ptr DGROUP:_OldPPPISR+2,dx
	mov	word ptr DGROUP:_OldPPPISR,ax
   ;	
   ;		setvect(PPPISRNum, PPPISR);
   ;	
	mov	ax,seg @PPPISR$qve
	push	ax
	mov	ax,offset @PPPISR$qve
	push	ax
	mov	al,byte ptr DGROUP:_PPPISRNum
	mov	ah,0
	push	ax
	call	far ptr _setvect
	add	sp,6
   ;	
   ;	
   ;		enable();
   ;	
	db	251
   ;	
   ;		return 0;
   ;	
	xor	ax,ax
@2@142:
   ;	
   ;	}
   ;	
	pop	di
	pop	si
	pop	bp
	ret	
@InstallPPPISR$quc	endp
   ;	
   ;	WORD UninstallPPPISR(void)
   ;	
	assume	cs:INT_TEXT,ds:DGROUP
@UninstallPPPISR$qv	proc	far
	push	si
	push	di
   ;	
   ;	{
   ;		disable();
   ;	
	db	250
   ;	
   ;		setvect(PPPISRNum, OldPPPISR);
   ;	
	push	word ptr DGROUP:_OldPPPISR+2
	push	word ptr DGROUP:_OldPPPISR
	mov	al,byte ptr DGROUP:_PPPISRNum
	mov	ah,0
	push	ax
	call	far ptr _setvect
	add	sp,6
   ;	
   ;		enable();
   ;	
	db	251
   ;	
   ;	
   ;		return 0;
   ;	
	xor	ax,ax
   ;	
   ;	}
   ;	
	pop	di
	pop	si
	ret	
@UninstallPPPISR$qv	endp
	?debug	C E9
	?debug	C FA00020000
INT_TEXT	ends
_DATA	segment word public 'DATA'
s@	label	byte
_DATA	ends
INT_TEXT	segment byte public 'CODE'
INT_TEXT	ends
_s@	equ	s@
_peek	equ	peek
_peekb	equ	peekb
_poke	equ	poke
_pokeb	equ	pokeb
	extrn	_getvect:far
	extrn	_setvect:far
	extrn	_biostime:far
	extrn	_printf:far
	extrn	_pOpenScript:dword
	extrn	_pCloseScript:dword
	extrn	_ResponseLevel:word
	public	_ScriptSize
	extrn	_Modem_State:word
	extrn	@Script@LoadScript$qnc:far
	extrn	_LCP_State:word
	extrn	@IPCP_ReLoadScript$qv:far
	extrn	@IPCP_Open$qv:far
	extrn	@IPCP_Close$quc:far
	extrn	_IPCP_State:word
	extrn	_IPCP_LocalIP:word
	extrn	_IPCP_RemoteIP:word
	extrn	_IPCP_RemotePDNS:word
	extrn	_IPCP_RemoteSDNS:word
	extrn	@EnableTimerISR$qv:far
	extrn	@DisableTimerISR$qv:far
	public	_RetRegs2
	public	@PPPISR$qve
	public	_OldPPPISR
	public	_PPPISRNum
	extrn	_Semaphore:byte
	extrn	_LocalStack:byte
	extrn	_OldSS:word
	extrn	_OldSP:word
	extrn	_OldBP:word
	extrn	_OldPSP:word
	extrn	_PSPSeg:word
	extrn	_TimeoutCount:word
	extrn	_Timeout:word
	public	@InstallPPPISR$quc
	public	@UninstallPPPISR$qv
	end
