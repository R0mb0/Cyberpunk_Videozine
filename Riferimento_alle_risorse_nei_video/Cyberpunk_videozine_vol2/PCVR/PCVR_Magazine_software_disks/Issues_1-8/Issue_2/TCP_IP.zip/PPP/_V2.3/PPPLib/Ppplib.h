// This ensures that this file will compile and link correctly under both C AND C++
#ifdef __cplusplus
extern "C"
{
#endif

//------------------------------------------------------------------------------
// PPP Packet Driver v2.5 - By Greg Gibeling - Copyright 2001/02 JK Microsysems
// Edited and tested by Ed Wetherell
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// NOTE!!
// This header file may change and grow in revisions yet to come, you should
// use the version distributed with the version of PPP given to you.
// IF THIS FILE IS OLDER THAN THE VERSION OF PPP BEING USED IT WILL STILL WORK!!
// IF THIS FILE IS NEWER THAN THE VERSION OF PPP BEING USED IT MAY NOT WORK!!
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// _DEBUG must be defined to include the debug functions and output.
// Uncomment the following line to enable debugging of PPPLib.
// Note that you must call PPPSetRespLev() to enable debug messages from PPP and
// that such messages are only availible from the debug version of PPP
//------------------------------------------------------------------------------
//#define _DEBUG

//------------------------------------------------------------------------------
// Use these to test the return code from PPPStatus
// These macros may change.  They may also some day be functions.
// Code compiled on previous versions will continue to operate correctly.
// You should make no assumptions about the value returned from PPPStatus()
// other than what these macros tells you.  The return value contains extra
// debug type information not of use to normal applications.
//------------------------------------------------------------------------------
#define PPPISOPEN(Status)		(((Status) & 0x7C00) == 0x0C00)
#define PPPISOPENING(Status)  ((((Status) & 0x7C00) == 0x0400) || (((Status) & 0x7C00) == 0x0800))
#define PPPISNEGOTIATING(Status) ((((Status) & 0x001F) == 0x0004) && PPPISOPENING(Status))
#define PPPISCLOSED(Status)	((((Status) & 0x7C00) == 0x1400) || (((Status) & 0x7C00) == 0x0000))
#define PPPISSCRIPT(Status)	(((Status) & 0x001F) == 0x0003)

//------------------------------------------------------------------------------
//	Function declarations
// Look into PPPLib.C or the PPP manual for more information on these functions
//------------------------------------------------------------------------------
unsigned int PPPInit(unsigned int Interrupt);
unsigned int PPPOpen(char* OpenScript, char* CloseScript, int WaitForConnect);
unsigned int PPPClose(void);
unsigned int PPPStatus(void);
unsigned long PPPLocalIP(void);
unsigned long PPPRemoteIP(void);
unsigned long PPPRemotePDNS(void);
unsigned long PPPRemoteSDNS(void);

unsigned long PPPTimeoutTicks(void);
unsigned long PPPTimeout(void);


#ifdef _DEBUG
// These functions are only availible in the debug version of PPP
unsigned int PPPGetRespLevel(void);
unsigned int PPPSetRespLevel(unsigned int ResponseLevel);
#endif

//------------------------------------------------------------------------------
//RETURN CODES:
//PPPInit()
//    0: Success; Found a valid instance of PPP
//    1: Failure; PPP is not loaded at the given interrupt
//
//PPPOpen()
//    0x8FFD: Failure in PPPLib; PPPInit() must be called before PPPOpen()
//    0x8FFF: Failure in PPPLib; Failed to load the open script file from disk
//    0x8FFE: Failure in PPPLib; Failed to load the close script file from disk
//    0x8FFC: Failure in PPPLib; Connection failed while in negotiation phase
//    0x8001: Failure in PPP; The current PPP connection must be closed before
//						another can be opened
//    0x8003: Failure in PPP; Failed to load one of the scripts
//						(Possibly the scripts are too large)
//    0x8002: Failure in PPP; Failed to initiate the connect sequence
//    0: Success; Connect sequence initiated
//
//PPPClose()
//    0x8FFD: Failure in PPPLib; PPPInit() must be called before PPPClose()
//    0x8001: Failure in PPP; The current PPP connection must be opened before
//						it can be closed
//    0: Success; PPP connection closed
//
//PPPLocalIP()
//PPPRemoteIP()
//PPPRemotePDNS()
//PPPRemoteSDNS()
//    0.0.0.0: PPP does not have a valid negotiated connection
//    255.255.255.255: PPPInit() must be called first
//    (Basically just check if it's a valid address)
//
//PPPSetRespLevel()
//    0x8FFD: Failure in PPPLib; PPPInit() must be called before PPPSetRespLevel
//    0x8001: Failed in PPP; This is not the debug version of PPP
//	 0: Success
//------------------------------------------------------------------------------

#ifdef __cplusplus
}
#endif