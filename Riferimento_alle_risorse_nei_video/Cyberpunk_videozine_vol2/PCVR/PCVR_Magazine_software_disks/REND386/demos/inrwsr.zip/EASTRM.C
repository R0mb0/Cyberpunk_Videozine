#include <stdio.h>
#include <dos.h>
#include <string.h>
#include <math.h>
#include <alloc.h>


#include "3dstruct.h"
#include "config.h"
#include "rend386.h"
#include "intmath.h"
#include "plg.h"
#include "segio.h"
#include "pointer.h"
#include "userint.h"
#include "splits.h"
#include "cursor.h"
#include "roomdefs.h"  //object defs - see for object information


extern int redraw, review, reframe, running, do_horizon;
extern OBJLIST *objlist;
extern int stereo_type;
extern int fancy_background, reflection_pool, show_logo, do_screen_clear;
extern VIEW default_view, orig_view, *current_view, *current_home_view;
extern VIEW real_view;
extern STEREO default_stereo;
extern SPLIT *split_tree;
extern unsigned lastkey;
extern unsigned paint;
extern int show_location, show_compass, show_framerate;


/*****************************************************************/

/*
    This room has been created as an example of how to add your own rooms.

    This first function will display the room and hide all the other objects
    outside of the room.
*/

void show_eastroom(void)
{

  current_view->ex+=1000;   // Get you away from the icon

  remove_from_objlist(hall);       //hide stuff outside
  remove_from_objlist(mainroom);
  remove_from_objlist(obj_back);

/*  Position all the objects */

  abs_rot_segment ( eastrms , 0, 90*65536L, 0, RXYZ );
  abs_move_segment (eastrms , 19300,300,0);
  abs_rot_segment ( eyes , 0, 45*65536L, 0, RXYZ );
  abs_move_segment (eyes , 21200,1000,1900);
  abs_rot_segment ( eye2s , 0, 135*65536L, 0, RXYZ );
  abs_move_segment (eye2s , 21200,1000,-1900);
  abs_rot_segment ( eastrm_columns , 0, 0, 0, RXYZ );
  abs_move_segment (eastrm_columns , 19500,300,0);
  abs_rot_segment ( logos , 0, 90*65536L, 0, RXYZ );
  abs_move_segment (logos , 19500,1000,0);

  update_segment ( eastrm_columns  );
  update_segment ( logos  );
  update_segment ( eastrms  );
  update_segment ( eyes  );
  update_segment ( eye2s  );

  refresh_display();

}

/*
    This function is executed when you leave the room by hitting the icon
    in front of the door.  It will hide the room and show the outside hall
    and mainroom.
*/

void leave_eastroom(void)
{

  eastroom=0;
  current_view->ex-=1000;       //Get you away from the icon
  remove_from_objlist(eastrm);  //Hide room and objects
  remove_from_objlist(eye);
  remove_from_objlist(eye2);
  remove_from_objlist(eastrm_column);
  remove_from_objlist(logo);
  abs_move_segment ( halls, 10000 , 0 , 0 );
  abs_move_segment (obj_backs, 3800, 1000, 0);
  abs_move_segment (mainrooms , 0, 0, 0);
  update_segment(halls);
  update_segment(mainrooms);
  update_segment(obj_backs);
  refresh_display();
}

/*******  Put everything that needs to go in a room in these functions *******/

int eye_x=1,eye_y=1;   //flags to rotate the eyes 45 degrees and back

void test_eastroom(void)
{

    if(eye_x==45)eye_y*=-1;
    if(eye_x==-45)eye_y*=-1;
    rel_rot_segment(eyes,0,eye_y*65536L,0,RXYZ);       //rot the eyes
    rel_rot_segment(eye2s,0,-eye_y*65536L,0,RXYZ);
    eye_x+=eye_y;
    rel_rot_segment(logos, 0, 2*65536L, 0, RYXZ);     //rot the logo

    update_segment(logos);
    update_segment(eyes);
    update_segment(eye2s);
    redraw=1;

}
