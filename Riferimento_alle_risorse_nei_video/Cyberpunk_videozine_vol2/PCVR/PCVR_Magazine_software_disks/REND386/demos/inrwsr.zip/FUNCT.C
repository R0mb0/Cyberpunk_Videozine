#include <stdio.h>
#include <dos.h>
#include <string.h>
#include <math.h>

#include "3dstruct.h"
#include "config.h"
#include "rend386.h"
#include "intmath.h"
#include "plg.h"
#include "segio.h"
#include "pointer.h"
#include "userint.h"
#include "splits.h"
#include "cursor.h"
#include "roomdefs.h"  // This header contains all the OBJECT and SEGMENT
                       // Defs for the objects being loaded in


extern int redraw, review, reframe, running, do_horizon;
extern OBJLIST *objlist;
extern int stereo_type;
extern int fancy_background, reflection_pool, show_logo, do_screen_clear;
extern VIEW default_view, orig_view, *current_view, *current_home_view;
extern VIEW real_view;
extern STEREO default_stereo;
extern SPLIT *split_tree;
extern unsigned lastkey;
extern unsigned paint;
extern int show_location, show_compass, show_framerate;



/******************* FVT World Setup ******************/

/*
    This function loads in all objects and sets them up.  To add your own
    just copy a block and change the OBJECT and SEGMENT names to the ones
    that you define in the roomdefs.h header and rend386.c  This function is
    called when the program first executes.
*/

void setup_world(void)
{

  FILE *in;

  set_loadplg_offset ( 0,0,0 );
  set_loadplg_scale ( 15,25,25 );


  if ((in = fopen ( "hall.plg", "r" )) == NULL )
    {
      fprintf ( stderr, "Unable to open hall file.\n" );
      exit(1);
    }

  hall = load_plg ( in );
  if ( load_err != 0 )
    {
      fprintf ( stderr, "Error loading hall.plg file.\n" );
      exit(1);
    }
  strcpy(hall->obj_name,"HALLWAY\0");
  strcpy(hall->obj_filename,"hall.plg\0");
  fclose ( in );


  set_loadplg_scale ( 15,15,15 );

  if ((in = fopen ( "mainroom.plg", "r" )) == NULL )
    {
      fprintf ( stderr, "Unable to open mainroom file.\n" );
      exit(1);
    }

  mainroom = load_plg ( in );
  if ( load_err != 0 )
    {
      fprintf ( stderr, "Error loading mainroom file.\n" );
      exit(1);
    }
  strcpy(mainroom->obj_name,"MAINROOM\0");
  strcpy(mainroom->obj_filename,"mainroom.plg\0");
  fclose ( in );

  set_loadplg_scale ( .6,.6,.6 );


  if ((in = fopen ( "eye.plg", "r" )) == NULL )
    {
      fprintf ( stderr, "Unable to open eye file.\n" );
      exit(1);
    }

  eye = load_plg ( in );
  if ( load_err != 0 )
    {
      fprintf ( stderr, "Error loading eye file.\n" );
      exit(1);
    }
  strcpy(eye->obj_name,"EYE\0");
  strcpy(eye->obj_filename,"eye.plg\0");
  fclose ( in );

    if ((in = fopen ( "eye.plg", "r" )) == NULL )
    {
      fprintf ( stderr, "Unable to open eye file.\n" );
      exit(1);
    }

  eye2 = load_plg ( in );
  if ( load_err != 0 )
    {
      fprintf ( stderr, "Error loading eye file.\n" );
      exit(1);
    }
  strcpy(eye2->obj_name,"EYE\0");
  strcpy(eye2->obj_filename,"eye.plg\0");
  fclose ( in );


  set_loadplg_scale ( 30,25,30 );


  if ((in = fopen ( "eastrm.plg", "r" )) == NULL )
    {
      fprintf ( stderr, "Unable to open eastrm file.\n" );
      exit(1);
    }

  eastrm = load_plg ( in );
  if ( load_err != 0 )
    {
      fprintf ( stderr, "Error loading eastrm file.\n" );
      exit(1);
    }
  strcpy(eastrm->obj_name,"EASTROOM\0");
  strcpy(eastrm->obj_filename,"eastrm.plg\0");
  fclose ( in );

  if ((in = fopen ( "column.plg", "r" )) == NULL )
    {
      fprintf ( stderr, "Unable to open column file.\n" );
      exit(1);
    }

  eastrm_column = load_plg ( in );
  if ( load_err != 0 )
    {
      fprintf ( stderr, "Error loading column file.\n" );
      exit(1);
    }
  strcpy(eastrm_column->obj_name,"PEDESTAL\0");
  strcpy(eastrm_column->obj_filename,"column.plg\0");
  fclose ( in );


  set_loadplg_scale ( .7,.7,.7 );

  if ((in = fopen ( "east.plg", "r" )) == NULL )
    {
      fprintf ( stderr, "Unable to open east file.\n" );
      exit(1);
    }

  obj_east = load_plg ( in );
  if ( load_err != 0 )
    {
      fprintf ( stderr, "Error loading east file.\n" );
      exit(1);
    }
  strcpy(obj_east->obj_name,"EAST\0");
  strcpy(obj_east->obj_filename,"east.plg\0");
  fclose ( in );


  if ((in = fopen ( "west.plg", "r" )) == NULL )
    {
      fprintf ( stderr, "Unable to open west file.\n" );
      exit(1);
    }

  obj_west = load_plg ( in );
  if ( load_err != 0 )
    {
      fprintf ( stderr, "Error loading west file.\n" );
      exit(1);
    }
  strcpy(obj_west->obj_name,"WEST\0");
  strcpy(obj_west->obj_filename,"west.plg\0");
  fclose ( in );

  if ((in = fopen ( "south.plg", "r" )) == NULL )
    {
      fprintf ( stderr, "Unable to open south file.\n" );
      exit(1);
    }

  obj_south = load_plg ( in );
  if ( load_err != 0 )
    {
      fprintf ( stderr, "Error loading south file.\n" );
      exit(1);
    }
  strcpy(obj_south->obj_name,"SOUTH\0");
  strcpy(obj_south->obj_filename,"south.plg\0");
  fclose ( in );


  if ((in = fopen ( "north.plg", "r" )) == NULL )
    {
      fprintf ( stderr, "Unable to open north file.\n" );
      exit(1);
    }

  obj_north = load_plg ( in );
  if ( load_err != 0 )
    {
      fprintf ( stderr, "Error loading north file.\n" );
      exit(1);
    }
  strcpy(obj_north->obj_name,"NORTH\0");
  strcpy(obj_north->obj_filename,"north.plg\0");
  fclose ( in );


  if ((in = fopen ( "back.plg", "r" )) == NULL )
    {
      fprintf ( stderr, "Unable to open back file.\n" );
      exit(1);
    }

  obj_back = load_plg ( in );
  if ( load_err != 0 )
    {
      fprintf ( stderr, "Error loading back file.\n" );
      exit(1);
    }
  strcpy(obj_back->obj_name,"BACK\0");
  strcpy(obj_back->obj_filename,"back.plg\0");
  fclose ( in );

  set_loadplg_scale ( .2,.2,.2 );

  if ((in = fopen ( "2mr.plg", "r" )) == NULL )
    {
      fprintf ( stderr, "Unable to open 2mr file.\n" );
      exit(1);
    }

  logo = load_plg ( in );
  if ( load_err != 0 )
    {
      fprintf ( stderr, "Error loading 2mr file.\n" );
      exit(1);
    }
  strcpy(logo->obj_name,"2Morrow, Inc\0");
  strcpy(logo->obj_filename,"2mr.plg\0");
  fclose ( in );


  add_obj_to_split ( &split_tree, hall );
  halls = new_seg ( NULL );
  seg_set_object ( halls, hall );
  set_object_owner ( hall, halls );
  update_segment ( halls );
  remove_from_objlist ( hall );

  add_obj_to_split ( &split_tree, mainroom );
  mainrooms = new_seg ( NULL );
  seg_set_object ( mainrooms, mainroom );
  set_object_owner ( mainroom, mainrooms );
  update_segment ( mainrooms );
  remove_from_objlist ( mainroom );

  add_obj_to_split ( &split_tree, obj_north );
  obj_norths = new_seg ( NULL );
  seg_set_object ( obj_norths, obj_north );
  set_object_owner ( obj_north, obj_norths );
  update_segment ( obj_norths );
  remove_from_objlist ( obj_north );

  add_obj_to_split ( &split_tree, obj_south );
  obj_souths = new_seg ( NULL );
  seg_set_object ( obj_souths, obj_south );
  set_object_owner ( obj_south, obj_souths );
  update_segment ( obj_souths );
  remove_from_objlist ( obj_south );

  add_obj_to_split ( &split_tree, obj_east );
  obj_easts = new_seg ( NULL );
  seg_set_object ( obj_easts, obj_east );
  set_object_owner ( obj_east, obj_easts );
  update_segment ( obj_easts );
  remove_from_objlist ( obj_east );

  add_obj_to_split ( &split_tree, obj_west );
  obj_wests  = new_seg ( NULL );
  seg_set_object ( obj_wests , obj_west );
  set_object_owner ( obj_west, obj_wests  );
  update_segment ( obj_wests  );
  remove_from_objlist ( obj_west );

  add_obj_to_split ( &split_tree, obj_back );
  obj_backs  = new_seg ( NULL );
  seg_set_object ( obj_backs , obj_back );
  set_object_owner ( obj_back, obj_backs  );
  update_segment ( obj_backs  );
  remove_from_objlist ( obj_back );

  add_obj_to_split ( &split_tree, eastrm );
  eastrms  = new_seg ( NULL );
  seg_set_object ( eastrms , eastrm );
  set_object_owner ( eastrm, eastrms  );
  update_segment( eastrms);
  remove_from_objlist ( eastrm );

  add_obj_to_split ( &split_tree, eye );
  eyes  = new_seg ( NULL );
  seg_set_object ( eyes , eye );
  set_object_owner ( eye, eyes  );
  update_segment ( eyes  );
  remove_from_objlist ( eye );

  add_obj_to_split ( &split_tree, eye2 );
  eye2s  = new_seg ( NULL );
  seg_set_object ( eye2s , eye2 );
  set_object_owner ( eye2, eye2s  );
  update_segment ( eye2s  );
  remove_from_objlist ( eye2 );

  add_obj_to_split ( &split_tree, eastrm_column );
  eastrm_columns  = new_seg ( NULL );
  seg_set_object ( eastrm_columns , eastrm_column );
  set_object_owner ( eastrm_column, eastrm_columns  );
  update_segment ( eastrm_columns  );
  remove_from_objlist ( eastrm_column );

  add_obj_to_split ( &split_tree, logo );
  logos  = new_seg ( NULL );
  seg_set_object ( logos , logo );
  set_object_owner ( logo, logos  );
  update_segment ( logos  );
  remove_from_objlist ( logo );



}



/*
    This function shows the main room with all the icons in the doorways
*/


void show_room( void )
{

  abs_move_segment ( mainrooms, 0, 0, 0 );
  update_segment ( mainrooms );

  abs_move_segment ( obj_norths, 0, 1000, 4000 );
  update_segment ( obj_norths );

  abs_move_segment ( obj_souths, 0, 1000, -4000 );
  update_segment ( obj_souths );

  abs_rot_segment ( obj_easts, 0 , 90*65536L , 0, RXYZ );
  abs_move_segment ( obj_easts, 4000, 1000, 0 );
  update_segment ( obj_easts );


  abs_rot_segment ( obj_wests, 0 , 90*65536L , 0, RXYZ );
  abs_move_segment ( obj_wests , -4000, 1000, 0 );
  update_segment ( obj_wests  );


  abs_move_segment ( halls, 0, 0, 10000 );
  update_segment ( halls );

  remove_from_objlist ( hall );

  refresh_display();

}

/*
    This function will display the hall in the correct position.  The
    placement is determined by the parm passed to the function.  Right
    now it supports E W N S.
*/


void show_hall( char location )
{

  remove_from_objlist ( hall );
  east=west=north=south=0;

  if(location == 'E'){
    east=1;
    abs_rot_segment ( halls, 0 , 90*65536L , 0, RXYZ );
    abs_move_segment ( halls, 10000 , 0 , 0 );
    abs_move_segment ( obj_easts, 17000, 1000, 0);
    abs_rot_segment(obj_backs,0,90*65536L,0, RXYZ);
    abs_move_segment (obj_backs, 3800, 1000, 0);
    update_segment(obj_backs);
    update_segment(obj_easts);
    update_segment ( halls );
    current_view->ex+=600;
  }
  else if (location == 'N'){
    north=1;
    abs_rot_segment ( halls,  0 , 0 , 0, RXYZ );
    abs_move_segment ( halls, 0 , 0 , 10000 );
    abs_move_segment ( obj_norths, 0, 1000, 17000);
    abs_move_segment (obj_backs, 0, 1000, 3800);
    abs_rot_segment(obj_backs,0,0,0, RXYZ);
    update_segment(obj_backs);
    update_segment(obj_norths);
    update_segment ( halls );
    current_view->ez+=500;
  }
  else if (location == 'W'){
    west=1;
    abs_rot_segment ( halls, 0 , -90*65536L , 0, RXYZ );
    abs_move_segment ( halls, -10000 , 0 , 0 );
    abs_move_segment ( obj_wests, -17000, 1000, 0);
    abs_rot_segment(obj_backs,0,90*65536L,0, RXYZ);
    abs_move_segment (obj_backs, -3800, 1000, 0);
    update_segment(obj_backs);
    update_segment(obj_wests);
    update_segment ( halls );
    current_view->ex-=500;
  }
  else if (location == 'S'){
    south=1;
    abs_rot_segment ( halls, 0 , 180*65536L , 0, RXYZ );
    abs_move_segment ( halls, 0 , 0 , -10000 );
    abs_move_segment ( obj_souths, 0, 1000, -17000);
    abs_move_segment (obj_backs, 0, 1000, -3800);
    abs_rot_segment(obj_backs,0,0,0, RXYZ);
    update_segment(obj_backs);
    update_segment(obj_souths);
    update_segment ( halls );
    current_view->ez-=500;
  }
  refresh_display();
}

/*
    This function will reset the world back to its original state after
    returning from a hall.  It will also jump you ahead a little to get
    you away from the icon to keep you from bouncing back into the hall
    after returning.
*/

void reset_world(void)
{

  abs_move_segment ( obj_norths, 0, 1000, 4000 );
  update_segment ( obj_norths );

  abs_move_segment ( obj_souths, 0, 1000, -4000 );
  update_segment ( obj_souths );

  abs_rot_segment ( obj_easts, 0 , 90*65536L , 0, RXYZ );
  abs_move_segment ( obj_easts, 4000, 1000, 0 );
  update_segment ( obj_easts );


  abs_rot_segment ( obj_wests, 0 , 90*65536L , 0, RXYZ );
  abs_move_segment ( obj_wests , -4000, 1000, 0 );
  update_segment ( obj_wests  );

  if(east){                         //Get you away from the Icon
    current_view->ex-=500;
  }else if(west) {
    current_view->ex+=500;
  }else if(north){
    current_view->ez-=500;
  }else if(south){
    current_view->ez+=500;
  }

  east=west=south=north=0;

  remove_from_objlist ( hall );
  remove_from_objlist ( obj_back );

  refresh_display();

}

/*
    This function is the 'transporter' function - It will make the
    transition from mainroom to hall to room and all the way back.
    This function is very important to keep you moving around the app
    It also executes the appropriate functions to display the needed
    objects.
*/

void test_object(void)
{

  /* Shows hall if icon hit from mainroom */

     if(!east && !west && !south && !north){
         if(check_list(obj_east)){show_hall('E');}
         else if(check_list(obj_west)){show_hall('W');}
         else if(check_list(obj_north)){show_hall('N');}
         else if(check_list(obj_south)){show_hall('S');}
      }
      else{
         if(check_list(obj_back)){reset_world();}  //Check to see if return
      }                                            //Icon was hit to bring
                                                   //Bring you back to the
                                                   //Main room


   /*  Enters room if icon hit at end of hall */

      if(east && !eastroom){
        if(check_list(obj_east)){
          eastroom=1;
          popmsg("EAST WING");
          show_eastroom();
          }
      }
      else if(west && !westroom){
        if(check_list(obj_west)){
          westroom=1;
          popmsg("WEST WING");
          delay(2500);
          show_westroom();
          }
      }
      else if(north && !northroom){
        if(check_list(obj_north)){
          northroom=1;
          popmsg("NORTH WING");
          delay(2500);
          show_northroom();
          }
      }
      else if(south && !southroom){
        if(check_list(obj_south)){
          southroom=1;
          popmsg("SOUTH WING");
          delay(2500);
          show_southroom();
          }
      }

  /* Leave rooms if Icon is hit */

      if(eastroom){
        if(check_list(obj_east)){leave_eastroom();}
      } else if(westroom){
        if(check_list(obj_west)){leave_westroom();}
      } else if(southroom){
        if(check_list(obj_south)){leave_southroom();}
      } else if(northroom){
        if(check_list(obj_north)){leave_northroom();}
      }
}
