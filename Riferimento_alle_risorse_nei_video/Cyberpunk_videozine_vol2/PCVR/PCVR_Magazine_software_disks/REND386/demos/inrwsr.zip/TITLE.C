#include <stdio.h>
#include <dos.h>     /* delay() */
#include <conio.h>

static char *title[] = {
	"",
        "                                 INTERWORLD",
	"",
	"                                 Version 1.0",
	"",
	"             This is a STONE SOUP type project.  I have created",
	"            a shell that can be easily added too.  You basically",
        "           just need to add in your rooms to the already provided",
	"             functions.  Check out the EAST WING for an example.",
	"              Also see the read.me file from programming info.",
	"",
	"            This program is free for non-commercial, non-profit,",
	"             non-promotional use.  Any other use requires prior",
	"                   written permission from the author",
	"",
	"                 Note: a 386 or 486 PC and VGA card are",
	"                     required to run this software.",
	"",
        "                BY:  Todd Porter of 2Morrow, Incorporated",
	"                         Version date: 7/19/94",
	"",
	"Loading files...",
	NULL
	};

void title_screen()
{
	int i;
	textattr((GREEN<<4)+WHITE);
	directvideo = 0;
	clrscr();

	for (i = 0; title[i]; ++i) {
		cputs(title[i]);
		cputs("\r\n");
		}
	directvideo = 1;
}

void wait_for_title()
{
	int i;
	cputs("\n\r Ready- Press a key to start.\n\r");
	for (i = 0; i < 100; i++)
	{
		delay(200);
		if (kbhit()) break;
	}
	if (kbhit()) getch();
}
