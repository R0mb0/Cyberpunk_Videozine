#include <stdio.h>
#include <dos.h>
#include <string.h>
#include <math.h>

#include "3dstruct.h"
#include "config.h"
#include "rend386.h"
#include "intmath.h"
#include "plg.h"
#include "segio.h"
#include "pointer.h"
#include "userint.h"
#include "splits.h"
#include "cursor.h"
#include "roomdefs.h"


extern int redraw, review, reframe, running, do_horizon;
extern OBJLIST *objlist;
extern int stereo_type;
extern int fancy_background, reflection_pool, show_logo, do_screen_clear;
extern VIEW default_view, orig_view, *current_view, *current_home_view;
extern VIEW real_view;
extern STEREO default_stereo;
extern SPLIT *split_tree;
extern unsigned lastkey;
extern unsigned paint;
extern int show_location, show_compass, show_framerate;


/****************************************************************/

/*
    The next functions are where all the westroom action will take place -
    Use the eastroom stuff for an example of what to do in it.
*/

/*  Shows the southroom  */

void show_southroom(void)
{

  current_view->ez-=1000;
  remove_from_objlist(hall);
  remove_from_objlist(mainroom);
  remove_from_objlist(obj_back);
  refresh_display();

}


/* Exits the southroom */


void leave_southroom(void)
{

  southroom=0;
  current_view->ez+=1000;
  abs_move_segment ( halls, 0 , 0 , -10000 );
  abs_move_segment (obj_backs, 0, 1000, -3800);
  abs_move_segment (mainrooms , 0, 0, 0);
  update_segment(halls);
  update_segment(mainrooms);
  update_segment(obj_backs);
  refresh_display();
}

/*  Things to do while in the room  */

void test_southroom(void)
{
}

