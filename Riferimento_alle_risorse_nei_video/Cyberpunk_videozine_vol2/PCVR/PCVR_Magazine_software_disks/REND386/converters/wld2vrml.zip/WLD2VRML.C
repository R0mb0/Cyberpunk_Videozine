/* Convert a WLD file (and PLG files) to a VRML file */

/* Version 1.0 */

/* Written by Bernie Roehl, August 1995 */

/* Uses the AVRIL library for parsing WLD, PLG and FIG files */

/* Usage is

              WLD2VRML [-b] infile.wld

   The WLD file is parsed, and all the PLG and FIG files are loaded;
   a VRML file is then written to standard output, which should be
   redirected.

   The optional -b flag causes a BackgroundColor node to be written
   out, using the skycolor from the WLD file.

   Things to do:

      * compute camera zoom (hard to test, since all of the
           browsers I have access to completely ignore cameras!)

      * test points and lines (none of the browsers I have access to
           support PointSet and IndexedLineSet!)

   To compile under Watcom C:

     wcc386 wld2vrml.c
     wlink option stack=16000 system dos4g file wld2vrml.obj library avrilw.lib

   To compile under Watcom C:

     bcc -ml wld2vrml.c avrilb.lib

   If you make changes to this code, I'd appreciate it if you would
   let me know so I can make them available to others.
   You can reach me by email: <broehl@sunee.uwaterloo.ca>.

 */

#include "avril.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

static float scale = 1.0;

static float ambient = 72.0/128.0;

static float degrees2radians = (3.14159262/180.0);

/* Convert a hue to an RGB color */

static void dump_color(int hue)
	{
	vrl_Palette *palette = vrl_WorldGetPalette();
	vrl_Hue *huemap = vrl_PaletteGetHuemap(palette);
	vrl_Color color;
	int r, g, b;
	hue = huemap[hue].start + huemap[hue].maxshade/2;
	color = vrl_PaletteGetEntry(palette, hue);
	r = (color >> 16) & 0x3F;  g = (color >> 8) & 0x3F;  b = color & 0x3F;
	printf("%f %f %f", r / 64.0, g / 64.0, b /64.0);
	}

/* Dump the points from a rep as a PointSet (untested!) */

static int dump_points(vrl_Rep *rep, vrl_Surfacemap *map)
	{
	vrl_Facet *facet;
	for (facet = rep->facets; facet; facet = facet->farside)
		if (vrl_FacetCountPoints(facet) == 1)
			break;
	if (facet == NULL) return -1;  /* no points */
	printf("\tSeparator {\n");
	printf("\t\tMaterialBinding { value OVERALL }\n");
	for (facet = rep->facets; facet; facet = facet->farside)
		if (vrl_FacetCountPoints(facet) == 1)
			{
			vrl_Surface *surf = vrl_SurfacemapGetSurface(map, vrl_FacetGetSurfnum(facet));
			printf("\t\tMaterial {\n");
			printf("\t\t\temissiveColor [ 0.2 0.2 0.2 ]\n");
			printf("\t\t\tambientColor [ %f %f %f ]\n", ambient, ambient, ambient);
			printf("\t\t\tdiffuseColor [ ");
			dump_color(vrl_SurfaceGetHue(surf));
			printf(" ]\n\t\t}\n");
			printf("\t\tPointSet { startIndex %d numpoints 1 }\n", vrl_FacetGetPoint(facet, 0), vrl_FacetGetPoint(facet, 0));
			}
	printf("\t}\n");
	return 0;
	}

/* Dump the lines from a rep as an IndexedLineSet (untested!) */

static int dump_lines(vrl_Rep *rep)
	{
	vrl_Facet *facet;
	for (facet = rep->facets; facet; facet = facet->farside)
		if (vrl_FacetCountPoints(facet) == 2)
			break;
	if (facet == NULL) return -1;  /* no polys */
	printf("\tIndexedLineSet {\n\t\tcoordIndex [\n\t\t\t");
	for (facet = rep->facets; facet; facet = facet->farside)
		if (vrl_FacetCountPoints(facet) == 2)
			printf("%d, %d, -1\n\t\t\t", vrl_FacetGetPoint(facet, 0), vrl_FacetGetPoint(facet, 1));
	printf("]\n");
	printf("\t\tmaterialIndex [\n");
	for (facet = rep->facets; facet; facet = facet->farside)
		if (vrl_FacetCountPoints(facet) == 2)
			printf("\t\t\t%d,\n", vrl_FacetGetSurfnum(facet));
	printf("\t\t\t-1\n\t\t]\n\t}\n");
	return 0;
	}

/* Dump the polys from a rep as an IndexedFaceSet */

static int dump_polys(vrl_Rep *rep)
	{
	vrl_Facet *facet;
	for (facet = rep->facets; facet; facet = facet->farside)
		if (vrl_FacetCountPoints(facet) > 2)
			break;
	if (facet == NULL) return -1;  /* no polys */
	printf("\tIndexedFaceSet {\n\t\tcoordIndex [\n\t\t\t");
	for (facet = rep->facets; facet; facet = facet->farside)
		if (vrl_FacetCountPoints(facet) > 2)
			{
			int n = vrl_FacetCountPoints(facet), i;
			for (i = 0; i < n; ++i)
				printf("%d, ", vrl_FacetGetPoint(facet, i));
			printf("-1, \n\t\t\t");
			}
	printf("]\n");
	printf("\t\tmaterialIndex [\n");
	for (facet = rep->facets; facet; facet = facet->farside)
		if (vrl_FacetCountPoints(facet) > 2)
			printf("\t\t\t%d,\n", vrl_FacetGetSurfnum(facet));
	printf("\t\t]\n\t}\n");
	return 0;
	}

/* Dump a single representation of an object */

static void dump_rep(vrl_Rep *rep, vrl_Surfacemap *map)
	{
	int nvertices = vrl_RepCountVertices(rep), i;
	printf("\tCoordinate3 { point [\n");
	for (i = 0; i < nvertices; ++i)
		{
		vrl_Vector v;
		vrl_RepGetVertex(rep, i, v);
		printf("\t\t%f %f %f,\n",
			scalar2float(v[X]) * scale,
			scalar2float(v[Y]) * scale,
			scalar2float(v[Z]) * -scale);
		}
	printf("\t\t]\n\t}\n");
	dump_points(rep, map);
	dump_lines(rep);
	dump_polys(rep);
	}

/* Dump a surface map as a Material node */

static void dump_surfmap(vrl_Object *obj)
	{
	int n, i;
	vrl_Surfacemap *map = vrl_ObjectGetSurfacemap(obj);
	if (map == NULL) map = vrl_ShapeGetSurfacemap(vrl_ObjectGetShape(obj));
	if (map == NULL) return;
	n = vrl_SurfacemapCountEntries(map);
	if (n == 0) return;
	printf("\tMaterial {\n");
	printf("\t\temissiveColor [ 0.2 0.2 0.2 ]\n");
	printf("\t\tambientColor [ %f %f %f ]\n", ambient, ambient, ambient);
	printf("\t\tdiffuseColor [\n");
	for (i = 0; i < n; ++i)
		{
		vrl_Surface *surf = vrl_SurfacemapGetSurface(map, i);
		if (surf == NULL)
			printf("\t\t\t0.0 0.0 0.0,\n");
		else
			{
			printf("\t\t\t");
			dump_color(vrl_SurfaceGetHue(surf));
			printf(",\n");
			}
		}
	printf("\t\t\t]\n");
	printf("\t\tshininess [\n");
	for (i = 0; i < n; ++i)
		{
		vrl_Surface *surf = vrl_SurfacemapGetSurface(map, i);
		if (surf == NULL)
			printf("\t\t\t0.0,\n");
		else if (vrl_SurfaceGetType(surf) == VRL_SURF_METAL || vrl_SurfaceGetType(surf) == VRL_SURF_GLASS)
			printf("\t\t\t0.5,\n");
		else
			printf("\t\t\t0.0,\n");
		}
	printf("\t\t\t]\n");
	printf("\t\ttransparency [\n");
	for (i = 0; i < n; ++i)
		{
		vrl_Surface *surf = vrl_SurfacemapGetSurface(map, i);
		if (surf == NULL)
			printf("\t\t\t0.0,\n");
		else if (vrl_SurfaceGetType(surf) == VRL_SURF_GLASS)
			printf("\t\t\t0.5,\n");
		else
			printf("\t\t\t0.0,\n");
		}
	printf("\t\t\t]\n");
	printf("\t}\n");
	}
	
/* Dump the geometry for an object; handles transformation, LOD */

static void dump_geometry(vrl_Object *object)
	{
	vrl_Shape *shape = vrl_ObjectGetShape(object);
	vrl_Rep *rep = NULL;
	float radius = scalar2float(vrl_ShapeGetRadius(shape)) * scale;
	vrl_Angle rx, ry, rz;
	vrl_Vector v;
	vrl_ObjectGetRelativeLocation(object, v);
	if (v[X] != 0 || v[Y] != 0 || v[Z] != 0)
		printf("\tTranslation { translation %f %f %f }\n",
			scalar2float(v[X]) * scale,
			scalar2float(v[Y]) * scale,
			scalar2float(v[Z]) * -scale);
	vrl_ObjectGetRelativeRotations(object, &rx, &ry, &rz);
	if (rz) printf("\tRotation { rotation 0 0 1 %f }\n", angle2float(rz) * degrees2radians);
	if (rx) printf("\tRotation { rotation 1 0 0 %f }\n", -angle2float(rx) * degrees2radians);
	if (ry) printf("\tRotation { rotation 0 1 0 %f }\n", -angle2float(ry) * degrees2radians);
	if (shape == NULL) return;
	rep = vrl_ShapeGetFirstRep(shape);
	if (rep == NULL) return;
	dump_surfmap(object);
	if (vrl_RepGetNext(rep))  /* multiple levels of detail */
		{
		vrl_Rep *r;
		printf("\tLOD {\n\t\trange [ ");
		for (r = rep; r; r = vrl_RepGetNext(r))
			printf("%f, ", radius * 160 / scalar2float(vrl_RepGetSize(r)));
		printf("]\n");
		while (rep)
			{
			printf("Separator {\n");
			dump_rep(rep, vrl_ObjectGetSurfacemap(object));
			printf("}\n");
			rep = vrl_RepGetNext(rep);
			}
		printf("\t\t}\n");
		}
	else
		dump_rep(rep, vrl_ObjectGetSurfacemap(object));
	}	

/* Recursively dump a tree of objects */

static void dump_object(vrl_Object *object)
	{
	while (object)
		{
		if (object->children || object->shape)
			{
			char *name = vrl_ObjectGetName(object);
			if (name)
				if (stricmp(name, "No Name"))
					printf("DEF %s ", name);
			printf("Separator {\n");
			dump_geometry(object);
			dump_object(object->children);
			printf("}\n\n");
			}
		object = object->siblings;
		}
	}

/* Dump a light source */

static void dump_light(vrl_Light *light)
	{
	vrl_Factor intensity = vrl_LightGetIntensity(light);
	char *name = vrl_LightGetName(light);
	if (name)
		if (stricmp(name, "No Name"))
			printf("DEF %s ", name);
	switch (vrl_LightGetType(light))
		{
		case VRL_LIGHT_DIRECTIONAL:
			{
			vrl_Vector v;
			vrl_Object *obj = vrl_LightGetObject(light);
			vrl_ObjectGetForwardVector(obj, v);
			printf("DirectionalLight {\n");
			printf("\tdirection %f %f %f\n",
				factor2float(v[X]), factor2float(v[Y]), factor2float(v[Z]));
			}
			break;
		case VRL_LIGHT_POINTSOURCE:
			printf("PointLight {\n");
			printf("\tlocation %f %f %f\n",
				scalar2float(vrl_LightGetWorldX(light)) * scale,
				scalar2float(vrl_LightGetWorldY(light)) * scale,
				scalar2float(vrl_LightGetWorldZ(light)) * -scale);
			break;
		case VRL_LIGHT_AMBIENT:  /* ignore ambient lights */
		default: return;
		}
	if (!vrl_LightIsOn(light))
		printf("\ton { FALSE }\n");
	if (intensity != VRL_UNITY)
		printf("\tintensity %f\n", factor2float(intensity));
	printf("}\n\n");
	}

/* Dump a camera */

static void dump_camera(vrl_Camera *camera)
	{
	vrl_Object *obj = vrl_CameraGetObject(camera);
	vrl_Vector v;
	char *name = vrl_CameraGetName(camera);
	if (name)
		if (stricmp(name, "No Name"))
			printf("DEF camera_%s ", name);
	printf("PerspectiveCamera {\n");
	printf("\tposition %f %f %f\n",
		scalar2float(vrl_CameraGetWorldX(camera)) * scale,
		scalar2float(vrl_CameraGetWorldY(camera)) * scale,
		scalar2float(vrl_CameraGetWorldZ(camera)) * -scale);
	vrl_ObjectGetForwardVector(obj, v);
	printf("\torientation %f %f %f 0.0\n",
		factor2float(v[X]), factor2float(v[Y]), factor2float(v[Z]));
	/* still have to figure out focalDistance */
	printf("}\n\n");
	}

static int background_flag = 0;  /* if non-zero, emit a BackgroundColor node */

void main(int argc, char *argv[])
	{
	FILE *in;
	vrl_Light *light;
	vrl_Camera *camera, *first_camera;
	while (argc > 1)
		{
		if (*argv[1] != '-')
			break;
		switch (argv[1][1])
			{
			case 'b': background_flag = 1; break;
			default: fprintf(stderr, "unknown flag '%s' ignored\n", argv[1]); break;
			}
		--argc;  ++argv;
		}
	if (argc < 2)
		{
		fprintf(stderr, "Usage: WLD2VRML infile\n");
		exit(1);
		}
	in = fopen(argv[1], "r");
	if (in == NULL)
		{
		fprintf(stderr, "Could not open '%s'\n", argv[1]);
		exit(2);
		}
	vrl_MathInit();
	vrl_WorldInit(vrl_WorldGetCurrent());
	vrl_ReadWLD(in);
	vrl_WorldUpdate();
	scale = scalar2float(vrl_WorldGetScale()) / 1000;  /* meters per unit */
	ambient = factor2float(vrl_WorldGetAmbient());
	/* put out header and some useful defaults */
	printf("#VRML V1.0 ascii\n#\n# Converted from '%s' by WLD2VRML\n#\n\n", argv[1]);
	printf("Separator {\n\n");
	if (background_flag)
		{
		printf("\tBackgroundColor {\n\t\trgb ");
		dump_color(vrl_WorldGetSkyColor());
		printf("\n\t\t}\n\n");
		}
	printf("\tMaterialBinding { value PER_FACE_INDEXED }\n");
	printf("\tShapeHints { vertexOrdering CLOCKWISE }\n\n");
	/* put out the lights [but won't it be dark?  :-)] */
	printf("DirectionalLight { }\n\n");
	for (light = vrl_WorldGetLights(); light; light = vrl_LightGetNext(light))
		dump_light(light);
	/* put out the cameras [should put out the cat, too!] */
	first_camera = vrl_WorldFindCamera("1");
	if (first_camera)  /* first things first... */
		dump_camera(first_camera);
	for (camera = vrl_WorldGetCameras(); camera; camera = vrl_CameraGetNext(camera))
		if (camera != first_camera)
			dump_camera(camera);
	/* finally, put out the tree [Christmas was over months ago!] */
	dump_object(vrl_WorldGetObjectTree());
	/* th- th- th- that's all, folks! */
	printf("}\n\n");
	printf("# End of file\n");
	}
